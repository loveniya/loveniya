import { initializeApp } from 'firebase/app';
import { getDatabase, ref, set, onValue, remove } from 'firebase/database';

const firebaseConfig = {
  apiKey: "AIzaSyAGRjFE45VNGA5fiz6Ruqz_KLDdsgnTApc",
  authDomain: "amniya-love.firebaseapp.com",
  databaseURL: "https://niya.am-b-asdfghjkl20112011.workers.dev",
  projectId: "amniya-love",
  storageBucket: "amniya-love.firebasestorage.app",
  messagingSenderId: "512178131727",
  appId: "1:512178131727:web:e2089041537b7b2fbe247a",
  measurementId: "G-6NTJGRZJN6"
};

const app = initializeApp(firebaseConfig);
export const rtdb = getDatabase(app);
