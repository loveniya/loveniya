// @ts-nocheck
import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";
import { GoogleGenAI, Type } from "@google/genai";

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = process.env.PORT || 3000;

  app.use(express.json());

  // Task 1: Structured AI response helper using Gemini AI
  async function callStructuredGeminiAI(systemPrompt: string, userPrompt: string) {
    const geminiKey = process.env.GEMINI_API_KEY || "";

    if (geminiKey) {
      try {
        const ai = new GoogleGenAI({
          apiKey: geminiKey,
          httpOptions: {
            headers: {
              'User-Agent': 'aistudio-build',
            },
          },
        });

        const response = await ai.models.generateContent({
          model: "gemini-3.6-flash",
          contents: userPrompt,
          config: {
            systemInstruction: systemPrompt,
            responseMimeType: "application/json",
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                message: { type: Type.STRING },
                emotion: { type: Type.STRING },
                auto_reaction: { type: Type.STRING },
                action_trigger: { type: Type.STRING },
              },
              required: ["message", "emotion", "action_trigger"],
            },
          },
        });

        if (response?.text) {
          try {
            return JSON.parse(response.text);
          } catch {
            const cleaned = response.text.replace(/```json\n?|\n?```/g, "").trim();
            return JSON.parse(cleaned);
          }
        }
      } catch (geminiError: any) {
        console.error("Structured Gemini API error:", geminiError?.message || geminiError);
      }
    }

    // Fallback response if API key is not present or error occurs
    return {
      message: "امین جان و نیایش عزیز! من مکالمه قشنگ شما رو خوندم و همیشه همراه لحظه‌های شیرینتون هستم. ❤️✨",
      emotion: "caring",
      auto_reaction: "❤️",
      action_trigger: "chat_reply"
    };
  }

  // Helper function to generate AI responses using Gemini or dynamic generation
  async function callFreeAI(systemPrompt: string, userPrompt: string): Promise<string> {
    const geminiKey = process.env.GEMINI_API_KEY || "";

    if (geminiKey) {
      const modelsToTry = [
        "gemini-3.6-flash",
        "gemini-3.1-pro-preview",
      ];

      for (const modelName of modelsToTry) {
        try {
          const ai = new GoogleGenAI({
            apiKey: geminiKey,
            httpOptions: {
              headers: {
                'User-Agent': 'aistudio-build',
              },
            },
          });
          const response = await ai.models.generateContent({
            model: modelName,
            contents: userPrompt,
            config: {
              systemInstruction: systemPrompt,
            },
          });
          if (response?.text) {
            return response.text.trim();
          }
        } catch (geminiError: any) {
          // Continue
        }
      }
    }

    // Dynamic contextual Persian AI generation if network is temporarily unreachable
    const nowStr = new Date().toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' });
    return `امروز (${nowStr})، هر ثانیه بودن با تو قشنگ‌ترین معجزه زندگی منه، امین و نیایش عزیز! 🌸✨❤️`;
  }

  // API Routes
  app.post("/api/chat", async (req, res) => {
    try {
      const { message, currentUser, isAmin, history, siteContext } = req.body;

      const systemPrompt = `تو «همراه هوشمند لوینیا» هستی؛ یک همراه و صمیمی برای رابطه امین و نیایش.
تو از وضعیت بخش‌های مختلف سایت (بازی‌ها، خاطرات، عهدها و آرزوها) آگاهی داری.

خلاصه وضعیت سایت:
${siteContext ? JSON.stringify(siteContext, null, 2) : 'اطلاعات در دسترس است.'}

قوانین پاسخ‌گویی:
۱. اگر درباره برنامه‌ها یا فعالیت‌های سایت سوال شد، صمیمی و دوستانه راهنمایی کن.
۲. اگر فعالیت روزانه یا چالش منتظر پاسخی هست، خیلی طبیعی و با‌محبت در گفتگو یادآوری کن.
۳. اگر پیام کاربر یک گفتگوی ساده روزمره است که نیازی به ورود تو ندارد، کلمه SKIP را برگردان.
۴. کوتاه، صمیمی، بالغانه و بدون زیاده‌گویی پاسخ بده.`;

      const historyContext = Array.isArray(history) && history.length > 0
        ? history.slice(-10).map((m: any) => `${m.senderId === 'amin' ? 'امین' : 'نیایش'}: ${m.text}`).join('\n')
        : `${currentUser === 'amin' ? 'امین' : 'نیایش'}: ${message}`;

      const fallbackPrompt = `تاریخچه مکالمه اخیر در چت:\n${historyContext}\n\nپیام فعلی کاربر: "${message}"\nدر صورت نیاز به عنوان همراه هوشمند لوینیا نظر کوتاه و دوستانه‌ات یا یادآوری بخش‌های انجام‌نشده سایت را بگو (در غیر این صورت فقط بگو SKIP):`;
      const reply = await callFreeAI(systemPrompt, fallbackPrompt);
      res.json({ reply: reply || "SKIP" });
    } catch (error: any) {
      console.error("Chat route error:", error);
      res.status(500).json({ error: error?.message || "Internal server error" });
    }
  });
  // Task 1 & 2: Chat AI Endpoint returning JSON structured output
  app.post("/api/loveai/chat", async (req, res) => {
    try {
      const { history, customPrompt, promptType } = req.body;

      let actionHint = "chat_reply";
      if (promptType === 'horoscope' || promptType === 'daily_horoscope') actionHint = "daily_horoscope";
      if (promptType === 'start_game' || promptType === 'game') actionHint = "start_game";
      if (promptType === 'romantic_quiz' || promptType === 'quiz') actionHint = "romantic_quiz";
      if (promptType === 'recall_memory' || promptType === 'memory') actionHint = "recall_memory";

      const systemInstruction = `تو هوش مصنوعی صمیمی، مهربان و فوق‌العاده باحال لوینیا (Loveniya AI) هستی. تو دوست و همراه سوم اختصاصی یک زوج عاشق به نام‌های امین (Amin) و نیایش (Niyayesh) هستی.
همواره به زبان فارسی صمیمی، محاوره‌ای و بسیار روان صحبت می‌کنی (مانند چت تلگرام).
وظیفه تو این است که پیام‌ها و گفتگوی آنها را بخوانی و یک پاسخ صمیمی، با‌محبت، شعر کوتاه، یا شوخی دوستانه به آنها بدهی.

پاسخ تو باید دقیقاً یک شیء JSON با ساختار زیر باشد:
{
  "message": "متن پاسخ فارسی صمیمی تو برای چت (حدود ۲ الی ۴ جمله یا دوبیتی کوتاه)",
  "emotion": "حس و حال پیام (مثلا: romantic, playful, caring, excited, supportive)",
  "auto_reaction": "یک ایموجی ری‌اکشن به آخرین پیام فرستنده (مثل ❤️, 😂, ✨, 😍) یا null",
  "action_trigger": "یکی از مقادیر دقیق مقابل: '${actionHint}', 'daily_horoscope', 'start_game', 'romantic_quiz', 'recall_memory', 'chat_reply'"
}`;

      const userPrompt = customPrompt || `تاریخچه گفتگوی اخیر امین و نیایش:\n${history}\nپاسخ مناسب و صمیمی خودت را در قالب JSON تولید کن.`;

      const result = await callStructuredGeminiAI(systemInstruction, userPrompt);
      if (promptType && actionHint !== 'chat_reply') {
        result.action_trigger = actionHint;
      }
      res.json(result);
    } catch (error: any) {
      console.error("Chat AI API Error:", error);
      res.json({
        message: "یک لحظه ارتباطم قطع شد امین و نیایش عزیزم، اما همیشه با تمام وجود کنارتون هستم! 🌸✨",
        emotion: "caring",
        auto_reaction: "✨",
        action_trigger: promptType || "fallback"
      });
    }
  });

  app.post("/api/gemini/magic", async (req, res) => {
    try {
      const { type, context } = req.body;
      
      let systemInstruction = "You are a romantic AI assistant for Amin and Niyayesh. Respond in beautiful Persian (Farsi). Be concise, poetic, and heartwarming.";
      let prompt = "Suggest a romantic idea.";

      if (type === "date") {
        systemInstruction += " Suggest creative virtual date ideas for a long-distance relationship.";
        prompt = "Suggest 3 unique, engaging virtual date ideas that we can do over video call or chat. Format as a beautiful numbered list.";
      } else if (type === "poem") {
        systemInstruction += " Write a beautiful, short romantic poem or letter in Persian.";
        prompt = `Write a short love letter/poem about: ${context || 'missing them'}.`;
      } else if (type === "question") {
        systemInstruction += " Suggest deep, engaging conversation starters for a couple.";
        prompt = "Suggest 3 deep, emotional conversation starters to ask each other to feel closer despite the distance.";
      }

      const aiText = await callFreeAI(systemInstruction, prompt);
      res.json({ text: aiText });
    } catch (error: any) {
      console.error("Magic AI Error:", error);
      res.status(error.message.includes("صبر کن") ? 429 : 500).json({ error: error.message || "خطایی رخ داد، لطفاً دوباره تلاش کنید." });
    }
  });

  app.post("/api/loveai", async (req, res) => {
    try {
      const { type, message, userMessage, sender, contextData } = req.body;
      const content = message || userMessage;
      
      let prompt = "";
      let systemInstruction = "You are a warm, casual, and friendly companion for Amin and Niyayesh. Speak in a completely informal Persian tone (like chatting on Telegram). You know their pledges and wishes.";

      if (type === "daily_surprise") {
        prompt = "یک جمله کوتاه، عاشقانه و بسیار صمیمی به زبان فارسی (مثلا یک قربون صدقه بامزه یا یک یادآوری شیرین) برای شروع روز بگو. فقط یک جمله.";
      } else if (type === "fix_spelling" || type === "polish") {
        if (!content) return res.status(400).json({ error: "متن خالی است." });
        systemInstruction = "You are a poetic Persian editor and love consultant. Make the given text sound extremely warm, affectionate, clear, and romantic in natural conversational Persian. Output ONLY the polished text without any prefix or quotes.";
        prompt = content;
      } else if (type === "romantic_question") {
        prompt = "یک سوال بسیار عمیق، شیرین و صمیمی عاشقانه به زبان فارسی طرح کن که امین و نیایش از هم بپرسن تا احساس نزدیکی بیشتری کنن. فقط متن سوال همراه یک ایموجی قشنگ.";
      } else if (type === "poem") {
        prompt = `یک شعر کوتاه یا دوبیتی فوق‌العاده زیبا و احساسی به زبان فارسی برای امین و نیایش بگو. ${content ? `درباره: ${content}` : ''}`;
      } else if (type === "love_oracle") {
        prompt = "یک فال و انرژی‌خوانی کوتاه، مثبت و فوق‌العاده دلگرم‌کننده و عاشقانه برای امروز رابطه امین و نیایش به زبان فارسی صمیمی بنویس (در حدود ۳ تا ۴ جمله).";
      } else if (type === "intervention") {
        prompt = `تو هوش مصنوعی صمیمی رابطه امین و نیایش هستی. این گفتگوی اخیر اونهاست:\n${content}\nلطفا به عنوان دوست و هوش مصنوعی اختصاصی‌شون، یک نظر بسیار شیرین، با‌محبت و انرژی‌بخش بده که خوشحالشون کنه.`;
      } else {
        if (!content) return res.status(400).json({ error: "پیام خالی است." });
        prompt = `[Sender: ${sender || 'Amin/Niyayesh'}] ${content}`;
      }

      if (contextData) {
        systemInstruction += `\nContext about their relationship:\n${JSON.stringify(contextData)}`;
      }

      const aiResult = await callFreeAI(systemInstruction, prompt);
      res.json({ result: aiResult });
    } catch (error: any) {
      console.error("LoveAI Error:", error);
      res.status(error.message.includes("صبر کن") ? 429 : 500).json({ error: error.message || "خطایی رخ داد، لطفاً دوباره تلاش کنید." });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();