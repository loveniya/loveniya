import React, { useState, useRef } from 'react';
import { 
  Music as MusicIcon, Plus, Star, Trash2, ExternalLink, 
  Edit3, Heart, Play, Upload, Disc
} from 'lucide-react';
import { useStore } from '../lib/store';
import { Music as MusicType } from '../lib/types';
import { KebabMenu, KebabMenuItem } from '../components/KebabMenu';
import { motion, AnimatePresence } from 'motion/react';

export const Music: React.FC = () => {
  const { playlist, addMusic, updateMusic, removeMusic } = useStore();
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [title, setTitle] = useState('');
  const [artist, setArtist] = useState('');
  const [url, setUrl] = useState('');
  const audioFileInputRef = useRef<HTMLInputElement>(null);
  
  const handleEdit = (song: MusicType) => {
    setEditingId(song.id);
    setTitle(song.title);
    setArtist(song.artist);
    setUrl(song.url);
    setShowForm(true);
  };

  const handleAudioFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setUrl(event.target.result as string);
          if (!title) {
            const nameWithoutExt = file.name.replace(/\.[^/.]+$/, "");
            setTitle(nameWithoutExt);
          }
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handlePlaySong = (songId: string) => {
    window.dispatchEvent(new CustomEvent('play_song', { detail: songId }));
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !url.trim()) return;

    if (editingId) {
      const existing = playlist.find(m => m.id === editingId);
      if (existing) {
        updateMusic({
          ...existing,
          title,
          artist: artist || 'ناشناس',
          url
        });
      }
    } else {
      const newMusic: MusicType = {
        id: Date.now().toString(),
        title,
        artist: artist || 'ناشناس',
        url,
        pinned: false
      };
      addMusic(newMusic);
    }
    resetForm();
  };

  const resetForm = () => {
    setTitle('');
    setArtist('');
    setUrl('');
    setEditingId(null);
    setShowForm(false);
  };

  const [showCount, setShowCount] = useState(6);

  const sortedMusic = [...playlist].sort((a, b) => {
    if (a.pinned && !b.pinned) return -1;
    if (!a.pinned && b.pinned) return 1;
    return 0;
  });

  const displayedMusic = sortedMusic.slice(0, showCount);
  const hasMore = showCount < sortedMusic.length;
  const hasLess = showCount > 6;

  return (
    <div className="space-y-6 pb-8" dir="rtl">
      {/* Header Card */}
      <div className="glass-card rounded-3xl p-4 sm:p-6 md:p-8 relative overflow-hidden border border-rose-100/80">
        <div className="absolute inset-0 overflow-hidden rounded-3xl pointer-events-none">
          <div className="absolute top-0 left-0 w-64 h-64 bg-rose-200/20 rounded-full blur-3xl mix-blend-multiply" />
          <div className="absolute bottom-0 right-0 w-64 h-64 bg-pink-200/20 rounded-full blur-3xl mix-blend-multiply" />
        </div>

        <div className="flex flex-wrap justify-between items-center gap-3 relative z-10">
          <div>
            <h2 className="text-lg sm:text-2xl font-black text-slate-800 flex items-center gap-2">
              <MusicIcon className="w-5 h-5 sm:w-6 sm:h-6 text-rose-500 shrink-0" />
              <span>موزیک‌های عاشقانه ما</span>
            </h2>
            <p className="text-xs text-slate-500 font-bold mt-1">
              آهنگ‌هایی که یادآور لحظات شیرین و خاطرات دو نفره‌مان هستند.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button 
              onClick={() => {
                if (playlist.length > 0) {
                  handlePlaySong(playlist[0].id);
                }
              }} 
              className="bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold px-4 py-2.5 rounded-2xl flex items-center gap-2 transition-all active:scale-95 shadow-md shadow-rose-200"
            >
              <Disc className="w-4 h-4 animate-[spin_6s_linear_infinite]" />
              <span>اجرای پلیر تمام‌صفحه</span>
            </button>

            <button 
              onClick={() => {
                if (showForm) {
                  resetForm();
                } else {
                  setShowForm(true);
                }
              }} 
              className="bg-stone-900 hover:bg-stone-800 text-white text-xs font-bold px-4 py-2.5 rounded-2xl flex items-center gap-2 transition-all active:scale-95 shadow-2xs"
            >
              <Plus className="w-4 h-4 text-rose-400" />
              <span>{showForm ? 'انصراف' : 'افزودن آهنگ'}</span>
            </button>
          </div>
        </div>

        {/* Add/Edit Song Form */}
        <AnimatePresence>
          {showForm && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="mt-6 relative z-10 pt-4 border-t border-rose-100"
            >
              <form onSubmit={handleSave} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-extrabold text-slate-700 mb-1">نام آهنگ:</label>
                    <input 
                      type="text" 
                      placeholder="مثلا: چشمای تو" 
                      required 
                      value={title} 
                      onChange={e => setTitle(e.target.value)}
                      className="w-full bg-white border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs focus:border-rose-400 focus:outline-none transition-all" 
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-extrabold text-slate-700 mb-1">خواننده / هنرمند:</label>
                    <input 
                      type="text" 
                      placeholder="مثلا: شادمهر عقیلی / پیانو بی‌کلام" 
                      value={artist} 
                      onChange={e => setArtist(e.target.value)}
                      className="w-full bg-white border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs focus:border-rose-400 focus:outline-none transition-all" 
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-extrabold text-slate-700 mb-1">لینک فایل فایل صوتی یا آپلود مستقیم:</label>
                  <div className="flex gap-2">
                    <input 
                      type="url" 
                      placeholder="https://..." 
                      required 
                      value={url} 
                      onChange={e => setUrl(e.target.value)}
                      className="flex-1 bg-white border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs focus:border-rose-400 focus:outline-none text-left transition-all" 
                      dir="ltr" 
                    />
                    <button
                      type="button"
                      onClick={() => audioFileInputRef.current?.click()}
                      className="bg-stone-100 text-slate-700 font-extrabold text-xs px-3.5 py-2.5 rounded-xl flex items-center gap-1.5 hover:bg-stone-200 transition-colors shrink-0"
                    >
                      <Upload className="w-4 h-4 text-rose-500" />
                      <span>انتخاب فایل</span>
                    </button>
                  </div>
                  <input 
                    type="file" 
                    ref={audioFileInputRef} 
                    onChange={handleAudioFileUpload} 
                    accept="audio/*" 
                    className="hidden" 
                  />
                </div>

                <div className="flex justify-end gap-2 pt-2">
                  <button 
                    type="button" 
                    onClick={resetForm} 
                    className="bg-slate-100 text-slate-600 text-xs px-4 py-2 rounded-xl font-bold hover:bg-slate-200 transition-colors"
                  >
                    انصراف
                  </button>
                  <button 
                    type="submit" 
                    className="bg-stone-900 hover:bg-stone-800 text-white text-xs font-bold px-6 py-2 rounded-xl transition-all shadow-2xs"
                  >
                    {editingId ? 'ذخیره تغییرات' : 'افزودن به پلی‌لیست'}
                  </button>
                </div>
              </form>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Playlist Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {sortedMusic.length === 0 ? (
          <div className="glass-card rounded-3xl p-10 text-center text-slate-500 text-xs flex flex-col items-center justify-center gap-3 col-span-full border border-dashed border-rose-200">
            <div className="w-12 h-12 rounded-full bg-rose-50 flex items-center justify-center text-rose-400">
              <Disc className="w-6 h-6" />
            </div>
            <p className="font-extrabold text-slate-700 text-sm">هنوز آهنگی اضافه نشده است</p>
            <p className="text-xs text-slate-400">با زدن دکمه «افزودن آهنگ جدید» اولین موزیک عاشقانه را اضافه کنید.</p>
          </div>
        ) : (
          displayedMusic.map(song => (
            <motion.div 
              layout 
              key={song.id} 
              className={`bg-white/90 backdrop-blur-md p-4 rounded-2xl sm:rounded-3xl border transition-all relative flex items-center justify-between group ${
                song.pinned 
                  ? 'border-amber-300/80 shadow-xs ring-1 ring-amber-200' 
                  : 'border-rose-100/80 shadow-2xs hover:border-rose-300/80'
              }`}
            >
              <div className="flex items-center gap-3 flex-1 min-w-0 pr-1">
                <button 
                  onClick={() => handlePlaySong(song.id)}
                  className="w-10 h-10 rounded-full bg-stone-900 hover:bg-rose-600 text-white flex items-center justify-center shadow-2xs transition-all shrink-0 active:scale-90"
                  title="پخش آهنگ"
                >
                  <Play className="w-4 h-4 fill-white ml-0.5" />
                </button>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5">
                    <h3 className="font-bold text-slate-900 text-xs sm:text-sm truncate">
                      {song.title}
                    </h3>
                    {song.pinned && (
                      <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400 shrink-0" />
                    )}
                  </div>
                  <p className="text-[11px] text-slate-500 font-medium truncate mt-0.5">{song.artist}</p>
                </div>
              </div>

              <div className="flex items-center gap-1 shrink-0">
                {song.url && (
                  <a 
                    href={song.url} 
                    target="_blank" 
                    rel="noreferrer" 
                    className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors" 
                    title="لینک فایل صوتی"
                  >
                    <ExternalLink className="w-4 h-4" />
                  </a>
                )}

                <KebabMenu>
                  <KebabMenuItem 
                    icon={<Play className="w-4 h-4 text-rose-500" />} 
                    label="پخش آنلاین" 
                    onClick={() => handlePlaySong(song.id)} 
                  />
                  <KebabMenuItem 
                    icon={<Star className="w-4 h-4 text-amber-500" />} 
                    label={song.pinned ? 'برداشتن نشان برتر' : 'نشان کردن به عنوان برتر'} 
                    onClick={() => updateMusic({ ...song, pinned: !song.pinned })} 
                  />
                  <KebabMenuItem 
                    icon={<Edit3 className="w-4 h-4 text-slate-600" />} 
                    label="ویرایش" 
                    onClick={() => handleEdit(song)} 
                  />
                  <KebabMenuItem 
                    icon={<Trash2 className="w-4 h-4 text-rose-600" />} 
                    label="حذف" 
                    danger 
                    onClick={() => removeMusic(song.id)} 
                  />
                </KebabMenu>
              </div>
            </motion.div>
          ))
        )}
      </div>

      {/* Pagination Controls */}
      {sortedMusic.length > 6 && (
        <div className="flex justify-center gap-3 mt-6">
          {hasMore && (
            <button 
              onClick={() => setShowCount(c => c + 6)} 
              className="bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 transition-colors px-6 py-2 rounded-full font-bold text-xs flex items-center gap-2 shadow-2xs active:scale-95"
            >
              <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500" />
              <span>نمایش بیشتر ({sortedMusic.length - showCount})</span>
            </button>
          )}
          {hasLess && (
            <button 
              onClick={() => setShowCount(6)} 
              className="bg-white border border-slate-200 hover:bg-slate-50 text-slate-600 transition-colors px-6 py-2 rounded-full font-bold text-xs flex items-center gap-2 shadow-2xs active:scale-95"
            >
              <span>نمایش کمتر</span>
            </button>
          )}
        </div>
      )}
    </div>
  );
};
