import React, { useState, useEffect } from 'react';
import { 
  Sparkles, Star, Heart, ArrowLeft, RefreshCw, 
  Check, Volume2, MessageCircle, Play, Users, 
  Tv, Video, Send, Gift, Coffee, Copy, HeartHandshake, Globe,
  Calendar, ShieldCheck, Gamepad2, Compass
} from 'lucide-react';
import { useStore } from '../lib/store';
import { NavLink } from 'react-router';
import { motion, AnimatePresence } from 'motion/react';
import { PageWrapper } from '../components/PageWrapper';
import { dedupById } from '../lib/dedup';

export const Home: React.FC = () => {
  const { memories, pledges, dreams } = useStore();
  const uniqueMemories = React.useMemo(() => dedupById(memories), [memories]);

  // Timer state
  const startDate = new Date(2026, 4, 10, 0, 0, 0); // 20 Ordibehesht 1405

  const calculateTime = () => {
    const now = new Date();
    if (now < startDate) return { years: 0, months: 0, days: 0, hours: 0, minutes: 0, seconds: 0 };
    
    let y = now.getFullYear() - startDate.getFullYear();
    let mo = now.getMonth() - startDate.getMonth();
    let d = now.getDate() - startDate.getDate();
    let h = now.getHours() - startDate.getHours();
    let mi = now.getMinutes() - startDate.getMinutes();
    let s = now.getSeconds() - startDate.getSeconds();

    if (s < 0) { s += 60; mi--; }
    if (mi < 0) { mi += 60; h--; }
    if (h < 0) { h += 24; d--; }
    if (d < 0) {
      const prevMonthDays = new Date(now.getFullYear(), now.getMonth(), 0).getDate();
      d += prevMonthDays;
      mo--;
    }
    if (mo < 0) { mo += 12; y--; }

    return { years: y, months: mo, days: d, hours: h, minutes: mi, seconds: s };
  };

  const [time, setTime] = useState(calculateTime());
  const [today, setToday] = useState(new Date());

  useEffect(() => {
    const interval = setInterval(() => {
      setTime(calculateTime());
      setToday(new Date());
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const todayMidnight = new Date(today.getFullYear(), today.getMonth(), today.getDate());
  
  let nextYear = today.getFullYear();
  let nextMonthIdx = today.getMonth();
  let maxDaysInMonth = new Date(nextYear, nextMonthIdx + 1, 0).getDate();
  let targetDate = Math.min(startDate.getDate(), maxDaysInMonth);
  
  let nextMonth = new Date(nextYear, nextMonthIdx, targetDate);

  if (todayMidnight.getTime() > nextMonth.getTime()) {
    nextMonthIdx += 1;
    if (nextMonthIdx > 11) {
      nextMonthIdx = 0;
      nextYear += 1;
    }
    maxDaysInMonth = new Date(nextYear, nextMonthIdx + 1, 0).getDate();
    targetDate = Math.min(startDate.getDate(), maxDaysInMonth);
    nextMonth = new Date(nextYear, nextMonthIdx, targetDate);
  }

  const daysUntilNext = Math.round((nextMonth.getTime() - todayMidnight.getTime()) / (1000 * 3600 * 24));

  // Daily Spotlight Memory: selects a random memory per day and keeps it constant throughout the day
  const topMemories = uniqueMemories.filter(m => m.pinned);
  const eligibleMemories = topMemories.length > 0 ? topMemories : uniqueMemories;
  const [spotlightMemoryId, setSpotlightMemoryId] = useState<string | null>(null);

  useEffect(() => {
    if (eligibleMemories.length === 0) {
      setSpotlightMemoryId(null);
      return;
    }

    const todayStr = new Date().toLocaleDateString('fa-IR-u-nu-latn'); // e.g. "1405/6/5"
    const storageKeyDate = 'loveniya_daily_memory_date';
    const storageKeyId = 'loveniya_daily_memory_id';

    const savedDate = localStorage.getItem(storageKeyDate);
    const savedId = localStorage.getItem(storageKeyId);

    // If we already have a chosen memory for today and it still exists in the eligible list
    if (savedDate === todayStr && savedId && eligibleMemories.some(m => m.id === savedId)) {
      setSpotlightMemoryId(savedId);
      return;
    }

    // Otherwise, pick a new random memory for today (trying to pick a different one than yesterday if possible)
    const availablePool = eligibleMemories.length > 1 && savedId 
      ? eligibleMemories.filter(m => m.id !== savedId)
      : eligibleMemories;

    const chosen = availablePool[Math.floor(Math.random() * availablePool.length)];
    if (chosen) {
      localStorage.setItem(storageKeyDate, todayStr);
      localStorage.setItem(storageKeyId, chosen.id);
      setSpotlightMemoryId(chosen.id);
    }
  }, [eligibleMemories]);

  const currentSpotlightMemory = memories.find(m => m.id === spotlightMemoryId) || (eligibleMemories.length > 0 ? eligibleMemories[0] : null);

  // Reason Generator
  const reasons = [
    "چون با یه لبخندت کل روزم ساخته میشه.",
    "چون امن‌ترین پناهگاه دنیا بغل توئه.",
    "چون هر روز بیشتر از دیروز دلم برات ضعف میره.",
    "چون وقتی صدام می‌کنی، قشنگ‌ترین اسم دنیا رو دارم.",
    "چون تو تنها کسی هستی که دیوونه‌بازیامو درک میکنی.",
    "چون خنده‌هات قشنگ‌ترین موسیقی دنیاست.",
    "چون با تو، ساده‌ترین لحظه‌ها هم رویاییه.",
    "چون تو دقیقاً همونی هستی که همیشه آرزوشو داشتم."
  ];
  const [reason, setReason] = useState("دکمه رو بزن تا یه دلیل قشنگ ببینی...");

  const showReason = () => {
    let newReason = reason;
    while (newReason === reason) {
      newReason = reasons[Math.floor(Math.random() * reasons.length)];
    }
    setReason(newReason);
  };

  return (
    <PageWrapper>
      <div className="space-y-4 sm:space-y-6 max-w-3xl mx-auto px-2 sm:px-4" dir="rtl">
      {/* Modern Editorial Header */}
      <section className="text-center space-y-2 pt-2 pb-1">
        <motion.div 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-50/80 border border-rose-200/60 text-rose-600 text-[10px] sm:text-xs font-bold shadow-xs"
        >
          <Heart className="w-3 h-3 sm:w-3.5 sm:h-3.5 fill-rose-500" />
          <span>پناهگاه اختصاصی امین و نیایش</span>
        </motion.div>
        <motion.h1 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="text-2xl sm:text-4xl md:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-l from-rose-600 via-pink-600 to-rose-500 tracking-tight leading-tight py-1"
        >
          جهان عاشقانمون
        </motion.h1>
      </section>

      {/* Dedicated Page Teaser Card for LDR Moments */}
      <section className="bg-white/95 rounded-3xl p-4 sm:p-6 border border-rose-200/90 shadow-xl shadow-rose-900/5 text-right space-y-2.5 relative overflow-hidden">
        <div className="flex items-center justify-between">
          <div className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-rose-50 text-rose-600 text-[10px] sm:text-[11px] font-extrabold border border-rose-100">
            <Sparkles className="w-3 h-3" />
            <span>چالش‌های اختصاصی دو نفره</span>
          </div>
          <span className="text-[9px] sm:text-[10px] font-bold text-rose-500 bg-white px-2 py-0.5 rounded-full border border-rose-100 shadow-2xs">
            آپدیت روزانه
          </span>
        </div>

        <div className="space-y-0.5">
          <h2 className="text-sm sm:text-lg font-black text-stone-800">
            لحظه‌ها، رازها و چالش‌های ویژه امروز
          </h2>
          <p className="text-[11px] sm:text-xs text-stone-500 font-medium leading-relaxed">
            صفحه اختصاصی آیین‌های روزانه، چالش‌های «این یا آن»، صندوق رازهای پنهان و ارسال حس آنلاین برای امین و نیایش.
          </p>
        </div>

        <div className="pt-0.5">
          <NavLink
            to="/moments"
            className="bg-gradient-to-l from-rose-500 to-pink-500 text-white hover:from-rose-600 hover:to-pink-600 px-4 py-2 sm:px-5 sm:py-2.5 rounded-xl text-xs font-bold transition-all inline-flex items-center gap-1.5 shadow-md shadow-rose-200 active:scale-95"
          >
            <span>ورود به صفحه چالش‌های امروز</span>
            <ArrowLeft className="w-3.5 h-3.5" />
          </NavLink>
        </div>
      </section>

      {/* Love Timer Counter */}
      <section className="bg-white/95 rounded-[2rem] sm:rounded-[2.5rem] p-4 sm:p-6 text-center shadow-xl shadow-rose-900/5 border border-rose-200/90 relative overflow-hidden">
        {/* Decorative ambient blobs */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-pink-100/40 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-32 h-32 bg-rose-100/40 rounded-full blur-3xl"></div>
        
        <h2 className="text-xs sm:text-base font-black text-rose-500 mb-4 sm:mb-6 flex items-center justify-center gap-1.5 relative z-10">
          <Heart className="w-3.5 h-3.5 sm:w-4 sm:h-4 fill-rose-500" /> 
          تپش‌های قلبم از ۲۰ اردیبهشت ۱۴۰۵ 
          <Heart className="w-3.5 h-3.5 sm:w-4 sm:h-4 fill-rose-500" />
        </h2>
        
        <div className="space-y-2 sm:space-y-3 relative z-10">
          {/* Top Row: Seconds, Minutes, Hours, Days */}
          <div className="grid grid-cols-4 gap-1.5 sm:gap-3">
            {[
              { label: 'ثانیه', value: time.seconds },
              { label: 'دقیقه', value: time.minutes },
              { label: 'ساعت', value: time.hours },
              { label: 'روز', value: time.days }
            ].map((unit, i) => (
              <div key={i} className="bg-white/80 rounded-2xl p-2 sm:p-3.5 flex flex-col items-center justify-center shadow-2xs border border-rose-100/60">
                <span className="block text-base sm:text-2xl font-black text-stone-700 tracking-tight leading-none mb-1">
                  {unit.value.toString().padStart(2, '0')}
                </span>
                <span className="text-[9px] sm:text-xs font-bold text-stone-500">{unit.label}</span>
              </div>
            ))}
          </div>

          {/* Bottom Row: Months, Years */}
          <div className="grid grid-cols-2 gap-1.5 sm:gap-3">
            {[
              { label: 'ماه', value: time.months },
              { label: 'سال', value: time.years }
            ].map((unit, i) => (
              <div key={i} className="bg-white/80 rounded-2xl p-3 sm:p-4 flex flex-col items-center justify-center shadow-2xs border border-rose-100/60">
                <span className="block text-xl sm:text-3xl font-black text-stone-700 tracking-tight leading-none mb-1">
                  {unit.value.toString().padStart(2, '0')}
                </span>
                <span className="text-[10px] sm:text-xs font-bold text-stone-500">{unit.label}</span>
              </div>
            ))}
          </div>
        </div>

        <p className="mt-4 sm:mt-5 text-xs sm:text-sm font-extrabold text-rose-500 relative z-10">
          {daysUntilNext === 0 
            ? 'امروز ماهگردمونه! 🎉' 
            : `${daysUntilNext} روز تا ماهگرد بعدی...`}
        </p>
      </section>

      {/* Memory Spotlight */}
      {currentSpotlightMemory && (
        <section className={`rounded-3xl p-4 sm:p-6 text-center relative overflow-hidden transition-all ${
          currentSpotlightMemory.pinned
            ? 'bg-white/95 border-2 border-rose-300/90 shadow-xl shadow-rose-500/10 ring-1 ring-rose-200/50'
            : 'bg-white/95 border border-rose-200/90 shadow-xl shadow-rose-900/5'
        }`}>
          <div className="absolute top-0 right-0 w-28 h-28 bg-rose-100/40 rounded-full blur-2xl pointer-events-none"></div>
          <h2 className="text-[11px] sm:text-xs font-black text-rose-600 mb-1 flex items-center justify-center gap-1.5 relative z-10">
            <Star className="w-3.5 h-3.5 text-rose-500 fill-amber-300" />
            <span>{currentSpotlightMemory.pinned ? 'خاطره برتر و منتخب' : 'یادآوری خاطره'}</span>
          </h2>
          <p className="text-sm sm:text-base font-extrabold text-stone-900 mb-0.5 relative z-10">{currentSpotlightMemory.title}</p>
          <p className="text-[10px] sm:text-[11px] text-stone-500 mb-3 font-bold relative z-10">{currentSpotlightMemory.date}</p>
          <NavLink to="/memories" className="bg-rose-500 hover:bg-rose-600 text-white px-5 py-2 sm:px-6 sm:py-2.5 rounded-xl text-xs font-bold transition-all inline-flex items-center gap-1.5 active:scale-95 shadow-md shadow-rose-500/20 relative z-10">
            <span>مرور این خاطره و آلبوم</span>
            <ArrowLeft className="w-3.5 h-3.5 text-white" />
          </NavLink>
        </section>
      )}

      {/* Reason Generator */}
      <section className="bg-white/95 rounded-3xl p-4 sm:p-6 text-center shadow-xl shadow-rose-900/5 border border-rose-200/90 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-24 h-24 bg-rose-50 rounded-full blur-2xl"></div>
        <h2 className="text-[11px] sm:text-xs font-bold text-rose-600 mb-1 flex items-center gap-1.5 justify-center relative z-10">
          <Sparkles className="w-3.5 h-3.5 text-rose-500" /> چرا عاشقتم؟
        </h2>
        <p className="text-[10px] sm:text-[11px] text-stone-500 font-bold mb-3 relative z-10">یک یادآوری دلی از طرف امین</p>

        <div className="bg-white/80 rounded-2xl p-3.5 sm:p-5 border border-rose-100/60 my-3 sm:my-4 shadow-2xs relative z-10">
          <p className="text-xs sm:text-base text-stone-800 font-black min-h-[40px] sm:min-h-[48px] flex items-center justify-center leading-relaxed">
            {reason}
          </p>
        </div>

        <button onClick={showReason} className="bg-gradient-to-l from-rose-500 to-pink-500 text-white text-xs font-bold px-5 py-2.5 sm:px-6 sm:py-3 rounded-xl hover:from-rose-600 hover:to-pink-600 transition-all inline-flex items-center gap-2 active:scale-95 shadow-md shadow-rose-200 relative z-10">
          <RefreshCw className="w-3.5 h-3.5" />
          <span>یک دلیل دیگر</span>
        </button>
      </section>
      </div>
    </PageWrapper>
  );
};

export default Home;


