import React, { useState, useRef, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router';
import { dedupById } from '../lib/dedup';
import { 
  Send, ArrowRight, MoreVertical, Trash2, CheckCheck, 
  Heart, Loader2, AlertTriangle, X, Sparkles
} from 'lucide-react';
import { fetchLoveAI } from '../lib/ai';
import { 
  updateUserPresence, 
  fetchPartnerPresenceData, 
  formatIranLastSeen, 
  PresenceData 
} from '../lib/presence';

const WORKER_URL = "https://niya.am-b-asdfghjkl20112011.workers.dev";

interface ChatMessage {
  id: string;
  senderId: 'amin' | 'niyayesh' | 'ai';
  senderName?: string;
  text: string;
  timestamp: string;
  createdAt: number;
  status: 'sent' | 'read';
}

export function AIChat() {
  const navigate = useNavigate();
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const syncMutatedAtRef = useRef<number>(0);
  const lastAiReplyTimeRef = useRef<number>(0);
  const [hasFetchedChat, setHasFetchedChat] = useState(false);

  const [currentUser] = useState<'amin' | 'niyayesh'>(
    (localStorage.getItem('loveniya_user') as 'amin' | 'niyayesh') || 'amin'
  );

  const isAmin = currentUser === 'amin';
  const partnerId = isAmin ? 'niyayesh' : 'amin';
  const partnerName = isAmin ? 'نیایش' : 'امین';
  const myName = isAmin ? 'امین' : 'نیایش';
  const partnerInitial = isAmin ? 'ن' : 'ا';
  
  const avatarColor = isAmin ? 'bg-fuchsia-600' : 'bg-sky-600';

  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    const saved = localStorage.getItem('chat_messages_synced');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          return parsed.sort((a: ChatMessage, b: ChatMessage) => (a.createdAt || 0) - (b.createdAt || 0));
        }
      } catch (e) {}
    }
    return [];
  });

  const [inputText, setInputText] = useState('');
  const [partnerPresence, setPartnerPresence] = useState<PresenceData | null>(null);
  const [partnerStatusText, setPartnerStatusText] = useState('در حال بررسی وضعیت...');
  const [isPartnerTyping, setIsPartnerTyping] = useState(false);
  const [isGeneratingAI, setIsGeneratingAI] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [showConfirmClearModal, setShowConfirmClearModal] = useState(false);
  const [isClearing, setIsClearing] = useState(false);
  const [toastError, setToastError] = useState<string | null>(null);

  const showToast = (message: string) => {
    setToastError(message);
    setTimeout(() => setToastError(null), 4000);
  };

  // بروزرسانی وضعیت حضور و تایپ من در کلودفلر
  const updateMyPresence = useCallback(async (typing: boolean) => {
    await updateUserPresence(currentUser, { isTyping: typing, isOnline: true });
  }, [currentUser]);

  // دریافت وضعیت آنلاین و آخرین بازدید دقیق پارتنر به وقت ایران
  const refreshPartnerPresence = useCallback(async () => {
    const data = await fetchPartnerPresenceData(partnerId);
    if (data) {
      setPartnerPresence(data);
      setIsPartnerTyping(Boolean(data.isTyping));
      const formatted = formatIranLastSeen(data, Boolean(data.isTyping));
      setPartnerStatusText(formatted);
    } else {
      setPartnerStatusText('آفلاین');
    }
  }, [partnerId]);

  // بروزرسانی وضعیت هنگام تایپ کاربر
  useEffect(() => {
    updateMyPresence(inputText.trim().length > 0);
  }, [inputText, updateMyPresence]);

  // تایمر همگام‌سازی وضعیت آنلاین و تایپ پارتنر
  useEffect(() => {
    refreshPartnerPresence();
    const presenceInterval = setInterval(() => {
      updateMyPresence(inputText.trim().length > 0);
      refreshPartnerPresence();
    }, 3000);
    return () => clearInterval(presenceInterval);
  }, [refreshPartnerPresence, updateMyPresence, inputText]);

  // همگام‌سازی چت دو نفره با کلودفلر
  const fetchCloudflareChat = useCallback(async () => {
    if (Date.now() - syncMutatedAtRef.current < 6000) return;

    try {
      const res = await fetch(`${WORKER_URL}/loveniya_chat.json?_t=${Date.now()}`, { cache: 'no-store' });
      if (res.ok) {
        const data = await res.json();
        const rawArr: any[] = data ? (Array.isArray(data) ? data : Object.values(data)) : [];
        
        const messagesArr: ChatMessage[] = rawArr
          .filter(m => m && typeof m === 'object' && m.id && m.text)
          .map(m => {
            const rawCreatedAt = Number(m.createdAt) || (typeof m.timestamp === 'number' ? m.timestamp : Date.now());
            return {
              id: String(m.id),
              senderId: m.senderId || (m.sender === 'Amin' ? 'amin' : m.sender === 'Niyaish' ? 'niyayesh' : 'ai'),
              senderName: m.senderName || (m.senderId === 'amin' ? 'امین' : m.senderId === 'niyayesh' ? 'نیایش' : 'لوینیا'),
              text: String(m.text || m.content || ''),
              timestamp: m.timestamp && typeof m.timestamp === 'string' && !m.timestamp.includes('NaN')
                ? m.timestamp 
                : new Date(rawCreatedAt).toLocaleTimeString('fa-IR', { timeZone: 'Asia/Tehran', hour: '2-digit', minute: '2-digit', hour12: false }),
              createdAt: rawCreatedAt,
              status: m.status || 'read'
            };
          })
          .sort((a, b) => (a.createdAt || 0) - (b.createdAt || 0));

        const cleanMessages = dedupById(messagesArr);
        setMessages(cleanMessages);
        setHasFetchedChat(true);
        try { localStorage.setItem('chat_messages_synced', JSON.stringify(cleanMessages)); } catch(e) {}
      }
    } catch (e) {
      console.warn("Error fetching chat:", e);
      setHasFetchedChat(true);
    }
  }, []);

  const syncChatToServer = async (newMessages: ChatMessage[], changedMessage?: ChatMessage, isClear?: boolean) => {
    try {
      syncMutatedAtRef.current = Date.now();
      localStorage.setItem('chat_messages_synced', JSON.stringify(newMessages));
      
      if (isClear) {
        await Promise.allSettled([
          fetch(`${WORKER_URL}/loveniya_chat.json`, { method: 'DELETE' }),
          fetch(`${WORKER_URL}/loveniya_chat.json`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({})
          })
        ]);
        return;
      }

      if (changedMessage) {
        await fetch(`${WORKER_URL}/loveniya_chat/${changedMessage.id}.json`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(changedMessage)
        });
      } else {
        const payload: Record<string, ChatMessage> = {};
        newMessages.forEach(m => payload[m.id] = m);
        await fetch(`${WORKER_URL}/loveniya_chat.json`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
      }
    } catch (e) {
      console.error("Error syncing chat to server:", e);
    }
  };

  useEffect(() => {
    fetchCloudflareChat();
    const interval = setInterval(fetchCloudflareChat, 3500);
    return () => clearInterval(interval);
  }, [fetchCloudflareChat]);

  // اسکرول خودکار به آخرین پیام
  useEffect(() => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollTo({
        top: scrollContainerRef.current.scrollHeight,
        behavior: 'smooth'
      });
    }
  }, [messages, isPartnerTyping, isGeneratingAI]);

  // پاک کردن کامل تاریخچه چت همراه با بستن فوری منو و مودال
  const confirmAndClearHistory = async () => {
    setIsClearing(true);
    try {
      syncMutatedAtRef.current = Date.now();
      setMessages([]);
      localStorage.setItem('chat_messages_synced', '[]');
      await syncChatToServer([], undefined, true);
    } catch (e) {
      console.error("Error clearing chat:", e);
    } finally {
      setIsClearing(false);
      setShowConfirmClearModal(false);
      setShowMenu(false);
    }
  };

  // فراخوانی تضمینی هوش مصنوعی کلودفلر
  const triggerAiEvaluation = async (promptType: 'chat_reply' | 'smart_evaluate', customText?: string) => {
    if (isGeneratingAI) return;
    
    // جلوگیری از اسپم در پاسخ‌های خودکار
    if (promptType === 'smart_evaluate' && Date.now() - lastAiReplyTimeRef.current < 25000) {
      return;
    }

    setIsGeneratingAI(true);

    try {
      const historyContext = messages.slice(-8).map(m => 
        `${m.senderId === 'amin' ? 'امین' : m.senderId === 'niyayesh' ? 'نیایش' : 'لوینیا'}: ${m.text}`
      ).join('\n');

      const targetPrompt = customText || (messages[messages.length - 1]?.text || 'سلام');

      const rawResult = await fetchLoveAI({
        type: promptType,
        userMessage: targetPrompt,
        history: historyContext,
        contextData: {
          user: currentUser,
          partner: partnerName
        }
      });

      if (rawResult === 'SKIP') {
        return; // No message added to UI
      }

      if (rawResult && typeof rawResult === 'string' && rawResult.trim().length > 0) {
        const now = Date.now();
        lastAiReplyTimeRef.current = now;

        const iranTime = new Date(now).toLocaleTimeString('fa-IR', {
          timeZone: 'Asia/Tehran',
          hour: '2-digit',
          minute: '2-digit',
          hour12: false
        });

        const aiMsg: ChatMessage = {
          id: `ai_${now}_${Math.random().toString(36).substring(2, 7)}`,
          senderId: 'ai',
          senderName: 'لوینیا',
          text: rawResult.trim(),
          timestamp: iranTime,
          createdAt: now,
          status: 'read'
        };

        setMessages((prev) => {
          const updated = [...prev, aiMsg].sort((a, b) => a.createdAt - b.createdAt);
          syncChatToServer(updated, aiMsg);
          return updated;
        });
      }
    } catch (err: any) {
      console.error("AI Evaluation Error:", err);
      showToast(err.message || "خطا در ارتباط با سرور هوش مصنوعی");
    } finally {
      setIsGeneratingAI(false);
    }
  };

  // ارسال پیام متنی
  const handleSend = async (forcedText?: string) => {
    const textToSend = (forcedText || inputText).trim();
    if (!textToSend) return;

    const now = Date.now();
    const iranTime = new Date(now).toLocaleTimeString('fa-IR', {
      timeZone: 'Asia/Tehran',
      hour: '2-digit',
      minute: '2-digit',
      hour12: false
    });

    const userMessage: ChatMessage = {
      id: `msg_${now}_${Math.random().toString(36).substring(2, 7)}`,
      senderId: currentUser,
      senderName: myName,
      text: textToSend,
      timestamp: iranTime,
      createdAt: now,
      status: 'sent'
    };

    if (!forcedText) {
      setInputText('');
    }

    let updatedList: ChatMessage[] = [];
    setMessages((prev) => {
      updatedList = [...prev, userMessage].sort((a, b) => a.createdAt - b.createdAt);
      syncChatToServer(updatedList, userMessage);
      return updatedList;
    });

    // بررسی درخواست از هوش مصنوعی
    const lower = textToSend.toLowerCase();
    const isDirectlyInvoked = 
      lower.includes('لوینیا') || 
      lower.includes('@ai') || 
      lower.includes('هوش مصنوعی') || 
      lower.includes('ai') ||
      lower.includes('ربات') ||
      lower.includes('جواب بده') ||
      lower.includes('کمک کن') ||
      lower.includes('چرا جواب نمیدی') ||
      lower.includes('شعر بگو') ||
      lower.includes('فال بگو') ||
      lower.includes('نظرت چیه') ||
      textToSend.endsWith('؟') ||
      textToSend.endsWith('?');

    if (isDirectlyInvoked) {
      setTimeout(() => {
        triggerAiEvaluation('chat_reply', textToSend);
      }, 400);
    }
  };

  return (
    <div className="flex flex-col h-[100dvh] w-full bg-[#0e1621] text-white font-sans overflow-hidden select-none" dir="rtl">
      
      {/* Header مینیمال و شیک با نمایش دقیق وضعیت به وقت ایران */}
      <header className="flex-none bg-[#17212b] min-h-[58px] pt-[max(env(safe-area-inset-top),_8px)] pb-2 px-3 flex items-center gap-3 z-20 shadow-xs relative border-b border-[#242f3d]">
        <button onClick={() => navigate('/')} className="p-2 rounded-full hover:bg-[#2b3a4a] transition text-[#7f91a4] active:scale-95 cursor-pointer" title="بازگشت به خانه">
          <ArrowRight className="w-5 h-5" />
        </button>
        
        <div className={`w-10 h-10 rounded-2xl flex items-center justify-center text-white text-base font-bold cursor-pointer ${avatarColor} shadow-md`}>
          {partnerInitial}
        </div>
        
        <div className="flex flex-col flex-1 justify-center">
          <div className="flex items-center gap-2">
            <span className="text-white font-bold text-[15px] leading-tight">{partnerName}</span>
          </div>
          <span className={`text-[11.5px] transition-colors duration-300 ${
            isPartnerTyping 
              ? 'text-[#4bb4e6] font-bold' 
              : partnerStatusText === 'آنلاین' 
                ? 'text-emerald-400 font-bold' 
                : 'text-[#8e9faf]'
          }`}>
            {partnerStatusText}
          </span>
        </div>

        <div className="relative flex items-center gap-1">
          <button 
            onClick={() => setShowMenu(!showMenu)} 
            className="p-2 rounded-full hover:bg-[#2b3a4a] transition text-[#7f91a4] active:scale-95 cursor-pointer"
          >
            <MoreVertical className="w-5 h-5" />
          </button>

          {showMenu && (
            <>
              <div className="fixed inset-0 z-40" onClick={() => setShowMenu(false)} />
              
              <div className="absolute left-0 top-12 bg-[#17212b] border border-[#2b3a4a] shadow-2xl rounded-2xl py-1.5 w-52 z-50 text-right text-xs overflow-hidden animate-fadeIn">
                <button
                  onClick={() => {
                    setShowMenu(false);
                    setShowConfirmClearModal(true);
                  }}
                  className="w-full text-right px-4 py-3 hover:bg-[#242f3d] text-rose-400 hover:text-rose-300 transition flex items-center justify-between cursor-pointer"
                >
                  <span className="font-medium text-[13px]">پاک کردن تاریخچه چت</span>
                  <Trash2 className="w-4 h-4 text-rose-400" />
                </button>
              </div>
            </>
          )}
        </div>
      </header>

      {/* لیست پیام‌ها */}
      <main 
        ref={scrollContainerRef} 
        className="flex-1 overflow-y-auto p-3 sm:p-4 flex flex-col gap-2.5 select-text" 
        style={{ backgroundImage: 'url("https://web.telegram.org/a/chat-bg-pattern-dark.png")', backgroundSize: '360px', backgroundBlendMode: 'overlay', backgroundColor: '#0e1621' }}
      >
        {!hasFetchedChat ? (
          <div className="flex-1 flex flex-col items-center justify-center text-[#7f91a4] text-xs gap-3 py-12 my-auto">
            <Loader2 className="w-6 h-6 animate-spin text-sky-400" />
            <span className="text-[13px] text-slate-300 font-medium">در حال همگام‌سازی پیام‌ها...</span>
          </div>
        ) : messages.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center text-[#7f91a4] text-xs gap-3 py-12 my-auto">
            <div className="bg-[#17212b]/90 border border-[#242f3d] rounded-3xl px-6 py-5 shadow-lg text-center max-w-sm">
              <div className="w-12 h-12 rounded-full bg-purple-600/20 border border-purple-500/30 flex items-center justify-center mx-auto mb-2 text-purple-300">
                <Heart className="w-6 h-6 text-pink-400" />
              </div>
              <h4 className="text-white font-bold text-sm mb-1">فضای اختصاصی امین و نیایش</h4>
              <p className="text-[12px] text-slate-300 leading-relaxed">
                پیام‌های شما به‌صورت خصوصی و زنده همگام می‌شوند.
              </p>
            </div>
          </div>
        ) : null}

        {hasFetchedChat && messages.map((msg, index) => {
          const isMe = msg.senderId === currentUser;
          const isAI = msg.senderId === 'ai';
          const showTail = index === messages.length - 1 || messages[index + 1]?.senderId !== msg.senderId;

          if (isAI) {
            return (
              <div key={msg.id ? `${msg.id}-${index}` : `ai-${index}`} className="flex w-full justify-center my-3 animate-fadeIn">
                <div className="relative w-[95%] sm:max-w-[85%] px-4 py-3 bg-gradient-to-br from-[#241a3a] to-[#181128] border border-purple-500/30 rounded-2xl shadow-xl shadow-purple-900/10">
                  <div className="flex items-center gap-2 mb-2 pb-2 border-b border-purple-500/20">
                    <div className="w-6 h-6 rounded-full bg-purple-500/20 flex items-center justify-center">
                      <Sparkles className="w-3.5 h-3.5 text-purple-400" />
                    </div>
                    <span className="text-[12.5px] font-bold text-purple-300">لوینیا</span>
                  </div>
                  <div className="text-[14px] whitespace-pre-wrap leading-relaxed text-purple-50 text-right">
                    {msg.text}
                  </div>
                  <div className="flex justify-end items-center mt-1 pt-1.5">
                    <span className="text-[10px] text-purple-400/60 font-medium tracking-wide">
                      {msg.timestamp}
                    </span>
                  </div>
                </div>
              </div>
            );
          }

          return (
            <div key={msg.id ? `${msg.id}-${index}` : `user-${index}`} className={`flex w-full ${isMe ? 'justify-start' : 'justify-end'}`}>
              <div 
                className={`relative max-w-[84%] sm:max-w-[75%] px-3.5 pt-2 pb-1.5 shadow-sm text-[15px] leading-relaxed break-words select-text
                ${isMe 
                  ? `bg-[#2b5278] text-white ${showTail ? 'rounded-2xl rounded-br-none' : 'rounded-2xl'}` 
                  : `bg-[#182533] text-white ${showTail ? 'rounded-2xl rounded-bl-none' : 'rounded-2xl'}`
                }`}
              >
                {/* نام فرستنده */}
                <div className={`text-[11px] font-bold mb-0.5 ${isMe ? 'text-sky-200' : 'text-fuchsia-200'}`}>
                  {msg.senderName || (msg.senderId === 'amin' ? 'امین' : 'نیایش')}
                </div>

                <div className="text-[14.5px] whitespace-pre-wrap leading-relaxed">
                  {msg.text}
                </div>
                
                {/* زمان و وضعیت تیک ارسال */}
                <div className="float-left flex items-center gap-1 mt-1 ml-[-2px] mr-3 pt-1 select-none">
                  <span className={`text-[10.5px] ${isMe ? 'text-[#7aa5cd]' : 'text-[#7f91a4]'}`}>
                    {msg.timestamp}
                  </span>
                  
                  {isMe && (
                    <span className="text-[#4bb4e6] flex items-center">
                      <CheckCheck className="w-3.5 h-3.5" />
                    </span>
                  )}
                </div>
              </div>
            </div>
          );
        })}

        {/* نشانگر در حال تایپ هوش مصنوعی */}
        {isGeneratingAI && (
          <div className="flex w-full justify-start animate-fadeIn">
            <div className="bg-[#241c38] border border-purple-800/40 text-purple-200 rounded-2xl px-4 py-2 text-xs flex items-center gap-2 shadow-sm">
              <span className="w-2 h-2 rounded-full bg-purple-400 animate-ping" />
              <span>لوینیا در حال پاسخ...</span>
            </div>
          </div>
        )}

        <div className="h-1 flex-none" />
      </main>

      {/* کادر ورود پیام پاک، شیک و بدون المان‌های اضافی */}
      <footer className="flex-none bg-[#17212b] px-3 pt-2 pb-[max(env(safe-area-inset-bottom),_10px)] flex items-end gap-2 border-t border-[#242f3d]">
        <div className="flex-1 bg-[#242f3d] rounded-2xl flex items-end min-h-[48px] max-h-[144px] relative border border-[#2d3a4c] focus-within:border-sky-500/50 transition">
          <textarea
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            disabled={isGeneratingAI}
            onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey && !isGeneratingAI) { e.preventDefault(); handleSend(); } }}
            placeholder={isGeneratingAI ? 'درحال پاسخ...' : `پیام به عنوان ${myName}...`}
            dir="rtl"
            className="flex-1 bg-transparent text-white placeholder-[#7f91a4] text-[14.5px] px-3.5 py-3 resize-none focus:outline-none max-h-[144px] overflow-y-auto disabled:opacity-50"
            rows={1}
            style={{ minHeight: '48px' }}
          />
        </div>

        <button 
          onClick={() => handleSend()} 
          disabled={!inputText.trim() || isGeneratingAI}
          className="w-12 h-12 bg-[#2b5278] hover:bg-[#34608c] disabled:opacity-40 text-white rounded-2xl flex items-center justify-center flex-none transition shadow-md active:scale-95 cursor-pointer"
        >
          <Send className="w-5 h-5 ml-0.5" />
        </button>
      </footer>

      {/* Toast Error Message */}
      {toastError && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 animate-fadeIn">
          <div className="bg-rose-500/90 backdrop-blur text-white px-4 py-2 rounded-2xl shadow-lg flex items-center gap-2 text-sm max-w-[90vw] text-center border border-rose-400">
            <AlertTriangle className="w-4 h-4 flex-none" />
            <span>{toastError}</span>
          </div>
        </div>
      )}

      {/* مودال تأیید پاک کردن تاریخچه */}
      {showConfirmClearModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs animate-fadeIn">
          <div className="bg-[#17212b] border border-[#2b3a4a] rounded-3xl p-6 max-w-sm w-full shadow-2xl text-center relative animate-scaleUp">
            <button 
              onClick={() => setShowConfirmClearModal(false)}
              className="absolute top-4 left-4 p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-[#242f3d] transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="w-14 h-14 bg-rose-500/10 border border-rose-500/30 rounded-2xl flex items-center justify-center mx-auto mb-4 text-rose-400">
              <AlertTriangle className="w-7 h-7" />
            </div>

            <h3 className="text-white font-bold text-base mb-2">پاک کردن تاریخچه چت</h3>
            <p className="text-slate-300 text-xs leading-relaxed mb-6">
              آیا مطمئن هستید؟ با این کار تمامی پیام‌های ثبت‌شده در گفتگوی دونفره برای همیشه حذف خواهند شد.
            </p>

            <div className="flex items-center gap-3">
              <button
                onClick={() => setShowConfirmClearModal(false)}
                disabled={isClearing}
                className="flex-1 py-3 px-4 rounded-2xl bg-[#242f3d] hover:bg-[#2e3b4d] text-slate-300 font-medium text-xs transition cursor-pointer"
              >
                انصراف
              </button>
              
              <button
                onClick={confirmAndClearHistory}
                disabled={isClearing}
                className="flex-1 py-3 px-4 rounded-2xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs transition flex items-center justify-center gap-2 shadow-lg shadow-rose-900/30 disabled:opacity-50 cursor-pointer"
              >
                {isClearing ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>در حال حذف...</span>
                  </>
                ) : (
                  <span>بله، پاک کن</span>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}

export default AIChat;
