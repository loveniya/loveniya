import React, { useState, useRef, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router';
import { 
  Send, ArrowRight, MoreVertical, Trash2, CheckCheck, Sparkles
} from 'lucide-react';
import { useStore } from '../lib/store';

const WORKER_URL = "https://niya.am-b-asdfghjkl20112011.workers.dev";

interface ChatMessage {
  id: string;
  senderId: 'amin' | 'niyayesh' | 'ai';
  senderName?: string;
  text: string;
  timestamp: string;
  status: 'sent' | 'read';
}

export function AIChat() {
  const navigate = useNavigate();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const store = useStore();

  const [currentUser] = useState<'amin' | 'niyayesh'>(
    (localStorage.getItem('loveniya_user') as 'amin' | 'niyayesh') || 'amin'
  );

  const isAmin = currentUser === 'amin';
  const partnerId = isAmin ? 'niyayesh' : 'amin';
  const partnerName = isAmin ? 'نیایش' : 'امین';
  const myName = isAmin ? 'امین' : 'نیایش';
  const partnerInitial = isAmin ? 'ن' : 'ا';
  
  const avatarColor = isAmin ? 'bg-fuchsia-600' : 'bg-sky-600';

  // State for Radar banner
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    const saved = localStorage.getItem('chat_messages_synced');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      } catch (e) {}
    }
    return [];
  });

  const [inputText, setInputText] = useState('');
  const [partnerStatus, setPartnerStatus] = useState('آنلاین');
  const [isTyping, setIsTyping] = useState(false);
  const [isGeneratingAI, setIsGeneratingAI] = useState(false);
  const [showMenu, setShowMenu] = useState(false);

  // همگام‌سازی چت دو نفره با ادغام هوشمند جهت جلوگیری از ناپدید شدن پیام‌ها
  const fetchCloudflareChat = useCallback(async () => {
    try {
      const res = await fetch(`${WORKER_URL}/loveniya_chat.json`);
      if (res.ok) {
        const data = await res.json();
        if (data !== null && Array.isArray(data)) {
          setMessages((prev) => {
            if (data.length === 0) {
              localStorage.setItem('chat_messages_synced', JSON.stringify([]));
              return [];
            }
            const serverMap = new Map(data.map((m: ChatMessage) => [m.id, m]));
            const localOnly = prev.filter((m) => !serverMap.has(m.id));
            const merged = [...data, ...localOnly];
            localStorage.setItem('chat_messages_synced', JSON.stringify(merged));
            return merged;
          });
        }
      }
    } catch (e) {
      console.warn("Error fetching chat:", e);
    }
  }, []);

  const syncChatToServer = async (newMessages: ChatMessage[]) => {
    try {
      localStorage.setItem('chat_messages_synced', JSON.stringify(newMessages));
      await fetch(`${WORKER_URL}/loveniya_chat.json`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newMessages)
      });
    } catch (e) {
      console.error("Error syncing chat to server:", e);
    }
  };

  useEffect(() => {
    fetchCloudflareChat();
    const interval = setInterval(fetchCloudflareChat, 3000);
    return () => clearInterval(interval);
  }, [fetchCloudflareChat]);

  // Proactive Daily Game & Activity Reminder from AI in Chat
  useEffect(() => {
    const todayStr = new Date().toLocaleDateString('en-CA');
    const lastReminderDate = localStorage.getItem(`ai_reminder_sent_${currentUser}`);

    if (lastReminderDate !== todayStr) {
      let momentsData: any = {};
      try {
        const cached = localStorage.getItem('loveniya_moments_v2');
        if (cached) momentsData = JSON.parse(cached);
      } catch (e) {}

      const isDailyDoneToday = momentsData.dailyCompletedDates?.includes(todayStr) || false;
      const dilemmas = Array.isArray(momentsData.dilemmas) ? momentsData.dilemmas : [];
      const pendingDilemmas = dilemmas.filter((d: any) => {
        const choice = currentUser === 'amin' ? d.aminChoice : d.niyayeshChoice;
        return !choice;
      }).length;

      const secrets = Array.isArray(momentsData.secrets) ? momentsData.secrets : [];
      const pendingSecrets = secrets.filter((s: any) => s.creator === partnerId && s.status === 'locked').length;

      const dares = Array.isArray(momentsData.dares) ? momentsData.dares : [];
      const pendingDares = dares.filter((d: any) => d.sender === partnerId && !d.isCompleted).length;

      const totalPending = pendingDilemmas + pendingSecrets + pendingDares;
      const isUnplayed = !isDailyDoneToday || totalPending > 0;

      if (isUnplayed) {
        let reminderText = `✨ **یادآوری همراه هوشمند به ${myName} عزیز**:\n`;
        if (!isDailyDoneToday) {
          reminderText += `• آیین امروز در بخش **لحظه‌ها** هنوز ثبت نشده! 😉\n`;
        }
        if (totalPending > 0) {
          reminderText += `• شما **${totalPending} چالش** منتظر پاسخ داری.\n`;
        }

        const autoReminderMsg: ChatMessage = {
          id: `ai_remind_${Date.now()}`,
          senderId: 'ai',
          senderName: 'همراه هوشمند',
          text: reminderText,
          timestamp: new Date().toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' }),
          status: 'read'
        };

        setMessages((prev) => {
          if (prev.some(m => m.id.startsWith('ai_remind_'))) return prev;
          const updated = [...prev, autoReminderMsg];
          syncChatToServer(updated);
          return updated;
        });

        localStorage.setItem(`ai_reminder_sent_${currentUser}`, todayStr);
      }
    }
  }, [currentUser, myName, partnerId]);

  // اسکرول خودکار به آخرین پیام
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping, isGeneratingAI]);

  const handleClearHistory = async () => {
    setMessages([]);
    await syncChatToServer([]);
    setShowMenu(false);
  };

  // پاسخ خودکار همراه هوشمند
  const generateAutomaticAIReply = async (currentList: ChatMessage[], userQueryOverride?: string) => {
    if (isGeneratingAI) return;
    
    setIsGeneratingAI(true);
    setPartnerStatus('در حال نوشتن...');
    setIsTyping(true);

    try {
      const historyPayload = currentList.slice(-15).map(m => ({
        senderId: m.senderId,
        text: m.text
      }));

      const lastUserMsg = userQueryOverride || currentList[currentList.length - 1]?.text || '';

      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: lastUserMsg,
          currentUser: currentUser,
          isAmin: isAmin,
          history: historyPayload
        })
      });

      const data = await response.json();
      const rawReply = data.reply || 'SKIP';
      const replyText = rawReply.replace(/^["']|["']$/g, '').trim();

      if (replyText === 'SKIP' || !replyText) {
        return; // No need to reply to this message
      }

      const aiReplyMessage: ChatMessage = {
        id: `ai_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        senderId: 'ai',
        senderName: 'همراه هوشمند',
        text: replyText,
        timestamp: new Date().toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' }),
        status: 'read'
      };

      setMessages((prev) => {
        const updated = [...prev, aiReplyMessage];
        syncChatToServer(updated);
        return updated;
      });
    } catch (error) {
      console.error("AI reply error:", error);
    } finally {
      setIsGeneratingAI(false);
      setIsTyping(false);
      setPartnerStatus('آنلاین');
    }
  };

  // ارسال پیام
  const handleSend = async () => {
    if (!inputText.trim()) return;

    const userMsgText = inputText.trim();
    const userMessage: ChatMessage = {
      id: `msg_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      senderId: currentUser,
      senderName: myName,
      text: userMsgText,
      timestamp: new Date().toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' }),
      status: 'read'
    };

    setInputText('');

    let updatedList: ChatMessage[] = [];
    setMessages((prev) => {
      updatedList = [...prev, userMessage];
      syncChatToServer(updatedList);
      return updatedList;
    });

    setTimeout(() => {
      generateAutomaticAIReply(updatedList);
    }, 1200);
  };

  return (
    <div className="flex flex-col h-screen w-full bg-[#0e1621] text-white font-sans overflow-hidden" dir="rtl">
      
      {/* Header مدرن شبیه تلگرام */}
      <header className="flex-none bg-[#17212b] h-[58px] px-3 flex items-center gap-3 z-20 shadow-xs relative border-b border-[#242f3d]">
        <button onClick={() => navigate('/')} className="p-2 rounded-full hover:bg-[#2b3a4a] transition text-[#7f91a4]">
          <ArrowRight className="w-5 h-5" />
        </button>
        
        <div className={`w-10 h-10 rounded-2xl flex items-center justify-center text-white text-base font-bold cursor-pointer ${avatarColor} shadow-xs`}>
          {partnerInitial}
        </div>
        
        <div className="flex flex-col flex-1 justify-center cursor-pointer">
          <div className="flex items-center gap-2">
            <span className="text-white font-bold text-[15px] leading-tight">{partnerName}</span>
            <span className="text-[10px] bg-[#243342] text-sky-200 px-2 py-0.5 rounded-md font-bold border border-[#344658]">
              اکانت: {myName}
            </span>
          </div>
          <span className={`text-[12px] transition-colors duration-300 ${isTyping ? 'text-[#4bb4e6]' : 'text-[#7f91a4]'}`}>
            {isTyping ? 'در حال نوشتن...' : partnerStatus}
          </span>
        </div>

        <div className="relative">
          <button 
            onClick={() => setShowMenu(!showMenu)} 
            className="p-2 rounded-full hover:bg-[#2b3a4a] transition text-[#7f91a4]"
          >
            <MoreVertical className="w-5 h-5" />
          </button>

          {showMenu && (
            <div className="absolute left-0 top-12 bg-[#17212b] border border-[#2b3a4a] shadow-2xl rounded-2xl py-2 w-56 z-50 text-right text-xs">
              <button
                onClick={handleClearHistory}
                className="w-full text-right px-4 py-2.5 hover:bg-[#242f3d] text-rose-400 transition flex items-center justify-between"
              >
                <span>پاک کردن تاریخچه چت</span>
                <Trash2 className="w-4 h-4 text-rose-400" />
              </button>
            </div>
          )}
        </div>
      </header>

      {/* لیست پیام‌ها */}
      <main className="flex-1 overflow-y-auto p-4 flex flex-col gap-2.5" style={{ backgroundImage: 'url("https://web.telegram.org/a/chat-bg-pattern-dark.png")', backgroundSize: '360px', backgroundBlendMode: 'overlay', backgroundColor: '#0e1621' }}>
        {messages.length === 0 && (
          <div className="flex-1 flex flex-col items-center justify-center text-[#7f91a4] text-xs gap-2 py-12 my-auto">
            <div className="bg-[#17212b] border border-[#242f3d] rounded-2xl px-5 py-3 shadow-md text-center text-[13px] text-slate-300">
              تاریخچه چت پاک شده است. اولین پیام را ارسال کنید ✨
            </div>
          </div>
        )}
        {messages.map((msg, index) => {
          const isMe = msg.senderId === currentUser;
          const isAI = msg.senderId === 'ai';
          const showTail = index === messages.length - 1 || messages[index + 1]?.senderId !== msg.senderId;

          if (isAI) {
            return (
              <div key={msg.id || index} className="flex w-full justify-center my-1.5">
                <div className="bg-[#1f1a2e] border border-purple-800/60 text-purple-100 rounded-2xl px-4 py-2.5 max-w-[88%] sm:max-w-[78%] shadow-md">
                  <div className="flex items-center gap-1.5 text-[11px] font-bold text-purple-300 mb-1.5 border-b border-purple-800/40 pb-1">
                    <Sparkles className="w-3.5 h-3.5 text-purple-400" />
                    <span>{msg.senderName || 'همراه هوشمند'}</span>
                  </div>
                  <p className="text-[14px] leading-relaxed font-medium whitespace-pre-wrap">{msg.text}</p>
                  <div className="text-[10px] text-purple-400/70 text-left mt-1 select-none font-sans">{msg.timestamp}</div>
                </div>
              </div>
            );
          }

          return (
            <div key={msg.id || index} className={`flex w-full ${isMe ? 'justify-start' : 'justify-end'}`}>
              <div 
                className={`relative max-w-[82%] px-3.5 pt-2 pb-1.5 shadow-xs text-[15px] leading-relaxed break-words
                ${isMe 
                  ? `bg-[#2b5278] text-white ${showTail ? 'rounded-2xl rounded-br-none' : 'rounded-2xl'}` 
                  : `bg-[#182533] text-white ${showTail ? 'rounded-2xl rounded-bl-none' : 'rounded-2xl'}`
                }`}
              >
                {/* نام فرستنده */}
                <div className={`text-[11px] font-bold mb-0.5 ${isMe ? 'text-sky-200' : 'text-fuchsia-200'}`}>
                  {msg.senderName || (msg.senderId === 'amin' ? 'امین' : 'نیایش')}
                </div>

                {msg.text}
                
                {/* زمان و آیکون تیک خوانده شده */}
                <div className="float-left flex items-center gap-1 mt-1 ml-[-2px] mr-3 pt-1 select-none">
                  <span className={`text-[11px] ${isMe ? 'text-[#7aa5cd]' : 'text-[#7f91a4]'}`}>
                    {msg.timestamp}
                  </span>
                  
                  {isMe && (
                    <span className="text-[#4bb4e6] flex items-center">
                      <CheckCheck className="w-3.5 h-3.5" />
                    </span>
                  )}
                </div>
              </div>
            </div>
          );
        })}
        <div ref={messagesEndRef} className="h-2" />
      </main>

      {/* کادر ورود پیام مدرن */}
      <footer className="flex-none bg-[#17212b] px-3 py-2 flex items-end gap-2 border-t border-[#242f3d]">
        <div className="flex-1 bg-[#242f3d] rounded-2xl flex items-end min-h-[48px] max-h-[144px] relative border border-[#2d3a4c]">
          <textarea
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); } }}
            placeholder={`ارسال پیام به عنوان ${myName}...`}
            dir="rtl"
            className="flex-1 bg-transparent text-white placeholder-[#7f91a4] text-[15px] px-4 py-3 resize-none focus:outline-none max-h-[144px] overflow-y-auto"
            rows={1}
            style={{ minHeight: '48px' }}
          />
        </div>

        <button 
          onClick={handleSend} 
          disabled={!inputText.trim()}
          className="w-12 h-12 bg-[#2b5278] hover:bg-[#34608c] disabled:opacity-40 text-white rounded-2xl flex items-center justify-center flex-none transition shadow-md"
        >
          <Send className="w-5 h-5 ml-0.5" />
        </button>
      </footer>
    </div>
  );
}

export default AIChat;
