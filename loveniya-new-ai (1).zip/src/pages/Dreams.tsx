import { PageWrapper } from "../components/PageWrapper";
import React, { useState } from 'react';
import { Compass, Plus, Star, Trash2, Edit3, X, Heart, Loader2, Bot, Sparkles } from 'lucide-react';
import { useStore } from '../lib/store';
import { Dream } from '../lib/types';
import { KebabMenu, KebabMenuItem } from '../components/KebabMenu';
import { motion, AnimatePresence } from 'motion/react';
import { fetchLoveAI } from '../lib/ai';
import { useNavigate } from 'react-router';
import { useDreamDraft } from '../lib/draftStore';
import { dedupById } from '../lib/dedup';

export const Dreams: React.FC = () => {
  const { dreams, addDream, updateDream, removeDream } = useStore();
  const navigate = useNavigate();
  const { draft, setDraft, resetDraft } = useDreamDraft();
  
  const showForm = draft.showForm;
  const editingId = draft.editingId;
  const text = draft.text;

  const [activeDream, setActiveDream] = useState<Dream | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const formRef = React.useRef<HTMLDivElement>(null);
  
  // Keep activeDream in sync with any updates or removals
  React.useEffect(() => {
    if (activeDream) {
      const fresh = dreams.find(d => d.id === activeDream.id);
      if (fresh) {
        setActiveDream(fresh);
      } else {
        setActiveDream(null);
      }
    }
  }, [dreams]);

  const handleEdit = (dream: Dream) => {
    setActiveDream(null);
    setDraft({
      editingId: dream.id,
      text: dream.text,
      showForm: true
    });
    setTimeout(() => {
      formRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 120);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSaving || !text.trim()) return;

    setIsSaving(true);
    try {
      let finalText = text;

      if (editingId) {
        const existing = dreams.find(d => d.id === editingId);
        if (existing) {
          updateDream({
            ...existing,
            text: finalText
          });
        }
      } else {
        const newDream: Dream = {
          id: `dream_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
          text: finalText,
          date: new Date().toLocaleDateString('fa-IR'),
          pinned: false
        };
        addDream(newDream);
      }
      resetForm();
    } finally {
      setIsSaving(false);
    }
  };

  const resetForm = () => {
    resetDraft();
  };

  const [showCount, setShowCount] = useState(4);

  // Deduplicate and sort dreams: pinned ones first
  const uniqueDreams = React.useMemo(() => dedupById(dreams), [dreams]);
  const sortedDreams = React.useMemo(() => {
    return [...uniqueDreams].sort((a, b) => {
      if (a.pinned && !b.pinned) return -1;
      if (!a.pinned && b.pinned) return 1;
      return 0;
    });
  }, [uniqueDreams]);

  const displayedDreams = sortedDreams.slice(0, showCount);
  const hasMore = showCount < sortedDreams.length;
  const hasLess = showCount > 4;

  return (
    <PageWrapper>
      <AnimatePresence mode="wait">
        {activeDream ? (
        <motion.div 
          key="detail"
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: -20 }}
          transition={{ type: "spring", stiffness: 300, damping: 30 }}
          className="space-y-6 pb-6 w-full" dir="rtl"
        >
          <div className="glass-card rounded-3xl p-4 sm:p-6 md:p-10 relative overflow-hidden shadow-2xl bg-white/95 border-2 border-amber-100">
            <div className="flex justify-between items-start mb-6 border-b border-amber-100 pb-4 sm:pb-6">
              <div>
                <h2 className="text-xl md:text-3xl font-black text-amber-600 flex items-center gap-2 mb-1.5">
                  <Compass className="w-5 h-5 sm:w-7 sm:h-7 text-amber-500 shrink-0" /> آرزوی مشترک
                </h2>
                <p className="text-xs md:text-sm text-slate-500 font-bold flex items-center gap-1">
                   تاریخ ثبت: {activeDream.date}
                   {activeDream.pinned && (
                     <span className="inline-flex items-center gap-1 bg-amber-100 text-amber-600 px-2 py-0.5 rounded-full mr-3 text-[10px]">
                       <Star className="w-3 h-3 fill-amber-500" /> آرزوی برتر
                     </span>
                   )}
                </p>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <button 
                  onClick={() => handleEdit(activeDream)}
                  className="text-slate-600 hover:text-amber-600 bg-amber-50 hover:bg-amber-100 px-3 py-1.5 rounded-xl font-bold text-xs transition-colors flex items-center gap-1.5"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>ویرایش</span>
                </button>
                <button onClick={() => setActiveDream(null)} className="text-slate-400 hover:text-amber-500 bg-slate-50 p-2 rounded-full transition-colors shrink-0">
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="whitespace-pre-wrap text-base sm:text-lg md:text-xl font-black text-slate-700 leading-relaxed sm:leading-[2.5] mb-6 sm:mb-8 text-center px-2 sm:px-4"
            >
              "{activeDream.text}"
            </motion.div>


          </div>
        </motion.div>
      ) : (
        <motion.div 
          key="list"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          transition={{ type: "spring", stiffness: 300, damping: 30 }}
          className="space-y-6 w-full" dir="rtl"
        >
          {/* Layer 2: Top Banner Header */}
          <div className="bg-white/95 rounded-3xl p-5 sm:p-7 relative overflow-hidden border border-amber-200/90 shadow-xl shadow-amber-900/5">
            <div className="absolute inset-0 overflow-hidden rounded-3xl pointer-events-none">
              <div className="absolute top-0 left-0 w-64 h-64 bg-amber-100/40 rounded-full blur-3xl"></div>
              <div className="absolute bottom-0 right-0 w-64 h-64 bg-orange-100/30 rounded-full blur-3xl"></div>
            </div>

            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 relative z-10">
              <div className="flex items-center gap-3.5">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-500 text-white flex items-center justify-center shadow-md shadow-amber-500/20 shrink-0">
                  <Compass className="w-6 h-6" />
                </div>
                <div>
                  <h2 className="text-lg sm:text-xl font-black text-slate-800 flex items-center gap-2">
                    <span>آرزوهای مشترک</span>
                  </h2>
                  <p className="text-xs text-slate-500 font-bold mt-0.5">
                    اهداف، رویاها و جاهایی که باهم قراره بریم
                  </p>
                </div>
              </div>
              <button 
                onClick={() => {
                  if (showForm) {
                    resetForm();
                  } else {
                    setDraft({ showForm: true });
                  }
                }} 
                className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white text-xs font-bold px-4 py-2.5 rounded-2xl flex items-center gap-2 transition-all active:scale-95 shadow-md shadow-amber-500/20 shrink-0 self-stretch sm:self-auto justify-center"
              >
                <Plus className={`w-4 h-4 text-white transition-transform duration-300 ${showForm ? 'rotate-45' : ''}`} />
                <span>{showForm ? 'انصراف' : 'ثبت آرزوی جدید'}</span>
              </button>
            </div>

            {/* Add/Edit Form */}
            <AnimatePresence>
              {showForm && (
                <motion.div 
                  ref={formRef}
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="mt-6 relative z-10 pt-4 border-t border-amber-100"
                >
                  <form onSubmit={handleSave} className="space-y-4">
                    {editingId && (
                      <div className="bg-amber-50 border border-amber-200 text-amber-800 text-xs font-bold px-3.5 py-2.5 rounded-xl flex items-center gap-1.5">
                        <Edit3 className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                        <span>در حال ویرایش آرزوی مشترک</span>
                      </div>
                    )}
                    <div>
                      <label className="block text-xs font-extrabold text-slate-700 mb-1.5">شرح آرزو یا هدف مشترک:</label>
                      <textarea 
                        rows={4} 
                        placeholder="مثلا: یه روزی باهم بریم سفر به..." 
                        required 
                        value={text} 
                        onChange={e => setDraft({ text: e.target.value })}
                        className="w-full bg-white border border-slate-200 rounded-xl p-3.5 text-xs focus:border-amber-400 focus:outline-none leading-relaxed transition-all"
                      ></textarea>
                    </div>
                    <div className="flex justify-end gap-2 pt-1">
                      <button 
                        type="button" 
                        onClick={resetForm} 
                        className="bg-slate-100 text-slate-600 text-xs px-4 py-2 rounded-xl font-bold hover:bg-slate-200 transition-colors"
                      >
                        انصراف
                      </button>
                      <button 
                        type="submit" 
                        className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white text-xs font-bold px-6 py-2 rounded-xl transition-all shadow-md shadow-amber-500/20"
                      >
                        {editingId ? 'ذخیره تغییرات' : 'ثبت آرزو'}
                      </button>
                    </div>
                  </form>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Layer 2: Dreams Cards directly on page */}
          <div className="space-y-4">
            {sortedDreams.length === 0 ? (
              <div className="glass-card rounded-3xl p-10 text-center text-slate-500 text-xs flex flex-col items-center justify-center gap-3 border border-dashed border-amber-200">
                <div className="w-12 h-12 rounded-full bg-amber-50 flex items-center justify-center text-amber-500">
                  <Compass className="w-6 h-6" />
                </div>
                <p className="font-extrabold text-slate-700 text-sm">هنوز آرزویی ثبت نشده...</p>
                <p className="text-xs text-slate-400">با زدن دکمه «ثبت آرزوی جدید» اولین رویای مشترک را ثبت کن.</p>
              </div>
            ) : (
              displayedDreams.map((dream) => (
                <motion.div 
                  layout 
                  key={dream.id} 
                  onClick={() => setActiveDream(dream)} 
                  className={`cursor-pointer rounded-3xl transition-all relative group ${
                    dream.pinned 
                      ? 'bg-white/95 p-5 sm:p-6 border-2 border-amber-300/90 shadow-md shadow-amber-500/10 ring-1 ring-amber-200/50 hover:border-amber-400 hover:shadow-lg' 
                      : 'bg-white/95 p-5 sm:p-6 border border-stone-200/90 shadow-sm hover:border-amber-300 hover:shadow-md'
                  }`}
                >
                  {/* Card Top Header */}
                  <div className="flex justify-between items-center gap-2 mb-3">
                    <div className="flex items-center gap-2 flex-wrap">
                      {dream.pinned ? (
                        <span className="inline-flex items-center gap-1.5 bg-gradient-to-r from-amber-500 to-orange-500 text-white text-[10px] font-black px-2.5 py-0.5 rounded-full shadow-xs shrink-0">
                          <Star className="w-3 h-3 fill-amber-200 text-amber-200" />
                          <span>رویای برتر</span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-amber-800 text-[10px] font-extrabold bg-amber-50 px-2.5 py-0.5 rounded-full border border-amber-200">
                          <Compass className="w-3 h-3 text-amber-600" />
                          <span>رویای مشترک</span>
                        </span>
                      )}
                    </div>
                    
                    <div className="flex items-center gap-2 shrink-0" onClick={e => e.stopPropagation()}>
                      <KebabMenu>
                        <KebabMenuItem 
                          icon={<Star className={`w-4 h-4 ${dream.pinned ? 'text-amber-500 fill-amber-500' : 'text-slate-400'}`} />} 
                          label={dream.pinned ? 'برداشتن نشان برتر' : 'نشان کردن به عنوان برتر'} 
                          onClick={() => updateDream({ ...dream, pinned: !dream.pinned })} 
                        />
                        <KebabMenuItem 
                          icon={<Edit3 className="w-4 h-4 text-slate-500" />} 
                          label="ویرایش" 
                          onClick={() => handleEdit(dream)} 
                        />
                        <KebabMenuItem 
                          icon={<Trash2 className="w-4 h-4 text-rose-500" />} 
                          label="حذف" 
                          danger 
                          onClick={() => removeDream(dream.id)} 
                        />
                      </KebabMenu>
                    </div>
                  </div>

                  <p className={`text-xs sm:text-sm whitespace-pre-wrap leading-relaxed ${
                    dream.pinned ? 'text-stone-900 font-bold' : 'text-stone-800 font-medium'
                  }`}>
                    {dream.text}
                  </p>

                  <div className="flex items-center justify-between text-[10px] mt-3 pt-2.5 border-t border-slate-100 font-bold">
                    <span className={`px-2.5 py-0.5 rounded-full border ${
                      dream.pinned 
                        ? 'bg-amber-50 text-amber-800 border-amber-200 font-bold' 
                        : 'text-stone-700 bg-stone-100 border-stone-200/90 font-bold'
                    }`}>
                      {dream.date}
                    </span>
                    <span className={`transition-colors font-black text-[11px] ${
                      dream.pinned 
                        ? 'text-amber-700 group-hover:text-amber-900' 
                        : 'text-amber-700 group-hover:text-amber-900'
                    }`}>
                      مشاهده جزئیات ←
                    </span>
                  </div>
                </motion.div>
              ))
            )}
          </div>

          {sortedDreams.length > 4 && (
            <div className="flex justify-center gap-3 mt-6 relative z-10 pb-4">
              {hasMore && (
                <button onClick={() => setShowCount(c => c + 4)} className="bg-white/95 backdrop-blur-sm border border-amber-100 hover:bg-amber-50 text-amber-600 transition-all px-6 py-2.5 rounded-full font-bold text-xs flex items-center gap-2 shadow-sm active:scale-95">
                  <Heart className="w-4 h-4 text-amber-500 fill-amber-500" />
                  نمایش بیشتر ({sortedDreams.length - showCount})
                </button>
              )}
              {hasLess && (
                <button onClick={() => setShowCount(4)} className="bg-white/95 backdrop-blur-sm border border-slate-100 hover:bg-slate-50 text-slate-500 transition-all px-6 py-2.5 rounded-full font-bold text-xs flex items-center gap-2 shadow-sm active:scale-95">
                  نمایش کمتر
                </button>
              )}
            </div>
          )}
        </motion.div>
      )}
    </AnimatePresence>
    </PageWrapper>
  );
};
