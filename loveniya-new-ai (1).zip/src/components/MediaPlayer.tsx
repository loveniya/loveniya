import React, { useState, useRef, useEffect, useCallback } from 'react';
import { useStore } from '../lib/store';
import { 
  Play, Pause, SkipForward, SkipBack, Music, X, 
  Volume2, VolumeX, Repeat, Gauge, ChevronDown, 
  RotateCcw, RotateCw, ListMusic, Sparkles, Disc, Radio, Minimize2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

const defaultPlaylist = [
  {
    id: 'def-1',
    title: 'نغمه عاشقانه پیانو',
    artist: 'پیانو لایت بی‌کلام',
    url: 'https://cdn.pixabay.com/download/audio/2022/05/27/audio_1808fbf07a.mp3?filename=romantic-piano-112199.mp3',
    pinned: true
  },
  {
    id: 'def-2',
    title: 'آرامش شب‌های دو نفره',
    artist: 'Loveniya Light Melody',
    url: 'https://cdn.pixabay.com/download/audio/2022/03/15/audio_c8c8a7311b.mp3?filename=soft-romantic-piano-10651.mp3',
    pinned: false
  }
];

export const MediaPlayer: React.FC = () => {
  const { playlist } = useStore();
  const audioRef = useRef<HTMLAudioElement>(null);

  const activePlaylist = playlist.length > 0 ? playlist : defaultPlaylist;

  const [isOpen, setIsOpen] = useState(true); 
  const [isMinimized, setIsMinimized] = useState(true);
  const [isExpanded, setIsExpanded] = useState(false);
  const [showQueue, setShowQueue] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [played, setPlayed] = useState(0);
  const [duration, setDuration] = useState(0);
  const [seeking, setSeeking] = useState(false);
  const [volume, setVolume] = useState(0.8);
  const [muted, setMuted] = useState(false);
  const [loop, setLoop] = useState(false);
  const [playbackRate, setPlaybackRate] = useState(1);

  const currentTrack = activePlaylist[currentIndex] || activePlaylist[0];

  const handleNext = useCallback(() => {
    if (activePlaylist.length === 0) return;
    setCurrentIndex((prev) => (prev + 1) % activePlaylist.length);
    setIsPlaying(true);
    setPlayed(0);
  }, [activePlaylist.length]);

  const handlePrev = useCallback(() => {
    if (activePlaylist.length === 0) return;
    setCurrentIndex((prev) => (prev - 1 + activePlaylist.length) % activePlaylist.length);
    setIsPlaying(true);
    setPlayed(0);
  }, [activePlaylist.length]);

  // Sync state with HTML5 audio element for seamless background playback
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    if (isPlaying && currentTrack) {
      audio.play().catch((err) => {
        console.warn("Background audio play error:", err);
        setIsPlaying(false);
      });
    } else {
      audio.pause();
    }
  }, [isPlaying, currentIndex, currentTrack]);

  // Register Media Session API for mobile background audio playback controls
  useEffect(() => {
    if ('mediaSession' in navigator && currentTrack) {
      try {
        navigator.mediaSession.metadata = new MediaMetadata({
          title: currentTrack.title || 'آهنگ عاشقانه',
          artist: currentTrack.artist || 'Loveniya',
          album: 'Loveniya Romantic Playlist',
          artwork: [
            { src: 'https://images.unsplash.com/photo-1518199266791-5375a83190b7?w=300&q=80', sizes: '300x300', type: 'image/jpeg' }
          ]
        });

        navigator.mediaSession.setActionHandler('play', () => setIsPlaying(true));
        navigator.mediaSession.setActionHandler('pause', () => setIsPlaying(false));
        navigator.mediaSession.setActionHandler('previoustrack', () => handlePrev());
        navigator.mediaSession.setActionHandler('nexttrack', () => handleNext());
      } catch (e) {
        console.warn("MediaSession error:", e);
      }
    }
  }, [currentTrack, handleNext, handlePrev]);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = volume;
      audioRef.current.muted = muted;
    }
  }, [volume, muted]);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.playbackRate = playbackRate;
    }
  }, [playbackRate]);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.loop = loop;
    }
  }, [loop]);

  // Listen for custom play_song event from Music page or other components
  useEffect(() => {
    const handlePlaySong = (e: Event) => {
      const customEvent = e as CustomEvent<string>;
      const songId = customEvent.detail;
      const index = activePlaylist.findIndex((s) => s.id === songId);
      if (index !== -1) {
        setCurrentIndex(index);
        setIsPlaying(true);
        setPlayed(0);
        setIsOpen(true);
        setIsMinimized(false);
        setIsExpanded(true);
      }
    };

    window.addEventListener('play_song', handlePlaySong);
    return () => window.removeEventListener('play_song', handlePlaySong);
  }, [activePlaylist]);

  // Keep currentIndex in bounds if playlist changes
  useEffect(() => {
    if (currentIndex >= activePlaylist.length && activePlaylist.length > 0) {
      setCurrentIndex(0);
    }
  }, [activePlaylist, currentIndex]);

  const jumpSeconds = useCallback((seconds: number) => {
    if (!audioRef.current) return;
    const newTime = Math.min(Math.max(0, audioRef.current.currentTime + seconds), duration);
    audioRef.current.currentTime = newTime;
    if (duration > 0) {
      setPlayed(newTime / duration);
    }
  }, [duration]);

  const handleSeekChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setPlayed(val);
  };

  const handleSeekMouseDown = () => {
    setSeeking(true);
  };

  const handleSeekMouseUp = (e: React.SyntheticEvent<HTMLInputElement>) => {
    setSeeking(false);
    const target = e.currentTarget;
    const val = parseFloat(target.value);
    setPlayed(val);
    if (audioRef.current && duration > 0) {
      audioRef.current.currentTime = val * duration;
    }
  };

  const formatTime = (seconds: number) => {
    if (isNaN(seconds) || seconds < 0) return '00:00';
    const date = new Date(seconds * 1000);
    const mm = date.getUTCMinutes();
    const ss = date.getUTCSeconds().toString().padStart(2, '0');
    return `${mm.toString().padStart(2, '0')}:${ss}`;
  };

  const speedOptions = [0.75, 1, 1.25, 1.5, 2];

  return (
    <>
      {/* Permanent Background HTML5 Audio Element */}
      {currentTrack && (
        <audio
          ref={audioRef}
          src={currentTrack.url}
          preload="auto"
          onLoadedMetadata={(e) => {
            setDuration(e.currentTarget.duration || 0);
          }}
          onTimeUpdate={(e) => {
            if (!seeking && e.currentTarget.duration) {
              setPlayed(e.currentTarget.currentTime / e.currentTarget.duration);
            }
          }}
          onEnded={handleNext}
          onError={(err) => console.error("Audio player error:", err)}
          className="hidden"
        />
      )}



      {/* Bottom Floating Music Bar Shortcut - Positioned above bottom navigation bar */}
      <AnimatePresence>
        {isOpen && (
          isMinimized ? (
            /* Minimized State: A small spinning vinyl turntable circle button at the bottom corner */
            <motion.div
              key="minimized-gramophone"
              initial={{ opacity: 0, scale: 0.8, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.8, y: 20 }}
              className="fixed bottom-[72px] sm:bottom-[80px] left-4 sm:left-6 z-40"
              dir="rtl"
            >
              <button
                onClick={() => setIsMinimized(false)}
                className={`p-2 rounded-full text-white shadow-2xl border backdrop-blur-xl flex items-center justify-center transition-all hover:scale-105 active:scale-95 group ${
                  isPlaying 
                    ? 'bg-stone-950/95 border-rose-500/60 shadow-rose-950/40 ring-2 ring-rose-500/30' 
                    : 'bg-stone-900/95 border-stone-700/80 shadow-black/40'
                }`}
                title="باز کردن کنترل سریع پخش موزیک"
              >
                {/* Vinyl Record Turntable Disc with groove highlights and visible asymmetric rotational marker */}
                <div 
                  className="w-8 h-8 rounded-full bg-slate-950 flex items-center justify-center text-white relative overflow-hidden shadow-inner border border-white/20"
                  style={{ animation: isPlaying ? 'spin 3s linear infinite' : 'none' }}
                >
                  {/* Vinyl Concentric Ring Grooves */}
                  <div className="absolute inset-1 rounded-full border border-white/10 pointer-events-none" />
                  <div className="absolute inset-2 rounded-full border border-white/10 pointer-events-none" />
                  
                  {/* Glossy Reflective Sheen Angle */}
                  <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/15 to-transparent pointer-events-none" />

                  {/* Asymmetric White Groove Notch for distinct, visible 360° rotation */}
                  <div className="absolute w-1 h-3.5 bg-gradient-to-b from-white to-rose-300 top-0 left-1/2 -translate-x-1/2 rounded-full opacity-90 z-10" />

                  {/* Center Label & Spindle */}
                  <div className="w-3.5 h-3.5 rounded-full bg-gradient-to-tr from-rose-600 via-pink-500 to-amber-400 flex items-center justify-center z-20 border border-white/40 shadow-xs">
                    <div className="w-1 h-1 bg-stone-950 rounded-full border border-white/80" />
                  </div>
                </div>
              </button>
            </motion.div>
          ) : (
            /* Expanded Floating Bar Shortcut at Bottom Corner */
            <motion.div
              key="expanded-bar"
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="fixed bottom-[72px] sm:bottom-[80px] left-4 sm:left-6 z-40 flex items-center max-w-[calc(100vw-32px)] sm:max-w-md"
              dir="rtl"
            >
              <div
                onClick={() => setIsExpanded(true)}
                className={`px-3 py-1.5 rounded-full shadow-2xl backdrop-blur-xl border flex items-center gap-2.5 transition-all cursor-pointer ${
                  isPlaying 
                    ? 'bg-stone-900/95 text-white border-rose-500/50 shadow-rose-950/30' 
                    : 'bg-white/95 text-slate-800 border-slate-200/90 hover:bg-white shadow-slate-300/50'
                }`}
              >
                {/* Spinning Turntable Icon */}
                <div 
                  className="w-7 h-7 rounded-full bg-slate-950 flex items-center justify-center text-white shrink-0 shadow-xs relative overflow-hidden border border-white/30"
                  style={{ animation: isPlaying ? 'spin 3s linear infinite' : 'none' }}
                >
                  <div className="absolute inset-1 rounded-full border border-white/10 pointer-events-none" />
                  <div className="absolute w-1 h-3 bg-gradient-to-b from-white to-rose-300 top-0 left-1/2 -translate-x-1/2 rounded-full opacity-90 z-10" />
                  <div className="w-3 h-3 rounded-full bg-gradient-to-tr from-rose-600 to-amber-400 flex items-center justify-center z-20 border border-white/40">
                    <div className="w-1 h-1 bg-slate-950 rounded-full" />
                  </div>
                </div>

                {/* Track Title ONLY (No singer name to eliminate wasted space) */}
                <div className="flex items-center min-w-0 max-w-[140px] sm:max-w-[200px] text-right">
                  <span className="text-[11px] font-black truncate leading-tight">
                    {currentTrack?.title || 'موزیک ما'}
                  </span>
                </div>

                {/* Action Controls */}
                <div className="flex items-center gap-1 shrink-0 border-r border-slate-500/20 pr-1.5 mr-0.5" onClick={(e) => e.stopPropagation()}>
                  {/* Play / Pause */}
                  <button
                    onClick={() => setIsPlaying(!isPlaying)}
                    className="w-6 h-6 rounded-full bg-rose-600 hover:bg-rose-500 text-white flex items-center justify-center transition-transform active:scale-90 shadow-2xs"
                    title={isPlaying ? 'توقف' : 'پخش'}
                  >
                    {isPlaying ? (
                      <Pause className="w-3 h-3 fill-white" />
                    ) : (
                      <Play className="w-3 h-3 fill-white ml-0.5" />
                    )}
                  </button>

                  {/* Next Track */}
                  <button
                    onClick={handleNext}
                    className="p-1 rounded-full text-slate-400 hover:text-rose-500 transition-colors"
                    title="آهنگ بعدی"
                  >
                    <SkipForward className="w-3.5 h-3.5 fill-current" />
                  </button>

                  {/* Minimize to Small Circle Button */}
                  <button
                    onClick={() => setIsMinimized(true)}
                    className="p-1 rounded-full text-slate-400 hover:text-amber-400 transition-colors"
                    title="کوچک‌سازی به دکمه شناور"
                  >
                    <Minimize2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </motion.div>
          )
        )}
      </AnimatePresence>

      {/* Full-Screen Music Player View */}
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ opacity: 0, y: "100%" }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: "100%" }}
            transition={{ type: "spring", damping: 28, stiffness: 280 }}
            className="fixed inset-0 z-50 w-full h-full bg-gradient-to-b from-stone-900 via-slate-900 to-stone-950 text-white flex flex-col justify-between p-4 sm:p-6 overflow-y-auto"
            dir="rtl"
          >
            {/* Top Navigation Header */}
            <div className="flex items-center justify-between w-full max-w-xl mx-auto pt-1 pb-3 border-b border-white/10 shrink-0">
              <button
                onClick={() => setIsExpanded(false)}
                className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-slate-200 transition-colors flex items-center gap-1.5 text-xs font-bold"
                title="بستن و بازگشت"
              >
                <ChevronDown className="w-5 h-5 text-white" />
                <span className="hidden sm:inline">کوچک‌کردن</span>
              </button>

              <div className="text-center">
                <span className="text-[10px] uppercase tracking-widest text-rose-400 font-bold block">درحال پخش</span>
                <h3 className="text-xs sm:text-sm font-black text-slate-100">پخش‌کننده تمام‌صفحه</h3>
              </div>

              <button
                onClick={() => setShowQueue(!showQueue)}
                className={`p-2 rounded-full transition-all flex items-center gap-1.5 text-xs font-bold ${
                  showQueue ? 'bg-rose-600 text-white shadow-lg' : 'bg-white/10 text-slate-200 hover:bg-white/20'
                }`}
                title="لیست پخش"
              >
                <ListMusic className="w-5 h-5" />
                <span className="hidden sm:inline">لیست</span>
              </button>
            </div>

            {/* Main Content Area */}
            <div className="flex-1 flex flex-col items-center justify-center w-full max-w-xl mx-auto py-2 my-auto">
              {showQueue ? (
                /* Full Screen Playlist Queue */
                <div className="w-full space-y-2 max-h-[60vh] overflow-y-auto custom-scroll pl-1 pr-1">
                  <div className="flex items-center justify-between mb-3 px-1">
                    <h4 className="text-sm font-black text-rose-300 flex items-center gap-2">
                      <ListMusic className="w-4 h-4 text-rose-400" />
                      <span>لیست آهنگ‌ها ({activePlaylist.length})</span>
                    </h4>
                    <span className="text-xs text-slate-400">برای پخش لمس کنید</span>
                  </div>

                  {activePlaylist.map((song, idx) => {
                    const isSelected = idx === currentIndex;
                    return (
                      <div
                        key={song.id}
                        onClick={() => {
                          setCurrentIndex(idx);
                          setIsPlaying(true);
                        }}
                        className={`p-3 rounded-2xl flex items-center justify-between gap-4 cursor-pointer transition-all border ${
                          isSelected 
                            ? 'bg-rose-600/30 border-rose-500/60 text-white shadow-md font-bold' 
                            : 'bg-white/5 border-white/5 hover:bg-white/10 text-slate-300'
                        }`}
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <div className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 ${
                            isSelected ? 'bg-rose-500 text-white shadow-sm' : 'bg-slate-800 text-slate-400'
                          }`}>
                            {isSelected && isPlaying ? (
                              <Pause className="w-4 h-4 fill-white" />
                            ) : (
                              <Play className="w-4 h-4 fill-current ml-0.5" />
                            )}
                          </div>
                          <div className="min-w-0">
                            <p className="text-xs sm:text-sm font-bold truncate">{song.title}</p>
                            <p className="text-[11px] text-slate-400 truncate">{song.artist}</p>
                          </div>
                        </div>
                        {isSelected && (
                          <span className="text-[10px] font-bold text-rose-300 bg-rose-500/20 px-2.5 py-0.5 rounded-full border border-rose-500/30">
                            درحال پخش
                          </span>
                        )}
                      </div>
                    );
                  })}
                </div>
              ) : (
                /* Full Screen Track Display & Gramophone Record Player Deck */
                <div className="w-full flex flex-col items-center">
                  {/* Gramophone Record Turntable Deck Platter */}
                  <div className="relative my-4 p-4 sm:p-5 rounded-3xl bg-gradient-to-b from-stone-900/90 via-stone-950 to-slate-950 border border-stone-800 shadow-[0_20px_60px_rgba(0,0,0,0.8)] flex items-center justify-center">
                    
                    {/* Metallic Tonearm Needle Arm Mechanism */}
                    <div 
                      className="absolute -top-1 right-6 sm:right-10 z-30 transition-transform origin-top-right duration-700 pointer-events-none" 
                      style={{ transform: isPlaying ? 'rotate(26deg)' : 'rotate(0deg)' }}
                    >
                      {/* Pivot Base */}
                      <div className="w-6 h-6 rounded-full bg-gradient-to-br from-stone-400 via-amber-200 to-stone-600 shadow-lg border border-stone-300 flex items-center justify-center -mr-1">
                        <div className="w-2.5 h-2.5 rounded-full bg-stone-900 border border-stone-500" />
                      </div>
                      {/* Tone Arm Rod */}
                      <div className="w-2 h-20 bg-gradient-to-b from-amber-100 via-stone-300 to-stone-500 rounded-full shadow-md border border-white/20 -mt-1 mr-1.5" />
                      {/* Stylus Head Cartridge */}
                      <div className="w-4 h-6 bg-gradient-to-br from-rose-600 to-pink-700 rounded-md -mt-1 mr-0.5 shadow-md border border-white/40 flex items-center justify-center">
                        <div className="w-1 h-2 bg-amber-200 rounded-full shadow-xs" />
                      </div>
                    </div>

                    {/* Platter Outer Ring */}
                    <div className="p-2 sm:p-2.5 rounded-full bg-gradient-to-tr from-stone-800 via-stone-600 to-stone-800 shadow-2xl border border-stone-600/50">
                      {/* Spinning Vinyl Record Disc */}
                      <div 
                        className="w-48 h-48 sm:w-64 sm:h-64 rounded-full bg-slate-950 p-1.5 shadow-[0_0_50px_rgba(244,114,182,0.25)] flex items-center justify-center relative shrink-0 overflow-hidden"
                        style={{ animation: isPlaying ? 'spin 6s linear infinite' : 'none' }}
                      >
                        {/* Vinyl Concentric Ring Grooves */}
                        <div className="absolute inset-2 rounded-full border border-white/10 pointer-events-none" />
                        <div className="absolute inset-5 rounded-full border border-white/10 pointer-events-none" />
                        <div className="absolute inset-8 rounded-full border border-white/10 pointer-events-none" />
                        <div className="absolute inset-12 rounded-full border border-white/10 pointer-events-none" />
                        <div className="absolute inset-16 rounded-full border border-white/10 pointer-events-none" />
                        <div className="absolute inset-20 rounded-full border border-white/10 pointer-events-none" />

                        {/* Light Refraction Glossy Sheen Overlay */}
                        <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/10 to-transparent pointer-events-none" />
                        <div className="absolute inset-0 bg-gradient-to-bl from-transparent via-rose-500/10 to-transparent pointer-events-none" />

                        {/* Asymmetric White Groove Notch for visible rotation */}
                        <div className="absolute w-1.5 h-6 bg-gradient-to-b from-white to-rose-300 top-1 left-1/2 -translate-x-1/2 rounded-full opacity-80 z-10" />

                        {/* Gramophone Record Label Center */}
                        <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-full bg-gradient-to-tr from-rose-600 via-pink-600 to-amber-500 flex flex-col items-center justify-center text-white shadow-inner z-20 border-4 border-stone-900 relative p-1 text-center">
                          <Disc className="w-6 h-6 sm:w-8 sm:h-8 opacity-90" />
                          <span className="text-[9px] font-black tracking-tight text-white/90 truncate max-w-full px-1">Loveniya</span>
                          <div className="absolute w-2.5 h-2.5 rounded-full bg-stone-950 border border-white/60 shadow-xs" />
                        </div>
                      </div>
                    </div>
                  </div>


                  {/* Song Meta Information */}
                  <div className="text-center space-y-1 my-2 max-w-full px-4">
                    <h2 className="text-lg sm:text-2xl font-black text-white truncate tracking-tight">{currentTrack?.title || 'انتخاب آهنگ'}</h2>
                    <p className="text-xs sm:text-sm font-bold text-rose-400 truncate">{currentTrack?.artist || 'ناشناس'}</p>
                  </div>

                  {/* Full Width Scannable Timeline Slider */}
                  <div className="w-full max-w-md space-y-1 my-2" dir="ltr">
                    <input
                      type="range"
                      min={0}
                      max={0.999999}
                      step="any"
                      value={played}
                      onChange={handleSeekChange}
                      onMouseDown={handleSeekMouseDown}
                      onMouseUp={handleSeekMouseUp}
                      onTouchStart={handleSeekMouseDown}
                      onTouchEnd={handleSeekMouseUp}
                      className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-rose-500 hover:h-2 transition-all"
                    />
                    <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 font-bold">
                      <span>{formatTime(played * duration)}</span>
                      <span>{formatTime(duration)}</span>
                    </div>
                  </div>

                  {/* Main Playback Control Cluster */}
                  <div className="flex items-center justify-center gap-3 sm:gap-5 my-2">
                    <button 
                      onClick={handlePrev} 
                      className="p-2.5 rounded-full text-slate-300 hover:text-white hover:bg-white/10 transition-colors active:scale-90"
                      title="آهنگ قبلی"
                    >
                      <SkipBack className="w-5 h-5 sm:w-6 sm:h-6 fill-current" />
                    </button>

                    <button
                      onClick={() => jumpSeconds(-10)}
                      className="p-2.5 rounded-full text-slate-300 hover:text-white hover:bg-white/10 transition-colors active:scale-90"
                      title="۱۰ ثانیه قبل"
                    >
                      <RotateCcw className="w-4 h-4 sm:w-5 sm:h-5" />
                    </button>
                    
                    <button 
                      onClick={() => setIsPlaying(!isPlaying)}
                      className="w-14 h-14 sm:w-18 sm:h-18 bg-gradient-to-tr from-rose-600 via-pink-500 to-rose-700 rounded-full flex items-center justify-center text-white shadow-xl shadow-rose-600/40 hover:scale-105 active:scale-95 transition-all border-2 border-white/20"
                      title={isPlaying ? 'توقف' : 'پخش'}
                    >
                      {isPlaying ? <Pause className="w-7 h-7 sm:w-8 sm:h-8 fill-white" /> : <Play className="w-7 h-7 sm:w-8 sm:h-8 fill-white ml-1" />}
                    </button>

                    <button
                      onClick={() => jumpSeconds(10)}
                      className="p-2.5 rounded-full text-slate-300 hover:text-white hover:bg-white/10 transition-colors active:scale-90"
                      title="۱۰ ثانیه بعد"
                    >
                      <RotateCw className="w-4 h-4 sm:w-5 sm:h-5" />
                    </button>

                    <button 
                      onClick={handleNext} 
                      className="p-2.5 rounded-full text-slate-300 hover:text-white hover:bg-white/10 transition-colors active:scale-90"
                      title="آهنگ بعدی"
                    >
                      <SkipForward className="w-5 h-5 sm:w-6 sm:h-6 fill-current" />
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Bottom Footer Controls (Volume, Repeat & Speed) */}
            <div className="w-full max-w-xl mx-auto pt-3 border-t border-white/10 space-y-2 shrink-0">
              <div className="flex items-center justify-between text-xs font-bold text-slate-300 px-2">
                <button onClick={() => setMuted(!muted)} className="flex items-center gap-1.5 hover:text-rose-400 transition-colors">
                  {muted || volume === 0 ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4" />}
                  <span className="text-[11px]">صدا</span>
                </button>
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.05}
                  value={muted ? 0 : volume}
                  onChange={(e) => {
                    const val = parseFloat(e.target.value);
                    setVolume(val);
                    setMuted(val === 0);
                  }}
                  className="w-32 sm:w-44 h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-rose-500"
                  dir="ltr"
                />
              </div>

              <div className="flex items-center justify-between pt-0.5 px-2 text-xs font-bold">
                <button
                  onClick={() => setLoop(!loop)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border transition-all text-[11px] ${
                    loop ? 'bg-rose-500/20 text-rose-300 border-rose-500/50 shadow-sm' : 'bg-white/5 text-slate-400 border-white/10 hover:bg-white/10'
                  }`}
                >
                  <Repeat className="w-3.5 h-3.5" />
                  <span>تکرار مداوم</span>
                </button>

                <div className="flex items-center gap-1 bg-white/5 p-1 rounded-xl border border-white/10">
                  <Gauge className="w-3.5 h-3.5 text-slate-400 ml-1" />
                  {speedOptions.map((rate) => (
                    <button
                      key={rate}
                      onClick={() => setPlaybackRate(rate)}
                      className={`px-1.5 py-0.5 rounded-lg text-[10px] font-black transition-all ${
                        playbackRate === rate ? 'bg-rose-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      {rate}x
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};
