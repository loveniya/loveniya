import React, { useState } from 'react';
import { Lock, Eye, EyeOff, AlertCircle, Sparkles, User } from 'lucide-react';
import clsx from 'clsx';

export const LockScreen: React.FC<{ onUnlock: () => void }> = ({ onUnlock }) => {
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState(false);
  const [selectedUser, setSelectedUser] = useState<'amin' | 'niyayesh' | null>(null);
  const [userError, setUserError] = useState(false);

  const normalizeFa = (str: string) => {
    return str
      .replace(/[\u200B-\u200D\uFEFF\s]/g, '')
      .replace(/ي/g, 'ی')
      .replace(/ك/g, 'ک')
      .replace(/[0-9]/g, d => '۰۱۲۳۴۵۶۷۸۹'[parseInt(d)])
      .toLowerCase();
  };

  const checkPassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUser) {
      setUserError(true);
      return;
    }
    const raw = normalizeFa(password);
    const valid = normalizeFa('دوست دارم عشقم');
    
    if (raw === valid) {
      localStorage.setItem('loveniya_unlocked', 'true');
      localStorage.setItem('loveniya_user', selectedUser);
      onUnlock();
    } else {
      setError(true);
      setPassword('');
    }
  };

  return (
    <div className="fixed inset-0 z-[100] bg-gradient-to-br from-sky-100/95 via-rose-100/95 to-purple-100/95 backdrop-blur-xl flex items-center justify-center p-6 transition-opacity duration-300">
      <div className="glass-modal rounded-3xl p-8 max-w-sm w-full text-center relative overflow-hidden">
        <div className="absolute -top-12 -right-12 w-32 h-32 bg-sky-300/30 rounded-full blur-2xl"></div>
        <div className="absolute -bottom-12 -left-12 w-32 h-32 bg-rose-300/30 rounded-full blur-2xl"></div>
        
        <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-rose-400 to-sky-400 text-white flex items-center justify-center mx-auto mb-4 shadow-lg glow-pulse">
          <Lock className="w-7 h-7" />
        </div>
        
        <h2 className="text-xl font-black text-slate-800 mb-1">به جهان امین و نیایش خوش آمدی 💕</h2>
        <p className="text-xs text-slate-500 mb-6">برای ورود، رمز عاشقانه رو وارد کن...</p>
        
        <form onSubmit={checkPassword} className="space-y-4">
          <div className="grid grid-cols-2 gap-3 mb-2">
            <button
              type="button"
              onClick={() => { setSelectedUser('amin'); setUserError(false); }}
              className={clsx(
                "py-3 px-4 rounded-2xl border-2 font-bold text-sm transition-all flex items-center justify-center gap-2",
                selectedUser === 'amin' 
                  ? "border-sky-400 bg-sky-50 text-sky-700 shadow-sm" 
                  : "border-slate-100 bg-white/60 text-slate-500 hover:bg-white"
              )}
            >
              <User className="w-4 h-4" />
              امین
            </button>
            <button
              type="button"
              onClick={() => { setSelectedUser('niyayesh'); setUserError(false); }}
              className={clsx(
                "py-3 px-4 rounded-2xl border-2 font-bold text-sm transition-all flex items-center justify-center gap-2",
                selectedUser === 'niyayesh' 
                  ? "border-rose-400 bg-rose-50 text-rose-700 shadow-sm" 
                  : "border-slate-100 bg-white/60 text-slate-500 hover:bg-white"
              )}
            >
              <User className="w-4 h-4" />
              نیایش
            </button>
          </div>
          
          {userError && (
            <p className="text-[11px] text-rose-500 font-bold mb-1">لطفاً اول مشخص کن که کی هستی عزیزم ❤️</p>
          )}

          <div className="relative flex items-center">
            <input 
              type={showPassword ? 'text' : 'password'}
              placeholder="رمز عبور..." 
              value={password}
              onChange={(e) => { setPassword(e.target.value); setError(false); }}
              className="w-full text-center bg-white/80 border border-rose-200 rounded-2xl px-10 py-3.5 text-sm focus:border-rose-400 focus:bg-white focus:outline-none transition-all shadow-inner font-bold text-slate-700"
            />
            <button 
              type="button" 
              onClick={() => setShowPassword(!showPassword)} 
              className="absolute left-3 text-slate-400 hover:text-rose-500 p-1"
            >
              {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
          
          {error && (
            <p className="text-xs text-rose-500 font-bold flex items-center justify-center gap-1">
              <AlertCircle className="w-3.5 h-3.5" /> رمز اشتباهه عشقم، دوباره امتحان کن 🙈
            </p>
          )}
          
          <button type="submit" className="w-full bg-gradient-to-r from-rose-400 via-pink-400 to-sky-400 text-white font-bold py-3.5 rounded-2xl hover:opacity-95 transition-all shadow-md active:scale-95 flex items-center justify-center gap-2 mt-2">
            <span>ورود به سایت</span>
            <Sparkles className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
