import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Heart } from 'lucide-react';

interface Particle {
  id: number;
  x: number;
  y: number;
}

export const RomanticEffects: React.FC = () => {
  const [clicks, setClicks] = useState<Particle[]>([]);

  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      // Don't spawn hearts if clicking on a button or input
      const target = e.target as HTMLElement;
      if (target.tagName === 'BUTTON' || target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.closest('button')) {
        return;
      }

      const newParticle = { id: Date.now(), x: e.clientX, y: e.clientY };
      setClicks((prev) => [...prev, newParticle]);

      // Remove after animation completes
      setTimeout(() => {
        setClicks((prev) => prev.filter(p => p.id !== newParticle.id));
      }, 1000);
    };

    window.addEventListener('click', handleClick);
    return () => window.removeEventListener('click', handleClick);
  }, []);

  // Spawn some floating particles continuously in the background
  const [floaters, setFloaters] = useState<{id: number, left: string, delay: string, duration: string}[]>([]);
  
  useEffect(() => {
    // Distribute 20 hearts evenly across 100vw, with minor randomness so they don't form a perfect grid
    const newFloaters = Array.from({ length: 20 }).map((_, i) => ({
      id: i,
      left: `${(i * 5) + (Math.random() * 3 - 1.5)}vw`,
      delay: `-${Math.random() * 25}s`,
      duration: `${18 + Math.random() * 10}s` // Add varying durations to avoid lines
    }));
    setFloaters(newFloaters);
  }, []);

  return (
    <>
      {/* Background Floating Particles */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        {floaters.map(f => (
          <div
            key={f.id}
            className="absolute bottom-[-10vh] text-rose-300/50"
            style={{
              left: f.left,
              animation: `floatUp ${f.duration} linear infinite`,
              animationDelay: f.delay,
              fontSize: `${Math.random() * 20 + 18}px`
            }}
          >
            ❤
          </div>
        ))}
      </div>

      {/* Click Hearts */}
      <div className="fixed inset-0 pointer-events-none z-50">
        <AnimatePresence>
          {clicks.map(click => (
            <motion.div
              key={click.id}
              initial={{ scale: 0, opacity: 1, x: click.x - 12, y: click.y - 12 }}
              animate={{ 
                scale: 1.5, 
                opacity: 0,
                y: click.y - 50 
              }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.8, ease: "easeOut" }}
              className="absolute text-rose-500"
            >
              <Heart className="w-6 h-6 fill-rose-500" />
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      <style dangerouslySetInnerHTML={{__html: `
        @keyframes floatUp {
          0% { transform: translate(0, 0) rotate(0deg); opacity: 0; }
          10% { opacity: 0.45; }
          50% { transform: translate(30px, -55vh) rotate(180deg); opacity: 0.45; }
          90% { opacity: 0.45; }
          100% { transform: translate(-20px, -110vh) rotate(360deg); opacity: 0; }
        }
      `}} />
    </>
  );
};
