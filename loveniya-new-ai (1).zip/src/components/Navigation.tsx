import React, { useState, useRef, useEffect } from 'react';
import { NavLink } from 'react-router';
import { 
  Heart, Clock, Camera, HeartHandshake, Compass, Music, Mail, 
  Settings, AlertCircle, MessageSquare, MoreVertical, X, Sparkles, Home, MessageCircle 
} from 'lucide-react';
import clsx from 'clsx';
import { useStore } from '../lib/store';
import { motion, AnimatePresence } from 'motion/react';

export const Navigation: React.FC = () => {
  const { syncStatus, syncError } = useStore();
  const [showDropdownMenu, setShowDropdownMenu] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  // Lock body scroll when dropdown is open
  useEffect(() => {
    if (showDropdownMenu) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [showDropdownMenu]);

  // Close dropdown menu on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setShowDropdownMenu(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const navItems = [
    { to: '/', label: 'خانه', icon: <Home className="w-5 h-5 text-rose-500" />, desc: 'صفحه اصلی و روزشمار عشق' },
    { to: '/magic', label: 'چت هوشمند', icon: <MessageCircle className="w-5 h-5 text-indigo-500" />, desc: 'چت‌روم هوشمند سه‌نفره و دستیار' },
    { to: '/moments', label: 'لحظه‌ها و بازی‌ها', icon: <Sparkles className="w-5 h-5 text-amber-500" />, desc: 'چالش‌های ویژه امروز و رازهای دو نفره' },
    { to: '/memories', label: 'آلبوم خاطرات ما', icon: <Camera className="w-5 h-5 text-pink-500" />, desc: 'عکس‌ها و لحظات ثبت‌شده' },
    { to: '/pledges', label: 'عهدها و پیمان‌ها', icon: <HeartHandshake className="w-5 h-5 text-indigo-500" />, desc: 'قول‌ها و عهدهای دو نفره' },
    { to: '/dreams', label: 'آرزوها و اهداف', icon: <Compass className="w-5 h-5 text-cyan-500" />, desc: 'رویای آینده و لیست آرزوها' },
    { to: '/music', label: 'موزیک روم مشترک', icon: <Music className="w-5 h-5 text-purple-500" />, desc: 'آهنگ‌های خاطره‌انگیز' },
    { to: '/letters', label: 'نامه‌های عاشقانه', icon: <Mail className="w-5 h-5 text-emerald-500" />, desc: 'صندوق نامه‌ها و یادداشت‌ها' },
    { to: '/settings', label: 'تنظیمات و قفل', icon: <Settings className="w-5 h-5 text-slate-500" />, desc: 'تنظیمات سیستم و امنیت' },
  ];

  return (
    <>
      {/* Top Header */}
      <nav className="fixed top-0 w-full bg-white/90 backdrop-blur-md z-40 border-b border-stone-200/60 shadow-2xs">
        <div className="max-w-4xl mx-auto px-4 py-2.5 flex items-center justify-between gap-3">
          <NavLink to="/" className="flex items-center gap-2 cursor-pointer group">
            <div className="w-8 h-8 rounded-xl bg-stone-900 text-stone-100 flex items-center justify-center shadow-xs relative transition-transform group-hover:scale-105">
              <Heart className="w-4 h-4 fill-rose-500 text-rose-500" />
              {(syncStatus === 'connected' || syncStatus === 'syncing') && (
                <div className={`absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-emerald-500 rounded-full border border-white ${syncStatus === 'syncing' ? 'animate-pulse' : ''}`} title={syncStatus === 'syncing' ? "در حال همگام‌سازی..." : "متصل"}></div>
              )}
              {syncStatus === 'disconnected' && (
                <div className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-stone-400 rounded-full border border-white" title="Offline"></div>
              )}
              {syncStatus === 'error' && (
                <div className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-rose-600 rounded-full border border-white animate-pulse" title="Sync Error"></div>
              )}
            </div>
            <span className="font-black text-base tracking-tight text-stone-900 group-hover:text-rose-700 transition-colors">
              Loveniya
            </span>
          </NavLink>

          <div className="flex items-center gap-1 text-xs font-bold text-stone-600" ref={menuRef}>
            {syncStatus === 'error' && (
               <div className="hidden md:flex items-center gap-1.5 text-[10px] bg-rose-50 text-rose-700 px-2 py-1 rounded-full border border-rose-200/60 font-bold">
                 <AlertCircle className="w-3.5 h-3.5" />
                 {syncError || 'Error syncing'}
               </div>
            )}

            {/* Three-Dot Main Menu Trigger */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setShowDropdownMenu(!showDropdownMenu)}
                className="p-2 rounded-xl hover:bg-stone-100 text-stone-700 transition-colors flex items-center justify-center relative z-[9999]"
                title="منوی بخش‌های سایت"
              >
                <MoreVertical className="w-4 h-4" />
              </button>

              {/* Three-Dot Dropdown / Drawer List */}
              <AnimatePresence>
                {showDropdownMenu && (
                  <>
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      onClick={() => setShowDropdownMenu(false)}
                      className="fixed inset-0 bg-transparent z-[9998]"
                    />
                    <motion.div
                      initial={{ opacity: 0, scale: 0.96, y: -6 }}
                      animate={{ opacity: 1, scale: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.96, y: -6 }}
                      transition={{ duration: 0.15 }}
                      className="fixed top-14 left-4 right-4 sm:absolute sm:left-0 sm:right-auto sm:top-12 sm:w-[280px] bg-white rounded-2xl shadow-xl border border-stone-200/80 py-2 z-[9999] text-right overflow-hidden origin-top-left"
                    >
                      <div className="px-3.5 py-2 border-b border-stone-100 flex items-center justify-between">
                        <div className="flex items-center gap-1.5 font-black text-xs text-stone-800">
                          <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                          <span>بخش‌های لوینیا</span>
                        </div>
                        <button 
                          onClick={() => setShowDropdownMenu(false)}
                          className="p-1 text-stone-400 hover:text-stone-700 rounded-lg"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div className="py-1 max-h-[70vh] overflow-y-auto custom-scroll">
                        {navItems.map((item, idx) => (
                          <NavLink
                            key={idx}
                            to={item.to}
                            onClick={() => setShowDropdownMenu(false)}
                            className={({ isActive }) => clsx(
                              "px-3.5 py-2 flex items-center gap-3 transition-colors border-b border-stone-50 last:border-0",
                              isActive 
                                ? "bg-stone-100 text-stone-900 font-black" 
                                : "hover:bg-stone-50 text-stone-700"
                            )}
                          >
                            {({ isActive }) => (
                              <>
                                <div className={clsx(
                                  "p-1.5 rounded-xl shrink-0 transition-colors",
                                  isActive ? "bg-white border border-stone-200/80 shadow-xs" : "bg-stone-100 border border-transparent"
                                )}>
                                  {item.icon}
                                </div>
                                <div className="flex flex-col">
                                  <span className="text-[12px] font-bold leading-snug">{item.label}</span>
                                  <span className="text-[10px] text-stone-400 font-medium">{item.desc}</span>
                                </div>
                              </>
                            )}
                          </NavLink>
                        ))}
                      </div>
                    </motion.div>
                  </>
                )}
              </AnimatePresence>
            </div>

            {/* Quick Settings Icon */}
            <NavLink to="/settings" className={({ isActive }) => clsx("hover:text-stone-900 transition-colors flex items-center p-2 rounded-xl hover:bg-stone-100", isActive && "text-stone-900 bg-stone-100")}>
              <Settings className="w-4 h-4" />
            </NavLink>
          </div>
        </div>
      </nav>

      {syncStatus === 'error' && (
        <div className="fixed top-14 w-full z-40 bg-red-500 text-white text-xs font-bold text-center py-2 px-4 shadow-sm md:hidden">
          <AlertCircle className="w-4 h-4 inline-block mr-1" />
          {syncError || 'Error syncing'}
        </div>
      )}

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 w-full bg-white/95 backdrop-blur-2xl z-40 border-t border-rose-100/80 shadow-[0_-8px_25px_rgba(244,114,182,0.12)] py-2 pb-safe">
        <div className="max-w-2xl mx-auto px-1 flex items-center justify-between w-full">
          <NavItem to="/" icon={<Home className="w-5 sm:w-6 h-5 sm:h-6" />} label="خانه" />
          <NavItem to="/memories" icon={<Camera className="w-5 sm:w-6 h-5 sm:h-6" />} label="خاطرات" />
          <NavItem to="/pledges" icon={<HeartHandshake className="w-5 sm:w-6 h-5 sm:h-6" />} label="عهدها" />
          <NavItem to="/magic" icon={<MessageCircle className="w-5 sm:w-6 h-5 sm:h-6" />} label="چت" />
          <NavItem to="/dreams" icon={<Compass className="w-5 sm:w-6 h-5 sm:h-6" />} label="آرزوها" />
          <NavItem to="/music" icon={<Music className="w-5 sm:w-6 h-5 sm:h-6" />} label="موزیک" />
          <NavItem to="/letters" icon={<Mail className="w-5 sm:w-6 h-5 sm:h-6" />} label="نامه‌ها" />
        </div>
      </nav>
    </>
  );
};

const NavItem = ({ to, icon, label }: { to: string; icon: React.ReactNode; label: string }) => {
  return (
    <NavLink 
      to={to} 
      className={({ isActive }) => clsx(
        "flex flex-col items-center justify-center py-2 px-1 sm:px-2 flex-1 transition-all duration-200 relative",
        isActive 
          ? "text-rose-600 font-black" 
          : "text-slate-400 hover:text-rose-500 font-medium"
      )}
    >
      {({ isActive }) => (
        <>
          <div className={clsx(
            "transition-all duration-200 mb-1 sm:mb-1.5",
            isActive ? "text-rose-500 scale-110" : "text-slate-400"
          )}>
            {icon}
          </div>
          <span className="text-[9px] sm:text-[11px] tracking-tight leading-none text-center whitespace-nowrap">{label}</span>
          {isActive && (
            <span className="absolute -bottom-1 w-4 h-1.5 bg-rose-500 rounded-full" />
          )}
        </>
      )}
    </NavLink>
  );
};

