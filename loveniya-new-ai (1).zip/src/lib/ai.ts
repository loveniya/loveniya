export const AI_WORKER_URL = "https://purple-cloud-1df2.am-b-asdfghjkl20112011.workers.dev";

async function fetchWithRetry(url: string, options: RequestInit, retries = 3, backoff = 1000): Promise<Response> {
  let lastRes: Response | null = null;
  for (let i = 0; i < retries; i++) {
    try {
      const res = await fetch(url, options);
      if (res.ok) return res;
      lastRes = res;
    } catch (err) {
      // network error
    }
    if (i < retries - 1) {
      await new Promise(resolve => setTimeout(resolve, backoff * Math.pow(2, i)));
    }
  }
  if (lastRes) return lastRes;
  throw new Error(`Failed to fetch after ${retries} retries`);
}

/**
 * Extracts AI text from various response structures of Cloudflare Workers AI
 */
function extractAIResponseText(data: any): string | null {
  if (!data) return null;
  
  if (typeof data === 'string') {
    const trimmed = data.trim();
    if (trimmed === 'SKIP') return 'SKIP';
    return trimmed.length > 0 ? trimmed : 'SKIP';
  }
  
  if (typeof data.response === 'string') {
    if (data.response.trim() === 'SKIP') return 'SKIP';
    return data.response.trim() || 'SKIP';
  }

  if (data.result !== undefined) {
    if (typeof data.result === 'string') {
      if (data.result.trim() === 'SKIP') return 'SKIP';
      return data.result.trim() || 'SKIP';
    }
    if (typeof data.result.response === 'string') {
      if (data.result.response.trim() === 'SKIP') return 'SKIP';
      return data.result.response.trim() || 'SKIP';
    }
    if (typeof data.result.text === 'string') {
      if (data.result.text.trim() === 'SKIP') return 'SKIP';
      return data.result.text.trim() || 'SKIP';
    }
    if (typeof data.result.reply === 'string') {
      if (data.result.reply.trim() === 'SKIP') return 'SKIP';
      return data.result.reply.trim() || 'SKIP';
    }
  }

  if (typeof data.reply === 'string') {
    if (data.reply.trim() === 'SKIP') return 'SKIP';
    return data.reply.trim() || 'SKIP';
  }
  if (typeof data.text === 'string') {
    if (data.text.trim() === 'SKIP') return 'SKIP';
    return data.text.trim() || 'SKIP';
  }
  if (typeof data.message === 'string') {
    if (data.message.trim() === 'SKIP') return 'SKIP';
    return data.message.trim() || 'SKIP';
  }
  if (Array.isArray(data.choices) && data.choices[0]?.message?.content) {
    const content = String(data.choices[0].message.content).trim();
    if (content === 'SKIP') return 'SKIP';
    return content;
  }

  return null;
}

/**
 * Universal Cloudflare AI Caller:
 * 1. Direct Cloudflare Worker AI with exact exact payload
 * 2. Backend Server proxy (/api/loveai)
 * 3. Heartfelt contextual Persian response generator
 */
export async function fetchLoveAI(payload: {
  type?: string;
  message?: string;
  prompt?: string;
  userMessage?: string;
  history?: string;
  contextData?: any;
}) {
  const textPrompt = payload.message || payload.prompt || payload.userMessage || '';
  const promptType = payload.type || 'chat';

  const exactPayload = {
    type: promptType,
    userMessage: textPrompt,
    contextData: payload.contextData || { pledges: [], wishes: [] },
    history: payload.history || ''
  };

  // Strategy 1: Direct Cloudflare AI Worker
  try {
    const res = await fetchWithRetry(AI_WORKER_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(exactPayload)
    }, 3, 1000);

    if (res.ok) {
      const rawText = await res.text();
      try {
        const parsed = JSON.parse(rawText);
        const result = extractAIResponseText(parsed);
        if (result !== null) return result;
        throw new Error(`پاسخ خالی یا نامعتبر: ${rawText.substring(0, 100)}`);
      } catch (e: any) {
        if (e.message.startsWith('پاسخ خالی')) throw e;
        const result = extractAIResponseText(rawText);
        if (result !== null) return result;
        throw new Error(`متن نامشخص: ${rawText.substring(0, 100)}`);
      }
    } else {
      const errText = await res.text();
      try {
        const errJson = JSON.parse(errText);
        if (errJson.message) throw new Error(errJson.message);
        if (errJson.error) throw new Error(errJson.error);
      } catch (e: any) {
        if (e.message && e.message !== 'Unexpected end of JSON input') throw e;
        throw new Error(`خطای ${res.status} در ارتباط با هوش مصنوعی: ${errText.substring(0, 100)}`);
      }
    }
  } catch (err: any) {
    throw err; // Let the UI handle network/HTTP errors via Toast
  }

  // Fallback shouldn't be reached unless fetch fails completely, 
  // but if we are here, we just throw error to let UI know
  throw new Error('عدم دریافت پاسخ معتبر از سرور');
}

function generatePersianResponseFallback(userMessage?: string, sender?: string): string {
  const msg = (userMessage || '').toLowerCase();
  
  if (msg.includes('شعر') || msg.includes('شاعرانه')) {
    return "«در دلم بنشسته‌ای بیرون مرو از پیش من\nای که عشقت بهتر از جان است اندر جان من»\n\nعشقتون پایدار و پر از آرامش باد! 🌸❤️";
  }

  if (msg.includes('فال') || msg.includes('حافظ')) {
    return "«مژده ای دل که مسیحا نفسی می‌آید\nکه ز انفاس خوشش بوی کسی می‌آید»\n\nفالتون پر از روشنایی، عشق و روزهای قشنگ در کنار هم است! ✨";
  }

  if (msg.includes('سلام') || msg.includes('درود')) {
    return `سلام به روی ماهت ${sender ? (sender === 'amin' ? 'امین جان' : 'نیایش جان') : 'عزیزم'}! جانم، با تمام وجود در خدمتم. 🌸`;
  }

  return "جانم! من همیشه اینجام و کنار شما هستم. هر سوال یا صحبتی دارید بفرمایید، با عشق تمام گوش میدم ❤️✨";
}
