export const AI_WORKER_URL = "/api/loveai";

export async function fetchLoveAI(payload: any) {
  try {
    const res = await fetch(AI_WORKER_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    
    if (!res.ok) {
      let errorMessage = 'خطا در ارتباط با سرور هوش مصنوعی.';
      try {
        const errorData = await res.json();
        if (errorData.error) {
          errorMessage = errorData.error;
        }
      } catch (e) {
        // Ignore json parse error
      }
      throw new Error(errorMessage);
    }
    
    const text = await res.text();
    try {
      const data = JSON.parse(text);
      return data.result || data.text || data.message || data.reply || data.response || text;
    } catch {
      return text;
    }
  } catch (error) {
    throw error;
  }
}
