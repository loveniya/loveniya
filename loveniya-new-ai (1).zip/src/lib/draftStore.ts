import { useState, useEffect } from 'react';

export interface MemoryDraft {
  showForm: boolean;
  editingId: string | null;
  title: string;
  desc: string;
  vidUrl: string;
  photos: string[];
}

export interface PledgeDraft {
  showForm: boolean;
  editingId: string | null;
  text: string;
  author: string; // 'amin' | 'niyayesh' | 'mutual'
}

export interface DreamDraft {
  showForm: boolean;
  editingId: string | null;
  text: string;
}

export interface LetterDraft {
  showForm: boolean;
  editingId: string | null;
  title: string;
  text: string;
  openDate: string;
  sender: string;
  recipient: string;
  confirmSave: boolean;
}

const defaultSender = () =>
  typeof window !== 'undefined' && localStorage.getItem('loveniya_user') === 'amin'
    ? 'امین'
    : typeof window !== 'undefined' && localStorage.getItem('loveniya_user') === 'niyayesh'
    ? 'نیایش'
    : '';

const defaultRecipient = () =>
  typeof window !== 'undefined' && localStorage.getItem('loveniya_user') === 'amin'
    ? 'نیایش'
    : typeof window !== 'undefined' && localStorage.getItem('loveniya_user') === 'niyayesh'
    ? 'امین'
    : '';

const defaultPledgeAuthor = () =>
  typeof window !== 'undefined' && localStorage.getItem('loveniya_user') === 'amin'
    ? 'amin'
    : typeof window !== 'undefined' && localStorage.getItem('loveniya_user') === 'niyayesh'
    ? 'niyayesh'
    : 'mutual';

export const defaultMemoryDraft: MemoryDraft = {
  showForm: false,
  editingId: null,
  title: '',
  desc: '',
  vidUrl: '',
  photos: [],
};

export const defaultPledgeDraft = (): PledgeDraft => ({
  showForm: false,
  editingId: null,
  text: '',
  author: defaultPledgeAuthor(),
});

export const defaultDreamDraft: DreamDraft = {
  showForm: false,
  editingId: null,
  text: '',
};

export const defaultLetterDraft = (): LetterDraft => ({
  showForm: false,
  editingId: null,
  title: '',
  text: '',
  openDate: '',
  sender: defaultSender(),
  recipient: defaultRecipient(),
  confirmSave: false,
});

// In-memory singletons across SPA navigations
let memoryDraftState: MemoryDraft = { ...defaultMemoryDraft };
let pledgeDraftState: PledgeDraft = defaultPledgeDraft();
let dreamDraftState: DreamDraft = { ...defaultDreamDraft };
let letterDraftState: LetterDraft = defaultLetterDraft();

type Listener = () => void;
const memoryListeners = new Set<Listener>();
const pledgeListeners = new Set<Listener>();
const dreamListeners = new Set<Listener>();
const letterListeners = new Set<Listener>();

// Memory Draft Store
export function getMemoryDraft(): MemoryDraft {
  return memoryDraftState;
}

export function setMemoryDraft(updater: Partial<MemoryDraft> | ((prev: MemoryDraft) => MemoryDraft)) {
  if (typeof updater === 'function') {
    memoryDraftState = updater(memoryDraftState);
  } else {
    memoryDraftState = { ...memoryDraftState, ...updater };
  }
  memoryListeners.forEach(l => l());
}

export function resetMemoryDraft() {
  memoryDraftState = { ...defaultMemoryDraft };
  memoryListeners.forEach(l => l());
}

export function useMemoryDraft() {
  const [draft, setDraft] = useState<MemoryDraft>(memoryDraftState);

  useEffect(() => {
    const listener = () => setDraft(memoryDraftState);
    memoryListeners.add(listener);
    return () => {
      memoryListeners.delete(listener);
    };
  }, []);

  return {
    draft,
    setDraft: setMemoryDraft,
    resetDraft: resetMemoryDraft,
  };
}

// Pledge Draft Store
export function getPledgeDraft(): PledgeDraft {
  return pledgeDraftState;
}

export function setPledgeDraft(updater: Partial<PledgeDraft> | ((prev: PledgeDraft) => PledgeDraft)) {
  if (typeof updater === 'function') {
    pledgeDraftState = updater(pledgeDraftState);
  } else {
    pledgeDraftState = { ...pledgeDraftState, ...updater };
  }
  pledgeListeners.forEach(l => l());
}

export function resetPledgeDraft() {
  pledgeDraftState = defaultPledgeDraft();
  pledgeListeners.forEach(l => l());
}

export function usePledgeDraft() {
  const [draft, setDraft] = useState<PledgeDraft>(pledgeDraftState);

  useEffect(() => {
    const listener = () => setDraft(pledgeDraftState);
    pledgeListeners.add(listener);
    return () => {
      pledgeListeners.delete(listener);
    };
  }, []);

  return {
    draft,
    setDraft: setPledgeDraft,
    resetDraft: resetPledgeDraft,
  };
}

// Dream Draft Store
export function getDreamDraft(): DreamDraft {
  return dreamDraftState;
}

export function setDreamDraft(updater: Partial<DreamDraft> | ((prev: DreamDraft) => DreamDraft)) {
  if (typeof updater === 'function') {
    dreamDraftState = updater(dreamDraftState);
  } else {
    dreamDraftState = { ...dreamDraftState, ...updater };
  }
  dreamListeners.forEach(l => l());
}

export function resetDreamDraft() {
  dreamDraftState = { ...defaultDreamDraft };
  dreamListeners.forEach(l => l());
}

export function useDreamDraft() {
  const [draft, setDraft] = useState<DreamDraft>(dreamDraftState);

  useEffect(() => {
    const listener = () => setDraft(dreamDraftState);
    dreamListeners.add(listener);
    return () => {
      dreamListeners.delete(listener);
    };
  }, []);

  return {
    draft,
    setDraft: setDreamDraft,
    resetDraft: resetDreamDraft,
  };
}

// Letter Draft Store
export function getLetterDraft(): LetterDraft {
  return letterDraftState;
}

export function setLetterDraft(updater: Partial<LetterDraft> | ((prev: LetterDraft) => LetterDraft)) {
  if (typeof updater === 'function') {
    letterDraftState = updater(letterDraftState);
  } else {
    letterDraftState = { ...letterDraftState, ...updater };
  }
  letterListeners.forEach(l => l());
}

export function resetLetterDraft() {
  letterDraftState = defaultLetterDraft();
  letterListeners.forEach(l => l());
}

export function useLetterDraft() {
  const [draft, setDraft] = useState<LetterDraft>(letterDraftState);

  useEffect(() => {
    const listener = () => setDraft(letterDraftState);
    letterListeners.add(listener);
    return () => {
      letterListeners.delete(listener);
    };
  }, []);

  return {
    draft,
    setDraft: setLetterDraft,
    resetDraft: resetLetterDraft,
  };
}
