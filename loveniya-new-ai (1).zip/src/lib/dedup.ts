/**
 * Safely deduplicates an array of items by their unique `id`.
 * Preserves order and ensures no duplicates with the same `id` are present.
 */
export function dedupById<T extends { id?: string | number }>(items: T[] | null | undefined): T[] {
  if (!items || !Array.isArray(items)) return [];
  const seen = new Set<string | number>();
  const result: T[] = [];

  for (const item of items) {
    if (!item) continue;
    const id = item.id;
    if (id !== undefined && id !== null && id !== '') {
      if (!seen.has(id)) {
        seen.add(id);
        result.push(item);
      }
    } else {
      result.push(item);
    }
  }

  return result;
}
