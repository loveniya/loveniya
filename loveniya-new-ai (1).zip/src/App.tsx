/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { HashRouter, Routes, Route, Navigate, useLocation } from 'react-router';
import { useState, useEffect } from 'react';
import { StoreProvider } from './lib/store';
import { Navigation } from './components/Navigation';
import { LockScreen } from './components/LockScreen';
import { Home } from './pages/Home';
import { Memories } from './pages/Memories';
import { Pledges } from './pages/Pledges';
import { Dreams } from './pages/Dreams';
import { Music } from './pages/Music';
import { Letters } from './pages/Letters';
import { Settings } from './pages/Settings';
import { AIChat } from './pages/AIChat';
import { Moments } from './pages/Moments';
import { RomanticEffects } from './components/RomanticEffects';
import { MediaPlayer } from './components/MediaPlayer';

function AppLayout({ handleLock }: { handleLock: () => void }) {
  const location = useLocation();
  const isChatPage = location.pathname === '/magic' || location.pathname === '/chat';

  if (isChatPage) {
    return (
      <div className="fixed inset-0 z-50 bg-[#0f1721] overflow-hidden">
        <AIChat />
      </div>
    );
  }

  return (
    <>
      <Navigation />
      <MediaPlayer />
      <main className="max-w-4xl mx-auto px-4 md:px-6 pt-20 pb-20 md:pb-24 relative z-10">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/memories" element={<Memories />} />
          <Route path="/pledges" element={<Pledges />} />
          <Route path="/dreams" element={<Dreams />} />
          <Route path="/music" element={<Music />} />
          <Route path="/letters" element={<Letters />} />
          <Route path="/moments" element={<Moments />} />
          <Route path="/games" element={<Moments />} />
          <Route path="/settings" element={<Settings onLock={handleLock} />} />
          <Route path="/chat" element={<AIChat />} />
          <Route path="/magic" element={<AIChat />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
    </>
  );
}

export default function App() {
  const [isUnlocked, setIsUnlocked] = useState(false);

  useEffect(() => {
    if (localStorage.getItem('loveniya_unlocked') === 'true' && localStorage.getItem('loveniya_user')) {
      setIsUnlocked(true);
    }
  }, []);

  const handleUnlock = () => setIsUnlocked(true);
  const handleLock = () => {
    localStorage.removeItem('loveniya_unlocked');
    setIsUnlocked(false);
  };

  if (!isUnlocked) {
    return <LockScreen onUnlock={handleUnlock} />;
  }

  return (
    <StoreProvider>
      <RomanticEffects />
      <HashRouter basename="/">
        <AppLayout handleLock={handleLock} />
      </HashRouter>
    </StoreProvider>
  );
}

