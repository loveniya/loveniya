/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { HashRouter, Routes, Route, Navigate } from 'react-router';
import { useState, useEffect } from 'react';
import { StoreProvider } from './lib/store';
import { Navigation } from './components/Navigation';
import { LockScreen } from './components/LockScreen';
import { Home } from './pages/Home';
import { Memories } from './pages/Memories';
import { Pledges } from './pages/Pledges';
import { Dreams } from './pages/Dreams';
import { Music } from './pages/Music';
import { Letters } from './pages/Letters';
import { Settings } from './pages/Settings';
import { RomanticEffects } from './components/RomanticEffects';
import { MediaPlayer } from './components/MediaPlayer';

export default function App() {
  const [isUnlocked, setIsUnlocked] = useState(false);

  useEffect(() => {
    if (localStorage.getItem('loveniya_unlocked') === 'true') {
      setIsUnlocked(true);
    }
  }, []);

  const handleUnlock = () => setIsUnlocked(true);
  const handleLock = () => {
    localStorage.removeItem('loveniya_unlocked');
    setIsUnlocked(false);
  };

  if (!isUnlocked) {
    return <LockScreen onUnlock={handleUnlock} />;
  }

  return (
    <StoreProvider>
      <RomanticEffects />
      <HashRouter basename="/">
        <Navigation />
        <MediaPlayer />
        <main className="max-w-4xl mx-auto px-4 md:px-6 pt-24 pb-28 relative z-10">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/memories" element={<Memories />} />
            <Route path="/pledges" element={<Pledges />} />
            <Route path="/dreams" element={<Dreams />} />
            <Route path="/music" element={<Music />} />
            <Route path="/letters" element={<Letters />} />
            <Route path="/settings" element={<Settings onLock={handleLock} />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </main>
      </HashRouter>
    </StoreProvider>
  );
}
