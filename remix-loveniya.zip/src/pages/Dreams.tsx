import React, { useState } from 'react';
import { Compass, Plus, Star, Trash2, Edit3 } from 'lucide-react';
import { useStore } from '../lib/store';
import { Dream } from '../lib/types';
import { KebabMenu, KebabMenuItem } from '../components/KebabMenu';

export const Dreams: React.FC = () => {
  const { dreams, addDream, updateDream, removeDream } = useStore();
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [text, setText] = useState('');
  
  const handleEdit = (dream: Dream) => {
    setEditingId(dream.id);
    setText(dream.text);
    setShowForm(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingId) {
      const existing = dreams.find(d => d.id === editingId);
      if (existing) {
        updateDream({
          ...existing,
          text
        });
      }
    } else {
      const newDream: Dream = {
        id: Date.now().toString(),
        text,
        date: new Date().toLocaleDateString('fa-IR'),
        pinned: false
      };
      addDream(newDream);
    }
    resetForm();
  };

  const resetForm = () => {
    setText('');
    setEditingId(null);
    setShowForm(false);
  };

  return (
    <div className="space-y-6" dir="rtl">
      <div className="glass-card rounded-3xl p-6 md:p-8">
        <div className="flex flex-wrap justify-between items-center gap-3 mb-6">
          <div>
            <h2 className="text-xl font-black text-slate-800 flex items-center gap-2">
              <Compass className="w-5 h-5 text-amber-500" /> آرزوهای مشترک
            </h2>
            <p className="text-[11px] text-slate-500 font-medium mt-0.5">رویایی که با هم می‌سازیم</p>
          </div>
          <button 
            onClick={() => {
              if (showForm) {
                resetForm();
              } else {
                setShowForm(true);
              }
            }} 
            className="bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold px-4 py-2.5 rounded-full shadow-sm flex items-center gap-1.5 active:scale-95 transition-all"
          >
            <Plus className="w-4 h-4" /> {showForm ? 'بستن فرم' : 'ثبت آرزو جدید'}
          </button>
        </div>

        {showForm && (
          <div className="mb-6 bg-white/80 rounded-2xl p-5 border border-amber-200 shadow-sm">
            <form onSubmit={handleSave} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">شرح آرزو یا هدف مشترک:</label>
                <textarea rows={4} placeholder="مثلا: یه روزی بریم..." required value={text} onChange={e => setText(e.target.value)}
                          className="w-full bg-white/90 border border-amber-200 rounded-xl p-3 text-xs focus:border-amber-400 focus:outline-none leading-relaxed"></textarea>
              </div>
              <div className="flex justify-end gap-2 pt-1">
                <button type="button" onClick={resetForm} className="bg-slate-200 text-slate-700 text-xs px-4 py-2 rounded-full font-bold">انصراف</button>
                <button type="submit" className="bg-amber-500 text-white text-xs font-bold px-6 py-2 rounded-full hover:bg-amber-600 shadow-md">
                  {editingId ? 'ذخیره تغییرات' : 'ثبت آرزو'}
                </button>
              </div>
            </form>
          </div>
        )}

        <div className="space-y-3">
          {dreams.length === 0 ? (
            <p className="text-center text-slate-500 text-xs py-10">هنوز آرزویی ثبت نشده...</p>
          ) : (
            dreams.map(dream => (
              <div key={dream.id} className="bg-white/80 p-4 rounded-2xl border border-amber-100 shadow-sm relative group">
                <div className="flex justify-between items-start mb-2">
                  <p className="text-sm text-slate-800 font-bold whitespace-pre-wrap leading-relaxed">
                    {dream.pinned && <Star className="inline w-3.5 h-3.5 text-amber-400 fill-amber-400 ml-1" />}
                    {dream.text}
                  </p>
                  <div className="flex gap-2 mr-4 shrink-0">
                    <KebabMenu>
                      <KebabMenuItem 
                        icon={<Star className="w-4 h-4" />} 
                        label={dream.pinned ? 'برداشتن نشان' : 'نشان کردن'} 
                        onClick={() => updateDream({ ...dream, pinned: !dream.pinned })} 
                      />
                      <KebabMenuItem 
                        icon={<Edit3 className="w-4 h-4" />} 
                        label="ویرایش" 
                        onClick={() => handleEdit(dream)} 
                      />
                      <KebabMenuItem 
                        icon={<Trash2 className="w-4 h-4" />} 
                        label="حذف" 
                        danger 
                        onClick={() => removeDream(dream.id)} 
                      />
                    </KebabMenu>
                  </div>
                </div>
                <div className="text-[10px] text-slate-400 mt-2">{dream.date}</div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
