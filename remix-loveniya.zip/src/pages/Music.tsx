import React, { useState } from 'react';
import { Music as MusicIcon, Plus, Star, Trash2, ExternalLink, Edit3 } from 'lucide-react';
import { useStore } from '../lib/store';
import { Music as MusicType } from '../lib/types';
import { KebabMenu, KebabMenuItem } from '../components/KebabMenu';

export const Music: React.FC = () => {
  const { playlist, addMusic, updateMusic, removeMusic } = useStore();
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [title, setTitle] = useState('');
  const [artist, setArtist] = useState('');
  const [url, setUrl] = useState('');
  
  const handleEdit = (song: MusicType) => {
    setEditingId(song.id);
    setTitle(song.title);
    setArtist(song.artist);
    setUrl(song.url);
    setShowForm(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingId) {
      const existing = playlist.find(m => m.id === editingId);
      if (existing) {
        updateMusic({
          ...existing,
          title,
          artist,
          url
        });
      }
    } else {
      const newMusic: MusicType = {
        id: Date.now().toString(),
        title,
        artist,
        url,
        pinned: false
      };
      addMusic(newMusic);
    }
    resetForm();
  };

  const resetForm = () => {
    setTitle('');
    setArtist('');
    setUrl('');
    setEditingId(null);
    setShowForm(false);
  };

  return (
    <div className="space-y-6" dir="rtl">
      <div className="glass-card rounded-3xl p-6 md:p-8">
        <div className="flex flex-wrap justify-between items-center gap-3 mb-6">
          <div>
            <h2 className="text-xl font-black text-slate-800 flex items-center gap-2">
              <MusicIcon className="w-5 h-5 text-sky-500" /> پلی‌لیست عاشقانه‌مون
            </h2>
            <p className="text-[11px] text-slate-500 font-medium mt-0.5">آهنگ‌هایی که باهاشون خاطره داریم</p>
          </div>
          <button 
            onClick={() => {
              if (showForm) {
                resetForm();
              } else {
                setShowForm(true);
              }
            }} 
            className="bg-sky-500 hover:bg-sky-600 text-white text-xs font-bold px-4 py-2.5 rounded-full shadow-sm flex items-center gap-1.5 active:scale-95 transition-all"
          >
            <Plus className="w-4 h-4" /> {showForm ? 'بستن فرم' : 'اضافه کردن موزیک'}
          </button>
        </div>

        {showForm && (
          <div className="mb-6 bg-white/80 rounded-2xl p-5 border border-sky-200 shadow-sm">
            <form onSubmit={handleSave} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">اسم آهنگ:</label>
                <input type="text" placeholder="مثلا: چشمای تو" required value={title} onChange={e => setTitle(e.target.value)}
                       className="w-full bg-white/90 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:border-sky-400 focus:outline-none" />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">خواننده:</label>
                <input type="text" placeholder="مثلا: شادمهر" required value={artist} onChange={e => setArtist(e.target.value)}
                       className="w-full bg-white/90 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:border-sky-400 focus:outline-none" />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">لینک گوش دادن (SoundCloud, Spotify, Youtube):</label>
                <input type="url" placeholder="https://..." required value={url} onChange={e => setUrl(e.target.value)}
                       className="w-full bg-white/90 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:border-sky-400 focus:outline-none text-left" dir="ltr" />
              </div>
              <div className="flex justify-end gap-2 pt-1">
                <button type="button" onClick={resetForm} className="bg-slate-200 text-slate-700 text-xs px-4 py-2 rounded-full font-bold">انصراف</button>
                <button type="submit" className="bg-sky-500 text-white text-xs font-bold px-6 py-2 rounded-full hover:bg-sky-600 shadow-md">
                  {editingId ? 'ذخیره تغییرات' : 'ذخیره'}
                </button>
              </div>
            </form>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {playlist.length === 0 ? (
            <p className="text-center text-slate-500 text-xs py-10 col-span-full">هنوز آهنگی اضافه نشده...</p>
          ) : (
            playlist.map(song => (
              <div key={song.id} className="bg-white/80 p-4 rounded-2xl border border-sky-100 shadow-sm flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-slate-800 text-sm flex items-center gap-1.5">
                    {song.title}
                    {song.pinned && <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />}
                  </h3>
                  <p className="text-xs text-slate-500">{song.artist}</p>
                </div>
                <div className="flex items-center gap-2">
                  <a href={song.url} target="_blank" rel="noreferrer" className="w-8 h-8 rounded-full bg-sky-50 text-sky-600 flex items-center justify-center hover:bg-sky-100">
                    <ExternalLink className="w-4 h-4" />
                  </a>
                  <KebabMenu>
                    <KebabMenuItem 
                      icon={<Star className="w-4 h-4" />} 
                      label={song.pinned ? 'برداشتن نشان' : 'نشان کردن'} 
                      onClick={() => updateMusic({ ...song, pinned: !song.pinned })} 
                    />
                    <KebabMenuItem 
                      icon={<Edit3 className="w-4 h-4" />} 
                      label="ویرایش" 
                      onClick={() => handleEdit(song)} 
                    />
                    <KebabMenuItem 
                      icon={<Trash2 className="w-4 h-4" />} 
                      label="حذف" 
                      danger 
                      onClick={() => removeMusic(song.id)} 
                    />
                  </KebabMenu>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
