import React, { useState } from 'react';
import { Music as MusicIcon, Plus, Star, Trash2, ExternalLink, Edit3 } from 'lucide-react';
import { useStore } from '../lib/store';
import { Music as MusicType } from '../lib/types';
import { KebabMenu, KebabMenuItem } from '../components/KebabMenu';
import { motion, AnimatePresence } from 'motion/react';

export const Music: React.FC = () => {
  const { playlist, addMusic, updateMusic, removeMusic } = useStore();
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [title, setTitle] = useState('');
  const [artist, setArtist] = useState('');
  const [url, setUrl] = useState('');
  
  const handleEdit = (song: MusicType) => {
    setEditingId(song.id);
    setTitle(song.title);
    setArtist(song.artist);
    setUrl(song.url);
    setShowForm(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingId) {
      const existing = playlist.find(m => m.id === editingId);
      if (existing) {
        updateMusic({
          ...existing,
          title,
          artist,
          url
        });
      }
    } else {
      const newMusic: MusicType = {
        id: Date.now().toString(),
        title,
        artist,
        url,
        pinned: false
      };
      addMusic(newMusic);
    }
    resetForm();
  };

  const resetForm = () => {
    setTitle('');
    setArtist('');
    setUrl('');
    setEditingId(null);
    setShowForm(false);
  };

  // Sort music: pinned ones first
  const sortedMusic = [...playlist].sort((a, b) => {
    if (a.pinned && !b.pinned) return -1;
    if (!a.pinned && b.pinned) return 1;
    return 0;
  });

  return (
    <div className="space-y-6" dir="rtl">
      <div className="glass-card rounded-3xl p-6 md:p-8 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-64 h-64 bg-blue-300/20 rounded-full blur-3xl pointer-events-none mix-blend-multiply"></div>
        <div className="absolute bottom-0 right-0 w-64 h-64 bg-sky-300/20 rounded-full blur-3xl pointer-events-none mix-blend-multiply"></div>

        <div className="flex flex-wrap justify-between items-center gap-3 mb-6 relative z-10">
          <div>
            <h2 className="text-2xl font-black text-slate-800 flex items-center gap-2">
              <MusicIcon className="w-6 h-6 text-sky-500" /> پلی‌لیست عاشقانه‌مون
            </h2>
            <p className="text-xs text-slate-500 font-medium mt-1">آهنگ‌هایی که باهاشون خاطره داریم</p>
          </div>
          <button 
            onClick={() => {
              if (showForm) {
                resetForm();
              } else {
                setShowForm(true);
              }
            }} 
            className="bg-gradient-to-r from-sky-500 to-blue-500 text-white text-xs font-bold px-5 py-2.5 rounded-full shadow-lg shadow-sky-200 flex items-center gap-1.5 active:scale-95 transition-all hover:opacity-90"
          >
            <Plus className="w-4 h-4" /> {showForm ? 'بستن فرم' : 'اضافه کردن موزیک'}
          </button>
        </div>

        <AnimatePresence>
          {showForm && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="mb-8 relative z-10"
            >
              <div className="bg-white/90 backdrop-blur-md rounded-2xl p-6 border border-sky-200 shadow-xl">
                <form onSubmit={handleSave} className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1.5">اسم آهنگ:</label>
                    <input type="text" placeholder="مثلا: چشمای تو" required value={title} onChange={e => setTitle(e.target.value)}
                           className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-xs focus:border-sky-400 focus:ring-2 focus:ring-sky-100 focus:outline-none transition-all" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1.5">خواننده:</label>
                    <input type="text" placeholder="مثلا: شادمهر" required value={artist} onChange={e => setArtist(e.target.value)}
                           className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-xs focus:border-sky-400 focus:ring-2 focus:ring-sky-100 focus:outline-none transition-all" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1.5">لینک آهنگ:</label>
                    <input type="url" placeholder="لینک مستقیم فایل MP3" required value={url} onChange={e => setUrl(e.target.value)}
                           className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-xs focus:border-sky-400 focus:ring-2 focus:ring-sky-100 focus:outline-none text-left transition-all" dir="ltr" />
                  </div>
                  <div className="flex justify-end gap-3 pt-2">
                    <button type="button" onClick={resetForm} className="bg-slate-200 text-slate-700 text-xs px-6 py-2.5 rounded-full font-bold hover:bg-slate-300 transition-colors">انصراف</button>
                    <button type="submit" className="bg-gradient-to-r from-sky-500 to-blue-500 text-white text-xs font-bold px-8 py-2.5 rounded-full hover:shadow-lg shadow-sky-200 transition-all">
                      {editingId ? 'ذخیره تغییرات' : 'ذخیره'}
                    </button>
                  </div>
                </form>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 relative z-10">
          {sortedMusic.length === 0 ? (
            <div className="text-center text-slate-400 text-xs py-16 flex flex-col items-center gap-3 col-span-full">
              <MusicIcon className="w-12 h-12 opacity-20" />
              <span>هنوز آهنگی اضافه نشده...</span>
            </div>
          ) : (
            sortedMusic.map(song => (
              <motion.div layout key={song.id} className={`bg-white/90 backdrop-blur-sm p-4 rounded-3xl border transition-all relative flex items-center justify-between group ${song.pinned ? 'border-amber-300 shadow-[0_0_20px_rgba(252,211,77,0.3)] ring-1 ring-amber-300/50' : 'border-sky-100 shadow-sm hover:shadow-md'}`}>
                {song.pinned && (
                  <div className="absolute -top-3 -right-3 bg-gradient-to-br from-amber-400 to-orange-500 text-white text-[10px] font-black px-3 py-1 rounded-full shadow-lg flex items-center gap-1 z-20 border-2 border-white">
                    <Star className="w-3 h-3 fill-white" /> آهنگ برتر
                  </div>
                )}
                
                <div className="flex-1 min-w-0 pr-2">
                  <h3 className="font-black text-slate-800 text-sm truncate">
                    {song.title}
                  </h3>
                  <p className="text-xs text-slate-500 font-medium truncate mt-0.5">{song.artist}</p>
                </div>
                <div className="flex items-center gap-1 shrink-0 relative z-20">
                  <a href={song.url} target="_blank" rel="noreferrer" className="w-9 h-9 rounded-full bg-sky-50 text-sky-600 flex items-center justify-center hover:bg-sky-100 transition-colors shadow-inner mr-2">
                    <ExternalLink className="w-4 h-4" />
                  </a>
                  <KebabMenu>
                    <KebabMenuItem 
                      icon={<Star className="w-4 h-4" />} 
                      label={song.pinned ? 'برداشتن نشان برتر' : 'نشان کردن به عنوان برتر'} 
                      onClick={() => updateMusic({ ...song, pinned: !song.pinned })} 
                    />
                    <KebabMenuItem 
                      icon={<Edit3 className="w-4 h-4" />} 
                      label="ویرایش" 
                      onClick={() => handleEdit(song)} 
                    />
                    <KebabMenuItem 
                      icon={<Trash2 className="w-4 h-4" />} 
                      label="حذف" 
                      danger 
                      onClick={() => removeMusic(song.id)} 
                    />
                  </KebabMenu>
                </div>
              </motion.div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
