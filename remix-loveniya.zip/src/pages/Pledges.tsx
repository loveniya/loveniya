import React, { useState } from 'react';
import { HeartHandshake, Plus, Star, Trash2, Edit3 } from 'lucide-react';
import { useStore } from '../lib/store';
import { Pledge } from '../lib/types';
import { KebabMenu, KebabMenuItem } from '../components/KebabMenu';

export const Pledges: React.FC = () => {
  const { pledges, addPledge, updatePledge, removePledge } = useStore();
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [text, setText] = useState('');
  
  const handleEdit = (plg: Pledge) => {
    setEditingId(plg.id);
    setText(plg.text);
    setShowForm(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingId) {
      const existing = pledges.find(p => p.id === editingId);
      if (existing) {
        updatePledge({
          ...existing,
          text
        });
      }
    } else {
      const newPledge: Pledge = {
        id: Date.now().toString(),
        text,
        date: new Date().toLocaleDateString('fa-IR'),
        pinned: false
      };
      addPledge(newPledge);
    }
    resetForm();
  };

  const resetForm = () => {
    setText('');
    setEditingId(null);
    setShowForm(false);
  };

  return (
    <div className="space-y-6" dir="rtl">
      <div className="glass-card rounded-3xl p-6 md:p-8">
        <div className="flex flex-wrap justify-between items-center gap-3 mb-6">
          <div>
            <h2 className="text-xl font-black text-slate-800 flex items-center gap-2">
              <HeartHandshake className="w-5 h-5 text-purple-500" /> عهدهای عاشقانه
            </h2>
            <p className="text-[11px] text-slate-500 font-medium mt-0.5">قول‌هایی که به همدیگه دادیم و هیچ‌وقت یادمون نمیره</p>
          </div>
          <button 
            onClick={() => {
              if (showForm) {
                resetForm();
              } else {
                setShowForm(true);
              }
            }} 
            className="bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold px-4 py-2.5 rounded-full shadow-sm flex items-center gap-1.5 active:scale-95 transition-all"
          >
            <Plus className="w-4 h-4" /> {showForm ? 'بستن فرم' : 'ثبت عهد جدید'}
          </button>
        </div>

        {showForm && (
          <div className="mb-6 bg-white/80 rounded-2xl p-5 border border-purple-200 shadow-sm">
            <form onSubmit={handleSave} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">متن کامل قول یا عهد عاطفی:</label>
                <textarea rows={4} placeholder="متن کامل قول‌مون رو بنویس..." required value={text} onChange={e => setText(e.target.value)}
                          className="w-full bg-white/90 border border-purple-200 rounded-xl p-3 text-xs focus:border-purple-400 focus:outline-none leading-relaxed"></textarea>
              </div>
              <div className="flex justify-end gap-2 pt-1">
                <button type="button" onClick={resetForm} className="bg-slate-200 text-slate-700 text-xs px-4 py-2 rounded-full font-bold">انصراف</button>
                <button type="submit" className="bg-purple-600 text-white text-xs font-bold px-6 py-2 rounded-full hover:bg-purple-700 shadow-md">
                  {editingId ? 'ذخیره تغییرات' : 'ثبت قول'}
                </button>
              </div>
            </form>
          </div>
        )}

        <div className="space-y-3">
          {pledges.length === 0 ? (
            <p className="text-center text-slate-500 text-xs py-10">هنوز عهدی ثبت نشده...</p>
          ) : (
            pledges.map(plg => (
              <div key={plg.id} className="bg-white/80 p-4 rounded-2xl border border-purple-100 shadow-sm relative group">
                <div className="flex justify-between items-start mb-2">
                  <p className="text-sm text-slate-800 font-bold whitespace-pre-wrap leading-relaxed">
                    {plg.pinned && <Star className="inline w-3.5 h-3.5 text-amber-400 fill-amber-400 ml-1" />}
                    {plg.text}
                  </p>
                  <div className="flex gap-2 mr-4 shrink-0">
                    <KebabMenu>
                      <KebabMenuItem 
                        icon={<Star className="w-4 h-4" />} 
                        label={plg.pinned ? 'برداشتن نشان' : 'نشان کردن'} 
                        onClick={() => updatePledge({ ...plg, pinned: !plg.pinned })} 
                      />
                      <KebabMenuItem 
                        icon={<Edit3 className="w-4 h-4" />} 
                        label="ویرایش" 
                        onClick={() => handleEdit(plg)} 
                      />
                      <KebabMenuItem 
                        icon={<Trash2 className="w-4 h-4" />} 
                        label="حذف" 
                        danger 
                        onClick={() => removePledge(plg.id)} 
                      />
                    </KebabMenu>
                  </div>
                </div>
                <div className="text-[10px] text-slate-400 mt-2">{plg.date}</div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
