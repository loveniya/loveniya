import React, { useState } from 'react';
import { HeartHandshake, Plus, Star, Trash2, Edit3, X } from 'lucide-react';
import { useStore } from '../lib/store';
import { Pledge } from '../lib/types';
import { KebabMenu, KebabMenuItem } from '../components/KebabMenu';
import { motion, AnimatePresence } from 'motion/react';

export const Pledges: React.FC = () => {
  const { pledges, addPledge, updatePledge, removePledge } = useStore();
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [activePledge, setActivePledge] = useState<Pledge | null>(null);
  const [text, setText] = useState('');
  
  const handleEdit = (plg: Pledge) => {
    setEditingId(plg.id);
    setText(plg.text);
    setShowForm(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingId) {
      const existing = pledges.find(p => p.id === editingId);
      if (existing) {
        updatePledge({
          ...existing,
          text
        });
      }
    } else {
      const newPledge: Pledge = {
        id: Date.now().toString(),
        text,
        date: new Date().toLocaleDateString('fa-IR'),
        pinned: false
      };
      addPledge(newPledge);
    }
    resetForm();
  };

  const resetForm = () => {
    setText('');
    setEditingId(null);
    setShowForm(false);
  };

  // Sort pledges: pinned ones first
  const sortedPledges = [...pledges].sort((a, b) => {
    if (a.pinned && !b.pinned) return -1;
    if (!a.pinned && b.pinned) return 1;
    return 0;
  });

  return (
    <AnimatePresence mode="wait">
      {activePledge ? (
        <motion.div 
          key="detail"
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: -20 }}
          transition={{ type: "spring", stiffness: 300, damping: 30 }}
          className="space-y-6 pb-6 w-full" dir="rtl"
        >
          <div className="glass-card rounded-3xl p-6 md:p-10 relative overflow-hidden shadow-2xl bg-white/95 border-2 border-purple-100">
            <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-purple-400 via-fuchsia-400 to-pink-400"></div>
            
            <div className="flex justify-between items-start mb-8 border-b border-purple-100 pb-6">
              <div>
                <h2 className="text-2xl md:text-3xl font-black text-purple-600 flex items-center gap-2 mb-2">
                  <HeartHandshake className="w-7 h-7 text-purple-500" /> عهد عاشقانه
                </h2>
                <p className="text-xs md:text-sm text-slate-500 font-bold flex items-center gap-1">
                   تاریخ ثبت: {activePledge.date}
                   {activePledge.pinned && (
                     <span className="inline-flex items-center gap-1 bg-amber-100 text-amber-600 px-2 py-0.5 rounded-full mr-3 text-[10px]">
                       <Star className="w-3 h-3 fill-amber-500" /> عهد برتر
                     </span>
                   )}
                </p>
              </div>
              <button onClick={() => setActivePledge(null)} className="text-slate-400 hover:text-purple-500 bg-slate-50 p-2 rounded-full transition-colors shrink-0">
                <X className="w-5 h-5" />
              </button>
            </div>

            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="whitespace-pre-wrap text-lg md:text-xl font-black text-slate-700 leading-[2.5] mb-10 text-center px-4"
            >
              "{activePledge.text}"
            </motion.div>
          </div>
        </motion.div>
      ) : (
        <motion.div 
          key="list"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          transition={{ type: "spring", stiffness: 300, damping: 30 }}
          className="space-y-6 w-full" dir="rtl"
        >
          <div className="glass-card rounded-3xl p-6 md:p-8 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-64 h-64 bg-purple-300/20 rounded-full blur-3xl pointer-events-none mix-blend-multiply"></div>
        <div className="absolute bottom-0 right-0 w-64 h-64 bg-fuchsia-300/20 rounded-full blur-3xl pointer-events-none mix-blend-multiply"></div>

        <div className="flex flex-wrap justify-between items-center gap-3 mb-6 relative z-10">
          <div>
            <h2 className="text-2xl font-black text-slate-800 flex items-center gap-2">
              <HeartHandshake className="w-6 h-6 text-purple-600" /> عهدهای عاشقانه
            </h2>
            <p className="text-xs text-slate-500 font-medium mt-1">قول‌هایی که به همدیگه دادیم و هیچ‌وقت یادمون نمیره</p>
          </div>
          <button 
            onClick={() => {
              if (showForm) {
                resetForm();
              } else {
                setShowForm(true);
              }
            }} 
            className="bg-gradient-to-r from-purple-600 to-fuchsia-600 text-white text-xs font-bold px-5 py-2.5 rounded-full shadow-lg shadow-purple-200 flex items-center gap-1.5 active:scale-95 transition-all hover:opacity-90"
          >
            <Plus className="w-4 h-4" /> {showForm ? 'بستن فرم' : 'ثبت عهد جدید'}
          </button>
        </div>

        <AnimatePresence>
          {showForm && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="mb-8 relative z-10"
            >
              <div className="bg-white/90 backdrop-blur-md rounded-2xl p-6 border border-purple-200 shadow-xl">
                <form onSubmit={handleSave} className="space-y-5">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1.5">متن کامل قول یا عهد عاطفی:</label>
                    <textarea rows={5} placeholder="متن کامل قول‌مون رو بنویس..." required value={text} onChange={e => setText(e.target.value)}
                              className="w-full bg-slate-50 border border-slate-200 rounded-xl p-4 text-xs focus:border-purple-400 focus:ring-2 focus:ring-purple-100 focus:outline-none leading-relaxed transition-all"></textarea>
                  </div>
                  <div className="flex justify-end gap-3 pt-2">
                    <button type="button" onClick={resetForm} className="bg-slate-200 text-slate-700 text-xs px-6 py-2.5 rounded-full font-bold hover:bg-slate-300 transition-colors">انصراف</button>
                    <button type="submit" className="bg-gradient-to-r from-purple-600 to-fuchsia-600 text-white text-xs font-bold px-8 py-2.5 rounded-full hover:shadow-lg shadow-purple-200 transition-all">
                      {editingId ? 'ذخیره تغییرات' : 'ثبت قول'}
                    </button>
                  </div>
                </form>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="space-y-4 relative z-10">
          {sortedPledges.length === 0 ? (
            <div className="text-center text-slate-400 text-xs py-16 flex flex-col items-center gap-3">
              <HeartHandshake className="w-12 h-12 opacity-20" />
              <span>هنوز عهدی ثبت نشده...</span>
            </div>
          ) : (
            sortedPledges.map(plg => (
              <motion.div layout key={plg.id} onClick={() => setActivePledge(plg)} className={`cursor-pointer bg-white/90 backdrop-blur-sm p-5 rounded-3xl border transition-all relative group ${plg.pinned ? 'border-amber-300 shadow-[0_0_20px_rgba(252,211,77,0.3)] ring-1 ring-amber-300/50' : 'border-purple-100 shadow-sm hover:shadow-md'}`}>
                {plg.pinned && (
                  <div className="absolute -top-3 -right-3 bg-gradient-to-br from-amber-400 to-orange-500 text-white text-[10px] font-black px-3 py-1 rounded-full shadow-lg flex items-center gap-1 z-20 border-2 border-white">
                    <Star className="w-3 h-3 fill-white" /> انتخاب برتر
                  </div>
                )}
                
                <div className="flex justify-between items-start mb-2">
                  <p className="text-sm text-slate-800 font-bold whitespace-pre-wrap leading-relaxed mt-1">
                    {plg.text}
                  </p>
                  <div className="flex gap-2 mr-4 shrink-0 relative z-20">
                    <KebabMenu>
                      <KebabMenuItem 
                        icon={<Star className="w-4 h-4" />} 
                        label={plg.pinned ? 'برداشتن نشان برتر' : 'نشان کردن به عنوان برتر'} 
                        onClick={() => updatePledge({ ...plg, pinned: !plg.pinned })} 
                      />
                      <KebabMenuItem 
                        icon={<Edit3 className="w-4 h-4" />} 
                        label="ویرایش" 
                        onClick={() => handleEdit(plg)} 
                      />
                      <KebabMenuItem 
                        icon={<Trash2 className="w-4 h-4" />} 
                        label="حذف" 
                        danger 
                        onClick={() => removePledge(plg.id)} 
                      />
                    </KebabMenu>
                  </div>
                </div>
                <div className="text-[10px] text-slate-400 mt-3 pt-3 border-t border-slate-100 font-bold">{plg.date}</div>
              </motion.div>
            ))
          )}
        </div>
      </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
