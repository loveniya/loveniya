import React, { useState } from 'react';
import { Camera, Plus, Star, Trash2, Edit3 } from 'lucide-react';
import { useStore } from '../lib/store';
import { Memory } from '../lib/types';
import { KebabMenu, KebabMenuItem } from '../components/KebabMenu';

export const Memories: React.FC = () => {
  const { memories, addMemory, updateMemory, removeMemory } = useStore();
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [title, setTitle] = useState('');
  const [desc, setDesc] = useState('');
  const [vidUrl, setVidUrl] = useState('');
  
  const handleEdit = (mem: Memory) => {
    setEditingId(mem.id);
    setTitle(mem.title);
    setDesc(mem.desc);
    setVidUrl(mem.vidUrl || '');
    setShowForm(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingId) {
      const existing = memories.find(m => m.id === editingId);
      if (existing) {
        updateMemory({
          ...existing,
          title,
          desc,
          vidUrl,
        });
      }
    } else {
      const newMemory: Memory = {
        id: Date.now().toString(),
        title,
        desc,
        vidUrl,
        date: new Date().toLocaleDateString('fa-IR'),
        pinned: false
      };
      addMemory(newMemory);
    }
    resetForm();
  };

  const resetForm = () => {
    setTitle('');
    setDesc('');
    setVidUrl('');
    setEditingId(null);
    setShowForm(false);
  };

  return (
    <div className="space-y-6" dir="rtl">
      <div className="glass-card rounded-3xl p-6 md:p-8">
        <div className="flex flex-wrap justify-between items-center gap-3 mb-6">
          <div>
            <h2 className="text-xl font-black text-slate-800 flex items-center gap-2">
              <Camera className="w-5 h-5 text-rose-500" /> قاب خاطرات
            </h2>
            <p className="text-[11px] text-slate-500 font-medium mt-0.5">ثبت عکس‌ها، ویدیوها و لحظات رویایی ما</p>
          </div>
          <button 
            onClick={() => {
              if (showForm) {
                resetForm();
              } else {
                setShowForm(true);
              }
            }} 
            className="bg-gradient-to-r from-rose-400 to-pink-400 text-white hover:opacity-90 px-4 py-2.5 rounded-full text-xs font-bold transition-all flex items-center gap-1.5 shadow-sm active:scale-95"
          >
            <Plus className="w-4 h-4" /> {showForm ? 'بستن فرم' : 'ثبت خاطره جدید'}
          </button>
        </div>

        {showForm && (
          <div className="mb-6 bg-white/80 rounded-2xl p-5 border border-rose-200 shadow-sm">
            <form onSubmit={handleSave} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">عنوان خاطره:</label>
                <input type="text" placeholder="مثلا: اولین غروب آفتاب کنار دریا..." required value={title} onChange={e => setTitle(e.target.value)}
                       className="w-full bg-white/90 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs focus:border-rose-400 focus:outline-none font-bold text-slate-800" />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">لینک ویدیو/عکس (اختیاری):</label>
                <input type="url" placeholder="https://..." value={vidUrl} onChange={e => setVidUrl(e.target.value)}
                       className="w-full bg-white/90 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:border-rose-400 focus:outline-none" />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">شرح احساسی خاطره:</label>
                <textarea rows={3} placeholder="احساسات اون لحظه‌ت رو بنویس..." required value={desc} onChange={e => setDesc(e.target.value)}
                          className="w-full bg-white/90 border border-slate-200 rounded-xl p-3 text-xs focus:border-rose-400 focus:outline-none leading-relaxed"></textarea>
              </div>
              <div className="flex justify-end gap-2 pt-1">
                <button type="button" onClick={resetForm} className="bg-slate-200 text-slate-700 text-xs px-4 py-2 rounded-full font-bold">انصراف</button>
                <button type="submit" className="bg-rose-500 text-white text-xs font-bold px-6 py-2 rounded-full hover:bg-rose-600 shadow-md">
                  {editingId ? 'ذخیره تغییرات' : 'ثبت خاطره'}
                </button>
              </div>
            </form>
          </div>
        )}

        <div className="space-y-3">
          {memories.length === 0 ? (
            <p className="text-center text-slate-500 text-xs py-10">هنوز خاطره‌ای ثبت نشده...</p>
          ) : (
            memories.map(mem => (
              <div key={mem.id} className="bg-white/80 p-4 rounded-2xl border border-rose-100 shadow-sm relative group">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-bold text-slate-800 text-sm flex items-center gap-2">
                    {mem.title}
                    {mem.pinned && <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />}
                  </h3>
                  <div className="flex gap-2">
                    <KebabMenu>
                      <KebabMenuItem 
                        icon={<Star className="w-4 h-4" />} 
                        label={mem.pinned ? 'برداشتن نشان' : 'نشان کردن'} 
                        onClick={() => updateMemory({ ...mem, pinned: !mem.pinned })} 
                      />
                      <KebabMenuItem 
                        icon={<Edit3 className="w-4 h-4" />} 
                        label="ویرایش" 
                        onClick={() => handleEdit(mem)} 
                      />
                      <KebabMenuItem 
                        icon={<Trash2 className="w-4 h-4" />} 
                        label="حذف" 
                        danger 
                        onClick={() => removeMemory(mem.id)} 
                      />
                    </KebabMenu>
                  </div>
                </div>
                <p className="text-xs text-slate-600 mb-3 whitespace-pre-wrap">{mem.desc}</p>
                {mem.vidUrl && (
                  <a href={mem.vidUrl} target="_blank" rel="noreferrer" className="text-xs text-sky-500 hover:underline">
                    مشاهده ضمیمه
                  </a>
                )}
                <div className="text-[10px] text-slate-400 mt-2">{mem.date}</div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
