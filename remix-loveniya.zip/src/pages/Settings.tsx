import React from 'react';
import { Settings as SettingsIcon, Trash2, Lock, CloudOff, Cloud, AlertCircle, RefreshCcw } from 'lucide-react';
import { useStore } from '../lib/store';

export const Settings: React.FC<{ onLock: () => void }> = ({ onLock }) => {
  const { trashItems, emptyTrash, restoreFromTrash, permanentlyDeleteFromTrash, syncStatus, syncError } = useStore();

  return (
    <div className="space-y-6" dir="rtl">
      <div className="glass-card rounded-3xl p-6 md:p-8">
        <h2 className="text-xl font-black text-slate-800 flex items-center gap-2 mb-6">
          <SettingsIcon className="w-5 h-5 text-slate-500" /> تنظیمات سایت
        </h2>

        <div className="space-y-4">
          
          {/* Lock Action */}
          <div className="bg-white/70 p-4 rounded-2xl border border-slate-100 flex items-center justify-between">
            <div>
              <h3 className="font-bold text-sm text-slate-700">قفل کردن مجدد سایت</h3>
              <p className="text-xs text-slate-500">برای ورود مجدد نیاز به رمز خواهد بود.</p>
            </div>
            <button onClick={onLock} className="bg-slate-200 hover:bg-slate-300 text-slate-700 px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2">
              <Lock className="w-4 h-4" /> قفل کردن
            </button>
          </div>

          {/* Sync Status */}
          <div className={`p-4 rounded-2xl border flex items-center justify-between shadow-sm transition-colors duration-300 ${syncStatus === 'connected' ? 'border-emerald-100 bg-emerald-50/60' : syncStatus === 'error' ? 'border-rose-100 bg-rose-50/60' : 'border-amber-100 bg-amber-50/60'}`}>
            <div>
              <h3 className="font-bold text-sm text-slate-700">وضعیت پایگاه داده (Firebase)</h3>
              <p className="text-xs text-slate-500 mt-1 max-w-[200px] sm:max-w-none">
                {syncStatus === 'connected' 
                  ? 'اطلاعات به صورت امن و زنده همگام‌سازی می‌شود.'
                  : syncStatus === 'error' 
                    ? `خطا در همگام‌سازی: ${syncError || 'نامشخص'}`
                    : 'در حال ارتباط با سرور ابری یا آفلاین...'}
              </p>
            </div>
            
            {syncStatus === 'connected' ? (
              <div className="flex items-center gap-1.5 text-[11px] font-bold text-emerald-600 bg-emerald-100 px-3 py-1.5 rounded-lg border border-emerald-200">
                <Cloud className="w-4 h-4" /> متصل
              </div>
            ) : syncStatus === 'error' ? (
              <div className="flex items-center gap-1.5 text-[11px] font-bold text-rose-600 bg-rose-100 px-3 py-1.5 rounded-lg border border-rose-200">
                <AlertCircle className="w-4 h-4" /> خطا
              </div>
            ) : (
              <div className="flex items-center gap-1.5 text-[11px] font-bold text-amber-600 bg-amber-100 px-3 py-1.5 rounded-lg border border-amber-200">
                <CloudOff className="w-4 h-4" /> قطع
              </div>
            )}
          </div>

          {/* Trash Bin */}
          <div className="bg-white/70 p-4 rounded-2xl border border-rose-100">
            <div className="flex items-center justify-between mb-4 pb-4 border-b border-rose-50">
              <div>
                <h3 className="font-bold text-sm text-rose-600 flex items-center gap-2">
                  <Trash2 className="w-4 h-4" /> سطل زباله
                  <span className="bg-rose-100 text-rose-600 px-2 py-0.5 rounded-full text-[10px]">{trashItems.length}</span>
                </h3>
                <p className="text-xs text-slate-500 mt-1">آیتم‌های حذف شده رو می‌تونی برگردونی</p>
              </div>
              {trashItems.length > 0 && (
                <button onClick={emptyTrash} className="text-xs text-rose-500 hover:text-rose-700 font-bold bg-rose-50 px-3 py-1.5 rounded-lg">
                  خالی کردن کامل
                </button>
              )}
            </div>

            <div className="space-y-2 max-h-64 overflow-y-auto custom-scroll pr-1">
              {trashItems.length === 0 ? (
                <p className="text-center text-xs text-slate-400 py-4">سطل زباله خالی است.</p>
              ) : (
                trashItems.map(item => (
                  <div key={item.trashId} className="flex items-center justify-between bg-slate-50 p-3 rounded-xl border border-slate-100">
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold uppercase block mb-0.5">{item.type}</span>
                      <p className="text-xs text-slate-700 font-medium truncate max-w-[200px]">
                        {item.itemPayload.title || item.itemPayload.text || 'آیتم بدون نام'}
                      </p>
                    </div>
                    <div className="flex items-center gap-1">
                      <button onClick={() => restoreFromTrash(item.trashId)} className="text-xs text-sky-500 hover:bg-sky-50 p-1.5 rounded-lg flex items-center justify-center" title="بازگردانی">
                        <RefreshCcw className="w-4 h-4" />
                      </button>
                      <button onClick={() => permanentlyDeleteFromTrash(item.trashId)} className="text-xs text-rose-500 hover:bg-rose-50 p-1.5 rounded-lg flex items-center justify-center" title="حذف برای همیشه">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
