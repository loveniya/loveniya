import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { Memory, Pledge, Dream, Music, Capsule, TrashItem, SyncStatus } from './types';
import { rtdb } from './firebase';
import { ref, set, onValue } from 'firebase/database';

interface StoreContextType {
  memories: Memory[];
  pledges: Pledge[];
  dreams: Dream[];
  playlist: Music[];
  capsules: Capsule[];
  trashItems: TrashItem[];
  letterContent: string;
  syncStatus: SyncStatus;
  syncError: string | null;
  addMemory: (m: Memory) => void;
  updateMemory: (m: Memory) => void;
  removeMemory: (id: string) => void;
  addPledge: (p: Pledge) => void;
  updatePledge: (p: Pledge) => void;
  removePledge: (id: string) => void;
  addDream: (d: Dream) => void;
  updateDream: (d: Dream) => void;
  removeDream: (id: string) => void;
  addMusic: (m: Music) => void;
  updateMusic: (m: Music) => void;
  removeMusic: (id: string) => void;
  addCapsule: (c: Capsule) => void;
  updateCapsule: (c: Capsule) => void;
  removeCapsule: (id: string) => void;
  setLetterContent: (text: string) => void;
  moveToTrash: (type: TrashItem['type'], item: any) => void;
  emptyTrash: () => void;
  restoreFromTrash: (trashId: string) => void;
  permanentlyDeleteFromTrash: (trashId: string) => void;
}

const StoreContext = createContext<StoreContextType | null>(null);

export const useStore = () => {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error('useStore must be used within StoreProvider');
  return ctx;
};

export const StoreProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const load = <T,>(key: string, def: T): T => {
    try {
      const stored = localStorage.getItem(key);
      return stored ? JSON.parse(stored) : def;
    } catch {
      return def;
    }
  };

  const [memories, setMemoriesState] = useState<Memory[]>(() => load('loveniya_mems', []));
  const [pledges, setPledgesState] = useState<Pledge[]>(() => load('loveniya_plg', []));
  const [dreams, setDreamsState] = useState<Dream[]>(() => load('loveniya_dreams', []));
  const [playlist, setPlaylistState] = useState<Music[]>(() => load('loveniya_msc', []));
  const [capsules, setCapsulesState] = useState<Capsule[]>(() => load('loveniya_capsules', []));
  const [trashItems, setTrashItemsState] = useState<TrashItem[]>(() => load('loveniya_trash', []));
  const [letterContent, setLetterContentState] = useState<string>(() => {
    return localStorage.getItem('loveniya_letter') || '';
  });
  
  const [syncStatus, setSyncStatus] = useState<SyncStatus>('disconnected');
  const [syncError, setSyncError] = useState<string | null>(null);

  useEffect(() => {
    const connectedRef = ref(rtdb, '.info/connected');
    const unsubConnected = onValue(connectedRef, (snap) => {
      if (snap.val() === true) {
        setSyncStatus('connected');
        setSyncError(null);
      } else {
        setSyncStatus('disconnected');
      }
    });

    const unsubMemories = onValue(ref(rtdb, 'loveniya_mems'), (s) => setMemoriesState(s.val() || []));
    const unsubPledges = onValue(ref(rtdb, 'loveniya_plg'), (s) => setPledgesState(s.val() || []));
    const unsubDreams = onValue(ref(rtdb, 'loveniya_dreams'), (s) => setDreamsState(s.val() || []));
    const unsubPlaylist = onValue(ref(rtdb, 'loveniya_msc'), (s) => setPlaylistState(s.val() || []));
    const unsubCapsules = onValue(ref(rtdb, 'loveniya_capsules'), (s) => setCapsulesState(s.val() || []));
    const unsubTrash = onValue(ref(rtdb, 'loveniya_trash'), (s) => setTrashItemsState(s.val() || []));
    const unsubLetter = onValue(ref(rtdb, 'loveniya_letter'), (s) => setLetterContentState(s.val() || ''));

    return () => {
      unsubConnected();
      unsubMemories();
      unsubPledges();
      unsubDreams();
      unsubPlaylist();
      unsubCapsules();
      unsubTrash();
      unsubLetter();
    };
  }, []);

  const safeSet = useCallback(async (path: string, data: any) => {
    try {
      await set(ref(rtdb, path), data);
      setSyncError(null);
    } catch (err: any) {
      setSyncStatus('error');
      setSyncError(err.message || 'خطا در ارتباط با سرور.');
    }
  }, []);

  const setMemories = (v: Memory[]) => safeSet('loveniya_mems', v);
  const setPledges = (v: Pledge[]) => safeSet('loveniya_plg', v);
  const setDreams = (v: Dream[]) => safeSet('loveniya_dreams', v);
  const setPlaylist = (v: Music[]) => safeSet('loveniya_msc', v);
  const setCapsules = (v: Capsule[]) => safeSet('loveniya_capsules', v);
  const setTrashItems = (v: TrashItem[]) => safeSet('loveniya_trash', v);
  const handleSetLetterContent = (text: string) => safeSet('loveniya_letter', text);


  const moveToTrash = (type: TrashItem['type'], item: any) => {
    const trashObj: TrashItem = {
      trashId: 'trash_' + Date.now(),
      type,
      deletedAt: new Date().toLocaleDateString('fa-IR'),
      itemPayload: item
    };
    setTrashItems([trashObj, ...trashItems]);
  };

  const restoreFromTrash = (trashId: string) => {
    const item = trashItems.find(t => t.trashId === trashId);
    if (!item) return;
    
    if (item.type === 'memory') setMemories([...memories, item.itemPayload]);
    if (item.type === 'pledge') setPledges([...pledges, item.itemPayload]);
    if (item.type === 'dream') setDreams([...dreams, item.itemPayload]);
    if (item.type === 'music') setPlaylist([...playlist, item.itemPayload]);
    if (item.type === 'capsule') setCapsules([...capsules, item.itemPayload]);
    
    setTrashItems(trashItems.filter(t => t.trashId !== trashId));
  };

  const permanentlyDeleteFromTrash = (trashId: string) => {
    setTrashItems(trashItems.filter(t => t.trashId !== trashId));
  };

  const emptyTrash = () => setTrashItems([]);

  const addMemory = (m: Memory) => setMemories([m, ...memories]);
  const updateMemory = (m: Memory) => setMemories(memories.map(x => x.id === m.id ? m : x));
  const removeMemory = (id: string) => {
    const item = memories.find(x => x.id === id);
    if (item) moveToTrash('memory', item);
    setMemories(memories.filter(x => x.id !== id));
  };

  const addPledge = (p: Pledge) => setPledges([p, ...pledges]);
  const updatePledge = (p: Pledge) => setPledges(pledges.map(x => x.id === p.id ? p : x));
  const removePledge = (id: string) => {
    const item = pledges.find(x => x.id === id);
    if (item) moveToTrash('pledge', item);
    setPledges(pledges.filter(x => x.id !== id));
  };

  const addDream = (d: Dream) => setDreams([d, ...dreams]);
  const updateDream = (d: Dream) => setDreams(dreams.map(x => x.id === d.id ? d : x));
  const removeDream = (id: string) => {
    const item = dreams.find(x => x.id === id);
    if (item) moveToTrash('dream', item);
    setDreams(dreams.filter(x => x.id !== id));
  };

  const addMusic = (m: Music) => setPlaylist([m, ...playlist]);
  const updateMusic = (m: Music) => setPlaylist(playlist.map(x => x.id === m.id ? m : x));
  const removeMusic = (id: string) => {
    const item = playlist.find(x => x.id === id);
    if (item) moveToTrash('music', item);
    setPlaylist(playlist.filter(x => x.id !== id));
  };

  const addCapsule = (c: Capsule) => setCapsules([c, ...capsules]);
  const updateCapsule = (c: Capsule) => setCapsules(capsules.map(x => x.id === c.id ? c : x));
  const removeCapsule = (id: string) => {
    const item = capsules.find(x => x.id === id);
    if (item) moveToTrash('capsule', item);
    setCapsules(capsules.filter(x => x.id !== id));
  };

  return (
    <StoreContext.Provider value={{
      memories, pledges, dreams, playlist, capsules, trashItems, letterContent,
      syncStatus, syncError,
      addMemory, updateMemory, removeMemory,
      addPledge, updatePledge, removePledge,
      addDream, updateDream, removeDream,
      addMusic, updateMusic, removeMusic,
      addCapsule, updateCapsule, removeCapsule,
      setLetterContent: handleSetLetterContent,
      moveToTrash, emptyTrash, restoreFromTrash, permanentlyDeleteFromTrash
    }}>
      {children}
    </StoreContext.Provider>
  );
};
