export type Memory = {
  id: string;
  title: string;
  desc: string;
  vidUrl?: string;
  mediaData?: string;
  photos?: string[]; // Multiple photos support
  isVideoFile?: boolean;
  date: string;
  pinned?: boolean; // We will use this for "Pin as Top/Best"
  synced?: boolean;
};

export type SyncStatus = 'connected' | 'disconnected' | 'error';


export type Pledge = {
  id: string;
  text: string;
  date: string;
  pinned?: boolean;
  synced?: boolean;
};

export type Dream = {
  id: string;
  text: string;
  date: string;
  pinned?: boolean;
  synced?: boolean;
};

export type Music = {
  id: string;
  title: string;
  artist: string;
  url: string;
  pinned?: boolean;
  synced?: boolean;
};

export type Capsule = {
  id: string;
  title: string;
  text: string;
  openDate: string; // ISO string or Persian date
  isOpened?: boolean;
  pinned?: boolean;
  synced?: boolean;
  sender?: string;
  recipient?: string;
  createdAt?: number;
};

export type TrashItem = {
  trashId: string;
  type: 'memory' | 'pledge' | 'dream' | 'music' | 'capsule';
  deletedAt: string;
  itemPayload: any;
};
