import React, { useState } from 'react';
import { useStore } from '../lib/store';
import { Play, Pause, SkipForward, SkipBack, Music, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import ReactPlayer from 'react-player';

export const MediaPlayer: React.FC = () => {
  const { playlist } = useStore();
  const [isOpen, setIsOpen] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);

  const currentTrack = playlist[currentIndex];

  const handleNext = () => {
    if (playlist.length === 0) return;
    setCurrentIndex((prev) => (prev + 1) % playlist.length);
    setIsPlaying(true);
  };

  const handlePrev = () => {
    if (playlist.length === 0) return;
    setCurrentIndex((prev) => (prev - 1 + playlist.length) % playlist.length);
    setIsPlaying(true);
  };

  return (
    <>
      {currentTrack && (
        <div className="hidden">
          <ReactPlayer 
            src={currentTrack.url}
            playing={isPlaying}
            onEnded={handleNext}
            width="0"
            height="0"
          />
        </div>
      )}

      <AnimatePresence>
        {!isOpen && (
          <motion.button
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            onClick={() => setIsOpen(true)}
            className="fixed bottom-24 right-4 z-[60] w-14 h-14 bg-gradient-to-br from-rose-500 to-purple-600 rounded-full shadow-lg shadow-rose-300 flex items-center justify-center text-white md:bottom-6 hover:scale-105 transition-transform border-2 border-white"
          >
            <Music className={`w-6 h-6 ${isPlaying ? 'animate-pulse' : ''}`} />
          </motion.button>
        )}

        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="fixed bottom-24 right-4 z-[60] w-72 bg-white/95 backdrop-blur-xl border border-rose-100 rounded-3xl p-5 shadow-[0_10px_40px_rgba(244,114,182,0.3)] md:bottom-6"
            dir="rtl"
          >
            <button 
              onClick={() => setIsOpen(false)}
              className="absolute top-4 left-4 text-slate-400 hover:text-slate-600 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            {playlist.length === 0 ? (
              <div className="text-center py-4">
                <Music className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                <p className="text-xs font-bold text-slate-500">پلی‌لیست خالیه!</p>
                <p className="text-[10px] text-slate-400 mt-1">اول برو تو بخش موزیک یه آهنگ اضافه کن</p>
              </div>
            ) : (
              <>
                <div className="flex items-center gap-3 mb-5 mt-1">
                  <div className={`w-12 h-12 rounded-full bg-gradient-to-br from-rose-400 to-purple-500 flex items-center justify-center shadow-md ${isPlaying ? 'animate-[spin_4s_linear_infinite]' : ''}`}>
                    <Music className="w-5 h-5 text-white" />
                  </div>
                  <div className="flex-1 min-w-0 pr-1">
                    <h4 className="text-sm font-black text-slate-800 truncate">{currentTrack.title}</h4>
                    <p className="text-xs font-bold text-slate-500 truncate mt-0.5">{currentTrack.artist}</p>
                  </div>
                </div>

                <div className="flex items-center justify-center gap-5">
                  <button onClick={handleNext} className="text-slate-400 hover:text-rose-500 transition-colors">
                    <SkipForward className="w-6 h-6" />
                  </button>
                  
                  <button 
                    onClick={() => setIsPlaying(!isPlaying)}
                    className="w-12 h-12 bg-gradient-to-r from-rose-500 to-pink-500 rounded-full flex items-center justify-center text-white shadow-lg hover:scale-105 transition-all"
                  >
                    {isPlaying ? <Pause className="w-5 h-5 fill-white" /> : <Play className="w-5 h-5 fill-white ml-1" />}
                  </button>

                  <button onClick={handlePrev} className="text-slate-400 hover:text-rose-500 transition-colors">
                    <SkipBack className="w-6 h-6" />
                  </button>
                </div>
              </>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};
