import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Heart } from 'lucide-react';

interface Particle {
  id: number;
  x: number;
  y: number;
}

export const RomanticEffects: React.FC = () => {
  const [clicks, setClicks] = useState<Particle[]>([]);

  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      // Don't spawn hearts if clicking on a button or input
      const target = e.target as HTMLElement;
      if (target.tagName === 'BUTTON' || target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.closest('button')) {
        return;
      }

      const newParticle = { id: Date.now(), x: e.clientX, y: e.clientY };
      setClicks((prev) => [...prev, newParticle]);

      // Remove after animation completes
      setTimeout(() => {
        setClicks((prev) => prev.filter(p => p.id !== newParticle.id));
      }, 1000);
    };

    window.addEventListener('click', handleClick);
    return () => window.removeEventListener('click', handleClick);
  }, []);

  // Spawn some floating particles continuously in the background
  const [floaters, setFloaters] = useState<{id: number, left: string, delay: string}[]>([]);
  
  useEffect(() => {
    const newFloaters = Array.from({ length: 15 }).map((_, i) => ({
      id: i,
      left: `${Math.random() * 100}vw`,
      delay: `${Math.random() * 20}s`
    }));
    setFloaters(newFloaters);
  }, []);

  return (
    <>
      {/* Background Floating Particles */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        {floaters.map(f => (
          <div
            key={f.id}
            className="absolute bottom-[-5vh] text-rose-300/30 opacity-50"
            style={{
              left: f.left,
              animation: `floatUp 15s linear infinite`,
              animationDelay: f.delay,
              fontSize: `${Math.random() * 20 + 10}px`
            }}
          >
            ❤
          </div>
        ))}
      </div>

      {/* Click Hearts */}
      <div className="fixed inset-0 pointer-events-none z-50">
        <AnimatePresence>
          {clicks.map(click => (
            <motion.div
              key={click.id}
              initial={{ scale: 0, opacity: 1, x: click.x - 12, y: click.y - 12 }}
              animate={{ 
                scale: 1.5, 
                opacity: 0,
                y: click.y - 50 
              }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.8, ease: "easeOut" }}
              className="absolute text-rose-500"
            >
              <Heart className="w-6 h-6 fill-rose-500" />
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      <style dangerouslySetInnerHTML={{__html: `
        @keyframes floatUp {
          0% { transform: translateY(0) rotate(0deg); opacity: 0; }
          10% { opacity: 0.5; }
          90% { opacity: 0.5; }
          100% { transform: translateY(-110vh) rotate(360deg); opacity: 0; }
        }
      `}} />
    </>
  );
};
