import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
// فونت وزیرمتن روی خود سایت (بدون وابستگی به CDN خارجی)
import '@fontsource-variable/vazirmatn';
import App from './App.tsx';
import './index.css';

// قفل زوم: متای viewport در اندروید کافیه، ولی iOS Safari اون رو نادیده می‌گیره و
// pinch-zoom رو با رویدادهای gesture* (و scale در touchmove) انجام می‌ده؛ اینجا مسدودشون می‌کنیم.
// دابل‌تپ-زوم هم با touch-action: manipulation در index.css بسته شده (بدون اینکه تپ‌های سریع دکمه‌ها رو ببلعه).
const blockZoom = (e: Event) => e.preventDefault();
document.addEventListener('gesturestart', blockZoom);
document.addEventListener('gesturechange', blockZoom);
document.addEventListener('gestureend', blockZoom);
document.addEventListener(
  'touchmove',
  (e: TouchEvent) => {
    if (e.touches.length > 1 || ((e as unknown as { scale?: number }).scale ?? 1) !== 1) e.preventDefault();
  },
  { passive: false }
);
createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
