# Loveniya Cloudflare Workers — V7 Final

دو Worker مستقل برای نسخهٔ GitHub Pages:

- `loveniya-firebase-proxy-worker.js` — ورود، نشست امضاشده، کنترل Origin و دسترسی کنترل‌شده به Firebase Realtime Database.
- `loveniya-ai-worker.js` — چت/استریم هوش مصنوعی و ذخیرهٔ پیام‌های هوشمند.

هر Worker را جداگانه در Cloudflare Workers بسازید. کد سایت داخل بستهٔ GitHub Pages نیست و این دو فایل نیز داخل ZIP سایت قرار داده نشده‌اند.

## 1) Data / Firebase Worker

نام پیشنهادی: `loveniya-firebase-proxy-v7`

Secrets / Variables:

```text
APP_SECRET=یک-رشته-تصادفی-طولانی-و-منحصر-به-فرد
FIREBASE_SECRET=Firebase-Database-Secret
APP_UNLOCK_PASSWORD_SHA256=SHA256-رمز-ورود-نرمال-شده
SESSION_SECRET=یک-رشته-تصادفی-طولانی
ALLOWED_ORIGIN=https://ACCOUNT.github.io
```

اختیاری برای rate limit پایدارتر:

```text
LOGIN_RATE_LIMIT_KV=<KV binding>
```

## 2) AI Worker

نام پیشنهادی: `loveniya-ai-v7`

Binding / Secrets:

```text
AI=<Workers AI binding>
APP_SECRET=دقیقاً همان APP_SECRET در Worker اول
SESSION_SECRET=دقیقاً همان SESSION_SECRET در Worker اول
FIREBASE_PROXY_URL=https://loveniya-firebase-proxy-v7.<SUBDOMAIN>.workers.dev
ALLOWED_ORIGIN=https://ACCOUNT.github.io
```

`APP_SECRET` و `SESSION_SECRET` را هرگز داخل GitHub repository یا فایل JavaScript قرار ندهید.

## 3) اتصال GitHub Pages

در Repository > Settings > Secrets and variables > Actions > Variables این دو متغیر را بسازید:

```text
LOVENIYA_DATA_WORKER_URL=https://loveniya-firebase-proxy-v7.<SUBDOMAIN>.workers.dev
LOVENIYA_AI_WORKER_URL=https://loveniya-ai-v7.<SUBDOMAIN>.workers.dev
```

Workflow انتشار سایت این دو مقدار را هنگام build به `VITE_FIREBASE_PROXY_URL` و `VITE_AI_WORKER_URL` تبدیل می‌کند و بدون آن‌ها build انتشار را متوقف می‌کند.

## 4) نکات عملی

- `ALLOWED_ORIGIN` باید origin باشد، نه مسیر repository؛ مثلاً `https://account.github.io`، نه `https://account.github.io/loveniya`.
- ورود و Firebase روی Worker اول با session token کار می‌کنند.
- Worker دوم برای درخواست مرورگر به session معتبر نیاز دارد و برای ارتباط داخلی با Worker اول از `APP_SECRET` استفاده می‌کند.
- پیام هوش مصنوعی در دادهٔ ذخیره‌شده با عنوان عمومی `پیام هوشمند` ثبت می‌شود تا نام برند روی حباب چت ظاهر نشود.
