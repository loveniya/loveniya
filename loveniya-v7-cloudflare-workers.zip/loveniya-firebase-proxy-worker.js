/*
 * Loveniya Firebase proxy + GitHub Pages session gateway.
 *
 * Required Worker secrets/vars:
 *   APP_SECRET                    - internal secret used only by the AI worker
 *   FIREBASE_SECRET               - Firebase database secret/token
 *   APP_UNLOCK_PASSWORD_SHA256    - SHA-256 of the normalized app passphrase
 *   SESSION_SECRET                - long random secret shared with the AI worker
 *   ALLOWED_ORIGIN                - required comma-separated GitHub Pages origin(s)
 */

const encoder = new TextEncoder();
const decoder = new TextDecoder();
const SESSION_TTL_MS = 7 * 24 * 60 * 60 * 1000;
const MAX_PASSWORD_ATTEMPTS = 8;
const LOGIN_WINDOW_MS = 10 * 60 * 1000;
const MAX_BODY_BYTES = 256 * 1024;

const ALLOWED_PATHS = new Set([
  'loveniya_mems',
  'loveniya_plg',
  'loveniya_dreams',
  'loveniya_msc',
  'loveniya_capsules',
  'loveniya_trash',
  'loveniya_letter',
  'loveniya_chat',
  'loveniya_moments_v2',
  'loveniya_ldr_games_async',
  'loveniya_presence_amin',
  'loveniya_presence_niyayesh',
]);

const loginAttempts = new Map();

export default {
  async fetch(request, env) {
    const cors = getCors(request, env);

    if (!isOriginAllowed(request, env)) {
      return json({ error: 'Origin مجاز نیست.' }, 403, cors);
    }

    if (request.method === 'OPTIONS') {
      return new Response(null, { status: 204, headers: cors });
    }

    try {
      const url = new URL(request.url);

      if (request.method !== 'GET' && request.headers.get('Content-Length')) {
        const size = Number(request.headers.get('Content-Length'));
        if (Number.isFinite(size) && size > MAX_BODY_BYTES) {
          return json({ error: 'بدنه درخواست بیش از حد بزرگ است.' }, 413, cors);
        }
      }

      if (url.pathname === '/auth/unlock' && request.method === 'POST') {
        return await handleUnlock(request, env, cors);
      }
      if (url.pathname === '/auth/status' && request.method === 'GET') {
        const session = await authenticate(request, env);
        return json({ authenticated: Boolean(session), ...(session ? { user: session.user, expiresAt: session.expiresAt } : {}) }, 200, cors);
      }
      if (url.pathname === '/auth/lock' && request.method === 'POST') {
        return json({ ok: true }, 200, cors);
      }

      if (url.pathname === '/' && request.method === 'GET') {
        return json({ ok: true, service: 'Loveniya Firebase Proxy', status: 'online' }, 200, cors);
      }

      const internalSecret = env.APP_SECRET || '';
      const internalAccess = Boolean(internalSecret && request.headers.get('X-App-Secret') === internalSecret);
      const session = internalAccess ? null : await authenticate(request, env);
      if (!internalAccess && !session) {
        return json({ error: 'دسترسی غیرمجاز' }, 401, cors);
      }

      const path = normalizeFirebasePath(url.pathname);
      if (!path || !ALLOWED_PATHS.has(path.split('/')[0])) {
        return json({ error: 'مسیر مجاز نیست' }, 404, cors);
      }

      const firebaseSecret = env.FIREBASE_SECRET;
      if (!firebaseSecret) {
        return json({ error: 'FIREBASE_SECRET تنظیم نشده است.' }, 500, cors);
      }

      const upgrade = request.headers.get('Upgrade');
      const searchParams = url.search;
      const authQuery = searchParams ? `${searchParams}&auth=${encodeURIComponent(firebaseSecret)}` : `?auth=${encodeURIComponent(firebaseSecret)}`;
      const targetBase = upgrade === 'websocket'
        ? 'wss://amniya-love-default-rtdb.europe-west1.firebasedatabase.app'
        : 'https://amniya-love-default-rtdb.europe-west1.firebasedatabase.app';
      const targetUrl = `${targetBase}/${path}.json${authQuery}`;

      const response = await fetchWithRetry(targetUrl, {
        method: request.method,
        headers: { 'Content-Type': request.headers.get('Content-Type') || 'application/json', Accept: 'application/json' },
        body: request.method === 'GET' || request.method === 'HEAD' ? undefined : request.body,
        redirect: 'follow',
      }, request.method === 'GET' || request.method === 'HEAD' ? 2 : 1);

      const out = new Response(response.body, response);
      for (const [key, value] of Object.entries(cors)) out.headers.set(key, value);
      return out;
    } catch (error) {
      return json({ error: String(error?.message || error || 'خطای ناشناخته').slice(0, 300) }, 500, cors);
    }
  },
};

async function handleUnlock(request, env, cors) {
  const ip = request.headers.get('CF-Connecting-IP') || 'unknown';
  const now = Date.now();
  const key = `login:${ip}`;
  const current = await readRateLimit(env, key, now);
  if (current && current.resetAt > now && current.count >= MAX_PASSWORD_ATTEMPTS) {
    return json({ error: 'تعداد تلاش‌های ورود زیاد است؛ کمی بعد دوباره امتحان کن.' }, 429, cors);
  }

  const body = await request.json().catch(() => ({}));
  const user = body?.user === 'niyayesh' ? 'niyayesh' : body?.user === 'amin' ? 'amin' : null;
  const password = typeof body?.password === 'string' ? body.password : '';
  if (!user || !password) return json({ error: 'اطلاعات ورود ناقص است.' }, 400, cors);

  const expected = String(env.APP_UNLOCK_PASSWORD_SHA256 || '').trim().toLowerCase();
  if (!/^[a-f0-9]{64}$/.test(expected)) {
    return json({ error: 'پیکربندی رمز ورود روی Worker ناقص است.' }, 500, cors);
  }

  const candidate = await sha256Hex(normalizePassword(password));
  const ok = timingSafeEqual(candidate, expected);

  if (!ok) {
    const next = current && current.resetAt > now
      ? { count: current.count + 1, resetAt: current.resetAt }
      : { count: 1, resetAt: now + LOGIN_WINDOW_MS };
    await writeRateLimit(env, key, next);
    return json({ error: 'رمز اشتباه است.' }, 401, cors);
  }

  await deleteRateLimit(env, key);
  if (!env.SESSION_SECRET) return json({ error: 'SESSION_SECRET تنظیم نشده است.' }, 500, cors);

  const issuedAt = now;
  const expiresAt = now + SESSION_TTL_MS;
  const payload = encodeBase64Url(JSON.stringify({ user, iat: issuedAt, exp: expiresAt, nonce: crypto.randomUUID() }));
  const signature = encodeBase64Url(await hmacSign(env.SESSION_SECRET, payload));
  const token = `${payload}.${signature}`;

  return json({ authenticated: true, user, expiresAt, token }, 200, cors);
}

async function authenticate(request, env) {
  const header = request.headers.get('Authorization') || '';
  const match = /^Bearer\s+(.+)$/i.exec(header.trim());
  if (!match || !env.SESSION_SECRET) return null;

  const raw = match[1];
  const parts = raw.split('.');
  if (parts.length !== 2) return null;
  const [payload, signature] = parts;

  const expected = encodeBase64Url(await hmacSign(env.SESSION_SECRET, payload));
  if (!timingSafeEqual(signature, expected)) return null;

  try {
    const data = JSON.parse(decodeBase64Url(payload));
    if ((data?.user !== 'amin' && data?.user !== 'niyayesh') || typeof data.exp !== 'number' || data.exp <= Date.now()) return null;
    return { user: data.user, expiresAt: data.exp };
  } catch {
    return null;
  }
}

async function fetchWithRetry(input, init, attempts) {
  let lastError;
  for (let i = 0; i < attempts; i++) {
    try {
      const response = await fetch(input, init);
      if (response.status >= 500 && i + 1 < attempts) {
        await new Promise(resolve => setTimeout(resolve, 180 * (i + 1)));
        continue;
      }
      return response;
    } catch (error) {
      lastError = error;
      if (i + 1 < attempts) await new Promise(resolve => setTimeout(resolve, 180 * (i + 1)));
    }
  }
  throw lastError || new Error('Upstream request failed.');
}

async function readRateLimit(env, key, now) {
  if (env.LOGIN_RATE_LIMIT_KV) {
    try {
      const value = await env.LOGIN_RATE_LIMIT_KV.get(key, 'json');
      if (value && value.resetAt > now) return value;
    } catch {}
  }
  const memoryValue = loginAttempts.get(key);
  if (memoryValue && memoryValue.resetAt > now) return memoryValue;
  return null;
}

async function writeRateLimit(env, key, value) {
  loginAttempts.set(key, value);
  if (env.LOGIN_RATE_LIMIT_KV) {
    try { await env.LOGIN_RATE_LIMIT_KV.put(key, JSON.stringify(value), { expirationTtl: Math.max(60, Math.ceil((value.resetAt - Date.now()) / 1000)) }); } catch {}
  }
}

async function deleteRateLimit(env, key) {
  loginAttempts.delete(key);
  if (env.LOGIN_RATE_LIMIT_KV) {
    try { await env.LOGIN_RATE_LIMIT_KV.delete(key); } catch {}
  }
}

function isOriginAllowed(request, env) {
  const origin = request.headers.get('Origin');
  if (!origin) return true;
  const configured = String(env.ALLOWED_ORIGIN || '').split(',').map(v => v.trim()).filter(Boolean);
  return configured.length > 0 && configured.includes(origin);
}

function normalizeFirebasePath(pathname) {
  const raw = pathname.replace(/^\/+/, '').replace(/\.json$/i, '');
  const parts = raw.split('/').filter(Boolean);
  if (!parts.length || parts.some(part => part === '.' || part === '..')) return '';
  return parts.join('/');
}

function normalizePassword(value) {
  return String(value || '')
    .normalize('NFKC')
    .trim()
    .toLocaleLowerCase('fa-IR')
    .replace(/ي/g, 'ی')
    .replace(/ك/g, 'ک')
    .replace(/\s+/g, ' ');
}

async function sha256Hex(value) {
  const hash = await crypto.subtle.digest('SHA-256', encoder.encode(value));
  return Array.from(new Uint8Array(hash), byte => byte.toString(16).padStart(2, '0')).join('');
}

async function hmacSign(secret, value) {
  const key = await crypto.subtle.importKey('raw', encoder.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  return await crypto.subtle.sign('HMAC', key, encoder.encode(value));
}

function timingSafeEqual(a, b) {
  const left = String(a);
  const right = String(b);
  if (left.length !== right.length) return false;
  let diff = 0;
  for (let i = 0; i < left.length; i++) diff |= left.charCodeAt(i) ^ right.charCodeAt(i);
  return diff === 0;
}

function encodeBase64Url(value) {
  const bytes = typeof value === 'string' ? encoder.encode(value) : new Uint8Array(value);
  let binary = '';
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
}

function decodeBase64Url(value) {
  const padded = String(value).replace(/-/g, '+').replace(/_/g, '/') + '==='.slice((String(value).length + 3) % 4);
  const binary = atob(padded);
  const bytes = Uint8Array.from(binary, char => char.charCodeAt(0));
  return decoder.decode(bytes);
}

function getCors(request, env) {
  const configured = String(env.ALLOWED_ORIGIN || '').split(',').map(value => value.trim()).filter(Boolean);
  const origin = request.headers.get('Origin');
  const allowOrigin = origin && configured.includes(origin) ? origin : (configured[0] || 'null');
  return {
    'Access-Control-Allow-Origin': allowOrigin,
    'Access-Control-Allow-Methods': 'GET, POST, PUT, PATCH, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-App-Secret',
    'Access-Control-Max-Age': '86400',
    'Vary': 'Origin',
  };
}

function json(data, status, headers) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      ...headers,
      'Content-Type': 'application/json; charset=UTF-8',
      'Cache-Control': 'no-store',
      'X-Content-Type-Options': 'nosniff',
      'Referrer-Policy': 'no-referrer',
    },
  });
}
