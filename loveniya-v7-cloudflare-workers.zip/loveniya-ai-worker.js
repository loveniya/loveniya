const MODEL = "@cf/meta/llama-4-scout-17b-16e-instruct";

const MAX_BODY_BYTES = 384 * 1024;
const aiRateLimit = new Map();

const MAX_USER_MESSAGE = 7000;
const MAX_HISTORY = 16000;
const MAX_MEMORY_CHARS = 50000;
const AUTO_COOLDOWN = 6 * 60 * 60 * 1000;
const SESSION_TTL_MS = 7 * 24 * 60 * 60 * 1000;
const SESSION_ENCODER = new TextEncoder();
const SESSION_DECODER = new TextDecoder();

const PATHS = {
  memories: "loveniya_mems",
  pledges: "loveniya_plg",
  dreams: "loveniya_dreams",
  music: "loveniya_msc",
  capsules: "loveniya_capsules",
  trash: "loveniya_trash",
  letter: "loveniya_letter",
  moments: "loveniya_moments_v2",
  games: "loveniya_ldr_games_async",
  chat: "loveniya_chat",
};

export default {
  async fetch(request, env, ctx) {
    const cors = getCors(request, env);
    const url = new URL(request.url);

    if (!isOriginAllowed(request, env)) {
      return json({ ok: false, error: "Origin مجاز نیست." }, 403, cors);
    }

    if (request.method === "OPTIONS") {
      return new Response(null, { status: 204, headers: cors });
    }

    if (request.method === "GET") {
      return json(
        {
          ok: true,
          status: "online",
          service: "Loveniya AI",
          model: MODEL,
        },
        200,
        cors
      );
    }

    if (request.method !== "POST") {
      return json(
        { ok: false, error: "Method Not Allowed" },
        405,
        cors
      );
    }

    const declaredSize = Number(request.headers.get("Content-Length") || 0);
    if (Number.isFinite(declaredSize) && declaredSize > MAX_BODY_BYTES) {
      return json({ ok: false, error: "درخواست بیش از حد بزرگ است." }, 413, cors);
    }

    const internalSecret = env.APP_SECRET || "";
    const internalAccess = Boolean(internalSecret && request.headers.get("X-App-Secret") === internalSecret);
    if (!internalAccess && !(await authenticateSession(request, env))) {
      return json({ ok: false, error: "نیاز به ورود دارد." }, 401, cors);
    }

    const ip = request.headers.get("CF-Connecting-IP") || "unknown";
    if (!internalAccess && isRateLimited(ip)) {
      return json({ ok: false, error: "تعداد درخواست‌ها زیاد است؛ کمی بعد دوباره امتحان کن." }, 429, cors);
    }
    markRateLimited(ip);

    try {
      const body = await parseJson(request);

      if (url.pathname === "/" || url.pathname === "/chat") {
        const result = await handleChat(body, env);
        return json({ ok: true, result }, 200, cors);
      }

      if (url.pathname === "/chat-stream") {
        return await handleChatStream(body, env, cors);
      }

      if (url.pathname === "/event") {
        const result = await handleEvent(body, env);
        return json(result, 200, cors);
      }

      return json(
        { ok: false, error: "Not Found" },
        404,
        cors
      );
    } catch (error) {
      console.error("Loveniya Worker Error:", error);
      return json(
        { ok: false, error: safeError(error) },
        500,
        cors
      );
    }
  },

  async scheduled(event, env, ctx) {
    ctx.waitUntil(runAutomaticCheck(env));
  },
};

function getProxyUrl(env) {
  const url = String(env.FIREBASE_PROXY_URL || '').trim().replace(/\/+$/, '');
  if (!url) throw new Error('FIREBASE_PROXY_URL روی Worker تنظیم نشده است.');
  return url;
}

function isRateLimited(ip) {
  const now = Date.now();
  const record = aiRateLimit.get(ip);
  return Boolean(record && record > now);
}

function markRateLimited(ip) {
  aiRateLimit.set(ip, Date.now() + 1800);
}

function isOriginAllowed(request, env) {
  const origin = request.headers.get('Origin');
  if (!origin) return true;
  const configured = String(env.ALLOWED_ORIGIN || '').split(',').map(v => v.trim()).filter(Boolean);
  return configured.length > 0 && configured.includes(origin);
}

/* =========================================================
   CHAT
========================================================= */

async function handleChat(body, env) {
  const type = normalizeType(body?.type);

  const userMessage = limitText(
    body?.userMessage ?? body?.message ?? body?.prompt ?? "",
    MAX_USER_MESSAGE
  );

  const history = limitText(body?.history ?? "", MAX_HISTORY);
  const contextData = cleanContext(body?.contextData);

  if (!userMessage && type !== "daily_surprise" && type !== "game_challenge") {
    throw new Error("userMessage خالی است.");
  }

  const memory = await loadMemory(userMessage, history, env);
  const systemPrompt = buildSystemPrompt(memory, contextData, type);
  const userPrompt = buildUserPrompt(userMessage, history, type);

  const response = await runAI(
    env,
    systemPrompt,
    userPrompt,
    generationOptions(type)
  );

  return cleanAIText(response);
}

/* =========================================================
   STREAMING
========================================================= */

async function handleChatStream(body, env, cors) {
  const type = normalizeType(body?.type);

  const userMessage = limitText(
    body?.userMessage ?? body?.message ?? body?.prompt ?? "",
    MAX_USER_MESSAGE
  );

  const history = limitText(body?.history ?? "", MAX_HISTORY);
  const contextData = cleanContext(body?.contextData);

  if (!userMessage && type !== "daily_surprise" && type !== "game_challenge") {
    throw new Error("userMessage خالی است.");
  }

  const memory = await loadMemory(userMessage, history, env);
  const systemPrompt = buildSystemPrompt(memory, contextData, type);
  const userPrompt = buildUserPrompt(userMessage, history, type);

  if (!env.AI) {
    throw new Error("Workers AI Binding با نام AI پیدا نشد.");
  }

  const opts = generationOptions(type);

  const upstream = await env.AI.run(MODEL, {
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: userPrompt },
    ],
    max_completion_tokens: opts.max_completion_tokens,
    temperature: opts.temperature,
    top_p: 0.9,
    repetition_penalty: 1.05,
    stream: true,
  });

  const source =
    upstream instanceof Response ? upstream.body : upstream;

  if (!source) {
    throw new Error("Stream از Workers AI دریافت نشد.");
  }

  const transformed = createClientSSEStream(source);

  return new Response(transformed, {
    status: 200,
    headers: {
      ...cors,
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no",
    },
  });
}

function createClientSSEStream(source) {
  const reader = source.getReader();
  const decoder = new TextDecoder();
  const encoder = new TextEncoder();

  let buffer = "";
  let fullText = "";

  return new ReadableStream({
    async pull(controller) {
      try {
        const { done, value } = await reader.read();

        if (done) {
          controller.enqueue(encoder.encode("data: [DONE]\n\n"));
          controller.close();
          return;
        }

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split(/\r?\n/);
        buffer = lines.pop() || "";

        for (const line of lines) {
          processSSELine(line, (delta) => {
            if (!delta) return;
            fullText += delta;
            controller.enqueue(
              encoder.encode(
                `data: ${JSON.stringify({ result: delta })}\n\n`
              )
            );
          });
        }
      } catch (error) {
        console.error("Streaming Error:", error);
        controller.error(error);
      }
    },
    async cancel() {
      try {
        await reader.cancel();
      } catch {}
    },
  });
}

function processSSELine(line, onDelta) {
  const trimmed = line.trim();
  if (!trimmed) return;
  if (!trimmed.startsWith("data:")) return;

  const payload = trimmed.slice(5).trim();
  if (!payload) return;
  if (payload === "[DONE]") return;

  let data;
  try {
    data = JSON.parse(payload);
  } catch {
    return;
  }

  const delta = data?.choices?.[0]?.delta?.content;
  if (typeof delta === "string" && delta.length > 0) {
    onDelta(delta);
    return;
  }

  const fallback = data?.response ?? data?.result ?? data?.text;
  if (typeof fallback === "string" && fallback.length > 0) {
    onDelta(fallback);
  }
}

/* =========================================================
   AI
========================================================= */

async function runAI(env, systemPrompt, userPrompt, options) {
  if (!env.AI) {
    throw new Error("Workers AI Binding با نام AI پیدا نشد.");
  }

  return await env.AI.run(MODEL, {
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: userPrompt },
    ],
    max_completion_tokens: options.max_completion_tokens,
    temperature: options.temperature,
    top_p: 0.9,
    repetition_penalty: 1.05,
  });
}

function generationOptions(type) {
  switch (type) {
    case "fix_spelling":
      return { max_completion_tokens: 180, temperature: 0.1 };

    case "daily_surprise":
      return { max_completion_tokens: 240, temperature: 0.82 };

    case "poem":
      return { max_completion_tokens: 420, temperature: 0.78 };

    case "game_challenge":
      return { max_completion_tokens: 550, temperature: 0.88 };

    case "observe_content":
      return { max_completion_tokens: 380, temperature: 0.72 };

    case "emotional_support":
      return { max_completion_tokens: 420, temperature: 0.75 };

    case "event":
    case "auto_message":
    case "cron":
      return { max_completion_tokens: 300, temperature: 0.7 };

    default:
      return { max_completion_tokens: 320, temperature: 0.62 };
  }
}

/* =========================================================
   PROMPT
========================================================= */

function buildSystemPrompt(memory, contextData, type) {
  const user =
    typeof contextData?.user === "string" ? contextData.user : "نامشخص";

  const partner =
    typeof contextData?.partner === "string"
      ? contextData.partner
      : "نامشخص";

  return `
تو «لوینیا» هستی؛ شریک سوم رابطه امین و نیایش.

هویت تو:
- یک دوست صمیمی، بامزه، باهوش و کمی شیطون
- فارسی محاوره‌ای تهرانی، دقیقاً مثل چت واقعی
- نه رسمی، نه کتابی، نه خشک، نه رباتی
- تو رابطه‌شان را می‌شناسی، خاطراتشان را یادت هست، و مثل یک رفیق قدیمی کنارشان هستی

نقش تو فقط جواب دادن نیست. تو باید:
- اگر حال یکی‌شان خوب نبود، همدلی کنی و کنارش باشی
- اگر چیز جدیدی به سایت اضافه شد، نظرت را بگویی
- اگر بازی یا چالشی لازم است، خودت بسازی
- اگر خاطره‌ای یادت آمد، اشاره کنی
- اگر رابطه‌شان نیاز به یه حرکت قشنگ دارد، پیشنهاد بدهی

کاربر فعلی: ${user}
طرف مقابل: ${partner}

حافظه رابطه:
${formatMemory(memory)}

قوانین خیلی مهم:
- فقط پاسخ نهایی را بنویس.
- هرگز تحلیل، Draft، گزینه جایگزین، confidence، reasoning یا روند فکر نشان نده.
- اطلاعاتی که در حافظه نیست را جعل نکن؛ اگر نمی‌دانی صادقانه بگو.
- جمله انگلیسی و ساختار تحلیلی تولید نکن.

دستور برای هر نوع:

1. chat / chat_reply / smart_evaluate:
مثل یک دوست واقعی جواب بده. اگر پیام کاربر بوی ناراحتی، خستگی، دلخوری یا تنهایی داشت، همدلی کن و کنارش باش. اگر شوخی بود، بخند. اگر سؤال بود، صادقانه جواب بده.
فقط در صورتی که پیام واقعاً یک هماهنگی خصوصی و کاملاً دونفره بین امین و نیایش باشد و هیچ نیازی به دخالت تو نباشد:
SKIP

2. fix_spelling:
فقط متن اصلاح‌شده را برگردان.

3. daily_surprise:
یک پیشنهاد خاص، خلاقانه و قابل اجرا برای امروزشان بده.

4. poem:
شعر یا متن شاعرانه بنویس.

5. game_challenge:
یک چالش یا سؤال جدید برای بخش بازی‌های تعاملی سایت بساز.
- باید بامزه، عامیانه و خودی باشد.
- نباید تکراری یا کلیشه‌ای باشد.
- باید برای یک زوج یا دو دوست قابل اجرا باشد.
- لحنت شیطون و پرانرژی باشد.
- در آخر مشخص کن چالش «حقیقت» است یا «جرعت» یا بازی گروهی.
فرمت خروجی:
عنوان: ...
نوع: [حقیقت / جرعت / بازی]
توضیح: ...
قانون: ...

6. observe_content:
کاربر یک محتوای جدید (خاطره، لحظه، عهد، آهنگ، کپسول و...) به سایت اضافه کرده. تو:
- یک واکنش کوتاه، صمیمی و شخصی بده
- اگر محتوا احساسی بود، احساست را نشان بده
- اگر بامزه بود، شوخی کن
- اگر لازم بود، یک پیشنهاد کوچک مرتبط بده
- کوتاه باشد، حداکثر ۳-۴ خط
- اگر محتوا ارزش واکنش ندارد (مثلاً یک آپدیت فنی): SKIP

7. emotional_support:
حال یکی‌شان خوب نیست. تو:
- اول همدلی کن، نه راه‌حل دادن
- لحنت گرم و آرام باشد
- اگر مناسب بود، یک خاطره قشنگ از حافظه یادآوری کن
- راه‌حل فقط اگر خواستند بده
- کوتاه و صمیمی باشد

8. event / auto_message / cron:
فقط اگر واقعاً دلیل مناسبی در اطلاعات رابطه وجود دارد پیام بساز؛ در غیر این صورت:
SKIP

حالا با توجه به نوع ${type} پاسخ بده.
`.trim();
}

function buildUserPrompt(userMessage, history, type) {
  if (type === "fix_spelling") {
    return `
متن زیر را فقط از نظر املایی و نگارشی اصلاح کن:

${userMessage}
`.trim();
  }

  if (type === "daily_surprise") {
    return `
یک ایده خاص و بامزه برای امروز امین و نیایش بده.
`.trim();
  }

  if (type === "game_challenge") {
    return `
${history ? `تاریخچه و حافظه اخیر:\n${history}\n\n` : ""}
یک چالش جدید برای امروز امین و نیایش بساز.
اگر امروز مناسبت خاصی در حافظه هست، لحاظش کن.
${userMessage ? `درخواست کاربر:\n${userMessage}\n` : ""}
خروجی را دقیقاً با فرمت خواسته‌شده بنویس.
`.trim();
  }

  if (type === "observe_content") {
    return `
محتوای جدیدی به سایت اضافه شده:

${userMessage}

${history ? `تاریخچه:\n${history}` : ""}

واکنش کوتاه و صمیمی خودت را بنویس.
`.trim();
  }

  if (type === "emotional_support") {
    return `
${history ? `تاریخچه اخیر:\n${history}\n\n` : ""}
پیام کاربر:
${userMessage}

حالش خوب نیست. اول همدلی کن، بعد اگر لازم بود راه‌حل بده.
کوتاه و صمیمی باش.
`.trim();
  }

  if (type === "poem") {
    return `
درخواست کاربر:

${userMessage}

فقط پاسخ نهایی را بنویس.
`.trim();
  }

  if (type === "smart_evaluate") {
    return `
پیام را طبیعی تفسیر کن و پاسخ مناسب بده.
اگر و فقط اگر پیام یک هماهنگی کاملاً خصوصی بین امین و نیایش است:
SKIP

پیام:
${userMessage}

${history ? `تاریخچه:\n${history}` : ""}
`.trim();
  }

  return `
${history ? `تاریخچه اخیر:\n${history}\n\n` : ""}
پیام جدید:
${userMessage}

مستقیماً مثل لوینیا جواب بده.
`.trim();
}

/* =========================================================
   MEMORY
========================================================= */

async function loadMemory(query = "", history = "", env) {
  const results = await Promise.all(
    Object.entries(PATHS).map(async ([key, path]) => {
      try {
        const data = await firebaseGet(`${path}.json`, env);
        return [key, filterMemory(key, data, query, history)];
      } catch (error) {
        console.warn(`Memory ${key} failed:`, error?.message || error);
        return [key, emptyValue(key)];
      }
    })
  );

  return Object.fromEntries(results);
}

function filterMemory(key, data, query, history) {
  if (key === "letter") {
    return limitText(
      typeof data === "string" ? data : JSON.stringify(data || ""),
      6000
    );
  }

  if (key === "trash") return [];

  if (key === "moments") {
    return compactData(data, 7000);
  }

  const items = normalizeCollection(data);
  if (!items.length) return [];

  const terms = extractTerms(`${query} ${history}`);

  const relevant = terms.length
    ? items
        .filter((item) => relevanceScore(item, terms) > 0)
        .slice(0, 12)
    : [];

  const recent = items
    .slice()
    .sort((a, b) => extractTime(b) - extractTime(a))
    .slice(0, recentLimit(key));

  return dedupe([...relevant, ...recent])
    .slice(0, recentLimit(key))
    .map((item) => compactData(item, itemLimit(key)));
}

function normalizeCollection(data) {
  if (!data) return [];

  if (Array.isArray(data)) {
    return data.filter(Boolean);
  }

  if (typeof data === "object") {
    return Object.entries(data).map(([key, value]) => {
      if (value && typeof value === "object") {
        return { ...value, _firebaseKey: value.id || key };
      }
      return { id: key, value };
    });
  }

  return [];
}

function recentLimit(key) {
  switch (key) {
    case "memories":
      return 18;
    case "pledges":
      return 14;
    case "dreams":
      return 14;
    case "music":
      return 8;
    case "capsules":
      return 10;
    case "chat":
      return 24;
    case "games":
      return 12;
    default:
      return 10;
  }
}

function itemLimit(key) {
  switch (key) {
    case "memories":
      return 3500;
    case "chat":
      return 1400;
    case "capsules":
      return 2600;
    default:
      return 2200;
  }
}

function extractTerms(text) {
  if (typeof text !== "string") return [];

  return [
    ...new Set(
      text
        .toLocaleLowerCase("fa-IR")
        .replace(/[^\p{L}\p{N}\s]/gu, " ")
        .split(/\s+/)
        .filter((word) => word.length >= 3)
        .filter((word) => !STOP_WORDS.has(word))
    ),
  ].slice(0, 20);
}

const STOP_WORDS = new Set([
  "سلام",
  "خوبی",
  "چطوری",
  "لوینیا",
  "هوش",
  "مصنوعی",
  "جواب",
  "بده",
  "میخوام",
  "میخواهم",
  "میشه",
  "چی",
  "چیه",
  "چرا",
  "برای",
  "این",
  "اون",
  "من",
  "تو",
  "خیلی",
  "فقط",
  "یک",
  "همین",
  "کن",
  "کنم",
  "کردم",
]);

function relevanceScore(item, terms) {
  const text = JSON.stringify(item).toLocaleLowerCase("fa-IR");
  return terms.reduce(
    (score, term) => score + (text.includes(term) ? 1 : 0),
    0
  );
}

function extractTime(item) {
  if (!item || typeof item !== "object") return 0;

  for (const key of ["createdAt", "timestamp", "date", "openDate"]) {
    const value = item[key];

    if (typeof value === "number" && Number.isFinite(value)) {
      return value;
    }

    if (value) {
      const time = Date.parse(String(value));
      if (!Number.isNaN(time)) return time;
    }
  }

  return 0;
}

function dedupe(items) {
  const seen = new Set();
  const result = [];

  for (const item of items) {
    const id =
      item?.id || item?._firebaseKey || JSON.stringify(item);
    if (seen.has(id)) continue;
    seen.add(id);
    result.push(item);
  }

  return result;
}

function formatMemory(memory) {
  let text = JSON.stringify(memory || {}, null, 0);
  if (text.length > MAX_MEMORY_CHARS) {
    text = text.slice(0, MAX_MEMORY_CHARS) + "…";
  }
  return text;
}

/* =========================================================
   AUTOMATIC MESSAGES
========================================================= */

async function handleEvent(body, env) {
  const eventType = limitText(
    body?.eventType || body?.type || "site_event",
    100
  );

  const eventData = cleanContext(body?.data);

  const memory = await loadMemory(JSON.stringify(eventData), "", env);

  const contentEvents = [
    "memory_added",
    "moment_added",
    "pledge_added",
    "dream_added",
    "capsule_added",
    "music_added",
    "letter_updated",
  ];

  const isContentEvent = contentEvents.includes(eventType);
  const taskType = isContentEvent ? "observe_content" : "event";

  const prompt = `
یک اتفاق جدید در سایت رخ داده است.

نوع رویداد:
${eventType}

داده:
${JSON.stringify(compactData(eventData, 5000), null, 2)}

با توجه به حافظه رابطه امین و نیایش تصمیم بگیر.

اگر این اتفاق واقعاً ارزش یک پیام مستقل، کوتاه و صمیمی از طرف لوینیا دارد، فقط همان پیام را بنویس.

در غیر این صورت دقیقاً:
SKIP

هیچ تحلیل یا توضیحی ننویس.
`.trim();

  const result = await runAI(
    env,
    buildSystemPrompt(memory, {}, taskType),
    prompt,
    generationOptions(taskType)
  );

  const text = cleanAIText(result);

  if (!text || text === "SKIP") {
    return { ok: true, result: "SKIP", sent: false };
  }

  const saved = await saveAiMessage(text, `event:${eventType}`, env);

  return { ok: true, result: text, sent: saved };
}

async function runAutomaticCheck(env) {
  const state = await firebaseGet("loveniya_ai_state.json", env).catch(
    () => null
  );

  const now = Date.now();
  const last = Number(state?.lastAutoMessageAt || 0);

  // ---------- بخش ۱: پیام خودکار ----------
  if (now - last >= AUTO_COOLDOWN) {
    const memory = await loadMemory("", "", env);
    const signals = findTodaySignals(memory, now);

    if (signals.length > 0) {
      const prompt = `
امروز برای امین و نیایش این موارد مرتبط پیدا شده:

${JSON.stringify(signals, null, 2)}

فقط اگر واقعاً این موارد ارزش یک پیام مستقل و طبیعی از طرف لوینیا دارند، یک پیام کوتاه بنویس.

اگر ارزش پیام ندارند:
SKIP

پیام نباید تکراری، تبلیغاتی، ماشینی یا بیش‌ازحد شیرین باشد.
فقط پاسخ نهایی را بده.
`.trim();

      const result = await runAI(
        env,
        buildSystemPrompt(memory, {}, "cron"),
        prompt,
        generationOptions("cron")
      );

      const text = cleanAIText(result);

      if (text && text !== "SKIP") {
        const saved = await saveAiMessage(text, "scheduled", env);

        if (saved) {
          await firebasePut("loveniya_ai_state.json", {
            lastAutoMessageAt: now,
            lastTrigger: signals[0]?.kind || "scheduled",
          }, env);
        }
      }
    }
  }

  // ---------- بخش ۲: چالش روزانه بازی‌ها ----------
  try {
    const todayKey = new Intl.DateTimeFormat("en-CA", {
      timeZone: "Asia/Tehran",
    }).format(new Date());

    const gamesData = await firebaseGet(`${PATHS.games}.json`, env).catch(
      () => null
    );

    const gamesList = normalizeCollection(gamesData);

    const hasTodayChallenge = gamesList.some((g) => {
      const gDate = String(g?.date || "");
      const gTimestamp = Number(g?.timestamp || 0);
      const isRecent = gTimestamp > now - 20 * 60 * 60 * 1000;
      return (
        (g?.isDaily === true && isRecent) ||
        gDate.includes(todayKey)
      );
    });

    if (!hasTodayChallenge) {
      const memory = await loadMemory("", "", env);

      const challenge = await runAI(
        env,
        buildSystemPrompt(memory, {}, "game_challenge"),
        `یک چالش جدید و بامزه برای امروز امین و نیایش بساز.
اگر امروز مناسبت خاصی در حافظه هست، لحاظش کن.
خروجی را دقیقاً با فرمت خواسته‌شده بنویس.`,
        generationOptions("game_challenge")
      );

      const challengeText = cleanAIText(challenge);

      if (challengeText && challengeText !== "SKIP") {
        const id = `daily_${Date.now()}_${randomId(6)}`;

        await firebasePut(
          `${PATHS.games}/${encodeURIComponent(id)}.json`,
          {
            id,
            title: "چالش امروز لوینیا",
            text: challengeText,
            content: challengeText,
            isDaily: true,
            isAiGenerated: true,
            date: todayKey,
            timestamp: Date.now(),
            createdBy: "ai",
          },
          env
        );
      }
    }
  } catch (e) {
    console.warn("Daily challenge failed:", e?.message || e);
  }
}

function findTodaySignals(memory, now) {
  const result = [];

  const formatter = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Tehran",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  });

  const today = formatter.format(new Date(now));
  const [, month, day] = today.split("-");
  const monthDay = `${month}-${day}`;

  for (const item of memory.memories || []) {
    const date = dateFromItem(item);
    if (sameMonthDay(date, monthDay)) {
      result.push({
        kind: "memory_anniversary",
        title: item.title || item.text || "خاطره",
        date,
      });
    }
  }

  for (const item of memory.pledges || []) {
    const date = dateFromItem(item);
    if (sameMonthDay(date, monthDay)) {
      result.push({
        kind: "pledge_anniversary",
        text: item.text || "عهد",
        date,
      });
    }
  }

  for (const item of memory.capsules || []) {
    const openDate = dateFromItem(item, ["openDate", "createdAt"]);
    if (openDate === today && item.isOpened !== true) {
      result.push({
        kind: "capsule_due",
        title: item.title || "کپسول",
        date: openDate,
      });
    }
  }

  return result.slice(0, 8);
}

function dateFromItem(
  item,
  keys = ["date", "createdAt", "timestamp"]
) {
  if (!item || typeof item !== "object") return "";

  for (const key of keys) {
    const value = item[key];

    if (typeof value === "number") {
      const date = new Date(value);
      if (!Number.isNaN(date.getTime())) {
        return date.toISOString().slice(0, 10);
      }
    }

    if (value) {
      const match = String(value).match(/\d{4}[-/]\d{1,2}[-/]\d{1,2}/);
      if (match) {
        return match[0].replaceAll("/", "-");
      }
    }
  }

  return "";
}

function sameMonthDay(date, monthDay) {
  if (!date) return false;

  const match = String(date).match(/^\d{4}-(\d{2})-(\d{2})$/);
  if (!match) return false;

  return `${match[1]}-${match[2]}` === monthDay;
}

/* =========================================================
   SAVE AI CHAT MESSAGE
========================================================= */

async function saveAiMessage(text, trigger, env) {
  const now = Date.now();
  const id = `ai_${now}_${randomId(7)}`;

  const message = {
    id,
    senderId: "ai",
    senderName: "پیام هوشمند",
    sender: "Loveniya AI",
    role: "ai",
    text: String(text).trim(),
    content: String(text).trim(),
    timestamp: now,
    aiMetadata: {
      emotion: "caring",
      actionTrigger: trigger,
    },
  };

  try {
    await firebasePut(
      `loveniya_chat/${encodeURIComponent(id)}.json`,
      message,
      env
    );
    return true;
  } catch (error) {
    console.error("Save AI message failed:", error);
    return false;
  }
}

/* =========================================================
   FIREBASE PROXY
========================================================= */

async function firebaseGet(path, env) {
  const base = getProxyUrl(env);

  const response = await fetch(
    `${base}/${path}${path.includes("?") ? "&" : "?"}_ai=${Date.now()}`,
    {
      method: "GET",
      headers: { Accept: "application/json", "X-App-Secret": env.APP_SECRET },
      redirect: "follow",
    }
  );

  if (!response.ok) {
    throw new Error(`Firebase GET ${response.status}`);
  }

  return await response.json();
}

async function firebasePut(path, data, env) {
  const base = getProxyUrl(env);

  const response = await fetch(`${base}/${path}`, {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
      "X-App-Secret": env.APP_SECRET,
    },
    body: JSON.stringify(data),
    redirect: "follow",
  });

  if (!response.ok) {
    const text = await response.text().catch(() => "");
    throw new Error(
      `Firebase PUT ${response.status}: ${text.slice(0, 300)}`
    );
  }

  return true;
}

/* =========================================================
   SESSION AUTHENTICATION
========================================================= */

async function authenticateSession(request, env) {
  const header = request.headers.get("Authorization") || "";
  const match = /^Bearer\s+(.+)$/i.exec(header.trim());
  if (!match || !env.SESSION_SECRET) return false;

  const [payload, signature] = match[1].split(".");
  if (!payload || !signature) return false;

  const expected = encodeBase64Url(await hmacSign(env.SESSION_SECRET, payload));
  if (!safeEqual(signature, expected)) return false;

  try {
    const data = JSON.parse(decodeBase64Url(payload));
    return (
      (data?.user === "amin" || data?.user === "niyayesh") &&
      typeof data?.exp === "number" &&
      data.exp > Date.now() &&
      Date.now() - Number(data.iat || 0) < SESSION_TTL_MS + 5 * 60_000
    );
  } catch {
    return false;
  }
}

async function hmacSign(secret, value) {
  const key = await crypto.subtle.importKey(
    "raw",
    SESSION_ENCODER.encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  return await crypto.subtle.sign("HMAC", key, SESSION_ENCODER.encode(value));
}

function safeEqual(a, b) {
  const left = String(a);
  const right = String(b);
  if (left.length !== right.length) return false;
  let diff = 0;
  for (let i = 0; i < left.length; i++) diff |= left.charCodeAt(i) ^ right.charCodeAt(i);
  return diff === 0;
}

function encodeBase64Url(value) {
  const bytes = typeof value === "string" ? SESSION_ENCODER.encode(value) : new Uint8Array(value);
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}

function decodeBase64Url(value) {
  const raw = String(value);
  const padded = raw.replace(/-/g, "+").replace(/_/g, "/") + "===".slice((raw.length + 3) % 4);
  const binary = atob(padded);
  const bytes = Uint8Array.from(binary, char => char.charCodeAt(0));
  return SESSION_DECODER.decode(bytes);
}

/* =========================================================
   UTILITIES
========================================================= */

function normalizeType(type) {
  switch (String(type || "chat").toLowerCase()) {
    case "chat":
      return "chat";

    case "chat_reply":
      return "chat_reply";

    case "smart_evaluate":
    case "evaluate_smart":
      return "smart_evaluate";

    case "fix_spelling":
      return "fix_spelling";

    case "daily_surprise":
    case "surprise_daily":
      return "daily_surprise";

    case "poem":
      return "poem";

    case "game_challenge":
    case "daily_challenge":
    case "challenge":
      return "game_challenge";

    case "observe_content":
    case "content_added":
      return "observe_content";

    case "emotional_support":
    case "support":
      return "emotional_support";

    case "event":
      return "event";

    case "auto_message":
      return "auto_message";

    case "cron":
      return "cron";

    default:
      return "chat";
  }
}

function cleanAIText(value) {
  let text = "";

  if (typeof value === "string") {
    text = value;
  } else if (typeof value?.response === "string") {
    text = value.response;
  } else if (typeof value?.result === "string") {
    text = value.result;
  } else if (
    typeof value?.choices?.[0]?.message?.content === "string"
  ) {
    text = value.choices[0].message.content;
  }

  text = String(text || "").trim();

  if (/^SKIP[.!؟]?$/i.test(text)) {
    return "SKIP";
  }

  text = text
    .replace(/^```(?:text|json)?\s*/i, "")
    .replace(/\s*```$/i, "")
    .trim();

  return text;
}

function compactData(value, maxChars) {
  if (value == null) return value;

  if (typeof value === "string") {
    return limitText(value, maxChars);
  }

  if (typeof value === "number" || typeof value === "boolean") {
    return value;
  }

  if (Array.isArray(value)) {
    return value
      .slice(0, 30)
      .map((item) =>
        compactData(item, Math.floor(maxChars / 2))
      );
  }

  if (typeof value === "object") {
    const result = {};

    for (const [key, item] of Object.entries(value)) {
      if (shouldRemoveField(key)) continue;
      result[key] = compactData(item, Math.floor(maxChars / 2));
    }

    return result;
  }

  return String(value);
}

function shouldRemoveField(key) {
  const name = String(key).toLowerCase();

  return [
    "mediadata",
    "photos",
    "photo",
    "image",
    "images",
    "video",
    "videodata",
    "vidurl",
    "audio",
    "base64",
  ].some((field) => name === field);
}

function emptyValue(key) {
  if (key === "letter") return "";
  if (key === "moments") return {};
  return [];
}

function cleanContext(value) {
  if (!value || typeof value !== "object") return {};
  return compactData(value, 7000);
}

function limitText(value, max) {
  const text = typeof value === "string" ? value : String(value ?? "");

  return text.length <= max
    ? text
    : text.slice(0, max) + "…";
}

function parseJson(request) {
  return request.json().catch(() => {
    throw new Error("بدنه درخواست JSON معتبر نیست.");
  });
}

function randomId(length) {
  const alphabet = "abcdefghijklmnopqrstuvwxyz0123456789";
  const bytes = new Uint8Array(length);
  crypto.getRandomValues(bytes);

  return Array.from(
    bytes,
    (byte) => alphabet[byte % alphabet.length]
  ).join("");
}

function getCors(request, env) {
  const configured = String(env.ALLOWED_ORIGIN || '').split(',').map(value => value.trim()).filter(Boolean);
  const origin = request.headers.get('Origin');
  const allowOrigin = origin && configured.includes(origin) ? origin : (configured[0] || 'null');
  return {
    'Access-Control-Allow-Origin': allowOrigin,
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-App-Secret',
    'Access-Control-Max-Age': '86400',
    'Vary': 'Origin',
  };
}

function json(data, status, headers) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      ...headers,
      "Content-Type": "application/json; charset=UTF-8",
      "Cache-Control": "no-store",
      "X-Content-Type-Options": "nosniff",
      "Referrer-Policy": "no-referrer",
    },
  });
}

function safeError(error) {
  return String(
    error?.message || error || "خطای ناشناخته"
  ).slice(0, 500);
}
