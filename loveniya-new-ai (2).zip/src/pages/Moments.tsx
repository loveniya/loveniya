import React, { useState, useEffect, useCallback } from 'react';
import { 
  Sparkles, Heart, Coffee, Send, Lock, Unlock, 
  Check, CheckCircle2, RotateCw, MessageCircle, HeartHandshake, 
  Users, Flame, RefreshCw, Calendar, ArrowLeft, Lightbulb,
  Camera, Music, ShieldCheck, Sun, Star, Award, Zap
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { NavLink } from 'react-router';

const WORKER_URL = "https://niya.am-b-asdfghjkl20112011.workers.dev";

// Dynamic Daily Prompts Matrix - Rotates based on day of year
const DAILY_SPECIAL_IDEAS = [
  {
    category: '📸 عکاسی لایو امروز',
    title: 'تصویر بی‌فلتر از دنیای امروز',
    prompt: 'همین الان بدون مرتب‌سازی یا ژست گرفتن، یک عکس از لبخندت یا نمای جلوی چشمت بفرست.',
    icon: Camera,
    color: 'bg-rose-50 text-rose-700 border-rose-200'
  },
  {
    category: '🎙️ ویس دلی ۵ ثانیه‌ای',
    title: 'شنیدن صدای گرم همسرت',
    prompt: 'یک ویس کوتاه با صدای آروم ضبط کن و بگو همین الان بیشتر از همه دوست داری چی بشنوی.',
    icon: Sparkles,
    color: 'bg-amber-50 text-amber-800 border-amber-200'
  },
  {
    category: '☕ قرار چای مجازی امروز',
    title: '۱۰ دقیقه چت صوتی با چای گرم',
    prompt: 'امروز عصر یک استکان چای یا قهوه بریزید و یک تماس صوتی ۱۰ دقیقه‌ای فقط برای حال‌واحوال بگیرید.',
    icon: Coffee,
    color: 'bg-amber-50/80 text-amber-900 border-amber-200'
  },
  {
    category: '💭 سوال عمیق امروز',
    title: 'شناخت عمیق‌تر لایه‌های پنهان',
    prompt: 'کدام خاطره از اولین ماه‌های آشنایی‌مون هنوز توی ذهنت مثل روز اول پررنگ و شیرینه؟',
    icon: Heart,
    color: 'bg-pink-50 text-pink-700 border-pink-200'
  },
  {
    category: '🎵 اهداء آهنگ امروز',
    title: 'موسیقی مشترک امروز ما',
    prompt: 'یک ترانه که امروز موقع کار یا راه رفتن تو رو یاد من انداخت توی بخش موزیک‌روم اضافه کن.',
    icon: Music,
    color: 'bg-purple-50 text-purple-700 border-purple-200'
  },
  {
    category: '💌 آرزوی کوچک امروز',
    title: 'یک تصمیم قشنگ برای دیدار بعدی',
    prompt: 'یک قرار کوچک (مثل خوردن یک بستنی خاص یا پیاده‌روی تو یک خیابان مشخص) برای دیدار بعدی پیشنهاد بده.',
    icon: Sun,
    color: 'bg-rose-50 text-rose-800 border-rose-200'
  }
];

// Preset Dilemmas
const PRESET_DILEMMAS = [
  {
    id: 'dil_1',
    title: 'طرز ارتباط در روزهای پرکار و شلوغ',
    optionA: 'ویس‌های صوتی چند دقیقه‌ای از اتفاقات روز',
    optionB: 'پیام‌های متنی کوتاه ولی مداوم و پرانرژی'
  },
  {
    id: 'dil_2',
    title: 'برنامه شب‌های تعطیل از راه دور',
    optionA: 'تماس تصویری و تماشای هم‌زمان فیلم آنلاین',
    optionB: 'بازی آنلاین دو نفره با چت صوتی و کل‌کل'
  },
  {
    id: 'dil_3',
    title: 'سورپرایز از راه دور برای آدرس منزل',
    optionA: 'پست کردن یک نامه دست‌نویس با یادگاری واقعی',
    optionB: 'سفارش آنلاین ناگهانی شیرینی و گل با اسنپ‌فود'
  },
  {
    id: 'dil_4',
    title: 'برنامه‌ریزی دیدار بعدی در شهر',
    optionA: 'یک سفر ۲ روزه فشرده و هیجان‌انگیز در اولین فرصت',
    optionB: 'برنامه‌ریزی صبورانه برای یک هفته کامل اقامت مشترک'
  }
];

const PRESET_DARES: Array<{ type: 'truth' | 'dare'; text: string }> = [
  { type: 'dare', text: 'یک ویس ۷ ثانیه‌ای خنده‌دار با لحن مجری گزارشگر فوتبال در چت بفرست' },
  { type: 'truth', text: 'عجیب‌ترین و بانمک‌ترین فکری که در اولین تماس تصویریامون کردی چی بود؟' },
  { type: 'dare', text: 'یک سلفی با ژست بامزه همین الان در چت دو نفره ثبت کن' },
  { type: 'truth', text: 'کدام عکس یا خاطره در آلبوم مشترک ما رو بیشتر از همه دوست داری؟' },
  { type: 'dare', text: 'یک شعر یا جمله عاشقانه کوتاه با لحن فوق‌العاده جدی برام وویس کن' },
  { type: 'truth', text: 'کدام پیام چتمون رو دوباره چند بار با لبخند و حس قشنگ خوندی؟' },
  { type: 'truth', text: 'بزرگترین آرزویی که دوست داری در آینده با هم بهش برسیم چیه؟' },
  { type: 'dare', text: 'همین الان یک عکس از منظره‌ای که جلوت هست (حتی دیوار!) بگیر و بفرست' },
  { type: 'truth', text: 'اگر قرار بود همین الان پیش هم باشیم، اولین جایی که با هم می‌رفتیم کجا بود؟' },
  { type: 'dare', text: 'با چشم بسته تایپ کن: "خیلی دلم برات تنگ شده" و بفرست!' },
  { type: 'truth', text: 'کدوم ویژگی من بیشتر از همه تو رو می‌خندونه؟' },
  { type: 'dare', text: 'یک ویس بخون و سعی کن بدون خندیدن یک جوک بی‌مزه تعریف کنی' },
];

export type DilemmaItem = {
  id: string;
  title: string;
  optionA: string;
  optionB: string;
  creator: 'amin' | 'niyayesh';
  aminVote?: 'A' | 'B';
  niyayeshVote?: 'A' | 'B';
};

export type SecretItem = {
  id: string;
  question: string;
  creator: 'amin' | 'niyayesh';
  secretText: string;
  guesserText?: string;
  status: 'locked' | 'unlocked';
};

export type DareItem = {
  id: string;
  type: 'truth' | 'dare';
  text: string;
  sender: 'amin' | 'niyayesh';
  isCompleted: boolean;
};

export type SignalState = {
  hugs: number;
  kisses: number;
  tea: number;
  lastSender?: string;
  lastNote?: string;
  lastTime?: string;
};

export type MomentsState = {
  lastResetDate?: string;
  dilemmas: DilemmaItem[];
  secrets: SecretItem[];
  dares: DareItem[];
  signals: SignalState;
  dailyCompletedDates: string[]; // List of YYYY-MM-DD completed
};

const INITIAL_STATE: MomentsState = {
  dilemmas: PRESET_DILEMMAS.map(d => ({ ...d, creator: 'amin' })),
  secrets: [
    {
      id: 'sec_1',
      question: 'اولین کاری که بلافاصله بعد از دیدن همدیگه انجام می‌دیم؟',
      creator: 'amin',
      secretText: 'یک آغوش طولانی بی کلام و آروم',
      status: 'locked'
    }
  ],
  dares: [
    {
      id: 'dare_1',
      type: 'dare',
      text: 'یک ویس ۵ ثانیه‌ای با لحن خنده‌دار همین الان بفرست!',
      sender: 'amin',
      isCompleted: false
    }
  ],
  signals: {
    hugs: 0,
    kisses: 0,
    tea: 0
  },
  dailyCompletedDates: []
};

export const Moments: React.FC = () => {
  // Current user identity from localStorage
  const [currentUser, setCurrentUser] = useState<'amin' | 'niyayesh'>(() => {
    return (localStorage.getItem('loveniya_user') as 'amin' | 'niyayesh') || 'amin';
  });

  const [momentsState, setMomentsState] = useState<MomentsState>(INITIAL_STATE);
  const [activeTab, setActiveTab] = useState<'today' | 'dilemmas' | 'secrets' | 'dares' | 'affection'>('today');
  
  // Daily Dynamic Activity calculation
  const todayStr = new Date().toLocaleDateString('en-CA');
  const dayOfYear = Math.floor((new Date().getTime() - new Date(new Date().getFullYear(), 0, 0).getTime()) / (1000 * 60 * 60 * 24));
  const [dailyIndexOffset, setDailyIndexOffset] = useState(0);
  
  const currentDailyIdea = DAILY_SPECIAL_IDEAS[(dayOfYear + dailyIndexOffset) % DAILY_SPECIAL_IDEAS.length];
  const isDailyDoneToday = momentsState.dailyCompletedDates?.includes(todayStr);

  // Inputs
  const [newDilTitle, setNewDilTitle] = useState('');
  const [newDilA, setNewDilA] = useState('');
  const [newDilB, setNewDilB] = useState('');
  const [showAddDil, setShowAddDil] = useState(false);

  const [newSecQuestion, setNewSecQuestion] = useState('');
  const [newSecAnswer, setNewSecAnswer] = useState('');
  const [secretGuessInput, setSecretGuessInput] = useState('');

  const [isGeneratingDare, setIsGeneratingDare] = useState(false);

  const [signalNote, setSignalNote] = useState('');
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const partnerName = currentUser === 'amin' ? 'نیایش' : 'امین';

  // Toggle identity subtly
  const handleToggleUser = (user: 'amin' | 'niyayesh') => {
    setCurrentUser(user);
    localStorage.setItem('loveniya_user', user);
  };

  // Sync state with REST worker
  const syncData = useCallback(async (newState: MomentsState) => {
    setMomentsState(newState);
    localStorage.setItem('loveniya_moments_v2', JSON.stringify(newState));

    try {
      await fetch(`${WORKER_URL}/loveniya_moments_v2.json`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newState)
      });
    } catch {
      // Graceful offline fallback
    }
  }, []);

  const fetchData = useCallback(async () => {
    try {
      const res = await fetch(`${WORKER_URL}/loveniya_moments_v2.json?_t=${Date.now()}`, { cache: 'no-store' });
      if (res.ok) {
        const data = await res.json();
        if (data && typeof data === 'object') {
          const todayStr = new Date().toLocaleDateString('en-CA');
          if (data.lastResetDate !== todayStr) {
            const resetState: MomentsState = {
              ...INITIAL_STATE,
              lastResetDate: todayStr
            };
            syncData(resetState);
          } else {
            setMomentsState(prev => ({
              ...prev,
              ...data,
              signals: { ...prev.signals, ...(data.signals || {}) }
            }));
          }
        }
      }
    } catch {
      // Silence network errors
    }
  }, [syncData]);

  useEffect(() => {
    const cached = localStorage.getItem('loveniya_moments_v2');
    if (cached) {
      try {
        const parsed = JSON.parse(cached);
        const todayStr = new Date().toLocaleDateString('en-CA');
        if (parsed.lastResetDate !== todayStr) {
          const resetState = { ...INITIAL_STATE, lastResetDate: todayStr };
          syncData(resetState);
        } else {
          setMomentsState(parsed);
        }
      } catch {}
    } else {
      const todayStr = new Date().toLocaleDateString('en-CA');
      const resetState = { ...INITIAL_STATE, lastResetDate: todayStr };
      syncData(resetState);
    }
    fetchData();
    const interval = setInterval(fetchData, 5000);
    return () => clearInterval(interval);
  }, [fetchData, syncData]);

  // Toast Helper
  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 3000);
  };

  // Handlers
  const handleMarkDailyDone = () => {
    if (isDailyDoneToday) return;
    const updatedDates = [...(momentsState.dailyCompletedDates || []), todayStr];
    syncData({ ...momentsState, dailyCompletedDates: updatedDates });
    showToast('آیین ویژه امروز ثبت و انجام شد! ✨');
  };

  const handleVoteDilemma = (id: string, choice: 'A' | 'B') => {
    const updated = momentsState.dilemmas.map(d => {
      if (d.id === id) {
        return {
          ...d,
          aminVote: currentUser === 'amin' ? choice : d.aminVote,
          niyayeshVote: currentUser === 'niyayesh' ? choice : d.niyayeshVote
        };
      }
      return d;
    });
    syncData({ ...momentsState, dilemmas: updated });
    showToast('انتخاب شما ذخیره شد');
  };

  const handleCreateDilemma = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDilTitle.trim() || !newDilA.trim() || !newDilB.trim()) return;

    const newObj: DilemmaItem = {
      id: 'dil_' + Date.now(),
      title: newDilTitle.trim(),
      optionA: newDilA.trim(),
      optionB: newDilB.trim(),
      creator: currentUser,
      aminVote: currentUser === 'amin' ? 'A' : undefined,
      niyayeshVote: currentUser === 'niyayesh' ? 'A' : undefined
    };

    syncData({ ...momentsState, dilemmas: [newObj, ...momentsState.dilemmas] });
    setNewDilTitle('');
    setNewDilA('');
    setNewDilB('');
    setShowAddDil(false);
    showToast(`چالش جدید برای ${partnerName} ایجاد شد`);
  };

  const handleCreateSecret = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSecQuestion.trim() || !newSecAnswer.trim()) return;

    const newObj: SecretItem = {
      id: 'sec_' + Date.now(),
      question: newSecQuestion.trim(),
      creator: currentUser,
      secretText: newSecAnswer.trim(),
      status: 'locked'
    };

    syncData({ ...momentsState, secrets: [newObj, ...momentsState.secrets] });
    setNewSecQuestion('');
    setNewSecAnswer('');
    showToast(`پاسخ پنهان شما قفل شد`);
  };

  const handleUnlockSecret = (id: string) => {
    if (!secretGuessInput.trim()) return;

    const updated = momentsState.secrets.map(s => {
      if (s.id === id) {
        return {
          ...s,
          guesserText: secretGuessInput.trim(),
          status: 'unlocked' as const
        };
      }
      return s;
    });

    syncData({ ...momentsState, secrets: updated });
    setSecretGuessInput('');
    showToast('راز بازگشایی شد!');
  };

  const generateAIDare = () => {
    setIsGeneratingDare(true);
    setTimeout(() => {
      const randomDare = PRESET_DARES[Math.floor(Math.random() * PRESET_DARES.length)];
      
      const newObj: DareItem = {
        id: 'dare_' + Date.now(),
        type: randomDare.type,
        text: randomDare.text,
        sender: currentUser,
        isCompleted: false
      };

      syncData({ ...momentsState, dares: [newObj, ...momentsState.dares] });
      setIsGeneratingDare(false);
      showToast(`سوال هوش مصنوعی برای ${partnerName} فرستاده شد`);
    }, 1500);
  };

  const handleCompleteDare = (id: string) => {
    const updated = momentsState.dares.map(d => {
      if (d.id === id) return { ...d, isCompleted: true };
      return d;
    });
    syncData({ ...momentsState, dares: updated });
    showToast('چالش تایید شد!');
  };

  const sendSignal = (type: 'hug' | 'kiss' | 'tea') => {
    const timeStr = new Date().toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' });
    const senderName = currentUser === 'amin' ? 'امین' : 'نیایش';

    const updatedSignals: SignalState = {
      ...momentsState.signals,
      hugs: type === 'hug' ? momentsState.signals.hugs + 1 : momentsState.signals.hugs,
      kisses: type === 'kiss' ? momentsState.signals.kisses + 1 : momentsState.signals.kisses,
      tea: type === 'tea' ? momentsState.signals.tea + 1 : momentsState.signals.tea,
      lastSender: senderName,
      lastTime: timeStr,
      lastNote: signalNote.trim() || momentsState.signals.lastNote
    };

    syncData({ ...momentsState, signals: updatedSignals });
    setSignalNote('');

    const labels = { hug: 'آغوش مجازی', kiss: 'بوسه از راه دور', tea: 'چای مشترک' };
    showToast(`${labels[type]} فرستاده شد!`);
  };

  return (
    <div className="space-y-4 sm:space-y-6 max-w-2xl mx-auto px-2 sm:px-4 py-2 sm:py-3" dir="rtl">
      
      {/* Editorial Page Header */}
      <div className="flex items-center justify-between border-b border-stone-200/80 pb-3">
        <div>
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-rose-50 text-rose-700 text-[10px] sm:text-[11px] font-bold border border-rose-200/60 mb-1">
            <Sparkles className="w-3 h-3 text-rose-500" />
            <span>لحظه‌ها و بازی‌های مشترک</span>
          </div>
          <h1 className="text-lg sm:text-2xl font-black text-stone-900 tracking-tight">
            لحظه‌ها و چالش‌های دو نفره
          </h1>
        </div>
      </div>

      {/* Partner Note Banner */}
      {momentsState.signals.lastSender && momentsState.signals.lastSender === partnerName && momentsState.signals.lastNote && (
        <motion.div
          initial={{ opacity: 0, y: -4 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-4 rounded-2xl bg-amber-50/80 border border-amber-200/80 flex items-start gap-3"
        >
          <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center shrink-0">
            <Sparkles className="w-4 h-4 text-amber-600" />
          </div>
          <div className="space-y-0.5">
            <div className="flex items-center gap-2">
              <span className="text-xs font-extrabold text-amber-900">
                پیام تازه از طرف {partnerName}:
              </span>
              <span className="text-[10px] text-amber-700 font-mono">{momentsState.signals.lastTime}</span>
            </div>
            <p className="text-xs text-amber-800 font-bold leading-relaxed">
              «{momentsState.signals.lastNote}»
            </p>
          </div>
        </motion.div>
      )}

      {/* Tabs Bar */}
      <div className="flex items-center gap-1 bg-stone-100/90 p-1 rounded-2xl border border-stone-200/70 overflow-x-auto custom-scroll">
        <button
          onClick={() => setActiveTab('today')}
          className={`flex-1 min-w-[105px] shrink-0 px-3 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap flex items-center justify-center gap-1.5 ${
            activeTab === 'today' ? 'bg-white text-stone-900 shadow-2xs' : 'text-stone-500 hover:text-stone-800'
          }`}
        >
          <Calendar className="w-4 h-4 shrink-0 text-rose-500" />
          <span>ویژه امروز</span>
        </button>

        <button
          onClick={() => setActiveTab('dilemmas')}
          className={`flex-1 min-w-[105px] shrink-0 px-3 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap flex items-center justify-center gap-1.5 ${
            activeTab === 'dilemmas' ? 'bg-white text-stone-900 shadow-2xs' : 'text-stone-500 hover:text-stone-800'
          }`}
        >
          <Users className="w-4 h-4 shrink-0 text-indigo-500" />
          <span>این یا آن؟</span>
        </button>

        <button
          onClick={() => setActiveTab('secrets')}
          className={`flex-1 min-w-[105px] shrink-0 px-3 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap flex items-center justify-center gap-1.5 ${
            activeTab === 'secrets' ? 'bg-white text-stone-900 shadow-2xs' : 'text-stone-500 hover:text-stone-800'
          }`}
        >
          <Lock className="w-4 h-4 shrink-0 text-amber-500" />
          <span>صندوق راز</span>
        </button>

        <button
          onClick={() => setActiveTab('dares')}
          className={`flex-1 min-w-[105px] shrink-0 px-3 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap flex items-center justify-center gap-1.5 ${
            activeTab === 'dares' ? 'bg-white text-stone-900 shadow-2xs' : 'text-stone-500 hover:text-stone-800'
          }`}
        >
          <Flame className="w-4 h-4 shrink-0 text-orange-500" />
          <span>جرات/حقیقت</span>
        </button>

        <button
          onClick={() => setActiveTab('affection')}
          className={`flex-1 min-w-[105px] shrink-0 px-3 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap flex items-center justify-center gap-1.5 ${
            activeTab === 'affection' ? 'bg-white text-stone-900 shadow-2xs' : 'text-stone-500 hover:text-stone-800'
          }`}
        >
          <HeartHandshake className="w-4 h-4 shrink-0 text-rose-500" />
          <span>حس آنلاین</span>
        </button>
      </div>

      {/* TAB 1: TODAY'S SPECIAL DYNAMIC RITUAL */}
      {activeTab === 'today' && (
        <div className="space-y-4">
          <div className="bg-white p-5 sm:p-6 rounded-3xl border border-stone-200/80 shadow-2xs space-y-4">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <span className={`px-2.5 py-1 rounded-full text-[11px] font-extrabold border ${currentDailyIdea.color}`}>
                {currentDailyIdea.category}
              </span>

              <button
                onClick={() => setDailyIndexOffset(prev => prev + 1)}
                className="text-[11px] font-bold text-stone-500 hover:text-stone-800 flex items-center gap-1"
              >
                <RotateCw className="w-3 h-3 text-rose-500" />
                <span>پیشنهاد دیگر</span>
              </button>
            </div>

            <div className="space-y-2">
              <h3 className="text-base font-extrabold text-stone-900">
                {currentDailyIdea.title}
              </h3>
              <p className="text-xs sm:text-sm text-stone-600 font-medium leading-relaxed">
                {currentDailyIdea.prompt}
              </p>
            </div>

            <div className="pt-2 flex flex-wrap items-center gap-2">
              {isDailyDoneToday ? (
                <div className="px-4 py-2 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-extrabold flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>آیین ویژه امروز انجام شد!</span>
                </div>
              ) : (
                <button
                  onClick={handleMarkDailyDone}
                  className="px-4 py-2 rounded-xl bg-stone-900 hover:bg-stone-800 text-white text-xs font-extrabold flex items-center gap-1.5 transition-all active:scale-95 shadow-2xs"
                >
                  <Check className="w-3.5 h-3.5 text-rose-400" />
                  <span>انجام دادیم! ✨</span>
                </button>
              )}


            </div>
          </div>

          {/* Daily Advice Card */}
          <div className="bg-rose-50/50 p-4 rounded-2xl border border-rose-100/80 text-xs text-rose-900 space-y-1">
            <span className="font-extrabold block text-rose-950">💡 چاشنی تازگی برای رابطه از راه دور:</span>
            <p className="leading-relaxed font-medium">
              هر روز یک پیشنهاد تازه در این بخش ظاهر می‌شود تا برنامه‌های دو نفره‌تان هیچ‌وقت به یکنواختی نرسد. حتی اگر یکی از شما دیرتر آنلاین شود، پیام‌ها و پاسخ‌ها محفوظ می‌مانند.
            </p>
          </div>
        </div>
      )}

      {/* TAB 2: THIS OR THAT DILEMMAS */}
      {activeTab === 'dilemmas' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between text-xs font-bold text-stone-600">
            <span>چالش‌های چندگزینه‌ای دو نفره</span>
            <button
              onClick={() => setShowAddDil(!showAddDil)}
              className="text-rose-600 hover:text-rose-700 flex items-center gap-1"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>+ افزودن سوال تازه</span>
            </button>
          </div>

          {showAddDil && (
            <form onSubmit={handleCreateDilemma} className="bg-white p-4 rounded-2xl border border-stone-200/80 space-y-3">
              <h4 className="text-xs font-extrabold text-stone-800">ایجاد چالش «این یا آن»:</h4>
              <input
                type="text"
                placeholder="عنوان چالش..."
                value={newDilTitle}
                onChange={(e) => setNewDilTitle(e.target.value)}
                className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3 py-2 text-xs text-stone-900 focus:outline-hidden focus:border-rose-400"
              />
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <input
                  type="text"
                  placeholder="گزینه اول..."
                  value={newDilA}
                  onChange={(e) => setNewDilA(e.target.value)}
                  className="bg-stone-50 border border-stone-200 rounded-xl px-3 py-2 text-xs text-stone-900 focus:outline-hidden focus:border-rose-400"
                />
                <input
                  type="text"
                  placeholder="گزینه دوم..."
                  value={newDilB}
                  onChange={(e) => setNewDilB(e.target.value)}
                  className="bg-stone-50 border border-stone-200 rounded-xl px-3 py-2 text-xs text-stone-900 focus:outline-hidden focus:border-rose-400"
                />
              </div>
              <div className="flex justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setShowAddDil(false)}
                  className="text-xs text-stone-500 px-3 py-1"
                >
                  انصراف
                </button>
                <button
                  type="submit"
                  className="bg-stone-900 text-white text-xs font-extrabold px-4 py-1.5 rounded-xl hover:bg-stone-800"
                >
                  ثبت سوال
                </button>
              </div>
            </form>
          )}

          <div className="space-y-3">
            {momentsState.dilemmas.map((d) => {
              const myVote = currentUser === 'amin' ? d.aminVote : d.niyayeshVote;
              const partnerVote = currentUser === 'amin' ? d.niyayeshVote : d.aminVote;
              const bothVoted = Boolean(myVote && partnerVote);
              const isMatch = bothVoted && myVote === partnerVote;

              return (
                <div key={d.id} className="bg-white p-4.5 rounded-2xl border border-stone-200/80 space-y-3 shadow-2xs">
                  <h4 className="text-xs font-extrabold text-stone-900">{d.title}</h4>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <button
                      onClick={() => handleVoteDilemma(d.id, 'A')}
                      className={`p-3 rounded-xl border text-right text-xs transition-all flex items-center justify-between ${
                        myVote === 'A'
                          ? 'bg-rose-50 border-rose-300 text-rose-900 font-extrabold'
                          : 'bg-stone-50/60 border-stone-200/70 text-stone-700 hover:bg-stone-100/60'
                      }`}
                    >
                      <span>{d.optionA}</span>
                      {myVote === 'A' && <Check className="w-3.5 h-3.5 text-rose-600 shrink-0" />}
                    </button>

                    <button
                      onClick={() => handleVoteDilemma(d.id, 'B')}
                      className={`p-3 rounded-xl border text-right text-xs transition-all flex items-center justify-between ${
                        myVote === 'B'
                          ? 'bg-rose-50 border-rose-300 text-rose-900 font-extrabold'
                          : 'bg-stone-50/60 border-stone-200/70 text-stone-700 hover:bg-stone-100/60'
                      }`}
                    >
                      <span>{d.optionB}</span>
                      {myVote === 'B' && <Check className="w-3.5 h-3.5 text-rose-600 shrink-0" />}
                    </button>
                  </div>

                  {bothVoted ? (
                    <div className={`p-2.5 rounded-xl border text-center text-xs font-bold flex items-center justify-center gap-1.5 ${
                      isMatch
                        ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                        : 'bg-amber-50 border-amber-200 text-amber-800'
                    }`}>
                      {isMatch ? (
                        <>
                          <Award className="w-4 h-4 text-emerald-600" />
                          <span>تطابق کامل نظر امین و نیایش!</span>
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-4 h-4 text-amber-600" />
                          <span>دو نگاه متفاوت! درباره این موضوع با هم گفتگو کنید.</span>
                        </>
                      )}
                    </div>
                  ) : (
                    <p className="text-[11px] text-stone-400 font-medium text-center">
                      {myVote ? `انتخاب شما ثبت شد. در انتظار انتخاب ${partnerName}` : `نظر شما چیست؟`}
                    </p>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 3: SECRET ENVELOPES */}
      {activeTab === 'secrets' && (
        <div className="space-y-4">
          <form onSubmit={handleCreateSecret} className="bg-white p-4.5 rounded-2xl border border-stone-200/80 space-y-3 shadow-2xs">
            <h4 className="text-xs font-extrabold text-stone-900 flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5 text-amber-600" />
              <span>قفل کردن یک جواب راز برای حدس زدن {partnerName}:</span>
            </h4>
            <input
              type="text"
              placeholder="سوال چالش (مثلاً: اولین جایی که تو سفر بعدی می‌ریم)..."
              value={newSecQuestion}
              onChange={(e) => setNewSecQuestion(e.target.value)}
              className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3 py-2 text-xs text-stone-900 focus:outline-hidden focus:border-rose-400"
            />
            <div className="flex gap-2">
              <input
                type="password"
                placeholder="پاسخ پنهان شما..."
                value={newSecAnswer}
                onChange={(e) => setNewSecAnswer(e.target.value)}
                className="flex-1 bg-stone-50 border border-stone-200 rounded-xl px-3 py-2 text-xs text-stone-900 focus:outline-hidden focus:border-rose-400"
              />
              <button
                type="submit"
                disabled={!newSecQuestion.trim() || !newSecAnswer.trim()}
                className="bg-stone-900 text-white text-xs font-extrabold px-4 py-2 rounded-xl hover:bg-stone-800 disabled:opacity-40 shrink-0"
              >
                قفل
              </button>
            </div>
          </form>

          <div className="space-y-3">
            {momentsState.secrets.map((s) => {
              const isMine = s.creator === currentUser;

              return (
                <div key={s.id} className="bg-white p-4.5 rounded-2xl border border-stone-200/80 space-y-3 shadow-2xs">
                  <div className="flex items-center justify-between border-b border-stone-100 pb-2">
                    <h4 className="text-xs font-extrabold text-stone-900">{s.question}</h4>
                    <span className="text-[10px] font-bold text-stone-400">
                      طراح: {s.creator === 'amin' ? 'امین' : 'نیایش'}
                    </span>
                  </div>

                  {s.status === 'locked' ? (
                    isMine ? (
                      <p className="text-xs text-amber-800 bg-amber-50 p-3 rounded-xl font-medium text-center">
                        پاسخ شما قفل شد. منتظر ورود بعدی {partnerName} برای حدس زدن باشید!
                      </p>
                    ) : (
                      <div className="space-y-2">
                        <p className="text-xs text-stone-600 font-bold">
                          {partnerName} جواب این سوال رو قفل کرده! حدس شما چیه؟
                        </p>
                        <div className="flex gap-2">
                          <input
                            type="text"
                            placeholder="حدس خودت رو بنویس..."
                            value={secretGuessInput}
                            onChange={(e) => setSecretGuessInput(e.target.value)}
                            className="flex-1 bg-stone-50 border border-stone-200 rounded-xl px-3 py-2 text-xs text-stone-900 focus:outline-hidden focus:border-rose-400"
                          />
                          <button
                            onClick={() => handleUnlockSecret(s.id)}
                            disabled={!secretGuessInput.trim()}
                            className="bg-rose-600 text-white text-xs font-extrabold px-4 py-2 rounded-xl hover:bg-rose-700 disabled:opacity-40 shrink-0"
                          >
                            بازگشایی
                          </button>
                        </div>
                      </div>
                    )
                  ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                      <div className="p-3 rounded-xl bg-rose-50 border border-rose-100 space-y-0.5">
                        <span className="text-[10px] text-rose-700 font-bold block">پاسخ واقعی {s.creator === 'amin' ? 'امین' : 'نیایش'}:</span>
                        <span className="font-extrabold text-rose-950">{s.secretText}</span>
                      </div>
                      <div className="p-3 rounded-xl bg-amber-50 border border-amber-100 space-y-0.5">
                        <span className="text-[10px] text-amber-700 font-bold block">حدس ثبت‌شده توسط {s.creator === 'amin' ? 'نیایش' : 'امین'}:</span>
                        <span className="font-extrabold text-amber-950">{s.guesserText}</span>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 4: TRUTH OR DARE */}
      {activeTab === 'dares' && (
        <div className="space-y-4">
          <div className="bg-white p-5 rounded-3xl border border-stone-200/80 shadow-xs text-center space-y-4">
            <div className="w-12 h-12 mx-auto rounded-full bg-indigo-50 flex items-center justify-center border border-indigo-100">
              <Sparkles className="w-6 h-6 text-indigo-500" />
            </div>
            <div>
              <h4 className="text-sm font-black text-stone-900 mb-1">بازی جرات یا حقیقت (با هوش مصنوعی)</h4>
              <p className="text-xs text-stone-500 font-medium">دیگه نیازی نیست خودت سوال طرح کنی! هوش مصنوعی بهترین سوالات رو برای شما آماده میکنه.</p>
            </div>
            
            <button
              onClick={generateAIDare}
              disabled={isGeneratingDare}
              className="mx-auto bg-stone-900 text-white text-xs font-extrabold px-6 py-3 rounded-2xl hover:bg-stone-800 disabled:opacity-60 flex items-center justify-center gap-2 transition-all active:scale-95 shadow-md"
            >
              {isGeneratingDare ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin text-stone-300" />
                  <span>درحال ساخت سوال...</span>
                </>
              ) : (
                <>
                  <Flame className="w-4 h-4 text-orange-400" />
                  <span>تولید چالش جدید برای {partnerName}</span>
                </>
              )}
            </button>
          </div>

          <div className="space-y-2.5">
            {momentsState.dares.map((dare) => {
              const isMine = dare.sender === currentUser;

              return (
                <div key={dare.id} className="p-3.5 rounded-2xl bg-white border border-stone-200/80 flex items-center justify-between gap-3 shadow-2xs">
                  <div className="space-y-0.5">
                    <span className={`text-[9px] font-extrabold px-2 py-0.5 rounded-full ${
                      dare.type === 'dare' ? 'bg-rose-100 text-rose-800' : 'bg-purple-100 text-purple-800'
                    }`}>
                      {dare.type === 'dare' ? 'جرات' : 'حقیقت'} (از طرف {dare.sender === 'amin' ? 'امین' : 'نیایش'})
                    </span>
                    <p className="text-xs font-bold text-stone-900">{dare.text}</p>
                  </div>

                  {dare.isCompleted ? (
                    <span className="px-3 py-1 rounded-xl bg-emerald-50 text-emerald-800 text-xs font-extrabold flex items-center gap-1 shrink-0 border border-emerald-200">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                      <span>انجام شد</span>
                    </span>
                  ) : isMine ? (
                    <span className="text-[11px] font-bold text-amber-800 bg-amber-50 px-2.5 py-1 rounded-xl border border-amber-200 shrink-0">
                      در انتظار انجام
                    </span>
                  ) : (
                    <button
                      onClick={() => handleCompleteDare(dare.id)}
                      className="px-3 py-1.5 rounded-xl bg-stone-900 text-white text-xs font-extrabold hover:bg-stone-800 shrink-0"
                    >
                      انجام دادم!
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 5: AFFECTION & SIGNALS */}
      {activeTab === 'affection' && (
        <div className="space-y-4">
          <div className="bg-white p-5 rounded-3xl border border-stone-200/80 shadow-2xs space-y-4">
            <h4 className="text-xs font-extrabold text-stone-900 text-center">
              ارسال یک حس دلی گرم یا یک یادداشت کوتاه:
            </h4>

            <input
              type="text"
              placeholder="یک پیام کوتاه محبت‌آمیز (اختیاری)..."
              value={signalNote}
              onChange={(e) => setSignalNote(e.target.value)}
              className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3.5 py-2.5 text-xs text-stone-900 focus:outline-hidden focus:border-rose-400"
            />

            <div className="grid grid-cols-3 gap-2.5">
              <button
                onClick={() => sendSignal('hug')}
                className="p-4 rounded-2xl bg-rose-50/60 hover:bg-rose-100/60 border border-rose-200/70 transition-all flex flex-col items-center justify-center gap-2 active:scale-95 group"
              >
                <HeartHandshake className="w-6 h-6 text-rose-600 group-hover:scale-110 transition-transform" />
                <span className="text-xs font-extrabold text-stone-900">آغوش گرم</span>
                <span className="text-[10px] font-bold text-rose-700 bg-white px-2 py-0.5 rounded-full border border-rose-200">
                  {momentsState.signals.hugs} بار
                </span>
              </button>

              <button
                onClick={() => sendSignal('kiss')}
                className="p-4 rounded-2xl bg-pink-50/60 hover:bg-pink-100/60 border border-pink-200/70 transition-all flex flex-col items-center justify-center gap-2 active:scale-95 group"
              >
                <Heart className="w-6 h-6 text-pink-600 fill-pink-500/20 group-hover:scale-110 transition-transform" />
                <span className="text-xs font-extrabold text-stone-900">بوسه از راه دور</span>
                <span className="text-[10px] font-bold text-pink-700 bg-white px-2 py-0.5 rounded-full border border-pink-200">
                  {momentsState.signals.kisses} بار
                </span>
              </button>

              <button
                onClick={() => sendSignal('tea')}
                className="p-4 rounded-2xl bg-amber-50/60 hover:bg-amber-100/60 border border-amber-200/70 transition-all flex flex-col items-center justify-center gap-2 active:scale-95 group"
              >
                <Coffee className="w-6 h-6 text-amber-700 group-hover:scale-110 transition-transform" />
                <span className="text-xs font-extrabold text-stone-900">چای مشترک</span>
                <span className="text-[10px] font-bold text-amber-800 bg-white px-2 py-0.5 rounded-full border border-amber-200">
                  {momentsState.signals.tea} بار
                </span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Toast Notification */}
      <AnimatePresence>
        {toastMsg && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            className="fixed bottom-6 left-1/2 -translate-x-1/2 bg-stone-900 text-white font-extrabold text-xs px-5 py-2.5 rounded-full shadow-lg z-50 flex items-center gap-2 border border-stone-700"
          >
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>{toastMsg}</span>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
};

export default Moments;
