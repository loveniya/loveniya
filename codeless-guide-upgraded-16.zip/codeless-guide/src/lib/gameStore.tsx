import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { useLocation } from 'react-router';
import { APP_SECRET } from './appSecret';
import { fetchGetAuth, fetchT } from './net';
import { WORKER_URL, bumpRev, fetchRevs } from './rev';
import { generateChallenge } from './gameAi';
import {
  Challenge, GameEvent, KIND_LABEL, MOMENTS_PATH, Who,
  applyOutbox, currentUserKey, detectEvents, isDone, nameOf, needsMe, otherOf,
  sanitizeList, toFa, unseenResults
} from './challenges';

/**
 * موتور هم‌زمان‌ناپذیرِ بخش «دونفره» (هر نفر هر وقت آنلاین شد جواب می‌ده) + اعلان‌های درون‌سایتی.
 *
 * - یک نظرسنجی مشترک برای کل سایت (نه فقط وقتی صفحه‌ی بازی بازه) تا اعلان‌ها همه‌جا برسن.
 *   اول فقط «شماره‌ی نسخه»ی ریز خونده می‌شه (rev.ts)؛ فقط اگه عوض شده باشه خودِ چالش‌ها دانلود می‌شن.
 * - هر نوشتن اول توی «صف ارسال» (localStorage) می‌ره و روی نسخه‌ی سرور اعمال می‌شه؛ با قطعی اینترنت
 *   چالش/جواب ناپدید نمی‌شه و با برگشتن اتصال خودکار فرستاده می‌شه.
 * - نوشتن‌ها همیشه «scoped»ن (هر چالش، هر جواب زیر کلید خودش)، پس دو دستگاه هم‌دیگه رو پاک نمی‌کنن.
 */

const MAX_WAITING_ON_PARTNER = 3; // بیشتر از این چالشِ بی‌جواب نمی‌شه پشت‌سرهم فرستاد
const TOAST_MS = 6000;
const SYNC_VISIBLE_GAMES_MS = 4000;
const SYNC_VISIBLE_OTHER_MS = 10000;
const FULL_REFRESH_MS = 30000;

export type GameToast = { id: number; text: string; tone: 'info' | 'error'; to?: string };
export type DrawBlock = 'mine' | 'waiting' | null;

type GamesCtx = {
  me: Who;
  partner: Who;
  partnerName: string;
  challenges: Challenge[];
  loaded: boolean;
  isDrawing: boolean;
  drawBlock: DrawBlock;
  todoCount: number;
  unseenResultIds: string[];
  attention: number;
  toast: GameToast | null;
  dismissToast: () => void;
  pushToast: (text: string, opts?: { tone?: 'info' | 'error'; to?: string }) => void;
  createChallenge: () => Promise<void>;
  submitAnswer: (id: string, text: string) => Promise<void>;
  markDareDone: (id: string) => Promise<void>;
  nudge: (id: string) => Promise<void>;
  markSeen: (ids: string[]) => void;
};

const GamesContext = createContext<GamesCtx | null>(null);

export function useGames(): GamesCtx {
  const ctx = useContext(GamesContext);
  if (!ctx) throw new Error('useGames باید داخل GameProvider استفاده بشه');
  return ctx;
}

function readJson<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function writeJson(key: string, value: unknown) {
  try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* حافظه پر یا خصوصی */ }
}

const sleep = (ms: number) => new Promise<void>(r => setTimeout(r, ms));

export const GameProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const me = useMemo(currentUserKey, []);
  const partner = otherOf(me);
  const partnerName = nameOf(partner);
  const OUTBOX_KEY = `loveniya_games_outbox_${me}`;
  const SEEN_KEY = `loveniya_games_seen_${me}`;

  const location = useLocation();
  const onGames = location.pathname === '/games' || location.pathname === '/moments';

  // ---- state ----
  const baseRef = useRef<Challenge[]>(sanitizeList(readJson<unknown>(MOMENTS_PATH, [])));
  const outboxRef = useRef<Record<string, unknown>>(readJson<Record<string, unknown>>(OUTBOX_KEY, {}));
  const viewRef = useRef<Challenge[]>(applyOutbox(baseRef.current, outboxRef.current));
  const [challenges, setChallenges] = useState<Challenge[]>(viewRef.current);
  const [loaded, setLoaded] = useState(false);
  const [isDrawing, setIsDrawing] = useState(false);
  const drawingRef = useRef(false);

  const seenKeyExists = useRef(localStorage.getItem(SEEN_KEY) !== null);
  const seenRef = useRef<Set<string>>(new Set(readJson<string[]>(SEEN_KEY, [])));
  const [seenVersion, setSeenVersion] = useState(0);

  // ---- toast ----
  const [toast, setToast] = useState<GameToast | null>(null);
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const toastSeq = useRef(0);
  const dismissToast = useCallback(() => {
    if (toastTimer.current) clearTimeout(toastTimer.current);
    setToast(null);
  }, []);
  const pushToast = useCallback((text: string, opts: { tone?: 'info' | 'error'; to?: string } = {}) => {
    if (toastTimer.current) clearTimeout(toastTimer.current);
    setToast({ id: ++toastSeq.current, text, tone: opts.tone ?? 'info', to: opts.to });
    toastTimer.current = setTimeout(() => setToast(null), TOAST_MS);
  }, []);
  useEffect(() => () => { if (toastTimer.current) clearTimeout(toastTimer.current); }, []);

  // ---- نمای نهایی = نسخه‌ی سرور + صف ارسال ----
  const commitView = useCallback(() => {
    const view = applyOutbox(baseRef.current, outboxRef.current);
    viewRef.current = view;
    setChallenges(prev => (JSON.stringify(prev) === JSON.stringify(view) ? prev : view));
    writeJson(MOMENTS_PATH, view);
  }, []);

  // ---- صف ارسال ----
  const flushingRef = useRef(false);
  const writeSeqRef = useRef(0);
  const lastOfflineToastRef = useRef(0);

  const flush = useCallback(async (): Promise<void> => {
    if (flushingRef.current) return;
    flushingRef.current = true;
    const attempted = new Set<string>();
    let anySent = false;
    try {
      for (const [p, body] of Object.entries(outboxRef.current)) {
        attempted.add(p);
        let status: 'ok' | 'drop' | 'retry' = 'retry';
        for (let attempt = 0; attempt < 3 && status === 'retry'; attempt++) {
          try {
            const res = await fetchT(`${WORKER_URL}/${MOMENTS_PATH}/${p}.json`, {
              method: 'PUT',
              headers: { 'Content-Type': 'application/json', 'X-App-Secret': APP_SECRET },
              body: JSON.stringify(body)
            }, 12000);
            if (res.ok) status = 'ok';
            else if (res.status >= 400 && res.status < 500 && res.status !== 429) status = 'drop'; // با تکرار درست نمی‌شه
          } catch { /* شبکه */ }
          if (status === 'retry' && attempt < 2) await sleep(700 * (attempt + 1));
        }
        if (status === 'retry') {
          // هنوز آفلاینیم؛ ترتیب مهمه (ساخت قبل از جواب)، پس همین‌جا می‌ایستیم و بعداً ادامه می‌دیم
          if (Date.now() - lastOfflineToastRef.current > 60000) {
            lastOfflineToastRef.current = Date.now();
            pushToast('ارسال نشد؛ ذخیره شد و با وصل‌شدن اینترنت خودکار می‌ره', { tone: 'error' });
          }
          break;
        }
        if (outboxRef.current[p] === body) delete outboxRef.current[p];
        if (status === 'drop') {
          pushToast('ذخیره نشد — دسترسی به سرور رد شد', { tone: 'error' });
        } else {
          anySent = true;
          // چیزی که الان روی سرور نشست، جزو «نسخه‌ی سرور» حساب بشه؛ وگرنه تا نظرسنجی بعدی
          // (چند ثانیه) نمایش به حالت قبل از جواب برمی‌گشت
          baseRef.current = applyOutbox(baseRef.current, { [p]: body });
        }
        writeJson(OUTBOX_KEY, outboxRef.current);
      }
    } finally {
      flushingRef.current = false;
    }
    if (anySent) {
      writeSeqRef.current += 1;
      void bumpRev(MOMENTS_PATH); // به دستگاه مقابل خبر بده
    }
    commitView();
    // چیزی که وسط ارسال به صف اضافه شد
    if (Object.keys(outboxRef.current).some(k => !attempted.has(k))) void flush();
  }, [OUTBOX_KEY, commitView, pushToast]);

  const queueWrite = useCallback((path: string, body: unknown) => {
    writeSeqRef.current += 1;
    outboxRef.current[path] = body;
    writeJson(OUTBOX_KEY, outboxRef.current);
    commitView();
    void flush();
  }, [OUTBOX_KEY, commitView, flush]);

  // ---- دریافت از سرور + اعلان‌ها ----
  const syncingRef = useRef(false);
  const lastRevRef = useRef<number | undefined>(undefined);
  const lastFullRef = useRef(0);
  const firstSyncRef = useRef(false);

  const announce = useCallback((events: GameEvent[]) => {
    if (events.length === 0) return;
    const to = '/games';
    if (events.length > 1) {
      pushToast(`${toFa(events.length)} خبر تازه در دونفره`, { to });
      return;
    }
    const ev = events[0];
    if (ev.type === 'incoming') {
      pushToast(`${partnerName} یه ${KIND_LABEL[ev.c.kind]} برات فرستاد`, { to });
    } else if (ev.type === 'nudge') {
      pushToast(`${partnerName} منتظر جواب توئه`, { to });
    } else if (ev.c.kind === 'dare') {
      pushToast(`${partnerName} جرأتت رو انجام داد`, { to });
    } else if (ev.c.kind === 'truth') {
      pushToast(`${partnerName} به سوالت جواب داد`, { to });
    } else {
      pushToast(`${partnerName} هم جواب داد — جواب‌ها بازه`, { to });
    }
  }, [partnerName, pushToast]);

  const sync = useCallback(async (force = false) => {
    if (syncingRef.current) return;
    syncingRef.current = true;
    try {
      if (Object.keys(outboxRef.current).length > 0) void flush();

      const now = Date.now();
      const revs = await fetchRevs();
      const rev = revs?.[MOMENTS_PATH];
      const revKnown = !!revs && rev !== undefined;
      const age = now - lastFullRef.current;
      const interval = onGames ? SYNC_VISIBLE_GAMES_MS : SYNC_VISIBLE_OTHER_MS;
      const needFetch =
        force ||
        !firstSyncRef.current ||
        age > FULL_REFRESH_MS ||
        (revKnown ? rev !== lastRevRef.current : age >= interval);
      if (!needFetch) return;

      const seqAtStart = writeSeqRef.current;
      const res = await fetchGetAuth(`${WORKER_URL}/${MOMENTS_PATH}/challenges.json?_t=${now}`, 12000);
      if (res.status === 401) {
        pushToast('دسترسی به سرور رد شد (رمز اپ)', { tone: 'error' });
        return;
      }
      if (!res.ok) return;
      const list = sanitizeList(await res.json());
      // وسط دریافت، نوشتنی انجام شده؛ نتیجه‌ی قدیمی رو دور بریز و دفعه‌ی بعد دوباره بگیر
      if (seqAtStart !== writeSeqRef.current) { lastRevRef.current = undefined; return; }

      lastRevRef.current = revKnown ? rev : undefined;
      lastFullRef.current = now;

      const prevView = viewRef.current;
      baseRef.current = list;
      commitView();
      const nextView = viewRef.current;

      if (!firstSyncRef.current) {
        firstSyncRef.current = true;
        // اولین بار: خوانده‌نشده‌های قبلی (نصب تازه) رو «دیده‌شده» حساب کن تا زنگ پر از خبرهای قدیمی نشه
        if (!seenKeyExists.current) {
          nextView.filter(isDone).forEach(c => seenRef.current.add(c.id));
          writeJson(SEEN_KEY, [...seenRef.current].slice(-300));
          seenKeyExists.current = true;
        }
        setSeenVersion(v => v + 1);
        setLoaded(true);
        // یک خلاصه‌ی کوتاه برای چیزهایی که وقتی سایت بسته بود پیش اومدن
        const todo = nextView.filter(c => needsMe(c, me)).length;
        const unseen = unseenResults(nextView, me, seenRef.current).length;
        if (todo > 0) pushToast(`${toFa(todo)} مورد توی دونفره منتظر جواب توئه`, { to: '/games' });
        else if (unseen > 0) pushToast('جواب تازه‌ای توی دونفره رسیده', { to: '/games' });
      } else {
        announce(detectEvents(prevView, nextView, me));
      }
    } catch {
      /* آفلاین: همون نسخه‌ی محلی می‌مونه */
    } finally {
      syncingRef.current = false;
    }
  }, [SEEN_KEY, announce, commitView, flush, me, onGames, pushToast]);

  // نمایش اولیه از حافظه‌ی محلی (آفلاین هم چیزی دیده بشه)
  useEffect(() => { if (viewRef.current.length > 0) setLoaded(true); }, []);

  useEffect(() => {
    void sync();
    const interval = setInterval(() => {
      if (document.visibilityState === 'visible') void sync();
    }, onGames ? SYNC_VISIBLE_GAMES_MS : SYNC_VISIBLE_OTHER_MS);
    const onVisible = () => { if (document.visibilityState === 'visible') void sync(true); };
    const onOnline = () => { void flush(); void sync(true); };
    document.addEventListener('visibilitychange', onVisible);
    window.addEventListener('online', onOnline);
    return () => {
      clearInterval(interval);
      document.removeEventListener('visibilitychange', onVisible);
      window.removeEventListener('online', onOnline);
    };
  }, [sync, flush, onGames]);

  // ---- محاسبه‌ها ----
  const todoCount = useMemo(() => challenges.filter(c => needsMe(c, me)).length, [challenges, me]);
  const waitingCount = useMemo(
    () => challenges.filter(c => !isDone(c) && !needsMe(c, me)).length,
    [challenges, me]
  );
  const unseenResultIds = useMemo(
    () => unseenResults(challenges, me, seenRef.current),
    // seenVersion عمداً وابستگیه: seenRef یک ref ـه و خودش رندر دوباره نمی‌سازه
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [challenges, me, seenVersion]
  );
  const attention = todoCount + unseenResultIds.length;
  const drawBlock: DrawBlock = todoCount > 0 ? 'mine' : waitingCount >= MAX_WAITING_ON_PARTNER ? 'waiting' : null;

  const markSeen = useCallback((ids: string[]) => {
    if (ids.length === 0) return;
    ids.forEach(id => seenRef.current.add(id));
    writeJson(SEEN_KEY, [...seenRef.current].slice(-300));
    setSeenVersion(v => v + 1);
  }, [SEEN_KEY]);

  // ---- اقدام‌ها ----
  const createChallenge = useCallback(async () => {
    if (drawingRef.current) return;
    const view = viewRef.current;
    const mine = view.some(c => needsMe(c, me));
    const waiting = view.filter(c => !isDone(c) && !needsMe(c, me)).length;
    if (mine || waiting >= MAX_WAITING_ON_PARTNER) return; // «طفره‌رفتن از چالش بی‌جواب» ممکن نیست
    drawingRef.current = true;
    setIsDrawing(true);
    try {
      const { kind, tone, text } = await generateChallenge(
        view.slice(0, 12).map(c => ({ kind: c.kind, tone: c.tone, text: c.text }))
      );
      if (!text.trim()) throw new Error('empty challenge');
      const item: Challenge = {
        id: 'ch_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7),
        kind, tone, text,
        createdBy: me,
        targetUser: kind === 'deep' ? undefined : partner,
        answers: {},
        createdAt: Date.now()
      };
      // Firebase کلید با مقدار undefined رو نمی‌پذیره
      const body: Record<string, unknown> = { ...item };
      if (body.targetUser === undefined) delete body.targetUser;
      queueWrite(`challenges/${item.id}`, body);
    } catch {
      pushToast('ساخت چالش انجام نشد؛ دوباره امتحان کن', { tone: 'error' });
    } finally {
      drawingRef.current = false;
      setIsDrawing(false);
    }
  }, [me, partner, pushToast, queueWrite]);

  const submitAnswer = useCallback(async (id: string, text: string) => {
    const t = text.trim();
    if (!t) return;
    const c = viewRef.current.find(x => x.id === id);
    queueWrite(`challenges/${id}/answers/${me}`, t);
    // اگه با همین جواب، سوالِ عمیق کامل شد، خودم همین الان نتیجه رو می‌بینم؛ «جدید» حسابش نکن
    if (c && c.kind === 'deep' && c.answers[partner]) markSeen([id]);
  }, [me, partner, queueWrite, markSeen]);

  const markDareDone = useCallback(async (id: string) => {
    queueWrite(`challenges/${id}/doneAt`, Date.now());
  }, [queueWrite]);

  const nudge = useCallback(async (id: string) => {
    queueWrite(`challenges/${id}/nudgedAt`, Date.now());
    pushToast(`یادآوری برای ${partnerName} فرستاده شد`);
  }, [partnerName, pushToast, queueWrite]);

  const value = useMemo<GamesCtx>(() => ({
    me, partner, partnerName, challenges, loaded, isDrawing, drawBlock, todoCount,
    unseenResultIds, attention, toast, dismissToast, pushToast,
    createChallenge, submitAnswer, markDareDone, nudge, markSeen
  }), [
    me, partner, partnerName, challenges, loaded, isDrawing, drawBlock, todoCount,
    unseenResultIds, attention, toast, dismissToast, pushToast,
    createChallenge, submitAnswer, markDareDone, nudge, markSeen
  ]);

  return <GamesContext.Provider value={value}>{children}</GamesContext.Provider>;
};
