import { fetchLoveAI } from './ai';

// این ماژول محتوای صفحه‌ی «گفتگوی دونفره» رو با هوش مصنوعی می‌سازه، چون امین و
// نیایش وقت کافی برای نوشتن دستی سوال و چالش ندارن. هر تابع در صورت خطا یا
// پاسخ نامعتبر از AI، به‌صورت کاملاً بی‌صدا (بدون نمایش خطا به کاربر) یک مقدار
// پیش‌فرض داخلی برمی‌گردونه تا بازی هیچ‌وقت خراب نشه.

export type ChallengeKind = 'truth' | 'dare' | 'deep';
export type ChallengeTone = 'light' | 'flirty' | 'deep';

const FALLBACK_LOVE_REASONS = [
  'چون با یه لبخندت کل روزم ساخته میشه.',
  'چون امن‌ترین پناهگاه دنیا بغل توئه.',
  'چون هر روز بیشتر از دیروز دلم برات ضعف میره.',
  'چون وقتی صدام می‌کنی، قشنگ‌ترین اسم دنیا رو دارم.',
  'چون تو تنها کسی هستی که دیوونه‌بازیامو درک میکنی.',
  'چون خنده‌هات قشنگ‌ترین موسیقی دنیاست.',
  'چون با تو، ساده‌ترین لحظه‌ها هم رویاییه.',
  'چون صدای نفس‌هات بهم آرامش بی‌نهایت میده.',
  'چون برق چشمات امید به آینده رو توی دلم زنده نگه می‌داره.',
  'چون تو دقیقاً همونی هستی که همیشه آرزوشو داشتم.'
];

/**
 * یک جمله‌ی تازه‌ی «چرا عاشقتم» با هوش مصنوعی می‌سازه. قبلاً این جمله‌ها یه
 * آرایه‌ی ثابت ۱۰تایی بودن که توی چند روز اول تکرار می‌شدن — برای سایتی که
 * قراره سال‌ها استفاده بشه، این فهرست هیچ‌وقت تموم نمی‌شه. avoid آخرین
 * جمله‌های دیده‌شده‌ی همین نشستن که ازشون خواسته می‌شه فاصله بگیره.
 */
export async function generateLoveReason(avoid: string[] = []): Promise<string> {
  try {
    const avoidLine = avoid.length > 0
      ? ` این جمله‌ها رو قبلاً گفتی، دقیقاً تکرارشون نکن: ${avoid.slice(-6).join(' / ')}`
      : '';
    const raw = await fetchLoveAI({
      type: 'chat',
      userMessage:
        'یک جمله‌ی کوتاه، صمیمی و محاوره‌ای فارسی بساز که با «چون» شروع بشه و دلیلی ' +
        'واقعی و گرم برای عاشق‌بودن به شریک زندگی باشه — نه کلیشه‌ای، نه رسمی.' +
        avoidLine +
        ' فقط خودِ جمله رو بنویس، یک خط، بدون مقدمه، بدون شماره، بدون گیومه.'
    });
    if (raw && raw !== 'SKIP' && raw.trim().length > 0) {
      return raw.trim().replace(/^["«]|["»]$/g, '');
    }
  } catch {
    // نادیده گرفتن خطا؛ از fallback استفاده می‌شه
  }
  const pool = FALLBACK_LOVE_REASONS.filter(r => !avoid.includes(r));
  return pickRandom(pool.length > 0 ? pool : FALLBACK_LOVE_REASONS);
}

function pickRandom<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

const KIND_INSTRUCTION: Record<ChallengeKind, string> = {
  truth: 'یک سوال «حقیقت» که طرف مقابل باید صادقانه جوابش رو بنویسه',
  dare: 'یک چالش «جرأت» کوتاه، مشخص و قابل‌انجام همین‌الان از راه دور (نه حضوری — پیام/تماس/عکس/صدا)',
  deep: 'یک سوالِ گفتگوی عمیق که هر دو نفر قراره جدا و صادقانه جواب بنویسن و بعد جواب‌ها با هم مقایسه بشه'
};

const TONE_INSTRUCTION: Record<ChallengeTone, string> = {
  light: 'با لحنی سبک، بامزه، امروزی و بدون فشار',
  flirty: 'با لحنی شیطنت‌آمیز، شوخ و فلرتی — بازیگوش و کمی گرم، ولی مؤدب و هیچ‌وقت مبتذل یا صریحِ جنسی',
  deep: 'با لحنی صمیمی و واقعاً عمیق — در حد احساسات واقعی، ترس‌ها یا رازها'
};

// وزن پایه‌ی لحن‌ها: حالت شیطنت‌آمیز عمداً کم‌رنگ نمی‌شه تا بازی همیشه کمی بازیگوش بمونه
const TONE_BASE_WEIGHT: Record<ChallengeTone, number> = { light: 0.35, flirty: 0.4, deep: 0.25 };

export type ChallengeHistoryItem = { kind: ChallengeKind; tone: ChallengeTone; text: string };

const RECENT_WINDOW = 6;

/** از بین گزینه‌ها، یکی رو با وزن انتخاب می‌کنه؛ هرچی اخیراً بیشتر اومده، شانسش کمتره. */
function pickVaried<T extends string>(
  options: T[],
  recent: T[],
  baseWeight: (o: T) => number = () => 1
): T {
  const weights = options.map(o => {
    const used = recent.slice(0, RECENT_WINDOW).filter(r => r === o).length;
    const justNow = recent[0] === o ? 0.3 : 1; // پشت‌سرهم تکرار نشه
    return baseWeight(o) * justNow / (1 + used * 1.5);
  });
  const total = weights.reduce((a, b) => a + b, 0);
  let r = Math.random() * total;
  for (let i = 0; i < options.length; i++) {
    r -= weights[i];
    if (r <= 0) return options[i];
  }
  return options[options.length - 1];
}

const normalize = (t: string) => t.replace(/[\s‌.،؟?!؛:"«»]/g, '').toLowerCase();

/** خروجی خام مدل رو به یک یا دو جمله‌ی تمیز تبدیل می‌کنه؛ اگه قابل‌استفاده نبود null. */
function cleanChallengeText(raw: string): string | null {
  const lines = raw
    .split('\n')
    .map(l => l.trim())
    .filter(Boolean);
  if (lines.length === 0) return null;
  let text = lines.slice(0, 2).join(' ');
  text = text
    .replace(/^[\s\-–•*\d۰-۹.)]+/, '')            // شماره/بولت ابتدای خط
    .replace(/\p{Extended_Pictographic}|\uFE0F/gu, '') // ایموجی با آیکون‌های سایت تداخل داره
    .replace(/^["«»]+|["«»]+$/g, '')
    .replace(/\s{2,}/g, ' ')
    .trim();
  if (text.length < 12 || text.length > 240) return null;
  // پاسخ‌هایی که مدل به‌جای خودِ متن، توضیح/مقدمه داده
  if (/^(حتماً|حتما|البته|بله|ببخشید|متاسفم|متأسفم)/.test(text)) return null;
  // متن باید عمدتاً فارسی باشه
  const persian = (text.match(/[\u0600-\u06FF]/g) || []).length;
  if (persian < text.replace(/\s/g, '').length * 0.5) return null;
  return text;
}

/**
 * یک چالش/سوال تازه می‌سازه. history = چالش‌های اخیر (جدیدترین اول) تا نوع، لحن و متن تکراری
 * نشه؛ اگه AI در دسترس نبود یا خروجی‌اش قابل‌استفاده نبود، از بین متن‌های آماده‌ی استفاده‌نشده
 * (بی‌صدا) انتخاب می‌شه تا بازی هیچ‌وقت خراب نشه.
 */
export async function generateChallenge(
  history: ChallengeHistoryItem[] = []
): Promise<{ kind: ChallengeKind; tone: ChallengeTone; text: string }> {
  const kind = pickVaried<ChallengeKind>(['truth', 'dare', 'deep'], history.map(h => h.kind));
  const tone = pickVaried<ChallengeTone>(['light', 'flirty', 'deep'], history.map(h => h.tone), t => TONE_BASE_WEIGHT[t]);
  const usedTexts = new Set(history.map(h => normalize(h.text)));

  try {
    const avoid = history.slice(0, 5).map(h => h.text);
    const avoidLine = avoid.length > 0
      ? ` این‌ها قبلاً پرسیده شده، شبیهشون نباش: ${avoid.join(' / ')}.`
      : '';
    const prompt =
      `${KIND_INSTRUCTION[kind]}، ${TONE_INSTRUCTION[tone]}، برای یک زوج بالغ در رابطه مسافتی (LDR) بساز. ` +
      'فقط خودِ متن رو در یک یا دو جمله بنویس، بدون مقدمه، بدون شماره، بدون گیومه، بدون ایموجی، بدون لحن بچگانه.' +
      avoidLine;
    const raw = await fetchLoveAI({ type: 'chat', userMessage: prompt });
    if (raw && raw !== 'SKIP') {
      const text = cleanChallengeText(raw);
      if (text && !usedTexts.has(normalize(text))) return { kind, tone, text };
    }
  } catch {
    // نادیده گرفتن خطا؛ از fallback استفاده می‌شه
  }
  const pool = FALLBACKS[kind][tone];
  const fresh = pool.filter(t => !usedTexts.has(normalize(t)));
  return { kind, tone, text: pickRandom(fresh.length > 0 ? fresh : pool) };
}

const FALLBACKS: Record<ChallengeKind, Record<ChallengeTone, string[]>> = {
  truth: {
    light: [
      'اولین چیزی که توی من نظرت رو جلب کرد چی بود؟',
      'کدوم عادت کوچیکِ من رو بیشتر از بقیه دوست داری؟',
      'اگه فردا یه روز کامل مرخصی داشتیم و کنار هم بودیم، اولین برنامه‌ات چی بود؟',
      'آخرین باری که بدون اینکه بفهمم داشتی بهم فکر می‌کردی کِی بود و چی شد؟'
    ],
    flirty: [
      'کدوم عکسِ من توی گوشیته که بیشتر از همه بهش نگاه می‌کنی؟',
      'اگه همین الان کنارم بودی، اولین کاری که می‌کردی چی بود؟',
      'چه چیزی توی لحن صدای من هست که هر بار حالت رو عوض می‌کنه؟',
      'کدوم لحظه‌ی ما رو وقتی تنهایی یواشکی دوباره مرور می‌کنی؟'
    ],
    deep: [
      'قشنگ‌ترین جمله‌ای که تا حالا بهت گفتم و هنوز توی ذهنته چیه؟',
      'چه چیزی درباره‌ی این فاصله هست که هیچ‌وقت بلند بهم نگفتی؟',
      'کِی حس کردی واقعاً می‌تونی جلوم خودت باشی، بدون هیچ نقابی؟',
      'چی باعث می‌شه توی رابطه‌مون احساس امنیت کنی، و چی کمی نگرانت می‌کنه؟'
    ]
  },
  dare: {
    light: [
      'همین الان یه ویس ۱۵ ثانیه‌ای بفرست و یه چیز بامزه از امروزت تعریف کن',
      'یه عکس از چیزی که همین لحظه جلوی چشمته بفرست، بدون هیچ توضیحی',
      'یه آهنگ بفرست که امروز یاد من افتادی، با یه جمله دلیلش',
      'یه ویس کوتاه بفرست و توش اسممو با سه لحن مختلف صدا بزن'
    ],
    flirty: [
      'یه ویس بفرست و توش بگو دلت برای چه چیزِ من بیشتر از همه تنگ شده',
      'یه عکس از بهترین لبخندت بفرست، همین الان',
      'با صدای آروم یه جمله بگو که تا آخر شب توی گوشم بمونه',
      'در یک جمله بنویس امشب دلت چه شکل بغلی می‌خواد'
    ],
    deep: [
      'یه پیام بنویس و توش دقیقاً بگو امروز به چه چیزِ من افتخار کردی',
      'زنگ بزن و بدون مقدمه بگو الان نسبت به این رابطه دقیقاً چه حسی داری',
      'یه ویس یک‌دقیقه‌ای بفرست و توش از چیزی بگو که از من یاد گرفتی',
      'یه نامه‌ی کوتاه برای «خودمون، یک سال دیگه» بنویس و برام بفرست'
    ]
  },
  deep: {
    light: [
      'اگه قرار بود امشب یه کار غیرمنتظره برای شاد کردن من انجام بدی، چی بود؟',
      'یه روز عادیِ ایده‌آل برای ما دو نفر، از صبح تا شب، چه شکلیه؟',
      'کوچک‌ترین چیزی که توی یه روز بد حالت رو خوب می‌کنه چیه؟',
      'اگه می‌تونستیم یه سفر ناگهانیِ دو نفره بریم، کجا و با چه حالی؟'
    ],
    flirty: [
      'اگه یه شب کامل فقط مال ما دو نفر بود، دوست داشتی چطور بگذره؟',
      'چی درباره‌ی من هست که فکر می‌کنی نمی‌دونم چقدر دوستش داری؟',
      'اولین باری که حس کردی از من خوشت اومده کِی بود؟ دقیق تعریف کن',
      'کدوم لحظه‌ی بین ما بود که قلبت واقعاً تند زد؟'
    ],
    deep: [
      'از چی درباره‌ی آینده‌ی ما بیشتر از همه می‌ترسی، و چی بیشتر از همه امیدوارت می‌کنه؟',
      'اگه بشه یه چیز از گذشته‌ت رو نشونم بدی تا بهتر بفهممت، چی بود؟',
      'از من چه چیزی لازم داری که هنوز نتونستی بگی؟',
      'وقتی به ده سال بعد فکر می‌کنی، ما کجاییم و در چه حالی؟'
    ]
  }
};
