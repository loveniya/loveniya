import React, { useState, useEffect, useCallback, useRef } from 'react';
import { 
  Heart, Sparkles, Coffee, Users, Send, 
  HelpCircle, Lock, Unlock, Check, CheckCircle2, RotateCw, 
  MessageCircle, HeartHandshake, ShieldCheck, 
  Gamepad2, Lightbulb, UserCheck, Inbox, Mail,
  Clock, Bell, Award, Flame, RefreshCw, Zap
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { NavLink } from 'react-router';

const WORKER_URL = "https://niya.am-b-asdfghjkl20112011.workers.dev";

// Default dilemmas for turn-based offline play
const PRESET_DILEMMAS = [
  {
    id: 'dil_preset_1',
    title: 'نحوه ارتباط در روزهای شلوغ کاری',
    optionA: 'ارسال ویس‌های صوتی چند دقیقه‌ای دلی از اتفاقات روز',
    optionB: 'پیام‌های متنی کوتاه ولی مداوم و پرانرژی در طول روز'
  },
  {
    id: 'dil_preset_2',
    title: 'برنامه تعطیلات آخر هفته از راه دور',
    optionA: 'تماس ویدیویی چند ساعته و تماشای هم‌زمان فیلم آنلاین',
    optionB: 'کل‌کل و رقابت در بازی آنلاین دو نفره با چت صوتی'
  },
  {
    id: 'dil_preset_3',
    title: 'سورپرایز غیرمنتظره برای منزل همدیگر',
    optionA: 'پست کردن یک نامه دست‌نویس با یک هدیه یادگاری واقعی',
    optionB: 'سفارش آنلاین ناگهانی شیرینی و گل با اسنپ‌فود'
  },
  {
    id: 'dil_preset_4',
    title: 'برنامه‌ریزی دیدار بعدی',
    optionA: 'یک سفر ۲ روزه فشرده و پرهیجان در اولین فرصت ممکن',
    optionB: 'برنامه‌ریزی صبورانه برای یک هفته کامل اقامت مشترک بی‌آشوب'
  }
];

const PRESET_TRUTHS_DARES: Array<{ type: 'truth' | 'dare'; prompt: string }> = [
  { type: 'dare', prompt: 'یک ویس ۷ ثانیه‌ای خنده‌دار با لحن مجری گزارشگر فوتبال در چت بفرست' },
  { type: 'truth', prompt: 'عجیب‌ترین و بانمک‌ترین فکری که در اولین تماس تصویریامون کردی چی بود؟' },
  { type: 'dare', prompt: 'یک سلفی با ژست خنده‌دار یا بامزه همین الان در چت ۲+۱ ثبت کن' },
  { type: 'truth', prompt: 'کدام عکس یا خاطره در آلبوم مشترک ما رو بیشتر از همه دوست داری؟' },
  { type: 'dare', prompt: 'یک شعر یا جمله عاشقانه کوتاه با لحن فوق‌العاده جدی برام وویس کن' },
  { type: 'truth', prompt: 'کدام پیام چتمون رو دوباره چند بار با لبخند و حس قشنگ خوندی؟' }
];

export type AsymmetricDilemma = {
  id: string;
  title: string;
  optionA: string;
  optionB: string;
  creator: 'amin' | 'niyayesh';
  createdAt: number;
  aminChoice?: 'A' | 'B';
  niyayeshChoice?: 'A' | 'B';
  status: 'waiting' | 'revealed';
};

export type SecretEnvelope = {
  id: string;
  question: string;
  creator: 'amin' | 'niyayesh';
  secretText: string;
  guesserChoice?: string;
  status: 'locked' | 'unlocked';
  createdAt: number;
  unlockedAt?: number;
};

export type OfflineDare = {
  id: string;
  type: 'truth' | 'dare';
  prompt: string;
  sender: 'amin' | 'niyayesh';
  status: 'pending' | 'completed';
  createdAt: number;
  completedAt?: number;
};

export type AffectionMessage = {
  id: string;
  sender: 'amin' | 'niyayesh';
  type: 'hug' | 'kiss' | 'tea' | 'note';
  noteText?: string;
  createdAt: number;
  isRead: boolean;
};

export type GameState = {
  dilemmas: AsymmetricDilemma[];
  secretEnvelopes: SecretEnvelope[];
  dares: OfflineDare[];
  affectionInbox: AffectionMessage[];
  loveNote: {
    text: string;
    sender: 'amin' | 'niyayesh';
    createdAt: number;
  } | null;
};

const INITIAL_GAME_STATE: GameState = {
  dilemmas: PRESET_DILEMMAS.map((d, i) => ({
    ...d,
    creator: 'amin',
    createdAt: Date.now() - (i * 3600000),
    status: 'waiting'
  })),
  secretEnvelopes: [
    {
      id: 'sec_preset_1',
      question: 'اولین کاری که بلافاصله بعد از دیدن همدیگه انجام می‌دیم؟',
      creator: 'amin',
      secretText: 'یک آغوش طولانی بی کلام و آروم',
      status: 'locked',
      createdAt: Date.now() - 7200000
    }
  ],
  dares: [
    {
      id: 'dare_preset_1',
      type: 'dare',
      prompt: 'یک ویس ۵ ثانیه‌ای خنده‌دار در چت برام بفرست!',
      sender: 'amin',
      status: 'pending',
      createdAt: Date.now() - 3600000
    }
  ],
  affectionInbox: [
    {
      id: 'aff_preset_1',
      sender: 'amin',
      type: 'hug',
      createdAt: Date.now() - 1800000,
      isRead: false
    }
  ],
  loveNote: {
    text: 'روزت پر از لبخند باشه مهربونم! منتظرم وقتی آنلاین شدی چالشامو ببینی ❤️',
    sender: 'amin',
    createdAt: Date.now() - 900000
  }
};

export const LdrGameEngine: React.FC = () => {
  // Current active user identity (Amin or Niayesh)
  const [currentUser, setCurrentUser] = useState<'amin' | 'niyayesh'>(() => {
    return (localStorage.getItem('loveniya_user') as 'amin' | 'niyayesh') || 'amin';
  });

  const [gameState, setGameState] = useState<GameState>(INITIAL_GAME_STATE);
  const [activeTab, setActiveTab] = useState<'mailbox' | 'dilemmas' | 'secret' | 'dares' | 'affection'>('mailbox');
  const [syncStatus, setSyncStatus] = useState<'syncing' | 'connected' | 'error'>('connected');

  // Input states for creating items asynchronously
  const [newDilemmaTitle, setNewDilemmaTitle] = useState('');
  const [newOptA, setNewOptA] = useState('');
  const [newOptB, setNewOptB] = useState('');
  const [showAddDilemma, setShowAddDilemma] = useState(false);

  const [newSecretQuestion, setNewSecretQuestion] = useState('');
  const [newSecretAnswer, setNewSecretAnswer] = useState('');
  const [guessInput, setGuessInput] = useState('');

  const [customDarePrompt, setCustomDarePrompt] = useState('');
  const [dareType, setDareType] = useState<'truth' | 'dare'>('dare');

  const [noteInput, setNoteInput] = useState('');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const partnerKey: 'amin' | 'niyayesh' = currentUser === 'amin' ? 'niyayesh' : 'amin';
  const partnerName = currentUser === 'amin' ? 'نیایش' : 'امین';
  const currentUserName = currentUser === 'amin' ? 'امین' : 'نیایش';

  const handleSwitchUser = (user: 'amin' | 'niyayesh') => {
    setCurrentUser(user);
    localStorage.setItem('loveniya_user', user);
  };

  const mutatedAtRef = useRef<number>(0);

  // REST API Sync with Cloudflare Worker
  const syncGameState = useCallback(async (newState: GameState) => {
    try {
      mutatedAtRef.current = Date.now();
      setSyncStatus('syncing');
      setGameState(newState);
      localStorage.setItem('loveniya_ldr_games_async', JSON.stringify(newState));

      const res = await fetch(`${WORKER_URL}/loveniya_ldr_games_async.json`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newState)
      });

      if (res.ok) {
        setSyncStatus('connected');
      } else {
        setSyncStatus('error');
      }
    } catch {
      setSyncStatus('error');
    }
  }, []);

  const fetchGameState = useCallback(async () => {
    // Prevent fetching if we recently mutated (within 8 seconds) to avoid overwriting optimistic updates
    if (Date.now() - mutatedAtRef.current < 8000) return;

    try {
      const res = await fetch(`${WORKER_URL}/loveniya_ldr_games_async.json?_t=${Date.now()}`, { cache: 'no-store' });
      if (res.ok) {
        const data = await res.json();
        if (data && typeof data === 'object' && Array.isArray(data.dilemmas)) {
          setGameState(data);
          setSyncStatus('connected');
        }
      }
    } catch {
      setSyncStatus('error');
    }
  }, []);

  useEffect(() => {
    const cached = localStorage.getItem('loveniya_ldr_games_async');
    if (cached) {
      try {
        setGameState(JSON.parse(cached));
      } catch {}
    }

    fetchGameState();
    const interval = setInterval(fetchGameState, 5000);
    return () => clearInterval(interval);
  }, [fetchGameState]);

  // Mark pending affection items as read when viewing mailbox/affection
  const markAffectionAsRead = useCallback(() => {
    let changed = false;
    const updatedInbox = gameState.affectionInbox.map(item => {
      if (item.sender === partnerKey && !item.isRead) {
        changed = true;
        return { ...item, isRead: true };
      }
      return item;
    });

    if (changed) {
      syncGameState({ ...gameState, affectionInbox: updatedInbox });
    }
  }, [gameState, partnerKey, syncGameState]);

  useEffect(() => {
    if (activeTab === 'mailbox' || activeTab === 'affection') {
      markAffectionAsRead();
    }
  }, [activeTab, markAffectionAsRead]);

  // Calculations for pending mailbox items for CURRENT USER
  const pendingDilemmas = gameState.dilemmas.filter(d => {
    const myChoice = currentUser === 'amin' ? d.aminChoice : d.niyayeshChoice;
    return !myChoice;
  });

  const pendingSecrets = gameState.secretEnvelopes.filter(s => {
    return s.creator === partnerKey && s.status === 'locked';
  });

  const pendingDares = gameState.dares.filter(d => {
    return d.sender === partnerKey && d.status === 'pending';
  });

  const unreadAffections = gameState.affectionInbox.filter(a => {
    return a.sender === partnerKey && !a.isRead;
  });

  const totalPendingMail = pendingDilemmas.length + pendingSecrets.length + pendingDares.length + unreadAffections.length;

  // Handlers for Dilemma
  const handleVoteDilemma = (dilemmaId: string, choice: 'A' | 'B') => {
    const updatedDilemmas = gameState.dilemmas.map(d => {
      if (d.id === dilemmaId) {
        const aminVal = currentUser === 'amin' ? choice : d.aminChoice;
        const niyayeshVal = currentUser === 'niyayesh' ? choice : d.niyayeshChoice;
        const isBothAnswered = Boolean(aminVal && niyayeshVal);

        return {
          ...d,
          aminChoice: aminVal,
          niyayeshChoice: niyayeshVal,
          status: (isBothAnswered ? 'revealed' : 'waiting') as 'waiting' | 'revealed'
        };
      }
      return d;
    });

    syncGameState({ ...gameState, dilemmas: updatedDilemmas });
    setToastMessage('پاسخ شما برای این چالش ثبت شد!');
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleCreateDilemma = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDilemmaTitle.trim() || !newOptA.trim() || !newOptB.trim()) return;

    const myChoice: 'A' | 'B' = 'A'; // Creator answers A by default
    const newObj: AsymmetricDilemma = {
      id: 'dil_' + Date.now(),
      title: newDilemmaTitle.trim(),
      optionA: newOptA.trim(),
      optionB: newOptB.trim(),
      creator: currentUser,
      createdAt: Date.now(),
      aminChoice: currentUser === 'amin' ? myChoice : undefined,
      niyayeshChoice: currentUser === 'niyayesh' ? myChoice : undefined,
      status: 'waiting'
    };

    syncGameState({
      ...gameState,
      dilemmas: [newObj, ...gameState.dilemmas]
    });

    setNewDilemmaTitle('');
    setNewOptA('');
    setNewOptB('');
    setShowAddDilemma(false);
    setToastMessage(`چالش جدید برای ${partnerName} ثبت شد!`);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Handlers for Secret Envelope
  const handleCreateSecret = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSecretQuestion.trim() || !newSecretAnswer.trim()) return;

    const newObj: SecretEnvelope = {
      id: 'sec_' + Date.now(),
      question: newSecretQuestion.trim(),
      secretText: newSecretAnswer.trim(),
      creator: currentUser,
      status: 'locked',
      createdAt: Date.now()
    };

    syncGameState({
      ...gameState,
      secretEnvelopes: [newObj, ...gameState.secretEnvelopes]
    });

    setNewSecretQuestion('');
    setNewSecretAnswer('');
    setToastMessage(`پاسخ پنهان شما قفل شد! منتظر ورود ${partnerName} باشید.`);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleUnlockSecret = (secretId: string) => {
    if (!guessInput.trim()) return;

    const updated = gameState.secretEnvelopes.map(s => {
      if (s.id === secretId) {
        return {
          ...s,
          guesserChoice: guessInput.trim(),
          status: 'unlocked' as const,
          unlockedAt: Date.now()
        };
      }
      return s;
    });

    syncGameState({ ...gameState, secretEnvelopes: updated });
    setGuessInput('');
    setToastMessage('پاکت راز بازگشایی شد!');
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Handlers for Dares
  const handleCreateDare = (promptText?: string, type?: 'truth' | 'dare') => {
    const textToUse = promptText || customDarePrompt.trim();
    const typeToUse = type || dareType;
    if (!textToUse) return;

    const newObj: OfflineDare = {
      id: 'dare_' + Date.now(),
      type: typeToUse,
      prompt: textToUse,
      sender: currentUser,
      status: 'pending',
      createdAt: Date.now()
    };

    syncGameState({
      ...gameState,
      dares: [newObj, ...gameState.dares]
    });

    if (!promptText) setCustomDarePrompt('');
    setToastMessage(`چالش ${typeToUse === 'dare' ? 'جرات' : 'حقیقت'} برای ${partnerName} فرستاده شد!`);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleCompleteDare = (dareId: string) => {
    const updated = gameState.dares.map(d => {
      if (d.id === dareId) {
        return {
          ...d,
          status: 'completed' as const,
          completedAt: Date.now()
        };
      }
      return d;
    });

    syncGameState({ ...gameState, dares: updated });
    setToastMessage('چالش به عنوان انجام‌شده علامت زده شد!');
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Handlers for Affection & Notes
  const sendAffection = (type: 'hug' | 'kiss' | 'tea') => {
    const newMsg: AffectionMessage = {
      id: 'aff_' + Date.now(),
      sender: currentUser,
      type,
      createdAt: Date.now(),
      isRead: false
    };

    syncGameState({
      ...gameState,
      affectionInbox: [newMsg, ...gameState.affectionInbox]
    });

    const labels = {
      hug: 'یک آغوش گرم آفلاین',
      kiss: 'یک بوسه از راه دور',
      tea: 'یک فنجان چای مجازی'
    };

    setToastMessage(`${labels[type]} در صندوق ${partnerName} ثبت شد!`);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleSaveLoveNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!noteInput.trim()) return;

    const newNote = {
      text: noteInput.trim(),
      sender: currentUser,
      createdAt: Date.now()
    };

    syncGameState({ ...gameState, loveNote: newNote });
    setNoteInput('');
    setToastMessage(`یادداشت برای ورود بعدی ${partnerName} ذخیره شد!`);
    setTimeout(() => setToastMessage(null), 3000);
  };

  return (
    <div className="relative overflow-hidden rounded-3xl bg-stone-900 text-stone-100 p-4 sm:p-6 shadow-xl border border-stone-800 space-y-5">
      
      {/* Header Bar: Identity & Offline Mailbox Counter */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-stone-800 pb-4">
        
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl bg-rose-500/10 text-rose-400 border border-rose-500/20 flex items-center justify-center shrink-0">
            <Inbox className="w-6 h-6 text-rose-400" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm sm:text-base font-extrabold text-white tracking-tight">
                صندوق چالش‌ها و رازهای امین و نیایش
              </h2>
              <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30">
                <Clock className="w-3 h-3 text-rose-400" />
                ثبت پیام و چالش
              </span>
            </div>
            <p className="text-[11px] text-stone-400 mt-0.5">
              ثبت چالش، راز و حس دلی برای زمانی که همسرتان آنلاین می‌شود
            </p>
          </div>
        </div>

      </div>

      {/* Persistent Note left for Next Visit */}
      {gameState.loveNote && gameState.loveNote.sender === partnerKey && (
        <motion.div
          initial={{ opacity: 0, y: -5 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-rose-950/40 border border-rose-800/60 p-3.5 rounded-2xl flex items-start gap-3"
        >
          <div className="w-8 h-8 rounded-xl bg-rose-500/20 text-rose-300 flex items-center justify-center shrink-0">
            <Mail className="w-4 h-4 text-rose-400" />
          </div>
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-xs font-extrabold text-rose-200">
                💌 یادداشت مستقیم از طرف {partnerName}:
              </span>
              <span className="text-[10px] text-rose-400 font-mono">
                {new Date(gameState.loveNote.createdAt).toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
            <p className="text-xs font-medium text-stone-200 leading-relaxed">
              «{gameState.loveNote.text}»
            </p>
          </div>
        </motion.div>
      )}

      {/* Tabs Row */}
      <div className="flex items-center gap-1 bg-stone-950 p-1 rounded-2xl border border-stone-800 overflow-x-auto">
        
        <button
          onClick={() => setActiveTab('mailbox')}
          className={`flex-1 min-w-[120px] px-3 py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 whitespace-nowrap relative ${
            activeTab === 'mailbox'
              ? 'bg-rose-600 text-white shadow-xs'
              : 'text-stone-400 hover:text-stone-200'
          }`}
        >
          <Bell className="w-3.5 h-3.5" />
          <span>صندوق ورودی</span>
          {totalPendingMail > 0 && (
            <span className="bg-amber-500 text-stone-950 text-[10px] font-black px-1.5 py-0.2 rounded-full border border-stone-900">
              {totalPendingMail}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab('dilemmas')}
          className={`flex-1 min-w-[110px] px-3 py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 whitespace-nowrap relative ${
            activeTab === 'dilemmas'
              ? 'bg-rose-600 text-white shadow-xs'
              : 'text-stone-400 hover:text-stone-200'
          }`}
        >
          <Users className="w-3.5 h-3.5" />
          <span>چالش این/آن</span>
          {pendingDilemmas.length > 0 && (
            <span className="w-2 h-2 rounded-full bg-amber-400" />
          )}
        </button>

        <button
          onClick={() => setActiveTab('secret')}
          className={`flex-1 min-w-[110px] px-3 py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 whitespace-nowrap relative ${
            activeTab === 'secret'
              ? 'bg-rose-600 text-white shadow-xs'
              : 'text-stone-400 hover:text-stone-200'
          }`}
        >
          <Lock className="w-3.5 h-3.5" />
          <span>صندوق راز</span>
          {pendingSecrets.length > 0 && (
            <span className="w-2 h-2 rounded-full bg-amber-400" />
          )}
        </button>

        <button
          onClick={() => setActiveTab('dares')}
          className={`flex-1 min-w-[110px] px-3 py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 whitespace-nowrap relative ${
            activeTab === 'dares'
              ? 'bg-rose-600 text-white shadow-xs'
              : 'text-stone-400 hover:text-stone-200'
          }`}
        >
          <Flame className="w-3.5 h-3.5" />
          <span>چالش جرات</span>
          {pendingDares.length > 0 && (
            <span className="w-2 h-2 rounded-full bg-amber-400" />
          )}
        </button>

        <button
          onClick={() => setActiveTab('affection')}
          className={`flex-1 min-w-[110px] px-3 py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 whitespace-nowrap relative ${
            activeTab === 'affection'
              ? 'bg-rose-600 text-white shadow-xs'
              : 'text-stone-400 hover:text-stone-200'
          }`}
        >
          <HeartHandshake className="w-3.5 h-3.5" />
          <span>حس آفلاین</span>
          {unreadAffections.length > 0 && (
            <span className="w-2 h-2 rounded-full bg-amber-400" />
          )}
        </button>
      </div>

      {/* TAB 1: MAILBOX OVERVIEW */}
      {activeTab === 'mailbox' && (
        <div className="space-y-4">
          <div className="bg-stone-950 p-4 rounded-2xl border border-stone-800 space-y-3">
            <div className="flex items-center justify-between border-b border-stone-800/80 pb-3">
              <h3 className="text-xs font-extrabold text-stone-200 flex items-center gap-2">
                <Bell className="w-4 h-4 text-amber-400" />
                <span>وضعیت موارد منتظر پاسخ {currentUserName}:</span>
              </h3>
              <span className="text-[11px] font-bold text-stone-400">
                {totalPendingMail === 0 ? 'همه موارد بررسی شده‌اند ✨' : `${totalPendingMail} مورد جدید`}
              </span>
            </div>

            {totalPendingMail === 0 ? (
              <div className="py-6 text-center text-stone-400 space-y-2">
                <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" />
                <p className="text-xs font-bold text-stone-300">
                  هیچ چالش خوانده‌نشده‌ای از طرف {partnerName} وجود ندارد!
                </p>
                <p className="text-[11px] text-stone-500">
                  می‌توانید یک چالش جدید در تب‌های بالا ثبت کنید تا وقتی {partnerName} آنلاین شد آن را ببیند.
                </p>
              </div>
            ) : (
              <div className="space-y-2.5">
                {/* Pending Dilemmas */}
                {pendingDilemmas.map(d => (
                  <div
                    key={d.id}
                    className="p-3 rounded-xl bg-stone-900 border border-stone-800 flex items-center justify-between gap-3"
                  >
                    <div className="space-y-0.5">
                      <span className="text-[10px] font-bold text-rose-400">چالش «این یا آن» منتظر نظر شما:</span>
                      <p className="text-xs font-bold text-stone-200">{d.title}</p>
                    </div>
                    <button
                      onClick={() => setActiveTab('dilemmas')}
                      className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-[11px] font-bold shrink-0 flex items-center gap-1"
                    >
                      <span>پاسخ بده</span>
                    </button>
                  </div>
                ))}

                {/* Pending Secrets */}
                {pendingSecrets.map(s => (
                  <div
                    key={s.id}
                    className="p-3 rounded-xl bg-stone-900 border border-stone-800 flex items-center justify-between gap-3"
                  >
                    <div className="space-y-0.5">
                      <span className="text-[10px] font-bold text-amber-400">یک راز قفل‌شده از طرف {partnerName}:</span>
                      <p className="text-xs font-bold text-stone-200">{s.question}</p>
                    </div>
                    <button
                      onClick={() => setActiveTab('secret')}
                      className="px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-500 text-stone-950 text-[11px] font-bold shrink-0 flex items-center gap-1"
                    >
                      <Lock className="w-3 h-3" />
                      <span>بازگشایی</span>
                    </button>
                  </div>
                ))}

                {/* Pending Dares */}
                {pendingDares.map(dare => (
                  <div
                    key={dare.id}
                    className="p-3 rounded-xl bg-stone-900 border border-stone-800 flex items-center justify-between gap-3"
                  >
                    <div className="space-y-0.5">
                      <span className="text-[10px] font-bold text-purple-400">چالش {dare.type === 'dare' ? 'جرات' : 'حقیقت'}:</span>
                      <p className="text-xs font-bold text-stone-200">{dare.prompt}</p>
                    </div>
                    <button
                      onClick={() => setActiveTab('dares')}
                      className="px-3 py-1.5 rounded-lg bg-purple-600 hover:bg-purple-500 text-white text-[11px] font-bold shrink-0 flex items-center gap-1"
                    >
                      <span>مشاهده</span>
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Quick Note Writer for Next Login */}
          <form onSubmit={handleSaveLoveNote} className="bg-stone-950 p-4 rounded-2xl border border-stone-800 space-y-3">
            <h4 className="text-xs font-bold text-stone-300 flex items-center gap-2">
              <Mail className="w-4 h-4 text-rose-400" />
              <span>ثبت یادداشت برای ورود بعدی {partnerName}:</span>
            </h4>
            <div className="flex gap-2">
              <input
                type="text"
                placeholder={`جمله‌ای برای ${partnerName} بنویسید که به محض باز کردن برنامه ببیند...`}
                value={noteInput}
                onChange={(e) => setNoteInput(e.target.value)}
                className="flex-1 bg-stone-900 border border-stone-800 rounded-xl px-3 py-2 text-xs text-stone-100 placeholder:text-stone-500 focus:outline-hidden focus:border-rose-500"
              />
              <button
                type="submit"
                disabled={!noteInput.trim()}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-500 disabled:opacity-40 text-white text-xs font-bold rounded-xl flex items-center gap-1 shrink-0"
              >
                <Send className="w-3.5 h-3.5" />
                <span>ذخیره</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* TAB 2: ASYNCHRONOUS DILEMMAS */}
      {activeTab === 'dilemmas' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between text-xs text-stone-400 font-medium">
            <span className="flex items-center gap-1.5">
              <Users className="w-4 h-4 text-rose-400" />
              <span>چالش‌های نوبتی «این یا آن»</span>
            </span>

            <button
              onClick={() => setShowAddDilemma(!showAddDilemma)}
              className="text-xs text-rose-400 hover:text-rose-300 font-bold flex items-center gap-1 bg-rose-950/60 px-2.5 py-1 rounded-lg border border-rose-800/50"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>+ ایجاد چالش جدید</span>
            </button>
          </div>

          {/* Form to add custom dilemma */}
          {showAddDilemma && (
            <motion.form
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              onSubmit={handleCreateDilemma}
              className="bg-stone-950 p-4 rounded-2xl border border-rose-900/50 space-y-3"
            >
              <h4 className="text-xs font-bold text-rose-300 flex items-center gap-1.5">
                <Lightbulb className="w-4 h-4 text-rose-400" />
                طرح یک چالش «این یا آن» جدید:
              </h4>
              <input
                type="text"
                placeholder="عنوان چالش (مثلاً: روش ترجیحی برای سپری کردن شب‌های تعطیل)..."
                value={newDilemmaTitle}
                onChange={(e) => setNewDilemmaTitle(e.target.value)}
                className="w-full bg-stone-900 border border-stone-800 rounded-xl px-3 py-2 text-xs text-stone-100 placeholder:text-stone-500 focus:outline-hidden focus:border-rose-500"
              />
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <input
                  type="text"
                  placeholder="گزینه اول..."
                  value={newOptA}
                  onChange={(e) => setNewOptA(e.target.value)}
                  className="bg-stone-900 border border-stone-800 rounded-xl px-3 py-2 text-xs text-stone-100 placeholder:text-stone-500 focus:outline-hidden focus:border-rose-500"
                />
                <input
                  type="text"
                  placeholder="گزینه دوم..."
                  value={newOptB}
                  onChange={(e) => setNewOptB(e.target.value)}
                  className="bg-stone-900 border border-stone-800 rounded-xl px-3 py-2 text-xs text-stone-100 placeholder:text-stone-500 focus:outline-hidden focus:border-rose-500"
                />
              </div>
              <div className="flex justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setShowAddDilemma(false)}
                  className="px-3 py-1.5 text-xs text-stone-400 hover:text-stone-200"
                >
                  انصراف
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold flex items-center gap-1"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>ارسال برای {partnerName}</span>
                </button>
              </div>
            </motion.form>
          )}

          {/* List of Asymmetric Dilemmas */}
          <div className="space-y-3">
            {gameState.dilemmas.map((d) => {
              const myChoice = currentUser === 'amin' ? d.aminChoice : d.niyayeshChoice;
              const partnerChoice = currentUser === 'amin' ? d.niyayeshChoice : d.aminChoice;
              const bothAnswered = Boolean(myChoice && partnerChoice);
              const isMatch = bothAnswered && myChoice === partnerChoice;

              return (
                <div key={d.id} className="bg-stone-950 p-4 rounded-2xl border border-stone-800 space-y-3">
                  <div className="flex items-center justify-between border-b border-stone-800/80 pb-2">
                    <span className="text-xs font-extrabold text-stone-200">{d.title}</span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-stone-900 text-stone-400 border border-stone-800">
                      ایجادشده توسط {d.creator === 'amin' ? 'امین' : 'نیایش'}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {/* Option A */}
                    <button
                      onClick={() => handleVoteDilemma(d.id, 'A')}
                      className={`p-3 rounded-xl border text-right transition-all flex flex-col justify-between gap-2 ${
                        myChoice === 'A'
                          ? 'bg-rose-600/20 border-rose-500 text-rose-100'
                          : 'bg-stone-900 border-stone-800 text-stone-300 hover:border-stone-700'
                      }`}
                    >
                      <div className="flex items-center justify-between w-full">
                        <span className="text-[10px] font-bold text-stone-400">گزینه اول</span>
                        {myChoice === 'A' && <Check className="w-3.5 h-3.5 text-rose-400" />}
                      </div>
                      <p className="text-xs font-bold">{d.optionA}</p>
                    </button>

                    {/* Option B */}
                    <button
                      onClick={() => handleVoteDilemma(d.id, 'B')}
                      className={`p-3 rounded-xl border text-right transition-all flex flex-col justify-between gap-2 ${
                        myChoice === 'B'
                          ? 'bg-rose-600/20 border-rose-500 text-rose-100'
                          : 'bg-stone-900 border-stone-800 text-stone-300 hover:border-stone-700'
                      }`}
                    >
                      <div className="flex items-center justify-between w-full">
                        <span className="text-[10px] font-bold text-stone-400">گزینه دوم</span>
                        {myChoice === 'B' && <Check className="w-3.5 h-3.5 text-rose-400" />}
                      </div>
                      <p className="text-xs font-bold">{d.optionB}</p>
                    </button>
                  </div>

                  {/* Status Outcome */}
                  {bothAnswered ? (
                    <div className={`p-2.5 rounded-xl border text-center text-xs font-bold flex items-center justify-center gap-2 ${
                      isMatch
                        ? 'bg-emerald-950/60 border-emerald-800 text-emerald-300'
                        : 'bg-amber-950/60 border-amber-800 text-amber-300'
                    }`}>
                      {isMatch ? (
                        <>
                          <Award className="w-4 h-4 text-emerald-400" />
                          <span>تطابق کامل! هر دو گزینه {myChoice === 'A' ? 'اول' : 'دوم'} را انتخاب کردید.</span>
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-4 h-4 text-amber-400" />
                          <span>دو دیدگاه متفاوت! شما: {myChoice === 'A' ? 'گزینه اول' : 'گزینه دوم'} | {partnerName}: {partnerChoice === 'A' ? 'گزینه اول' : 'گزینه دوم'}</span>
                        </>
                      )}
                    </div>
                  ) : (
                    <div className="p-2 rounded-xl bg-stone-900 border border-stone-800/80 text-center text-[11px] text-stone-400">
                      {myChoice 
                        ? `پاسخ شما ثبت شد. منتظر انتخاب ${partnerName} هنگام ورود بعدی باشید!` 
                        : `${partnerName} منتظر پاسخ شماست!`}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 3: SECRET GUESSING ENVELOPES */}
      {activeTab === 'secret' && (
        <div className="space-y-4">
          {/* Create Secret Form */}
          <form onSubmit={handleCreateSecret} className="bg-stone-950 p-4 rounded-2xl border border-stone-800 space-y-3">
            <h3 className="text-xs font-extrabold text-stone-200 flex items-center gap-2">
              <Lock className="w-4 h-4 text-amber-400" />
              <span>قفل کردن یک پاسخ پنهان برای حدس زدن {partnerName}:</span>
            </h3>
            <input
              type="text"
              placeholder="سوال چالش (مثلاً: اولین جایی که تو سفر بعدی می‌ریم کجاست؟)..."
              value={newSecretQuestion}
              onChange={(e) => setNewSecretQuestion(e.target.value)}
              className="w-full bg-stone-900 border border-stone-800 rounded-xl px-3 py-2 text-xs text-stone-100 placeholder:text-stone-500 focus:outline-hidden focus:border-rose-500"
            />
            <div className="flex gap-2">
              <input
                type="password"
                placeholder="پاسخ واقعی و پنهان شما (تا زمانی که همسرتان حدس نزند مخفی می‌ماند)..."
                value={newSecretAnswer}
                onChange={(e) => setNewSecretAnswer(e.target.value)}
                className="flex-1 bg-stone-900 border border-stone-800 rounded-xl px-3 py-2 text-xs text-stone-100 placeholder:text-stone-500 focus:outline-hidden focus:border-rose-500"
              />
              <button
                type="submit"
                disabled={!newSecretQuestion.trim() || !newSecretAnswer.trim()}
                className="px-4 py-2 bg-amber-600 hover:bg-amber-500 disabled:opacity-40 text-stone-950 text-xs font-bold rounded-xl flex items-center gap-1 shrink-0"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>قفل پاکت</span>
              </button>
            </div>
          </form>

          {/* List of Secret Envelopes */}
          <div className="space-y-3">
            {gameState.secretEnvelopes.map((s) => {
              const isMine = s.creator === currentUser;

              return (
                <div key={s.id} className="bg-stone-950 p-4 rounded-2xl border border-stone-800 space-y-3">
                  <div className="flex items-center justify-between border-b border-stone-800/80 pb-2">
                    <span className="text-xs font-extrabold text-stone-200">{s.question}</span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-stone-900 text-stone-400 border border-stone-800">
                      ثبت توسط {s.creator === 'amin' ? 'امین' : 'نیایش'}
                    </span>
                  </div>

                  {s.status === 'locked' ? (
                    isMine ? (
                      <div className="p-3 rounded-xl bg-stone-900 border border-stone-800 text-center text-xs text-amber-300 font-medium">
                        پاسخ شما قفل شده است. منتظر ورود بعدی {partnerName} برای حدس زدن باشید!
                      </div>
                    ) : (
                      <div className="space-y-2">
                        <p className="text-[11px] text-amber-300 font-bold flex items-center gap-1">
                          <Lock className="w-3.5 h-3.5 text-amber-400" />
                          <span>{partnerName} این پاسخ را قفل کرده است! حدس شما چیست؟</span>
                        </p>
                        <div className="flex gap-2">
                          <input
                            type="text"
                            placeholder="حدس شما از پاسخ واقعی..."
                            value={guessInput}
                            onChange={(e) => setGuessInput(e.target.value)}
                            className="flex-1 bg-stone-900 border border-stone-800 rounded-xl px-3 py-2 text-xs text-stone-100 placeholder:text-stone-500 focus:outline-hidden focus:border-rose-500"
                          />
                          <button
                            onClick={() => handleUnlockSecret(s.id)}
                            disabled={!guessInput.trim()}
                            className="px-4 py-2 bg-rose-600 hover:bg-rose-500 disabled:opacity-40 text-white text-xs font-bold rounded-xl flex items-center gap-1 shrink-0"
                          >
                            <Unlock className="w-3.5 h-3.5" />
                            <span>بازگشایی پاکت</span>
                          </button>
                        </div>
                      </div>
                    )
                  ) : (
                    <div className="space-y-2">
                      <div className="p-2.5 rounded-xl bg-emerald-950/60 border border-emerald-800 text-center text-xs font-bold text-emerald-300 flex items-center justify-center gap-1.5">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        <span>پاکت راز بازگشایی شد!</span>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                        <div className="p-3 rounded-xl bg-stone-900 border border-stone-800">
                          <span className="text-[10px] text-stone-400 font-bold block">پاسخ واقعی {s.creator === 'amin' ? 'امین' : 'نیایش'}:</span>
                          <span className="text-xs font-extrabold text-rose-300">{s.secretText}</span>
                        </div>
                        <div className="p-3 rounded-xl bg-stone-900 border border-stone-800">
                          <span className="text-[10px] text-stone-400 font-bold block">حدس ثبت‌شده توسط {s.creator === 'amin' ? 'نیایش' : 'امین'}:</span>
                          <span className="text-xs font-extrabold text-amber-300">{s.guesserChoice}</span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 4: ASYNCHRONOUS DARES & TRUTHS */}
      {activeTab === 'dares' && (
        <div className="space-y-4">
          <div className="bg-stone-950 p-4 rounded-2xl border border-stone-800 space-y-3">
            <h3 className="text-xs font-extrabold text-stone-200 flex items-center gap-2">
              <Flame className="w-4 h-4 text-purple-400" />
              <span>ارسال یک چالش «جرات یا حقیقت» برای ورود بعدی همسر:</span>
            </h3>

            {/* Quick Presets */}
            <div className="space-y-1.5">
              <span className="text-[10px] font-bold text-stone-400">پیشنهادهای آماده:</span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                {PRESET_TRUTHS_DARES.map((p, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleCreateDare(p.prompt, p.type)}
                    className="p-2 rounded-xl bg-stone-900 hover:bg-stone-800 border border-stone-800 text-right text-[11px] font-bold text-stone-200 flex items-center justify-between gap-2"
                  >
                    <span className="truncate">{p.prompt}</span>
                    <span className={`text-[9px] font-extrabold px-1.5 py-0.5 rounded-md ${
                      p.type === 'dare' ? 'bg-rose-950 text-rose-300' : 'bg-purple-950 text-purple-300'
                    }`}>
                      {p.type === 'dare' ? 'جرات' : 'حقیقت'}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Custom Dare Input */}
            <div className="flex gap-2 pt-2 border-t border-stone-800">
              <select
                value={dareType}
                onChange={(e) => setDareType(e.target.value as 'truth' | 'dare')}
                className="bg-stone-900 border border-stone-800 text-xs font-bold rounded-xl px-2.5 text-stone-200 focus:outline-hidden"
              >
                <option value="dare">جرات</option>
                <option value="truth">حقیقت</option>
              </select>
              <input
                type="text"
                placeholder="متن چالش دلخواه..."
                value={customDarePrompt}
                onChange={(e) => setCustomDarePrompt(e.target.value)}
                className="flex-1 bg-stone-900 border border-stone-800 rounded-xl px-3 py-2 text-xs text-stone-100 placeholder:text-stone-500 focus:outline-hidden"
              />
              <button
                onClick={() => handleCreateDare()}
                disabled={!customDarePrompt.trim()}
                className="px-4 py-2 bg-purple-600 hover:bg-purple-500 disabled:opacity-40 text-white text-xs font-bold rounded-xl flex items-center gap-1 shrink-0"
              >
                <Send className="w-3.5 h-3.5" />
                <span>ارسال</span>
              </button>
            </div>
          </div>

          {/* List of Pending/Completed Dares */}
          <div className="space-y-2.5">
            {gameState.dares.map((dare) => {
              const isMine = dare.sender === currentUser;

              return (
                <div key={dare.id} className="p-3.5 rounded-2xl bg-stone-950 border border-stone-800 flex items-center justify-between gap-3">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className={`text-[9px] font-extrabold px-2 py-0.5 rounded-full ${
                        dare.type === 'dare' ? 'bg-rose-950 text-rose-300' : 'bg-purple-950 text-purple-300'
                      }`}>
                        {dare.type === 'dare' ? 'جرات' : 'حقیقت'}
                      </span>
                      <span className="text-[10px] text-stone-400 font-bold">
                        از طرف {dare.sender === 'amin' ? 'امین' : 'نیایش'}
                      </span>
                    </div>
                    <p className="text-xs font-extrabold text-stone-200">{dare.prompt}</p>
                  </div>

                  {dare.status === 'completed' ? (
                    <span className="px-3 py-1 rounded-xl bg-emerald-950 text-emerald-300 text-[11px] font-bold flex items-center gap-1 shrink-0">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                      <span>انجام شد</span>
                    </span>
                  ) : isMine ? (
                    <span className="text-[11px] font-bold text-amber-400 bg-amber-950/60 px-2.5 py-1 rounded-xl border border-amber-800/50 shrink-0">
                      منتظر انجام {partnerName}
                    </span>
                  ) : (
                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        onClick={() => handleCompleteDare(dare.id)}
                        className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-bold flex items-center gap-1"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>انجام دادم</span>
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 5: ASYNCHRONOUS AFFECTION & SIGNALS */}
      {activeTab === 'affection' && (
        <div className="space-y-4 text-center py-1">
          <p className="text-xs text-stone-400 font-medium">
            حس آغوش، بوسه یا فنجان چای مجازی ارسال کنید تا در صندوق ورودی همسرتان ثبت و در زمان ورودش مشاهده شود.
          </p>

          <div className="grid grid-cols-3 gap-2.5">
            <button
              onClick={() => sendAffection('hug')}
              className="bg-stone-950 hover:bg-rose-950/40 p-4 rounded-2xl border border-stone-800 hover:border-rose-800 transition-all flex flex-col items-center justify-center gap-2 active:scale-95 group"
            >
              <div className="w-10 h-10 rounded-2xl bg-rose-500/10 text-rose-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                <HeartHandshake className="w-6 h-6 text-rose-400" />
              </div>
              <span className="text-xs font-bold text-stone-200">آغوش آفلاین</span>
              <span className="text-[10px] font-semibold text-rose-400 bg-rose-950 px-2.5 py-0.5 rounded-full border border-rose-800/40">
                ثبت در صندوق
              </span>
            </button>

            <button
              onClick={() => sendAffection('kiss')}
              className="bg-stone-950 hover:bg-rose-950/40 p-4 rounded-2xl border border-stone-800 hover:border-rose-800 transition-all flex flex-col items-center justify-center gap-2 active:scale-95 group"
            >
              <div className="w-10 h-10 rounded-2xl bg-rose-500/10 text-rose-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                <Heart className="w-6 h-6 text-rose-400 fill-rose-500/20" />
              </div>
              <span className="text-xs font-bold text-stone-200">بوسه از راه دور</span>
              <span className="text-[10px] font-semibold text-rose-400 bg-rose-950 px-2.5 py-0.5 rounded-full border border-rose-800/40">
                ثبت در صندوق
              </span>
            </button>

            <button
              onClick={() => sendAffection('tea')}
              className="bg-stone-950 hover:bg-rose-950/40 p-4 rounded-2xl border border-stone-800 hover:border-rose-800 transition-all flex flex-col items-center justify-center gap-2 active:scale-95 group"
            >
              <div className="w-10 h-10 rounded-2xl bg-amber-500/10 text-amber-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                <Coffee className="w-6 h-6 text-amber-400" />
              </div>
              <span className="text-xs font-bold text-stone-200">چای مجازی</span>
              <span className="text-[10px] font-semibold text-amber-400 bg-amber-950 px-2.5 py-0.5 rounded-full border border-amber-800/40">
                ثبت در صندوق
              </span>
            </button>
          </div>

          {/* Affection Feed Log */}
          <div className="bg-stone-950 p-4 rounded-2xl border border-stone-800 space-y-2 text-right">
            <h4 className="text-xs font-bold text-stone-300 border-b border-stone-800/80 pb-2">
              تاریخچه آخرین ابراز علاقه‌های ثبت‌شده:
            </h4>
            <div className="space-y-1.5 max-h-[180px] overflow-y-auto pr-1">
              {gameState.affectionInbox.map((a) => (
                <div key={a.id} className="p-2.5 rounded-xl bg-stone-900 border border-stone-800/80 flex items-center justify-between text-xs">
                  <span className="font-bold text-stone-200 flex items-center gap-1.5">
                    <Zap className="w-3.5 h-3.5 text-rose-400" />
                    {a.sender === 'amin' ? 'امین' : 'نیایش'} یک {a.type === 'hug' ? 'آغوش گرم' : a.type === 'kiss' ? 'بوسه از راه دور' : 'فنجان چای'} ثبت کرد
                  </span>
                  <span className="text-[10px] font-mono text-stone-400">
                    {new Date(a.createdAt).toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Floating Toast Notification */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed bottom-6 left-1/2 -translate-x-1/2 bg-rose-600 text-white font-bold text-xs px-5 py-2.5 rounded-full shadow-2xl z-50 flex items-center gap-2 border border-rose-400/30"
          >
            <Sparkles className="w-4 h-4 text-amber-300" />
            <span>{toastMessage}</span>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
};

export default LdrGameEngine;
