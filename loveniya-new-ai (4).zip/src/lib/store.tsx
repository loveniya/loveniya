import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { Memory, Pledge, Dream, Music, Capsule, TrashItem, SyncStatus } from './types';

// آدرس پُل اختصاصی شما در کلودفلر
const WORKER_URL = "https://niya.am-b-asdfghjkl20112011.workers.dev";

interface StoreContextType {
  memories: Memory[];
  pledges: Pledge[];
  dreams: Dream[];
  playlist: Music[];
  capsules: Capsule[];
  trashItems: TrashItem[];
  letterContent: string;
  syncStatus: SyncStatus;
  syncError: string | null;
  addMemory: (m: Memory) => void;
  updateMemory: (m: Memory) => void;
  removeMemory: (id: string) => void;
  addPledge: (p: Pledge) => void;
  updatePledge: (p: Pledge) => void;
  removePledge: (id: string) => void;
  addDream: (d: Dream) => void;
  updateDream: (d: Dream) => void;
  removeDream: (id: string) => void;
  addMusic: (m: Music) => void;
  updateMusic: (m: Music) => void;
  removeMusic: (id: string) => void;
  addCapsule: (c: Capsule) => void;
  updateCapsule: (c: Capsule) => void;
  removeCapsule: (id: string) => void;
  setLetterContent: (text: string) => void;
  moveToTrash: (type: TrashItem['type'], item: any) => void;
  emptyTrash: () => void;
  restoreFromTrash: (trashId: string) => void;
  permanentlyDeleteFromTrash: (trashId: string) => void;
}

const StoreContext = createContext<StoreContextType | null>(null);

export const useStore = () => {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error('useStore must be used within StoreProvider');
  return ctx;
};

export const StoreProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const load = <T,>(key: string, def: T): T => {
    try {
      const stored = localStorage.getItem(key);
      return stored ? JSON.parse(stored) : def;
    } catch {
      return def;
    }
  };

  const [memories, setMemoriesState] = useState<Memory[]>(() => load('loveniya_mems', []));
  const [pledges, setPledgesState] = useState<Pledge[]>(() => load('loveniya_plg', []));
  const [dreams, setDreamsState] = useState<Dream[]>(() => load('loveniya_dreams', []));
  const [playlist, setPlaylistState] = useState<Music[]>(() => load('loveniya_msc', []));
  const [capsules, setCapsulesState] = useState<Capsule[]>(() => load('loveniya_capsules', []));
  const [trashItems, setTrashItemsState] = useState<TrashItem[]>(() => load('loveniya_trash', []));
  const [letterContent, setLetterContentState] = useState<string>(() => {
    return localStorage.getItem('loveniya_letter') || '';
  });

  const [syncStatus, setSyncStatus] = useState<SyncStatus>('connected');
  const [syncError, setSyncError] = useState<string | null>(null);

  // نگهداری زمان آخرین تغییر محلی برای هر کلید تا پاسخی از سرور نتواند تغییرات را موقتاً بازگرداند
  const mutatedAtRef = React.useRef<Record<string, number>>({});
  const consecutiveFailuresRef = React.useRef<number>(0);

  // تابع ارسال مستقیم اطلاعات به فایربیس از طریق کلودفلر و ذخیره همزمان در حافظه گوشی
  const safeSet = useCallback(async (path: string, localKey: string, data: any) => {
    mutatedAtRef.current[path] = Date.now();
    try {
      localStorage.setItem(localKey, typeof data === 'string' ? data : JSON.stringify(data));
    } catch (e) {}

    try {
      setSyncStatus('syncing');
      const res = await fetch(`${WORKER_URL}/${path}.json`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });

      if (!res.ok) throw new Error(`خطای HTTP: ${res.status}`);
      
      consecutiveFailuresRef.current = 0;
      setSyncStatus('connected');
      setSyncError(null);
    } catch (err: any) {
      consecutiveFailuresRef.current += 1;
      if (consecutiveFailuresRef.current >= 3) {
        setSyncStatus('disconnected');
        setSyncError(err.message || 'خطا در ارتباط با سرور.');
      } else {
        setSyncStatus('connected');
      }
    }
  }, []);

  // دریافت تمام اطلاعات از دیتابیس بدون نیاز به وب‌سوکت با ادغام هوشمند جهت عدم از دست رفتن داده‌ها
  const fetchAllData = useCallback(async () => {
    const isRecentlyMutated = (key: string) => {
      const lastMutated = mutatedAtRef.current[key] || 0;
      return Date.now() - lastMutated < 8000;
    };

    try {
      const t = Date.now();
      const [mRes, pRes, dRes, msRes, cRes, tRes, lRes] = await Promise.all([
        fetch(`${WORKER_URL}/loveniya_mems.json?_t=${t}`, { cache: 'no-store' }),
        fetch(`${WORKER_URL}/loveniya_plg.json?_t=${t}`, { cache: 'no-store' }),
        fetch(`${WORKER_URL}/loveniya_dreams.json?_t=${t}`, { cache: 'no-store' }),
        fetch(`${WORKER_URL}/loveniya_msc.json?_t=${t}`, { cache: 'no-store' }),
        fetch(`${WORKER_URL}/loveniya_capsules.json?_t=${t}`, { cache: 'no-store' }),
        fetch(`${WORKER_URL}/loveniya_trash.json?_t=${t}`, { cache: 'no-store' }),
        fetch(`${WORKER_URL}/loveniya_letter.json?_t=${t}`, { cache: 'no-store' }),
      ]);

      if (mRes.ok && !isRecentlyMutated('loveniya_mems')) {
        const data = await mRes.json();
        const arr = data ? (Array.isArray(data) ? data : Object.values(data)) : [];
        setMemoriesState(arr as Memory[]);
        try { localStorage.setItem('loveniya_mems', JSON.stringify(arr)); } catch(e) {}
      }

      if (pRes.ok && !isRecentlyMutated('loveniya_plg')) {
        const data = await pRes.json();
        const arr = data ? (Array.isArray(data) ? data : Object.values(data)) : [];
        setPledgesState(arr as Pledge[]);
        try { localStorage.setItem('loveniya_plg', JSON.stringify(arr)); } catch(e) {}
      }

      if (dRes.ok && !isRecentlyMutated('loveniya_dreams')) {
        const data = await dRes.json();
        const arr = data ? (Array.isArray(data) ? data : Object.values(data)) : [];
        setDreamsState(arr as Dream[]);
        try { localStorage.setItem('loveniya_dreams', JSON.stringify(arr)); } catch(e) {}
      }

      if (msRes.ok && !isRecentlyMutated('loveniya_msc')) {
        const data = await msRes.json();
        const arr = data ? (Array.isArray(data) ? data : Object.values(data)) : [];
        setPlaylistState(arr as Music[]);
        try { localStorage.setItem('loveniya_msc', JSON.stringify(arr)); } catch(e) {}
      }

      if (cRes.ok && !isRecentlyMutated('loveniya_capsules')) {
        const data = await cRes.json();
        const arr = data ? (Array.isArray(data) ? data : Object.values(data)) : [];
        setCapsulesState(arr as Capsule[]);
        try { localStorage.setItem('loveniya_capsules', JSON.stringify(arr)); } catch(e) {}
      }

      if (tRes.ok && !isRecentlyMutated('loveniya_trash')) {
        const data = await tRes.json();
        let arr = data ? (Array.isArray(data) ? data : Object.values(data)) : [];
        arr = arr.filter((x: any) => x && x.trashId);
        setTrashItemsState(arr as TrashItem[]);
        try { localStorage.setItem('loveniya_trash', JSON.stringify(arr)); } catch(e) {}
      }

      if (lRes.ok && !isRecentlyMutated('loveniya_letter')) {
        const data = await lRes.json();
        const text = (typeof data === 'string' && data.trim().length > 0) ? data : '';
        setLetterContentState(text);
        try { localStorage.setItem('loveniya_letter', text); } catch(e) {}
      }

      consecutiveFailuresRef.current = 0;
      setSyncStatus('connected');
      setSyncError(null);
    } catch (err: any) {
      consecutiveFailuresRef.current += 1;
      if (consecutiveFailuresRef.current >= 3) {
        setSyncStatus('disconnected');
      }
    }
  }, []);

  useEffect(() => {
    fetchAllData();
    // همگام‌سازی بی‌سروصدا هر ۵ ثانیه
    const interval = setInterval(fetchAllData, 5000);
    return () => clearInterval(interval);
  }, [fetchAllData]);

  const setMemories = (v: Memory[]) => {
    setMemoriesState(v);
    safeSet('loveniya_mems', 'loveniya_mems', v);
  };

  const setPledges = (v: Pledge[]) => {
    setPledgesState(v);
    safeSet('loveniya_plg', 'loveniya_plg', v);
  };

  const setDreams = (v: Dream[]) => {
    setDreamsState(v);
    safeSet('loveniya_dreams', 'loveniya_dreams', v);
  };

  const setPlaylist = (v: Music[]) => {
    setPlaylistState(v);
    safeSet('loveniya_msc', 'loveniya_msc', v);
  };

  const setCapsules = (v: Capsule[]) => {
    setCapsulesState(v);
    safeSet('loveniya_capsules', 'loveniya_capsules', v);
  };

  const setTrashItems = (v: TrashItem[]) => {
    setTrashItemsState(v);
    safeSet('loveniya_trash', 'loveniya_trash', v);
  };

  const handleSetLetterContent = (text: string) => {
    setLetterContentState(text);
    safeSet('loveniya_letter', 'loveniya_letter', text);
  };

  const moveToTrash = (type: TrashItem['type'], item: any) => {
    const trashObj: TrashItem = {
      trashId: 'trash_' + Date.now(),
      type,
      deletedAt: new Date().toLocaleDateString('fa-IR'),
      itemPayload: item
    };
    setTrashItems([trashObj, ...trashItems]);
  };

  const restoreFromTrash = (trashId: string) => {
    const item = trashItems.find(t => t.trashId === trashId);
    if (!item) return;
    
    if (item.type === 'memory') setMemories([...memories, item.itemPayload]);
    if (item.type === 'pledge') setPledges([...pledges, item.itemPayload]);
    if (item.type === 'dream') setDreams([...dreams, item.itemPayload]);
    if (item.type === 'music') setPlaylist([...playlist, item.itemPayload]);
    if (item.type === 'capsule') setCapsules([...capsules, item.itemPayload]);
    
    setTrashItems(trashItems.filter(t => t.trashId !== trashId));
  };

  const permanentlyDeleteFromTrash = (trashId: string) => {
    setTrashItems(trashItems.filter(t => t.trashId !== trashId));
  };

  const emptyTrash = () => setTrashItems([]);

  const addMemory = (m: Memory) => setMemories([m, ...memories]);
  const updateMemory = (m: Memory) => setMemories(memories.map(x => x.id === m.id ? m : x));
  const removeMemory = (id: string) => {
    const item = memories.find(x => x.id === id);
    if (item) moveToTrash('memory', item);
    setMemories(memories.filter(x => x.id !== id));
  };

  const addPledge = (p: Pledge) => setPledges([p, ...pledges]);
  const updatePledge = (p: Pledge) => setPledges(pledges.map(x => x.id === p.id ? p : x));
  const removePledge = (id: string) => {
    const item = pledges.find(x => x.id === id);
    if (item) moveToTrash('pledge', item);
    setPledges(pledges.filter(x => x.id !== id));
  };

  const addDream = (d: Dream) => setDreams([d, ...dreams]);
  const updateDream = (d: Dream) => setDreams(dreams.map(x => x.id === d.id ? d : x));
  const removeDream = (id: string) => {
    const item = dreams.find(x => x.id === id);
    if (item) moveToTrash('dream', item);
    setDreams(dreams.filter(x => x.id !== id));
  };

  const addMusic = (m: Music) => setPlaylist([m, ...playlist]);
  const updateMusic = (m: Music) => setPlaylist(playlist.map(x => x.id === m.id ? m : x));
  const removeMusic = (id: string) => {
    const item = playlist.find(x => x.id === id);
    if (item) moveToTrash('music', item);
    setPlaylist(playlist.filter(x => x.id !== id));
  };

  const addCapsule = (c: Capsule) => setCapsules([c, ...capsules]);
  const updateCapsule = (c: Capsule) => setCapsules(capsules.map(x => x.id === c.id ? c : x));
  const removeCapsule = (id: string) => {
    const item = capsules.find(x => x.id === id);
    if (item) moveToTrash('capsule', item);
    setCapsules(capsules.filter(x => x.id !== id));
  };

  return (
    <StoreContext.Provider value={{
      memories, pledges, dreams, playlist, capsules, trashItems, letterContent,
      syncStatus, syncError,
      addMemory, updateMemory, removeMemory,
      addPledge, updatePledge, removePledge,
      addDream, updateDream, removeDream,
      addMusic, updateMusic, removeMusic,
      addCapsule, updateCapsule, removeCapsule,
      setLetterContent: handleSetLetterContent,
      moveToTrash, emptyTrash, restoreFromTrash, permanentlyDeleteFromTrash
    }}>
      {children}
    </StoreContext.Provider>
  );
};