// @ts-nocheck
import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";

dotenv.config();

const CLOUDFLARE_AI_WORKER_URL = "https://purple-cloud-1df2.am-b-asdfghjkl20112011.workers.dev";

async function fetchWithRetry(url: string, options: RequestInit, retries = 3, backoff = 1000): Promise<Response> {
  let lastRes: Response | null = null;
  for (let i = 0; i < retries; i++) {
    try {
      const res = await fetch(url, options);
      if (res.ok) return res;
      lastRes = res;
    } catch (err) {
      // network error
    }
    if (i < retries - 1) {
      await new Promise(resolve => setTimeout(resolve, backoff * Math.pow(2, i)));
    }
  }
  if (lastRes) return lastRes;
  throw new Error(`Failed to fetch after ${retries} retries`);
}

function extractAIResponse(data: any): string | null {
  if (!data) return null;
  if (typeof data === 'string') {
    const trimmed = data.trim();
    if (trimmed === 'SKIP') return 'SKIP';
    return trimmed.length > 0 ? trimmed : 'SKIP'; // return SKIP for empty
  }
  if (typeof data.response === 'string') {
    if (data.response.trim() === 'SKIP') return 'SKIP';
    return data.response.trim() || 'SKIP';
  }
  if (data.result !== undefined) {
    if (typeof data.result === 'string') {
      if (data.result.trim() === 'SKIP') return 'SKIP';
      return data.result.trim() || 'SKIP';
    }
    if (typeof data.result.response === 'string') {
      if (data.result.response.trim() === 'SKIP') return 'SKIP';
      return data.result.response.trim() || 'SKIP';
    }
    if (typeof data.result.text === 'string') {
      if (data.result.text.trim() === 'SKIP') return 'SKIP';
      return data.result.text.trim() || 'SKIP';
    }
    if (typeof data.result.reply === 'string') {
      if (data.result.reply.trim() === 'SKIP') return 'SKIP';
      return data.result.reply.trim() || 'SKIP';
    }
  }
  if (typeof data.reply === 'string') {
    if (data.reply.trim() === 'SKIP') return 'SKIP';
    return data.reply.trim() || 'SKIP';
  }
  if (typeof data.text === 'string') {
    if (data.text.trim() === 'SKIP') return 'SKIP';
    return data.text.trim() || 'SKIP';
  }
  if (typeof data.message === 'string') {
    if (data.message.trim() === 'SKIP') return 'SKIP';
    return data.message.trim() || 'SKIP';
  }
  if (Array.isArray(data.choices) && data.choices[0]?.message?.content) {
    const content = String(data.choices[0].message.content).trim();
    if (content === 'SKIP') return 'SKIP';
    return content;
  }
  return null;
}

async function startServer() {
  const app = express();
  const PORT = process.env.PORT || 3000;

  app.use(express.json());

  // Direct Cloudflare AI Worker Gateway
  async function callCloudflareAI(payload: any) {
    try {
      const response = await fetchWithRetry(CLOUDFLARE_AI_WORKER_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      }, 3, 1000);

      if (response.ok) {
        const text = await response.text();
        try {
          const parsed = JSON.parse(text);
          const res = extractAIResponse(parsed);
          if (res !== null) return res;
          throw new Error(`پاسخ خالی یا نامعتبر: ${text.substring(0, 100)}`);
        } catch (e: any) {
          if (e.message.startsWith('پاسخ خالی')) throw e;
          const res = extractAIResponse(text);
          if (res !== null) return res;
          throw new Error(`متن نامشخص: ${text.substring(0, 100)}`);
        }
      } else {
        const errText = await response.text();
        try {
          const errJson = JSON.parse(errText);
          if (errJson.message) throw new Error(errJson.message);
          if (errJson.error) throw new Error(errJson.error);
        } catch (e: any) {
          if (e.message && e.message !== 'Unexpected end of JSON input') throw e;
          throw new Error(`خطای ${response.status} در ارتباط با هوش مصنوعی (Proxy): ${errText.substring(0, 100)}`);
        }
      }
    } catch (cfError: any) {
      throw cfError;
    }

    throw new Error('عدم دریافت پاسخ معتبر از سرور');
  }

  // API Routes
  app.post("/api/chat", async (req, res) => {
    try {
      const { message, currentUser, history } = req.body;
      const historyContext = Array.isArray(history) && history.length > 0
        ? history.slice(-8).map((m: any) => `${m.senderId === 'amin' ? 'امین' : 'نیایش'}: ${m.text}`).join('\n')
        : `${currentUser === 'amin' ? 'امین' : 'نیایش'}: ${message}`;

      const reply = await callCloudflareAI({
        type: "chat",
        userMessage: message || "سلام",
        contextData: { pledges: [], wishes: [] },
        history: historyContext
      });
      res.json({ reply });
    } catch (error: any) {
      console.error("Chat route error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/loveai", async (req, res) => {
    try {
      const aiResult = await callCloudflareAI(req.body);
      res.json({ result: aiResult });
    } catch (error: any) {
      console.error("LoveAI Error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
