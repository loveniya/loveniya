export type Memory = {
  id: string;
  title: string;
  desc: string;
  vidUrl?: string;
  mediaData?: string;
  photos?: string[]; // Multiple photos support
  isVideoFile?: boolean;
  date: string;
  pinned?: boolean; // We will use this for "Pin as Top/Best"
  synced?: boolean;
  storyId?: string;    // اگر این خاطره حلقه‌ای از یک زنجیره خاطرات باشه
  storyTitle?: string; // عنوان مشترک زنجیره (روی همه‌ی حلقه‌های زنجیره یکسانه)
};

export type SyncStatus = 'connected' | 'disconnected' | 'error' | 'syncing';


export type Pledge = {
  id: string;
  text: string;
  date: string;
  pinned?: boolean;
  synced?: boolean;
  author?: string; // 'amin' | 'niyayesh' or display name
};

export type Dream = {
  id: string;
  text: string;
  date: string;
  pinned?: boolean;
  synced?: boolean;
};

export type Music = {
  id: string;
  title: string;
  artist: string;
  url: string;
  pinned?: boolean;
  synced?: boolean;
};

export type Capsule = {
  id: string;
  title: string;
  text: string;
  openDate: string; // ISO string or Persian date
  isOpened?: boolean;
  pinned?: boolean;
  synced?: boolean;
  sender?: string;
  recipient?: string;
  createdAt?: number;
};

export type SenderId = 'amin' | 'niyayesh' | 'loveniya_ai';

export type ChatMessage = {
  id: string; // unique immutable id (msg_<timestamp>_<random>)
  senderId: SenderId;
  senderName: string;
  sender: 'Amin' | 'Niyaish' | 'Loveniya AI';
  role?: 'user' | 'ai';
  text: string;
  content: string; // compatibility with UI content field
  timestamp: number;
  reactions?: Record<string, string>; // e.g. { "amin": "❤️", "niyayesh": "😂" }
  aiMetadata?: {
    emotion?: string;
    actionTrigger?: string;
  };
  replyTo?: {
    id: string;
    sender: string;
    text: string;
  };
};

export type TrashItem = {
  trashId: string;
  type: 'memory' | 'pledge' | 'dream' | 'music' | 'capsule';
  deletedAt: string;
  itemPayload: any;
};
