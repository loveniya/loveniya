/**
 * Safely deduplicates an array of items by their unique `id`.
 * Keeps the LAST occurrence of an item with the same ID, ensuring that newer edits 
 * (which might be appended or stored in string keys by Firebase) overwrite older ones.
 * Preserves the original order of the first occurrence.
 */
export function dedupById<T extends { id?: string | number }>(items: T[] | null | undefined): T[] {
  if (!items || !Array.isArray(items)) return [];
  const map = new Map<string | number, T>();
  const noIdItems: T[] = [];
  for (const item of items) {
    if (!item) continue;
    const id = item.id;
    if (id !== undefined && id !== null && id !== '') {
      map.set(id, item);
    } else {
      noIdItems.push(item);
    }
  }
  return [...Array.from(map.values()), ...noIdItems];
}
