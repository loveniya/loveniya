/**
 * Jalali (Solar Hijri / شمسی) Date Conversion & Formatting Utilities
 * Standard astronomical algorithms supporting years 1300 to 1500+
 */

export const JALALI_MONTH_NAMES = [
  'فروردین',
  'اردیبهشت',
  'خرداد',
  'تیر',
  'مرداد',
  'شهریور',
  'مهر',
  'آبان',
  'آذر',
  'دی',
  'بهمن',
  'اسفند'
];

/**
 * Converts Gregorian date to Jalali
 */
export function gregorianToJalali(gy: number, gm: number, gd: number): { jy: number; jm: number; jd: number } {
  const g_d_m = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
  let gy2 = (gm > 2) ? (gy + 1) : gy;
  let days = 355666 + (365 * gy) + Math.floor((gy2 + 3) / 4) - Math.floor((gy2 + 99) / 100) + Math.floor((gy2 + 399) / 400) + gd + g_d_m[gm - 1];
  let jy = -1595 + (33 * Math.floor(days / 12053));
  days %= 12053;
  jy += 4 * Math.floor(days / 1461);
  days %= 1461;
  if (days > 365) {
    jy += Math.floor((days - 1) / 365);
    days = (days - 1) % 365;
  }
  let jm: number;
  let jd: number;
  if (days < 186) {
    jm = 1 + Math.floor(days / 31);
    jd = 1 + (days % 31);
  } else {
    jm = 7 + Math.floor((days - 186) / 30);
    jd = 1 + ((days - 186) % 30);
  }
  return { jy, jm, jd };
}

/**
 * Converts Jalali date to Gregorian
 */
export function jalaliToGregorian(jy: number, jm: number, jd: number): { gy: number; gm: number; gd: number } {
  let jy_norm = jy + 1595;
  let days = -355668 + (365 * jy_norm) + (Math.floor(jy_norm / 33) * 8) + Math.floor(((jy_norm % 33) + 3) / 4) + jd + ((jm < 7) ? ((jm - 1) * 31) : (((jm - 7) * 30) + 186));
  let gy = 400 * Math.floor(days / 146097);
  days %= 146097;
  if (days > 36524) {
    gy += 100 * Math.floor(--days / 36524);
    days %= 36524;
    if (days >= 365) days++;
  }
  gy += 4 * Math.floor(days / 1461);
  days %= 1461;
  if (days > 365) {
    gy += Math.floor((days - 1) / 365);
    days = (days - 1) % 365;
  }
  let gd = days + 1;
  const sal_a = [0, 31, ((gy % 4 === 0 && gy % 100 !== 0) || (gy % 400 === 0)) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  let gm: number;
  for (gm = 0; gm < 13 && gd > sal_a[gm]; gm++) gd -= sal_a[gm];
  return { gy, gm, gd };
}

/**
 * Gets the current Tehran Jalali date and time parts
 */
export function getTehranJalaliNow(): { jy: number; jm: number; jd: number; hour: number; minute: number } {
  const d = new Date();
  // Format in Tehran time
  const tehranParts = new Intl.DateTimeFormat('en-US', {
    timeZone: 'Asia/Tehran',
    year: 'numeric',
    month: 'numeric',
    day: 'numeric',
    hour: 'numeric',
    minute: 'numeric',
    hour12: false
  }).formatToParts(d);

  const gYear = parseInt(tehranParts.find(p => p.type === 'year')?.value || '2026', 10);
  const gMonth = parseInt(tehranParts.find(p => p.type === 'month')?.value || '1', 10);
  const gDay = parseInt(tehranParts.find(p => p.type === 'day')?.value || '1', 10);
  const hour = parseInt(tehranParts.find(p => p.type === 'hour')?.value || '12', 10);
  const minute = parseInt(tehranParts.find(p => p.type === 'minute')?.value || '0', 10);

  const { jy, jm, jd } = gregorianToJalali(gYear, gMonth, gDay);
  return { jy, jm, jd, hour, minute };
}

/**
 * Parses an ISO date or timestamp into Jalali date parts
 */
export function parseDateToJalali(dateInput: string | number | Date): { jy: number; jm: number; jd: number; hour: number; minute: number } {
  const d = new Date(dateInput);
  if (isNaN(d.getTime())) {
    return getTehranJalaliNow();
  }

  const tehranParts = new Intl.DateTimeFormat('en-US', {
    timeZone: 'Asia/Tehran',
    year: 'numeric',
    month: 'numeric',
    day: 'numeric',
    hour: 'numeric',
    minute: 'numeric',
    hour12: false
  }).formatToParts(d);

  const gYear = parseInt(tehranParts.find(p => p.type === 'year')?.value || '2026', 10);
  const gMonth = parseInt(tehranParts.find(p => p.type === 'month')?.value || '1', 10);
  const gDay = parseInt(tehranParts.find(p => p.type === 'day')?.value || '1', 10);
  const hour = parseInt(tehranParts.find(p => p.type === 'hour')?.value || '12', 10);
  const minute = parseInt(tehranParts.find(p => p.type === 'minute')?.value || '0', 10);

  const { jy, jm, jd } = gregorianToJalali(gYear, gMonth, gDay);
  return { jy, jm, jd, hour, minute };
}

/**
 * Builds an ISO string from Jalali date parts (in Tehran time zone: +03:30)
 */
export function jalaliToIso(jy: number, jm: number, jd: number, hour: number = 12, minute: number = 0): string {
  const { gy, gm, gd } = jalaliToGregorian(jy, jm, jd);
  const pad = (n: number) => String(n).padStart(2, '0');
  // Representing in Tehran time (+03:30)
  // Converting to Date object
  const dateStr = `${gy}-${pad(gm)}-${pad(gd)}T${pad(hour)}:${pad(minute)}:00+03:30`;
  const dateObj = new Date(dateStr);
  return isNaN(dateObj.getTime()) ? new Date().toISOString() : dateObj.toISOString();
}

/**
 * Formats a date into a beautiful Persian readable string
 * e.g. "۱۵ اردیبهشت ۱۴۰۴ ساعت ۲۰:۳۰"
 */
export function formatJalaliReadable(dateInput: string | number | Date): string {
  const d = new Date(dateInput);
  if (isNaN(d.getTime())) return '';

  const { jy, jm, jd, hour, minute } = parseDateToJalali(d);
  const monthName = JALALI_MONTH_NAMES[jm - 1] || '';
  const pad = (n: number) => String(n).padStart(2, '0');

  const toPersianDigits = (str: string | number) => {
    const pDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    return String(str).replace(/[0-9]/g, (w) => pDigits[+w]);
  };

  return `${toPersianDigits(jd)} ${monthName} ${toPersianDigits(jy)} ساعت ${toPersianDigits(pad(hour))}:${toPersianDigits(pad(minute))}`;
}
