import { fetchLoveAI } from './ai';

// این ماژول محتوای بازی‌ها (سوال تله‌پاتی، چالش/حقیقت بطری) رو با هوش مصنوعی
// می‌سازه، چون امین و نیایش وقت کافی برای نوشتن دستی سوال و چالش ندارن.
// هر تابع در صورت خطا یا پاسخ نامعتبر از AI، به‌صورت کاملاً بی‌صدا (بدون نمایش
// خطا به کاربر) یک مقدار پیش‌فرض داخلی برمی‌گردونه تا بازی هیچ‌وقت خراب نشه.

export interface AiTelepathyQuestion {
  q: string;
  a: string;
  b: string;
}

const FALLBACK_TELEPATHY: AiTelepathyQuestion[] = [
  { q: 'برای شب‌های خستگی کدوم رو ترجیح میدی؟', a: 'ویس‌کال شبانه تا وقتی خوابمون ببره 🌙', b: 'تماشای همزمان فیلم با واچ‌پارتی 🎬' },
  { q: 'نوع پیام دلخواهت در طول روزهای پرمشغله؟', a: 'ویس‌های کوتاه ۲۰ ثانیه‌ای یهویی 🎙️', b: 'متن‌های پر از قربون‌صدقه در چت 💌' },
  { q: 'اولین کار در اولین دیدار حضوری آینده؟', a: 'یک بغل محکم و طولانی بدون هیچ حرفی 🫂', b: 'رفتن به یک کافه دنج و دست همو گرفتن ☕' },
];

const FALLBACK_TRUTH = [
  'قشنگ‌ترین جمله‌ای که تاحالا بهت گفتم و هنوز توی ذهنت مونده چیه؟',
  'اولین باری که حس کردی واقعاً دوستم داری کی و کجا بود؟',
];

const FALLBACK_DARE = [
  'همین الان یک ویس ۱۵ ثانیه‌ای با قشنگ‌ترین قربون‌صدقه‌ای که بلدی بفرست!',
  'یک سلفی یهویی از وضعیت همین لحظه‌ات رو بفرست 📸',
];

function pickRandom<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

/** یک سوال دوراهی («این یا اون») تازه با هوش مصنوعی می‌سازه. */
export async function generateTelepathyQuestion(): Promise<AiTelepathyQuestion> {
  try {
    const raw = await fetchLoveAI({
      type: 'chat',
      userMessage:
        'یک سوال دوراهی («این یا اون») کوتاه، رمانتیک، خلاقانه و تازه برای یک زوج ' +
        'در رابطه‌ی مسافتی (LDR) بساز که هیچ ربطی به سوالات تکراری قبلی نداشته باشه. ' +
        'دقیقاً و فقط با همین فرمت جواب بده، بدون هیچ توضیح یا مقدمه‌ی اضافه، جدا شده با کاراکتر |:\n' +
        'متن سوال | متن گزینه اول با یک ایموجی مرتبط در پایان | متن گزینه دوم با یک ایموجی مرتبط در پایان'
    });

    if (raw && raw !== 'SKIP') {
      const parts = raw.split('|').map(s => s.trim()).filter(Boolean);
      if (parts.length >= 3 && parts[0] && parts[1] && parts[2]) {
        return { q: parts[0], a: parts[1], b: parts[2] };
      }
    }
  } catch {
    // نادیده گرفتن خطا؛ از fallback استفاده می‌شه
  }
  return pickRandom(FALLBACK_TELEPATHY);
}

/** یک متن «حقیقت» یا «شجاعت» تازه با هوش مصنوعی می‌سازه. */
export async function generateTruthOrDare(kind: 'truth' | 'dare'): Promise<string> {
  try {
    const prompt = kind === 'truth'
      ? 'یک سوال «حقیقت» صمیمی، عاشقانه، کوتاه و تازه برای یک زوج در رابطه مسافتی (LDR) بساز. ' +
        'فقط خودِ سوال رو در یک جمله بنویس، بدون مقدمه، بدون شماره، بدون گیومه.'
      : 'یک چالش «شجاعت» کوتاه، تازه، عاشقانه و قابل انجام از راه دور (نه حضوری) برای یک زوج در رابطه مسافتی (LDR) بساز. ' +
        'فقط خودِ چالش رو در یک جمله بنویس، بدون مقدمه، بدون شماره، بدون گیومه.';

    const raw = await fetchLoveAI({ type: 'chat', userMessage: prompt });
    if (raw && raw !== 'SKIP' && raw.trim().length > 0) {
      return raw.trim().replace(/^["«]|["»]$/g, '');
    }
  } catch {
    // نادیده گرفتن خطا؛ از fallback استفاده می‌شه
  }
  return pickRandom(kind === 'truth' ? FALLBACK_TRUTH : FALLBACK_DARE);
}
