import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { Memory, Pledge, Dream, Music, Capsule, TrashItem, SyncStatus } from './types';

// آدرس پُل اختصاصی شما در کلودفلر
const WORKER_URL = "https://niya.am-b-asdfghjkl20112011.workers.dev";

interface StoreContextType {
  memories: Memory[];
  pledges: Pledge[];
  dreams: Dream[];
  playlist: Music[];
  capsules: Capsule[];
  trashItems: TrashItem[];
  letterContent: string;
  syncStatus: SyncStatus;
  syncError: string | null;
  addMemory: (m: Memory) => void;
  updateMemory: (m: Memory) => void;
  removeMemory: (id: string) => void;
  addPledge: (p: Pledge) => void;
  updatePledge: (p: Pledge) => void;
  removePledge: (id: string) => void;
  addDream: (d: Dream) => void;
  updateDream: (d: Dream) => void;
  removeDream: (id: string) => void;
  addMusic: (m: Music) => void;
  updateMusic: (m: Music) => void;
  removeMusic: (id: string) => void;
  addCapsule: (c: Capsule) => void;
  updateCapsule: (c: Capsule) => void;
  removeCapsule: (id: string) => void;
  setLetterContent: (text: string) => void;
  moveToTrash: (type: TrashItem['type'], item: any) => void;
  emptyTrash: () => void;
  restoreFromTrash: (trashId: string) => void;
  permanentlyDeleteFromTrash: (trashId: string) => void;
}

const StoreContext = createContext<StoreContextType | null>(null);

export const useStore = () => {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error('useStore must be used within StoreProvider');
  return ctx;
};

export const StoreProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const load = <T,>(key: string, def: T): T => {
    try {
      const stored = localStorage.getItem(key);
      return stored ? JSON.parse(stored) : def;
    } catch {
      return def;
    }
  };

  const [memories, setMemoriesState] = useState<Memory[]>(() => load('loveniya_mems', []));
  const [pledges, setPledgesState] = useState<Pledge[]>(() => load('loveniya_plg', []));
  const [dreams, setDreamsState] = useState<Dream[]>(() => load('loveniya_dreams', []));
  const [playlist, setPlaylistState] = useState<Music[]>(() => load('loveniya_msc', []));
  const [capsules, setCapsulesState] = useState<Capsule[]>(() => load('loveniya_capsules', []));
  const [trashItems, setTrashItemsState] = useState<TrashItem[]>(() => load('loveniya_trash', []));
  const [letterContent, setLetterContentState] = useState<string>(() => {
    return localStorage.getItem('loveniya_letter') || '';
  });

  const [syncStatus, setSyncStatus] = useState<SyncStatus>('connected');
  const [syncError, setSyncError] = useState<string | null>(null);

  // نگهداری زمان آخرین تغییر محلی برای هر کلید تا پاسخی از سرور نتواند تغییرات را موقتاً بازگرداند
  const mutatedAtRef = React.useRef<Record<string, number>>({});
  const consecutiveFailuresRef = React.useRef<number>(0);

  // تابع ارسال مستقیم اطلاعات به فایربیس از طریق کلودفلر و ذخیره همزمان در حافظه گوشی
  const safeSet = useCallback(async (path: string, localKey: string, data: any, itemId?: string, itemData?: any) => {
    mutatedAtRef.current[path] = Date.now();
    try {
      localStorage.setItem(localKey, typeof data === 'string' ? data : JSON.stringify(data));
    } catch (e) {}

    try {
      setSyncStatus('syncing');
      
      let targetUrl = `${WORKER_URL}/${path}.json`;
      let method = 'PUT';
      let bodyData = data;
      
      if (itemId !== undefined) {
        targetUrl = `${WORKER_URL}/${path}/${itemId}.json`;
        if (itemData === null) {
          method = 'DELETE';
          bodyData = undefined;
        } else {
          method = 'PUT';
          bodyData = itemData;
        }
      } else if (Array.isArray(data) && data.length > 0) {
        // Fallback for full sync, convert to object
        bodyData = {};
        data.forEach(item => {
          if (item.id) bodyData[item.id] = item;
          else if (item.trashId) bodyData[item.trashId] = item;
        });
      } else if (Array.isArray(data) && data.length === 0) {
        bodyData = {};
      }

      const res = await fetch(targetUrl, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: bodyData === undefined ? undefined : JSON.stringify(bodyData),
      });

      if (res.status === 401) {
        throw new Error('عدم دسترسی به دیتابیس (احتمالاً قوانین امنیتی فایربیس منقضی شده است)');
      }
      if (!res.ok) throw new Error(`خطای HTTP: ${res.status}`);
      
      consecutiveFailuresRef.current = 0;
      setSyncStatus('connected');
      setSyncError(null);
    } catch (err: any) {
      consecutiveFailuresRef.current += 1;
      if (consecutiveFailuresRef.current >= 3 || err.message.includes('عدم دسترسی')) {
        setSyncStatus('error');
        setSyncError(err.message || 'خطا در ارتباط با سرور.');
      } else {
        setSyncStatus('connected');
      }
    }
  }, []);

  // دریافت تمام اطلاعات از دیتابیس بدون نیاز به وب‌سوکت با ادغام هوشمند جهت عدم از دست رفتن داده‌ها
  const fetchAllData = useCallback(async () => {
    const isRecentlyMutated = (key: string) => {
      const lastMutated = mutatedAtRef.current[key] || 0;
      return Date.now() - lastMutated < 8000;
    };

    try {
      const t = Date.now();
      const [mRes, pRes, dRes, msRes, cRes, tRes, lRes] = await Promise.all([
        fetch(`${WORKER_URL}/loveniya_mems.json?_t=${t}`, { cache: 'no-store' }),
        fetch(`${WORKER_URL}/loveniya_plg.json?_t=${t}`, { cache: 'no-store' }),
        fetch(`${WORKER_URL}/loveniya_dreams.json?_t=${t}`, { cache: 'no-store' }),
        fetch(`${WORKER_URL}/loveniya_msc.json?_t=${t}`, { cache: 'no-store' }),
        fetch(`${WORKER_URL}/loveniya_capsules.json?_t=${t}`, { cache: 'no-store' }),
        fetch(`${WORKER_URL}/loveniya_trash.json?_t=${t}`, { cache: 'no-store' }),
        fetch(`${WORKER_URL}/loveniya_letter.json?_t=${t}`, { cache: 'no-store' }),
      ]);

      const any401 = [mRes, pRes, dRes, msRes, cRes, tRes, lRes].some(r => r.status === 401);
      if (any401) {
        throw new Error('عدم دسترسی به دیتابیس (قوانین ۳۰ روزه فایربیس شما منقضی شده است. لطفا از کنسول فایربیس آن را روی true تنظیم کنید)');
      }

      if (mRes.ok && !isRecentlyMutated('loveniya_mems')) {
        const data = await mRes.json();
        const arr = data ? (Array.isArray(data) ? data : Object.values(data)) : [];
        setMemoriesState(arr as Memory[]);
        try { localStorage.setItem('loveniya_mems', JSON.stringify(arr)); } catch(e) {}
      }

      if (pRes.ok && !isRecentlyMutated('loveniya_plg')) {
        const data = await pRes.json();
        const arr = data ? (Array.isArray(data) ? data : Object.values(data)) : [];
        setPledgesState(arr as Pledge[]);
        try { localStorage.setItem('loveniya_plg', JSON.stringify(arr)); } catch(e) {}
      }

      if (dRes.ok && !isRecentlyMutated('loveniya_dreams')) {
        const data = await dRes.json();
        const arr = data ? (Array.isArray(data) ? data : Object.values(data)) : [];
        setDreamsState(arr as Dream[]);
        try { localStorage.setItem('loveniya_dreams', JSON.stringify(arr)); } catch(e) {}
      }

      if (msRes.ok && !isRecentlyMutated('loveniya_msc')) {
        const data = await msRes.json();
        const arr = data ? (Array.isArray(data) ? data : Object.values(data)) : [];
        setPlaylistState(arr as Music[]);
        try { localStorage.setItem('loveniya_msc', JSON.stringify(arr)); } catch(e) {}
      }

      if (cRes.ok && !isRecentlyMutated('loveniya_capsules')) {
        const data = await cRes.json();
        const arr = data ? (Array.isArray(data) ? data : Object.values(data)) : [];
        setCapsulesState(arr as Capsule[]);
        try { localStorage.setItem('loveniya_capsules', JSON.stringify(arr)); } catch(e) {}
      }

      if (tRes.ok && !isRecentlyMutated('loveniya_trash')) {
        const data = await tRes.json();
        let arr = data ? (Array.isArray(data) ? data : Object.values(data)) : [];
        arr = arr.filter((x: any) => x && x.trashId);
        setTrashItemsState(arr as TrashItem[]);
        try { localStorage.setItem('loveniya_trash', JSON.stringify(arr)); } catch(e) {}
      }

      if (lRes.ok && !isRecentlyMutated('loveniya_letter')) {
        const data = await lRes.json();
        const text = (typeof data === 'string' && data.trim().length > 0) ? data : '';
        setLetterContentState(text);
        try { localStorage.setItem('loveniya_letter', text); } catch(e) {}
      }

      consecutiveFailuresRef.current = 0;
      setSyncStatus('connected');
      setSyncError(null);
    } catch (err: any) {
      consecutiveFailuresRef.current += 1;
      if (consecutiveFailuresRef.current >= 3 || err.message.includes('عدم دسترسی')) {
        setSyncStatus('error');
        setSyncError(err.message || 'خطا در ارتباط با سرور.');
      }
    }
  }, []);

  useEffect(() => {
    fetchAllData();

    // Silent background sync — every 5s normally, but backs off to every 20s
    // after repeated failures, and pauses entirely while the tab is hidden
    // (avoids draining battery/data and avoids a jarring resync the instant
    // the tab regains focus).
    let cancelled = false;
    let timeoutId: ReturnType<typeof setTimeout>;

    const scheduleNext = () => {
      const delay = consecutiveFailuresRef.current >= 3 ? 20000 : 5000;
      timeoutId = setTimeout(async () => {
        if (cancelled) return;
        if (typeof document === 'undefined' || document.visibilityState === 'visible') {
          await fetchAllData();
        }
        scheduleNext();
      }, delay);
    };
    scheduleNext();

    return () => {
      cancelled = true;
      clearTimeout(timeoutId);
    };
  }, [fetchAllData]);

  const setMemories = (v: Memory[] | ((prev: Memory[]) => Memory[]), itemId?: string, itemData?: any) => {
    setMemoriesState(prev => {
      const next = typeof v === 'function' ? (v as (p: Memory[]) => Memory[])(prev) : v;
      safeSet('loveniya_mems', 'loveniya_mems', next, itemId, itemData);
      return next;
    });
  };

  const setPledges = (v: Pledge[] | ((prev: Pledge[]) => Pledge[]), itemId?: string, itemData?: any) => {
    setPledgesState(prev => {
      const next = typeof v === 'function' ? (v as (p: Pledge[]) => Pledge[])(prev) : v;
      safeSet('loveniya_plg', 'loveniya_plg', next, itemId, itemData);
      return next;
    });
  };

  const setDreams = (v: Dream[] | ((prev: Dream[]) => Dream[]), itemId?: string, itemData?: any) => {
    setDreamsState(prev => {
      const next = typeof v === 'function' ? (v as (p: Dream[]) => Dream[])(prev) : v;
      safeSet('loveniya_dreams', 'loveniya_dreams', next, itemId, itemData);
      return next;
    });
  };

  const setPlaylist = (v: Music[] | ((prev: Music[]) => Music[]), itemId?: string, itemData?: any) => {
    setPlaylistState(prev => {
      const next = typeof v === 'function' ? (v as (p: Music[]) => Music[])(prev) : v;
      safeSet('loveniya_msc', 'loveniya_msc', next, itemId, itemData);
      return next;
    });
  };

  const setCapsules = (v: Capsule[] | ((prev: Capsule[]) => Capsule[]), itemId?: string, itemData?: any) => {
    setCapsulesState(prev => {
      const next = typeof v === 'function' ? (v as (p: Capsule[]) => Capsule[])(prev) : v;
      safeSet('loveniya_capsules', 'loveniya_capsules', next, itemId, itemData);
      return next;
    });
  };

  const setTrashItems = (v: TrashItem[] | ((prev: TrashItem[]) => TrashItem[]), itemId?: string, itemData?: any) => {
    setTrashItemsState(prev => {
      const next = typeof v === 'function' ? (v as (p: TrashItem[]) => TrashItem[])(prev) : v;
      safeSet('loveniya_trash', 'loveniya_trash', next, itemId, itemData);
      return next;
    });
  };

  const handleSetLetterContent = (text: string) => {
    setLetterContentState(text);
    safeSet('loveniya_letter', 'loveniya_letter', text);
  };

  const moveToTrash = (type: TrashItem['type'], item: any) => {
    const trashObj: TrashItem = {
      trashId: 'trash_' + Date.now(),
      type,
      deletedAt: new Date().toLocaleDateString('fa-IR', { timeZone: 'Asia/Tehran' }),
      itemPayload: item
    };
    setTrashItems(prev => [trashObj, ...prev], trashObj.trashId, trashObj);
  };

  const restoreFromTrash = (trashId: string) => {
    const item = trashItems.find(t => t.trashId === trashId);
    if (!item) return;
    
    // Safely replace or append
    const safelyMerge = (arr: any[], newItem: any) => {
      const idx = arr.findIndex(x => x.id === newItem.id);
      if (idx !== -1) return arr.map(x => x.id === newItem.id ? newItem : x);
      return [...arr, newItem];
    };

    if (item.type === 'memory') setMemories(prev => safelyMerge(prev, item.itemPayload), item.itemPayload.id, item.itemPayload);
    if (item.type === 'pledge') setPledges(prev => safelyMerge(prev, item.itemPayload), item.itemPayload.id, item.itemPayload);
    if (item.type === 'dream') setDreams(prev => safelyMerge(prev, item.itemPayload), item.itemPayload.id, item.itemPayload);
    if (item.type === 'music') setPlaylist(prev => safelyMerge(prev, item.itemPayload), item.itemPayload.id, item.itemPayload);
    if (item.type === 'capsule') setCapsules(prev => safelyMerge(prev, item.itemPayload), item.itemPayload.id, item.itemPayload);
    
    setTrashItems(prev => prev.filter(t => t.trashId !== trashId), trashId, null);
  };

  const permanentlyDeleteFromTrash = (trashId: string) => {
    setTrashItems(prev => prev.filter(t => t.trashId !== trashId), trashId, null);
  };

  const emptyTrash = () => setTrashItems([]);

  const addMemory = (m: Memory) => setMemories(prev => [m, ...prev], m.id, m);
  const updateMemory = (m: Memory) => {
    setMemories(prev => prev.map(x => x.id === m.id ? m : x), m.id, m);
  };
  const removeMemory = (id: string) => {
    const item = memories.find(x => x.id === id);
    if (item) moveToTrash('memory', item);
    setMemories(prev => prev.filter(x => x.id !== id), id, null); // Scoped delete: only removes this item remotely, never overwrites the whole list
  };

  const addPledge = (p: Pledge) => setPledges(prev => [p, ...prev], p.id, p);
  const updatePledge = (p: Pledge) => {
    setPledges(prev => prev.map(x => x.id === p.id ? p : x), p.id, p);
  };
  const removePledge = (id: string) => {
    const item = pledges.find(x => x.id === id);
    if (item) moveToTrash('pledge', item);
    setPledges(prev => prev.filter(x => x.id !== id), id, null);
  };

  const addDream = (d: Dream) => setDreams(prev => [d, ...prev], d.id, d);
  const updateDream = (d: Dream) => {
    setDreams(prev => prev.map(x => x.id === d.id ? d : x), d.id, d);
  };
  const removeDream = (id: string) => {
    const item = dreams.find(x => x.id === id);
    if (item) moveToTrash('dream', item);
    setDreams(prev => prev.filter(x => x.id !== id), id, null);
  };

  const addMusic = (m: Music) => setPlaylist(prev => [m, ...prev], m.id, m);
  const updateMusic = (m: Music) => {
    setPlaylist(prev => prev.map(x => x.id === m.id ? m : x), m.id, m);
  };
  const removeMusic = (id: string) => {
    const item = playlist.find(x => x.id === id);
    if (item) moveToTrash('music', item);
    setPlaylist(prev => prev.filter(x => x.id !== id), id, null);
  };

  const addCapsule = (c: Capsule) => setCapsules(prev => [c, ...prev], c.id, c);
  const updateCapsule = (c: Capsule) => {
    setCapsules(prev => prev.map(x => x.id === c.id ? c : x), c.id, c);
  };
  const removeCapsule = (id: string) => {
    const item = capsules.find(x => x.id === id);
    if (item) moveToTrash('capsule', item);
    setCapsules(prev => prev.filter(x => x.id !== id), id, null);
  };

  return (
    <StoreContext.Provider value={{
      memories, pledges, dreams, playlist, capsules, trashItems, letterContent,
      syncStatus, syncError,
      addMemory, updateMemory, removeMemory,
      addPledge, updatePledge, removePledge,
      addDream, updateDream, removeDream,
      addMusic, updateMusic, removeMusic,
      addCapsule, updateCapsule, removeCapsule,
      setLetterContent: handleSetLetterContent,
      moveToTrash, emptyTrash, restoreFromTrash, permanentlyDeleteFromTrash
    }}>
      {children}
    </StoreContext.Provider>
  );
};