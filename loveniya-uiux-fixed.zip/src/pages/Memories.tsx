import React, { useState, useRef, useEffect } from 'react';
import { Camera, Plus, Star, Trash2, Edit3, Image as ImageIcon, X, Heart, Loader2, Bot, Video, Upload, Sparkles, ArrowRight, Link2, Unlink, ChevronDown } from 'lucide-react';
import { useStore } from '../lib/store';
import { Memory } from '../lib/types';
import { KebabMenu, KebabMenuItem } from '../components/KebabMenu';
import { motion, AnimatePresence } from 'motion/react';
import { BuiltInVideoPlayer } from '../components/BuiltInVideoPlayer';
import { fetchLoveAI } from '../lib/ai';
import { useNavigate, useLocation, useSearchParams } from 'react-router';
import { PageWrapper } from '../components/PageWrapper';
import { compressImage } from '../lib/imageCompressor';
import { useMemoryDraft } from '../lib/draftStore';
import { dedupById } from '../lib/dedup';

export const Memories: React.FC = () => {
  const { memories, addMemory, updateMemory, removeMemory } = useStore();
  const navigate = useNavigate();
  const location = useLocation();
  const [searchParams] = useSearchParams();
  const { draft, setDraft, resetDraft } = useMemoryDraft();
  
  const showForm = draft.showForm;
  const editingId = draft.editingId;
  const title = draft.title;
  const desc = draft.desc;
  const vidUrl = draft.vidUrl;
  const photos = draft.photos;
  const linkToId = draft.linkToId;

  const [activeMemory, setActiveMemory] = useState<Memory | null>(null);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isCompressingImages, setIsCompressingImages] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoFileInputRef = useRef<HTMLInputElement>(null);
  const formRef = useRef<HTMLDivElement>(null);

  // Automatically open target memory if passed via URL ?id= or navigation state
  useEffect(() => {
    const targetId = searchParams.get('id') || (location.state as any)?.memoryId;
    if (targetId && memories.length > 0) {
      const found = memories.find(m => m.id === targetId);
      if (found) {
        setActiveMemory(found);
      }
    }
  }, [searchParams, location.state, memories]);

  const handleCloseDetail = () => {
    setActiveMemory(null);
    if (searchParams.get('id') || (location.state as any)?.memoryId) {
      navigate('/memories', { replace: true });
    }
  };

  // Keep activeMemory in sync with any updates or removals
  React.useEffect(() => {
    if (activeMemory) {
      const fresh = memories.find(m => m.id === activeMemory.id);
      if (fresh) {
        setActiveMemory(fresh);
      } else {
        setActiveMemory(null);
      }
    }
  }, [memories]);

  const handleVideoFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setDraft({ vidUrl: event.target.result as string });
        }
      };
      reader.readAsDataURL(file);
    }
  };
  
  const handleEdit = (mem: Memory) => {
    handleCloseDetail();
    setDraft({
      editingId: mem.id,
      title: mem.title,
      desc: mem.desc,
      vidUrl: mem.vidUrl || '',
      photos: mem.photos || [],
      linkToId: '',
      showForm: true
    });
    setTimeout(() => {
      formRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 120);
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setIsCompressingImages(true);
      try {
        const newPhotos: string[] = [];
        for (let i = 0; i < e.target.files.length; i++) {
          const file = e.target.files[i];
          const compressed = await compressImage(file, {
            maxWidth: 1200,
            maxHeight: 1200,
            quality: 0.75,
            maxSizeKB: 200
          });
          newPhotos.push(compressed.base64);
        }
        setDraft(prev => ({ ...prev, photos: [...prev.photos, ...newPhotos] }));
      } catch (err) {
        console.error("Error compressing image:", err);
      } finally {
        setIsCompressingImages(false);
        if (fileInputRef.current) fileInputRef.current.value = '';
      }
    }
  };

  const removePhoto = (index: number) => {
    setDraft(prev => ({ ...prev, photos: prev.photos.filter((_, i) => i !== index) }));
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSaving || (!title.trim() && !desc.trim())) return;

    setIsSaving(true);
    try {
      let finalDesc = desc;

      // اگر خاطره‌ای برای وصل‌شدن انتخاب شده، زنجیره رو بساز یا بهش ملحق شو
      let storyId: string | undefined;
      let storyTitle: string | undefined;
      if (linkToId) {
        const linkedMemory = memories.find(m => m.id === linkToId);
        if (linkedMemory) {
          if (linkedMemory.storyId) {
            // آن خاطره از قبل بخشی از یک زنجیره‌ست؛ همون زنجیره ادامه پیدا می‌کنه
            storyId = linkedMemory.storyId;
            storyTitle = linkedMemory.storyTitle || linkedMemory.title;
          } else {
            // این اولین باریه که این خاطره وصل می‌شه؛ یک زنجیره تازه شروع می‌شه
            storyId = `story_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
            storyTitle = linkedMemory.title;
            updateMemory({ ...linkedMemory, storyId, storyTitle });
          }
        }
      }

      if (editingId) {
        const existing = memories.find(m => m.id === editingId);
        if (existing) {
          updateMemory({
            ...existing,
            title,
            desc: finalDesc,
            vidUrl,
            photos,
            ...(storyId ? { storyId, storyTitle } : {})
          });
        }
      } else {
        const newMemory: Memory = {
          id: `mem_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
          title,
          desc: finalDesc,
          vidUrl,
          photos,
          date: new Date().toLocaleDateString('fa-IR', { timeZone: 'Asia/Tehran' }),
          pinned: false,
          ...(storyId ? { storyId, storyTitle } : {})
        };
        addMemory(newMemory);
      }
      resetForm();
    } finally {
      setIsSaving(false);
    }
  };

  const resetForm = () => {
    resetDraft();
  };

  const [showCount, setShowCount] = useState(4);

  // خاطره‌ها با id به‌شکل mem_{timestamp}_{random} ساخته می‌شن؛ همون timestamp
  // برای مرتب‌سازی زمانی زنجیره خیلی قابل‌اعتمادتر از رشته‌ی تاریخ فارسیه.
  const getMemoryTs = (mem: Memory): number => {
    const parts = mem.id.split('_');
    const ts = parts.length > 1 ? Number(parts[1]) : NaN;
    return Number.isFinite(ts) ? ts : 0;
  };

  // Deduplicate and sort memories: pinned ones first
  const uniqueMemories = React.useMemo(() => dedupById(memories), [memories]);
  const sortedMemories = React.useMemo(() => {
    return [...uniqueMemories].sort((a, b) => {
      if (a.pinned && !b.pinned) return -1;
      if (!a.pinned && b.pinned) return 1;
      return 0;
    });
  }, [uniqueMemories]);

  // زنجیره خاطرات: خاطره‌هایی که با storyId مشترک به‌هم وصل شدن، به ترتیب زمانی
  const storyChains = React.useMemo(() => {
    const map: { [storyId: string]: Memory[] } = {};
    uniqueMemories.forEach(m => {
      if (m.storyId) {
        if (!map[m.storyId]) map[m.storyId] = [];
        map[m.storyId].push(m);
      }
    });
    Object.keys(map).forEach(sid => {
      map[sid].sort((a, b) => getMemoryTs(a) - getMemoryTs(b));
    });
    return map;
  }, [uniqueMemories]);

  // فهرست خاطره‌های قابل‌انتخاب برای «ادامه‌ی این خاطره»، جدیدترین اول، بدون خودِ خاطره‌ی در حال ویرایش
  const linkableMemories = React.useMemo(() => {
    return [...uniqueMemories]
      .filter(m => m.id !== editingId)
      .sort((a, b) => getMemoryTs(b) - getMemoryTs(a));
  }, [uniqueMemories, editingId]);

  const getStoryPosition = (mem: Memory) => {
    if (!mem.storyId) return null;
    const chain = storyChains[mem.storyId] || [mem];
    const index = chain.findIndex(m => m.id === mem.id);
    return { index: index + 1, total: chain.length, chain };
  };

  const displayedMemories = sortedMemories.slice(0, showCount);
  const hasMore = showCount < sortedMemories.length;
  const hasLess = showCount > 4;

  const editingMemory = editingId ? memories.find(m => m.id === editingId) || null : null;

  const handleUnlinkFromStory = (mem: Memory) => {
    updateMemory({ ...mem, storyId: undefined, storyTitle: undefined });
  };

  return (
    <PageWrapper>
      <AnimatePresence mode="wait">
      {activeMemory ? (
        <motion.div 
          key="detail"
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: -20 }}
          transition={{ type: "spring", stiffness: 300, damping: 30 }}
          className="space-y-6 pb-6 w-full" dir="rtl"
        >
          <div className="glass-card rounded-3xl p-4 sm:p-6 md:p-10 relative overflow-hidden shadow-2xl bg-white/95">
            <div className="flex justify-between items-start mb-6 border-b border-rose-100 pb-4 sm:pb-6">
              <div>
                <h2 className="text-xl md:text-3xl font-black text-rose-600 flex items-center gap-2 mb-1.5">
                  <Camera className="w-5 h-5 sm:w-7 sm:h-7 fill-rose-500/20 text-rose-500 shrink-0" /> {activeMemory.title}
                </h2>
                <p className="text-xs md:text-sm text-slate-500 font-bold flex items-center gap-2 flex-wrap">
                   <span>ثبت شده در: {activeMemory.date}</span>
                   {activeMemory.pinned && (
                     <span className="inline-flex items-center gap-1 bg-amber-100 text-amber-600 px-2 py-0.5 rounded-full text-[10px] shrink-0">
                       <Star className="w-3 h-3 fill-amber-500" /> خاطره برتر
                     </span>
                   )}
                   {activeMemory.storyId && (
                     <span className="inline-flex items-center gap-1 bg-indigo-50 text-indigo-700 border border-indigo-200 px-2 py-0.5 rounded-full text-[10px] max-w-[160px] sm:max-w-[240px]">
                       <Link2 className="w-3 h-3 shrink-0" /> <span className="truncate">{activeMemory.storyTitle}</span>
                     </span>
                   )}
                </p>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <button 
                  onClick={() => handleEdit(activeMemory)}
                  className="text-rose-600 hover:text-rose-700 bg-rose-50 hover:bg-rose-100 px-3.5 py-1.5 rounded-xl font-bold text-xs transition-colors flex items-center gap-1.5 border border-rose-200/60"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>ویرایش</span>
                </button>
                <button 
                  onClick={handleCloseDetail} 
                  className="text-stone-700 hover:text-stone-900 bg-stone-100 hover:bg-stone-200 px-3.5 py-1.5 rounded-xl font-bold text-xs transition-colors flex items-center gap-1.5 border border-stone-200/80"
                >
                  <ArrowRight className="w-3.5 h-3.5" />
                  <span>بازگشت</span>
                </button>
              </div>
            </div>

            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="whitespace-pre-wrap text-sm md:text-base font-medium text-slate-700 leading-loose mb-10"
            >
              {activeMemory.desc}
            </motion.div>

            {activeMemory.storyId && (() => {
              const pos = getStoryPosition(activeMemory);
              if (!pos) return null;
              return (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.3 }}
                  className="mb-10 bg-indigo-50/60 border border-indigo-100 rounded-2xl p-4 sm:p-5"
                >
                  <h3 className="text-sm font-black text-indigo-900 flex items-center gap-2 mb-4 flex-wrap">
                    <Link2 className="w-4 h-4 text-indigo-500 shrink-0" />
                    <span className="truncate max-w-[70%]">زنجیره «{activeMemory.storyTitle}»</span>
                    <span className="text-[10px] font-bold text-indigo-500 shrink-0">(قسمت {pos.index} از {pos.total})</span>
                  </h3>
                  <div className="space-y-1">
                    {pos.chain.map((step, i) => {
                      const isCurrent = step.id === activeMemory.id;
                      return (
                        <button
                          key={step.id}
                          type="button"
                          onClick={() => !isCurrent && setActiveMemory(step)}
                          className={`w-full flex gap-3 text-right rounded-xl px-3 py-2.5 transition-colors ${
                            isCurrent ? 'bg-white border border-indigo-300 shadow-2xs cursor-default' : 'hover:bg-white/70 cursor-pointer'
                          }`}
                        >
                          <div className="flex flex-col items-center pt-0.5 shrink-0">
                            <span className={`w-2.5 h-2.5 rounded-full shrink-0 ${isCurrent ? 'bg-indigo-600' : 'bg-indigo-300'}`} />
                            {i < pos.chain.length - 1 && <span className="w-px flex-1 min-h-[18px] bg-indigo-200 mt-1" />}
                          </div>
                          <div className="min-w-0 flex-1 pb-1">
                            <p className={`text-xs font-black truncate ${isCurrent ? 'text-indigo-900' : 'text-stone-700'}`}>
                              {step.title}
                            </p>
                            <p className="text-[10px] text-stone-400 font-bold">{step.date}</p>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </motion.div>
              );
            })()}

            {activeMemory.photos && activeMemory.photos.length > 0 && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.4 }}
                className="space-y-3 mt-8"
              >
                <h3 className="text-sm font-black text-slate-800 flex items-center gap-2 mb-4">
                  <ImageIcon className="w-4 h-4 text-rose-400" /> گالری این خاطره
                </h3>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                  {activeMemory.photos.map((photo, idx) => (
                    <div key={idx} onClick={() => setSelectedImage(photo)} className="aspect-square rounded-2xl overflow-hidden border-2 border-white shadow-lg group cursor-pointer relative">
                      <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors z-10"></div>
                      <img src={photo} alt="" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300" />
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {activeMemory.vidUrl && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.5 }}
                className="mt-8 pt-6 border-t border-slate-100 space-y-4"
              >
                <h3 className="text-sm font-black text-slate-800 flex items-center gap-2 mb-2">
                  <Video className="w-4 h-4 text-rose-500" /> ویدیوی خاطره
                </h3>
                <BuiltInVideoPlayer url={activeMemory.vidUrl} title={activeMemory.title} />
              </motion.div>
            )}


          </div>
        </motion.div>
      ) : (
        <motion.div 
          key="list"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          transition={{ type: "spring", stiffness: 300, damping: 30 }}
          className="space-y-6 w-full" dir="rtl"
        >
          {/* Header Card */}
          <div className="bg-white rounded-3xl p-5 sm:p-6 relative overflow-hidden border border-rose-200/80 shadow-2xs">
            <div className="absolute inset-0 overflow-hidden rounded-3xl pointer-events-none">
              <div className="absolute top-0 right-0 w-64 h-64 bg-rose-100/30 rounded-full blur-3xl"></div>
              <div className="absolute bottom-0 left-0 w-64 h-64 bg-pink-100/20 rounded-full blur-3xl"></div>
            </div>

            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 relative z-10">
              <div className="flex items-center gap-3.5">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-rose-500 to-pink-500 text-white flex items-center justify-center shadow-md shadow-rose-500/20 shrink-0">
                  <Camera className="w-6 h-6" />
                </div>
                <div>
                  <h2 className="text-lg sm:text-xl font-black text-slate-800 flex items-center gap-2">
                    <span>قاب خاطرات</span>
                  </h2>
                </div>
              </div>
              <button 
                onClick={() => {
                  if (showForm) {
                    resetForm();
                  } else {
                    setDraft({ showForm: true });
                  }
                }} 
                className="bg-gradient-to-r from-rose-500 to-pink-500 hover:from-rose-600 hover:to-pink-600 text-white text-sm font-bold px-5 py-3 rounded-2xl flex items-center gap-2 transition-all active:scale-95 shadow-md shadow-rose-500/20 shrink-0 self-stretch sm:self-auto justify-center"
              >
                <Plus className={`w-4 h-4 text-white transition-transform duration-300 ${showForm ? 'rotate-45' : ''}`} />
                <span>{showForm ? 'انصراف' : 'ثبت خاطره جدید'}</span>
              </button>
            </div>

            {/* Add/Edit Form */}
            <AnimatePresence>
              {showForm && (
                <motion.div 
                  ref={formRef}
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="mt-6 relative z-10 pt-4 border-t border-rose-100"
                >
                  <form onSubmit={handleSave} className="space-y-4">
                    {editingId && (
                      <div className="text-rose-600 text-xs font-black flex items-center gap-2 pb-1">
                        <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
                        <Edit3 className="w-3.5 h-3.5 text-rose-600 shrink-0" />
                        <span>در حال ویرایش خاطره: {title || 'بدون عنوان'}</span>
                      </div>
                    )}
                    <div>
                      <label className="block text-xs font-extrabold text-slate-700 mb-1">عنوان خاطره:</label>
                      <input 
                        type="text" 
                        placeholder="مثلا: اولین غروب آفتاب کنار دریا..." 
                        required 
                        value={title} 
                        onChange={e => setDraft({ title: e.target.value })}
                        className="w-full bg-white border border-slate-200 rounded-xl px-3.5 py-2.5 text-base focus:border-rose-400 focus:outline-none font-bold text-slate-800 transition-all" 
                      />
                    </div>

                    {/* زنجیره خاطرات */}
                    {editingMemory?.storyId ? (
                      <div className="flex items-center justify-between gap-2 bg-indigo-50 border border-indigo-200 rounded-xl px-3.5 py-2.5">
                        <div className="flex items-center gap-2 min-w-0 text-indigo-800">
                          <Link2 className="w-4 h-4 shrink-0" />
                          <span className="text-xs font-bold truncate">
                            بخشی از زنجیره «{editingMemory.storyTitle || editingMemory.title}»
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={() => handleUnlinkFromStory(editingMemory)}
                          className="flex items-center gap-1 text-[11px] font-black text-indigo-600 hover:text-indigo-800 shrink-0"
                        >
                          <Unlink className="w-3.5 h-3.5" />
                          <span>خروج از زنجیره</span>
                        </button>
                      </div>
                    ) : linkableMemories.length > 0 && (
                      <div>
                        <label className="block text-xs font-extrabold text-slate-700 mb-1">
                          ادامه‌ی یکی از خاطره‌های قبلیه؟ (اختیاری)
                        </label>
                        <div className="relative">
                          <Link2 className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none z-10" />
                          <ChevronDown className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                          <select
                            value={linkToId}
                            onChange={e => setDraft({ linkToId: e.target.value })}
                            className="w-full bg-white border border-slate-200 rounded-xl pr-10 pl-9 py-2.5 text-base focus:border-rose-400 focus:outline-none font-bold text-slate-800 transition-all appearance-none truncate"
                          >
                            <option value="">مستقل — به خاطره‌ای وصل نیست</option>
                            {linkableMemories.map(m => (
                              <option key={m.id} value={m.id}>
                                {m.storyTitle ? `↳ ${m.storyTitle}: ` : ''}{m.title} — {m.date}
                              </option>
                            ))}
                          </select>
                        </div>
                        {linkToId && (
                          <p className="text-[11px] text-indigo-600 font-bold mt-1.5 flex items-center gap-1">
                            <Sparkles className="w-3 h-3 shrink-0" />
                            <span>این خاطره به‌عنوان ادامه‌ی داستان بالا ثبت می‌شه</span>
                          </p>
                        )}
                      </div>
                    )}

                    <div>
                      <label className="block text-xs font-extrabold text-slate-700 mb-1">عکس‌های خاطره:</label>
                      <div className="flex flex-wrap gap-2.5">
                        {photos.map((photo, i) => (
                          <div key={i} className="relative w-20 h-20 rounded-xl overflow-hidden shadow-sm group border border-slate-200">
                            <img src={photo} alt="" className="w-full h-full object-cover" />
                            <button 
                              type="button" 
                              onClick={() => removePhoto(i)}
                              className="absolute top-1 right-1 bg-white/90 p-1 rounded-full text-rose-500 opacity-0 group-hover:opacity-100 transition-opacity shadow-xs"
                            >
                              <X className="w-3 h-3" />
                            </button>
                          </div>
                        ))}
                        {isCompressingImages ? (
                          <div className="w-20 h-20 rounded-xl border border-rose-200 bg-rose-50/70 flex flex-col items-center justify-center text-rose-500 text-center p-1 animate-pulse">
                            <Loader2 className="w-5 h-5 animate-spin mb-1" />
                            <span className="text-[10px] font-bold">بهینه‌سازی...</span>
                          </div>
                        ) : (
                          <button 
                            type="button"
                            onClick={() => fileInputRef.current?.click()}
                            className="w-20 h-20 rounded-xl border-2 border-dashed border-slate-300 flex flex-col items-center justify-center text-slate-400 hover:text-rose-500 hover:border-rose-400 transition-colors bg-white active:scale-95"
                          >
                            <ImageIcon className="w-5 h-5 mb-1 text-slate-400" />
                            <span className="text-[10px] font-bold">افزودن عکس</span>
                          </button>
                        )}
                        <input 
                          type="file" 
                          ref={fileInputRef} 
                          onChange={handleFileChange} 
                          multiple 
                          accept="image/*" 
                          className="hidden" 
                          disabled={isCompressingImages}
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-extrabold text-slate-700 mb-1">لینک ویدیو یا انتخاب ویدیوی اختصاصی (اختیاری):</label>
                      <div className="flex gap-2">
                        <input 
                          type="text" 
                          placeholder="لینک ویدیو (MP4 یا یوتیوب)" 
                          value={vidUrl} 
                          onChange={e => setDraft({ vidUrl: e.target.value })}
                          className="flex-1 min-w-0 bg-white border border-slate-200 rounded-xl px-3.5 py-2.5 text-base focus:border-rose-400 focus:outline-none transition-all" 
                          dir="ltr"
                        />
                        <button
                          type="button"
                          onClick={() => videoFileInputRef.current?.click()}
                          className="bg-rose-50 text-rose-600 border border-rose-200 font-bold text-xs px-3.5 py-2 rounded-xl flex items-center gap-1.5 hover:bg-rose-100 transition-colors shrink-0"
                        >
                          <Upload className="w-4 h-4" />
                          <span>انتخاب ویدیو</span>
                        </button>
                      </div>
                      <input 
                        type="file" 
                        ref={videoFileInputRef} 
                        onChange={handleVideoFileUpload} 
                        accept="video/*" 
                        className="hidden" 
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-extrabold text-slate-700 mb-1">شرح احساسی خاطره:</label>
                      <textarea 
                        rows={4} 
                        placeholder="احساسات اون لحظه‌ت رو بنویس..." 
                        required 
                        value={desc} 
                        onChange={e => setDraft({ desc: e.target.value })}
                        className="w-full bg-white border border-slate-200 rounded-xl p-3.5 text-base focus:border-rose-400 focus:outline-none leading-relaxed transition-all"
                      ></textarea>
                    </div>
                    <div className="flex justify-end gap-2 pt-1">
                      <button 
                        type="button" 
                        onClick={resetForm} 
                        className="bg-slate-100 text-slate-600 text-xs px-4 py-2 rounded-xl font-bold hover:bg-slate-200 transition-colors"
                      >
                        انصراف
                      </button>
                      <button 
                        type="submit" 
                        className="bg-gradient-to-r from-rose-500 to-pink-500 hover:from-rose-600 hover:to-pink-600 text-white text-sm font-bold px-6 py-3 rounded-xl transition-all shadow-md shadow-rose-500/20"
                      >
                        {editingId ? 'ذخیره تغییرات' : 'ثبت خاطره'}
                      </button>
                    </div>
                  </form>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Memory List Cards directly on page background (Layer 2) */}
          <div className="space-y-4">
            {sortedMemories.length === 0 ? (
              <div className="glass-card rounded-3xl p-10 text-center text-slate-500 text-xs flex flex-col items-center justify-center gap-3 border border-dashed border-rose-200">
                <div className="w-12 h-12 rounded-full bg-rose-50 flex items-center justify-center text-rose-400">
                  <Camera className="w-6 h-6" />
                </div>
                <p className="font-extrabold text-slate-700 text-sm">هنوز خاطره‌ای ثبت نشده...</p>
                <p className="text-xs text-slate-400">با زدن دکمه «ثبت خاطره جدید» اولین خاطره قشنگ‌مون رو ثبت کن.</p>
              </div>
            ) : (
              displayedMemories.map((mem) => (
                <motion.div 
                  layout 
                  key={mem.id} 
                  onClick={() => setActiveMemory(mem)} 
                  className={`cursor-pointer rounded-3xl transition-all duration-300 relative group ${
                    mem.pinned 
                      ? 'bg-[#fffafb] p-5 sm:p-6 shadow-2xs border-2 border-rose-200/90 hover:shadow-xs' 
                      : 'bg-white p-5 sm:p-6 shadow-2xs hover:shadow-xs border border-stone-200/80'
                  }`}
                >
                  {/* Card Top Header */}
                  <div className="flex justify-between items-center gap-2 mb-1.5">
                    <h3 className={`font-black text-sm sm:text-base truncate min-w-0 ${
                      mem.pinned ? 'text-rose-950' : 'text-stone-900'
                    }`}>
                      {mem.title}
                    </h3>

                    <div className="flex items-center gap-2 shrink-0" onClick={e => e.stopPropagation()}>
                      <KebabMenu>
                        <KebabMenuItem 
                          icon={<Star className={`w-4 h-4 ${mem.pinned ? 'text-rose-500 fill-rose-500' : 'text-slate-400'}`} />} 
                          label={mem.pinned ? 'برداشتن نشان برتر' : 'نشان کردن به عنوان برتر'} 
                          onClick={() => updateMemory({ ...mem, pinned: !mem.pinned })} 
                        />
                        <KebabMenuItem 
                          icon={<Edit3 className="w-4 h-4 text-slate-500" />} 
                          label="ویرایش" 
                          onClick={() => handleEdit(mem)} 
                        />
                        <KebabMenuItem 
                          icon={<Trash2 className="w-4 h-4 text-rose-500" />} 
                          label="حذف" 
                          danger 
                          onClick={() => removeMemory(mem.id)} 
                        />
                      </KebabMenu>
                    </div>
                  </div>

                  {/* Badges + Date — on their own row so they never squeeze the title or kebab menu */}
                  <div className="flex items-center gap-1.5 flex-wrap mb-3">
                    {mem.pinned && (
                      <span className="inline-flex items-center gap-1 bg-rose-50 border border-rose-200 text-rose-700 text-[10px] font-black px-2 py-0.5 rounded-full shadow-2xs">
                        <Star className="w-2.5 h-2.5 fill-rose-500 text-rose-500" />
                        <span>خاطره برتر</span>
                      </span>
                    )}
                    {(() => {
                      const pos = getStoryPosition(mem);
                      if (!pos) return null;
                      return (
                        <span className="inline-flex items-center gap-1 bg-indigo-50 border border-indigo-200 text-indigo-700 text-[10px] font-black px-2 py-0.5 rounded-full shadow-2xs max-w-full">
                          <Link2 className="w-2.5 h-2.5 shrink-0" />
                          <span className="truncate">قسمت {pos.index} از {pos.total} · {mem.storyTitle}</span>
                        </span>
                      );
                    })()}
                    <span className="text-[10px] text-stone-500 font-medium">
                      {mem.date}
                    </span>
                  </div>
                  
                  <p className={`text-sm mb-3.5 whitespace-pre-wrap leading-relaxed line-clamp-3 ${
                    mem.pinned ? 'text-stone-800 font-medium' : 'text-stone-700'
                  }`}>
                    {mem.desc}
                  </p>
                  
                  {mem.photos && mem.photos.length > 0 && (
                    <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 mb-3.5">
                      {mem.photos.map((photo, idx) => (
                        <div key={idx} className={`aspect-square rounded-2xl overflow-hidden shadow-xs bg-slate-100 ${
                          mem.pinned ? 'border border-rose-200' : 'border border-stone-200/80'
                        }`}>
                          <img src={photo} alt="" className="w-full h-full object-cover hover:scale-105 transition-transform duration-300" />
                        </div>
                      ))}
                    </div>
                  )}

                  <div className="flex justify-end items-center mt-2 border-t border-slate-100 pt-2.5">
                    <span className={`text-[11px] font-black transition-colors ${
                      mem.pinned 
                        ? 'text-rose-600 group-hover:text-rose-800' 
                        : 'text-rose-600 group-hover:text-rose-700'
                    }`}>
                      مشاهده جزئیات کامل ←
                    </span>
                  </div>
                </motion.div>
              ))
            )}
          </div>

          {sortedMemories.length > 4 && (
            <div className="flex justify-center gap-3 mt-6 relative z-10 pb-4">
              {hasMore && (
                <button onClick={() => setShowCount(c => c + 4)} className="bg-white/95 backdrop-blur-sm border border-rose-100 hover:bg-rose-50 text-rose-500 transition-all px-6 py-2.5 rounded-full font-bold text-xs flex items-center gap-2 shadow-sm active:scale-95">
                  <Heart className="w-4 h-4 fill-rose-500" />
                  نمایش بیشتر ({sortedMemories.length - showCount})
                </button>
              )}
              {hasLess && (
                <button onClick={() => setShowCount(4)} className="bg-white/95 backdrop-blur-sm border border-slate-100 hover:bg-slate-50 text-slate-500 transition-all px-6 py-2.5 rounded-full font-bold text-xs flex items-center gap-2 shadow-sm active:scale-95">
                  نمایش کمتر
                </button>
              )}
            </div>
          )}
    </motion.div>
      )}
    </AnimatePresence>
      
      <AnimatePresence>
        {selectedImage && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/90 backdrop-blur-sm p-4"
            onClick={() => setSelectedImage(null)}
          >
            <button 
              className="absolute top-6 right-6 text-white/70 hover:text-white bg-black/20 hover:bg-black/40 p-3 rounded-full transition-colors z-[110]"
              onClick={(e) => {
                e.stopPropagation();
                setSelectedImage(null);
              }}
            >
              <X className="w-6 h-6" />
            </button>
            <motion.img 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ type: "spring", stiffness: 300, damping: 30 }}
              src={selectedImage} 
              alt="بزرگنمایی" 
              className="max-w-full max-h-full object-contain rounded-xl shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </PageWrapper>
  );
};
