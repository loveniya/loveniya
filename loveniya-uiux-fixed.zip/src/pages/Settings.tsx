import React, { useState } from 'react';
import { 
  Settings as SettingsIcon, Trash2, Lock, CloudOff, Cloud, 
  AlertCircle, RefreshCcw, UserCheck, ShieldCheck, Database,
  Download, Heart, Check
} from 'lucide-react';
import { useStore } from '../lib/store';
import { PageWrapper } from '../components/PageWrapper';

export const Settings: React.FC<{ onLock: () => void }> = ({ onLock }) => {
  const { memories, pledges, dreams, capsules, trashItems, emptyTrash, restoreFromTrash, permanentlyDeleteFromTrash, syncStatus, syncError } = useStore();
  const [currentUser, setCurrentUser] = useState<'amin' | 'niyayesh'>(
    (localStorage.getItem('loveniya_user') as 'amin' | 'niyayesh') || 'amin'
  );
  const [downloaded, setDownloaded] = useState(false);

  const toggleUser = () => {
    const newUser = currentUser === 'amin' ? 'niyayesh' : 'amin';
    localStorage.setItem('loveniya_user', newUser);
    setCurrentUser(newUser);
    window.location.reload();
  };

  const handleExportBackup = () => {
    const backupData = {
      exportDate: new Date().toISOString(),
      user: currentUser,
      memories,
      pledges,
      dreams,
      capsules,
      trashItems
    };

    const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `loveniya-backup-${new Date().toLocaleDateString('en-CA')}.json`;
    a.click();
    URL.revokeObjectURL(url);
    setDownloaded(true);
    setTimeout(() => setDownloaded(false), 3000);
  };

  return (
    <PageWrapper>
      <div className="space-y-4 max-w-xl mx-auto px-2 sm:px-4 py-2" dir="rtl">
        
        {/* Header */}
        <div className="bg-white rounded-3xl p-5 border border-rose-200/80 shadow-2xs flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-rose-50 border border-rose-200 text-rose-600 flex items-center justify-center shrink-0">
              <SettingsIcon className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-base font-black text-stone-900 tracking-tight">تنظیمات و امنیت</h1>
              <p className="text-xs text-stone-500 font-bold">پایگاه داده، امنیت و نسخه پشتیبان</p>
            </div>
          </div>
        </div>

        {/* Grouped Settings List */}
        <div className="bg-white rounded-3xl border border-stone-200/90 shadow-2xs divide-y divide-stone-100 overflow-hidden">
          
          {/* Section 1: Active Profile */}
          <div className="p-4 sm:p-5 flex items-center justify-between hover:bg-stone-50/80 transition-colors">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-stone-100 text-stone-600 flex items-center justify-center shrink-0">
                <UserCheck className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-black text-xs sm:text-sm text-stone-900 mb-0.5">حساب کاربری فعال</h3>
                <p className="text-[11px] text-stone-500 font-medium">
                  هویت ثبت شده برای خاطرات و پیام‌ها
                </p>
              </div>
            </div>
            <button 
              onClick={toggleUser}
              className="text-xs font-black text-rose-700 bg-rose-50 hover:bg-rose-100 active:scale-95 transition-all h-9 px-3 rounded-full border border-rose-200 shadow-2xs flex items-center gap-1.5 shrink-0 cursor-pointer"
            >
              <Heart className="w-2.5 h-2.5 fill-rose-500 text-rose-500" />
              <span>{currentUser === 'amin' ? 'امین' : 'نیایش'} (تغییر)</span>
            </button>
          </div>

          {/* Section 2: Cloud Sync Status */}
          <div className="p-4 sm:p-5 flex items-center justify-between hover:bg-stone-50/80 transition-colors">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-indigo-50 text-indigo-500 flex items-center justify-center shrink-0">
                <Database className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-black text-xs sm:text-sm text-stone-900 mb-0.5">وضعیت پایگاه داده</h3>
                <p className="text-[11px] text-stone-500 font-medium">
                  {syncStatus === 'connected' ? 'همگام‌سازی زنده فعال است' : 'بررسی اتصال...'}
                </p>
              </div>
            </div>
            {syncStatus === 'connected' ? (
              <span className="flex items-center gap-1 text-[10px] font-black text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200 shrink-0">
                <Cloud className="w-3.5 h-3.5 text-emerald-600" />
                <span>متصل</span>
              </span>
            ) : syncStatus === 'error' ? (
              <span className="flex items-center gap-1 text-[10px] font-black text-rose-700 bg-rose-50 px-2.5 py-1 rounded-lg border border-rose-200 shrink-0">
                <AlertCircle className="w-3.5 h-3.5 text-rose-600" />
                <span>خطا</span>
              </span>
            ) : (
              <span className="flex items-center gap-1 text-[10px] font-black text-amber-700 bg-amber-50 px-2.5 py-1 rounded-lg border border-amber-200 shrink-0">
                <CloudOff className="w-3.5 h-3.5 text-amber-600" />
                <span>اتصال...</span>
              </span>
            )}
          </div>

          {/* Section 3: Lock Screen & Security */}
          <div className="p-4 sm:p-5 flex items-center justify-between hover:bg-stone-50/80 transition-colors">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0 border border-emerald-100">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-black text-xs sm:text-sm text-stone-900 mb-0.5">قفل امنیتی سایت</h3>
                <p className="text-[11px] text-stone-500 font-medium">
                  محافظت از حریم خصوصی
                </p>
              </div>
            </div>
            <button
              onClick={onLock}
              className="bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 h-9 px-3 rounded-full text-xs font-black flex items-center gap-1.5 shrink-0 shadow-2xs cursor-pointer active:scale-95 transition-all"
            >
              <Lock className="w-3 h-3 text-rose-500" />
              <span>قفل برنامه</span>
            </button>
          </div>

          {/* Section 4: Backup Export */}
          <div className="p-4 sm:p-5 flex items-center justify-between hover:bg-stone-50/80 transition-colors">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-sky-50 text-sky-500 flex items-center justify-center shrink-0">
                <Download className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-black text-xs sm:text-sm text-stone-900 mb-0.5">نسخه پشتیبان</h3>
                <p className="text-[11px] text-stone-500 font-medium">
                  دانلود اطلاعات به صورت JSON
                </p>
              </div>
            </div>
            <button
              onClick={handleExportBackup}
              className="bg-stone-100 text-stone-700 hover:bg-stone-200 border border-stone-200 h-9 px-3 rounded-full text-xs font-black flex items-center gap-1.5 shrink-0 shadow-2xs cursor-pointer active:scale-95 transition-all"
            >
              {downloaded ? <Check className="w-3 h-3 text-emerald-600" /> : <Download className="w-3 h-3" />}
              <span>{downloaded ? 'انجام شد' : 'دانلود'}</span>
            </button>
          </div>

        </div>

        {/* Section 5: Trash Bin */}
        <div className="bg-white rounded-3xl p-5 border border-rose-200/80 shadow-2xs space-y-3">
          <div className="flex items-center justify-between border-b border-stone-100 pb-3">
            <div className="flex items-center gap-2">
              <Trash2 className="w-4 h-4 text-rose-500" />
              <h3 className="font-black text-xs sm:text-sm text-stone-900">سطل زباله و بازیابی</h3>
              <span className="bg-rose-100 text-rose-700 font-black text-[10px] px-2 py-0.5 rounded-full">
                {trashItems.length}
              </span>
            </div>

            {trashItems.length > 0 && (
              <button
                onClick={emptyTrash}
                className="text-sm text-rose-600 hover:text-rose-700 font-bold bg-rose-50 h-10 px-3.5 rounded-xl border border-rose-200 cursor-pointer flex items-center"
              >
                خالی کردن سطل
              </button>
            )}
          </div>

          <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
            {trashItems.length === 0 ? (
              <p className="text-center text-xs text-stone-400 py-3 font-medium">سطل زباله خالی است.</p>
            ) : (
              trashItems.map((item, itemIdx) => (
                <div
                  key={item.trashId ? `${item.trashId}-${itemIdx}` : itemIdx}
                  className="flex items-center justify-between bg-stone-50 p-3 rounded-2xl border border-stone-200/80"
                >
                  <div className="min-w-0 flex-1 pr-1">
                    <span className="text-[10px] text-stone-400 font-bold block">
                      {item.type === 'memory' ? 'خاطره' : item.type === 'pledge' ? 'عهد' : item.type === 'dream' ? 'آرزو' : item.type === 'music' ? 'آهنگ' : item.type === 'capsule' ? 'نامه' : 'آیتم'}
                    </span>
                    <p className="text-xs text-stone-800 font-bold truncate">
                      {item.itemPayload.title || item.itemPayload.text || 'بدون عنوان'}
                    </p>
                  </div>

                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      onClick={() => restoreFromTrash(item.trashId)}
                      className="text-indigo-600 hover:bg-indigo-50 min-w-[44px] min-h-[44px] flex items-center justify-center rounded-xl transition-colors cursor-pointer"
                      title="بازگردانی"
                    >
                      <RefreshCcw className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => permanentlyDeleteFromTrash(item.trashId)}
                      className="text-rose-500 hover:bg-rose-50 min-w-[44px] min-h-[44px] flex items-center justify-center rounded-xl transition-colors cursor-pointer"
                      title="حذف همیشگی"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

      </div>
    </PageWrapper>
  );
};
