import { PageWrapper } from "../components/PageWrapper";
import React, { useState, useRef } from 'react';
import { 
  Music as MusicIcon, Plus, Star, Trash2, ExternalLink, 
  Edit3, Heart, Play, Upload, Disc, Sparkles
} from 'lucide-react';
import { useStore } from '../lib/store';
import { Music as MusicType } from '../lib/types';
import { KebabMenu, KebabMenuItem } from '../components/KebabMenu';
import { motion, AnimatePresence } from 'motion/react';
import { dedupById } from '../lib/dedup';

export const Music: React.FC = () => {
  const { playlist, addMusic, updateMusic, removeMusic } = useStore();
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [title, setTitle] = useState('');
  const [artist, setArtist] = useState('');
  const [url, setUrl] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const audioFileInputRef = useRef<HTMLInputElement>(null);
  const formRef = useRef<HTMLDivElement>(null);
  
  const handleEdit = (song: MusicType) => {
    setEditingId(song.id);
    setTitle(song.title);
    setArtist(song.artist);
    setUrl(song.url);
    setShowForm(true);
    setTimeout(() => {
      formRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 100);
  };

  const handleAudioFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setUrl(event.target.result as string);
          if (!title) {
            const nameWithoutExt = file.name.replace(/\.[^/.]+$/, "");
            setTitle(nameWithoutExt);
          }
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handlePlaySong = (songId: string) => {
    window.dispatchEvent(new CustomEvent('play_song', { detail: songId }));
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (isSaving || !title.trim() || !url.trim()) return;

    setIsSaving(true);
    try {
      if (editingId) {
        const existing = playlist.find(m => m.id === editingId);
        if (existing) {
          updateMusic({
            ...existing,
            title,
            artist: artist || 'ناشناس',
            url
          });
        }
      } else {
        const newMusic: MusicType = {
          id: `song_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
          title,
          artist: artist || 'ناشناس',
          url,
          pinned: false
        };
        addMusic(newMusic);
      }
      resetForm();
    } finally {
      setIsSaving(false);
    }
  };

  const resetForm = () => {
    setTitle('');
    setArtist('');
    setUrl('');
    setEditingId(null);
    setShowForm(false);
  };

  const [showCount, setShowCount] = useState(6);

  // Deduplicate and sort playlist: pinned ones first
  const uniquePlaylist = React.useMemo(() => dedupById(playlist), [playlist]);
  const sortedMusic = React.useMemo(() => {
    return [...uniquePlaylist].sort((a, b) => {
      if (a.pinned && !b.pinned) return -1;
      if (!a.pinned && b.pinned) return 1;
      return 0;
    });
  }, [uniquePlaylist]);

  const displayedMusic = sortedMusic.slice(0, showCount);
  const hasMore = showCount < sortedMusic.length;
  const hasLess = showCount > 6;

  return (
    <PageWrapper>
      <div className="space-y-4" dir="rtl">
        {/* Header Card */}
      <div className="bg-white rounded-3xl p-4 sm:p-5 relative overflow-hidden border border-fuchsia-200/80 shadow-2xs">
        <div className="absolute inset-0 overflow-hidden rounded-3xl pointer-events-none">
          <div className="absolute top-0 left-0 w-64 h-64 bg-fuchsia-100/30 rounded-full blur-3xl" />
          <div className="absolute bottom-0 right-0 w-64 h-64 bg-pink-100/20 rounded-full blur-3xl" />
        </div>

        <div className="flex flex-wrap justify-between items-center gap-3 relative z-10">
          <div>
            <h2 className="text-base sm:text-lg font-black text-slate-800 flex items-center gap-2">
              <MusicIcon className="w-5 h-5 text-fuchsia-500 shrink-0" />
              <span>موزیک‌های عاشقانه ما</span>
            </h2>
            <p className="text-xs text-slate-500 font-bold mt-1">
              آهنگ‌هایی که یادآور لحظات شیرین و خاطرات دو نفره‌مان هستند.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button 
              onClick={() => {
                if (playlist.length > 0) {
                  handlePlaySong(playlist[0].id);
                }
              }} 
              className="bg-white hover:bg-stone-50 border border-fuchsia-200 text-fuchsia-700 text-xs font-black px-3.5 py-2 rounded-xl flex items-center gap-1.5 transition-all active:scale-95 shadow-2xs cursor-pointer"
            >
              <Disc className="w-3.5 h-3.5 text-fuchsia-500 animate-[spin_6s_linear_infinite]" />
              <span>پلیر تمام‌صفحه</span>
            </button>

            <button 
              onClick={() => {
                if (showForm) {
                  resetForm();
                } else {
                  setShowForm(true);
                }
              }} 
              className="bg-gradient-to-r from-fuchsia-500 to-pink-500 hover:from-fuchsia-600 hover:to-pink-600 text-white text-xs font-bold px-4 py-2 rounded-xl flex items-center gap-1.5 transition-all active:scale-95 shadow-md shadow-fuchsia-500/20 shrink-0 cursor-pointer"
            >
              <Plus className={`w-3.5 h-3.5 text-white transition-transform duration-300 ${showForm ? 'rotate-45' : ''}`} />
              <span>{showForm ? 'انصراف' : 'افزودن آهنگ'}</span>
            </button>
          </div>
        </div>

        {/* Add/Edit Song Form */}
        <AnimatePresence>
          {showForm && (
            <motion.div 
              ref={formRef}
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="mt-6 relative z-10 pt-4 border-t border-rose-100"
            >
              <form onSubmit={handleSave} className="space-y-4">
                {editingId && (
                  <div className="text-fuchsia-600 text-xs font-black flex items-center gap-2 pb-1">
                    <span className="w-2 h-2 rounded-full bg-fuchsia-500 animate-pulse" />
                    <Edit3 className="w-3.5 h-3.5 text-fuchsia-600 shrink-0" />
                    <span>در حال ویرایش آهنگ: {title || 'بدون عنوان'}</span>
                  </div>
                )}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-extrabold text-slate-700 mb-1">نام آهنگ:</label>
                    <input 
                      type="text" 
                      placeholder="مثلا: چشمای تو" 
                      required 
                      value={title} 
                      onChange={e => setTitle(e.target.value)}
                      className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm focus:border-rose-400 focus:outline-none transition-all" 
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-extrabold text-slate-700 mb-1">خواننده / هنرمند:</label>
                    <input 
                      type="text" 
                      placeholder="مثلا: شادمهر عقیلی / پیانو بی‌کلام" 
                      value={artist} 
                      onChange={e => setArtist(e.target.value)}
                      className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm focus:border-rose-400 focus:outline-none transition-all" 
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-extrabold text-slate-700 mb-1">لینک فایل فایل صوتی یا آپلود مستقیم:</label>
                  <div className="flex gap-2">
                    <input 
                      type="url" 
                      placeholder="https://..." 
                      required 
                      value={url} 
                      onChange={e => setUrl(e.target.value)}
                      className="flex-1 min-w-0 bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm focus:border-rose-400 focus:outline-none text-left transition-all" 
                      dir="ltr" 
                    />
                    <button
                      type="button"
                      onClick={() => audioFileInputRef.current?.click()}
                      className="bg-stone-100 text-slate-700 font-extrabold text-xs px-3 py-2 rounded-xl flex items-center gap-1.5 hover:bg-stone-200 transition-colors shrink-0"
                    >
                      <Upload className="w-3.5 h-3.5 text-rose-500" />
                      <span>انتخاب فایل</span>
                    </button>
                  </div>
                  <input 
                    type="file" 
                    ref={audioFileInputRef} 
                    onChange={handleAudioFileUpload} 
                    accept="audio/*" 
                    className="hidden" 
                  />
                </div>

                <div className="flex justify-end gap-2 pt-1">
                  <button 
                    type="button" 
                    onClick={resetForm} 
                    className="flex items-center justify-center bg-slate-100 text-slate-600 text-xs px-3.5 py-2 rounded-xl font-bold hover:bg-slate-200 transition-colors"
                  >
                    انصراف
                  </button>
                  <button 
                    type="submit" 
                    className="flex items-center justify-center bg-gradient-to-r from-rose-500 to-pink-500 hover:from-rose-600 hover:to-pink-600 text-white text-xs font-bold px-4 py-2 rounded-xl transition-all shadow-md shadow-rose-500/20"
                  >
                    {editingId ? 'ذخیره تغییرات' : 'افزودن به پلی‌لیست'}
                  </button>
                </div>
              </form>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Playlist Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {sortedMusic.length === 0 ? (
          <div className="glass-card rounded-3xl p-10 text-center text-slate-500 text-xs flex flex-col items-center justify-center gap-3 col-span-full border border-dashed border-rose-200">
            <div className="w-12 h-12 rounded-full bg-rose-50 flex items-center justify-center text-rose-400">
              <Disc className="w-6 h-6" />
            </div>
            <p className="font-extrabold text-slate-700 text-base">هنوز آهنگی اضافه نشده است</p>
            <p className="text-xs text-slate-400">با زدن دکمه «افزودن آهنگ جدید» اولین موزیک عاشقانه را اضافه کنید.</p>
          </div>
        ) : (
          displayedMusic.map((song) => (
            <motion.div 
              layout 
              key={song.id} 
              className={`p-3.5 sm:p-4 rounded-2xl transition-all duration-300 relative flex items-center justify-between group shadow-2xs hover:shadow-xs ${
                song.pinned 
                  ? 'bg-[#fffafb] border-2 border-rose-200/90' 
                  : 'bg-white border border-stone-200/80'
              }`}
            >
              <div className="flex items-center gap-2.5 flex-1 min-w-0 pr-1">
                <button 
                  onClick={() => handlePlaySong(song.id)}
                  className={`w-8 h-8 rounded-xl flex items-center justify-center transition-all shrink-0 active:scale-90 shadow-2xs cursor-pointer ${
                    song.pinned 
                      ? 'bg-rose-500 hover:bg-rose-600 text-white' 
                      : 'bg-stone-900 hover:bg-rose-600 text-white'
                  }`}
                  title="پخش آهنگ"
                >
                  <Play className="w-3.5 h-3.5 fill-white ml-0.5" />
                </button>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <h3 className={`font-black text-xs sm:text-base truncate ${
                      song.pinned ? 'text-rose-950' : 'text-stone-900'
                    }`}>
                      {song.title}
                    </h3>
                    {song.pinned && (
                      <span className="inline-flex items-center gap-1 bg-rose-50 border border-rose-200 text-rose-700 text-[10px] font-black px-2 py-0.5 rounded-full shadow-2xs">
                        <Star className="w-2.5 h-2.5 fill-rose-500 text-rose-500" />
                        <span>برگزیده</span>
                      </span>
                    )}
                  </div>
                  <p className={`text-[11px] font-bold truncate mt-0.5 ${
                    song.pinned ? 'text-rose-700' : 'text-stone-500'
                  }`}>{song.artist}</p>
                </div>
              </div>

              <div className="flex items-center gap-1 shrink-0">
                {song.url && (
                  <a 
                    href={song.url} 
                    target="_blank" 
                    rel="noreferrer" 
                    className="p-2 rounded-xl text-stone-400 hover:text-stone-700 hover:bg-stone-100 transition-colors" 
                    title="لینک فایل صوتی"
                  >
                    <ExternalLink className="w-4 h-4" />
                  </a>
                )}

                <KebabMenu>
                  <KebabMenuItem 
                    icon={<Play className="w-4 h-4 text-rose-500" />} 
                    label="پخش آنلاین" 
                    onClick={() => handlePlaySong(song.id)} 
                  />
                  <KebabMenuItem 
                    icon={<Star className={`w-4 h-4 ${song.pinned ? 'text-rose-500 fill-rose-500' : 'text-slate-400'}`} />} 
                    label={song.pinned ? 'برداشتن نشان برتر' : 'نشان کردن به عنوان برتر'} 
                    onClick={() => updateMusic({ ...song, pinned: !song.pinned })} 
                  />
                  <KebabMenuItem 
                    icon={<Edit3 className="w-4 h-4 text-slate-500" />} 
                    label="ویرایش" 
                    onClick={() => handleEdit(song)} 
                  />
                  <KebabMenuItem 
                    icon={<Trash2 className="w-4 h-4 text-rose-500" />} 
                    label="حذف" 
                    danger 
                    onClick={() => removeMusic(song.id)} 
                  />
                </KebabMenu>
              </div>
            </motion.div>
          ))
        )}
      </div>

      {/* Pagination Controls */}
      {sortedMusic.length > 6 && (
        <div className="flex justify-center gap-3 mt-6">
          {hasMore && (
            <button 
              onClick={() => setShowCount(c => c + 6)} 
              className="bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 transition-colors px-6 py-2 rounded-full font-bold text-xs flex items-center gap-2 shadow-2xs active:scale-95"
            >
              <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500" />
              <span>نمایش بیشتر ({sortedMusic.length - showCount})</span>
            </button>
          )}
          {hasLess && (
            <button 
              onClick={() => setShowCount(6)} 
              className="bg-white border border-slate-200 hover:bg-slate-50 text-slate-600 transition-colors px-6 py-2 rounded-full font-bold text-xs flex items-center gap-2 shadow-2xs active:scale-95"
            >
              <span>نمایش کمتر</span>
            </button>
          )}
        </div>
      )}
    </div>
    </PageWrapper>
  );
};
