import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { 
  Sparkles, Heart, ArrowLeft, RefreshCw, 
  Camera
} from 'lucide-react';
import { useStore } from '../lib/store';
import { NavLink } from 'react-router';
import { motion } from 'motion/react';
import { PageWrapper } from '../components/PageWrapper';
import { ModernLoveTimer } from '../components/ModernLoveTimer';
import { dedupById } from '../lib/dedup';

export const Home: React.FC = () => {
  const { memories } = useStore();
  const uniqueMemories = useMemo(() => dedupById(memories), [memories]);

  // Daily Spotlight Memory: selects a random memory per 24 hours (Tehran timezone)
  const [spotlightMemoryId, setSpotlightMemoryId] = useState<string | null>(null);

  const selectDailyMemory = useCallback((forceNew = false) => {
    if (uniqueMemories.length === 0) {
      setSpotlightMemoryId(null);
      return;
    }

    const todayStr = new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Tehran' });
    const storageKeyDate = 'loveniya_daily_memory_date';
    const storageKeyId = 'loveniya_daily_memory_id';

    const savedDate = localStorage.getItem(storageKeyDate);
    const savedId = localStorage.getItem(storageKeyId);

    if (!forceNew && savedDate === todayStr && savedId && uniqueMemories.some(m => m.id === savedId)) {
      setSpotlightMemoryId(savedId);
      return;
    }

    const availablePool = uniqueMemories.length > 1 && savedId
      ? uniqueMemories.filter(m => m.id !== savedId)
      : uniqueMemories;

    const chosen = availablePool[Math.floor(Math.random() * availablePool.length)];
    if (chosen) {
      localStorage.setItem(storageKeyDate, todayStr);
      localStorage.setItem(storageKeyId, chosen.id);
      setSpotlightMemoryId(chosen.id);
    }
  }, [uniqueMemories]);

  useEffect(() => {
    selectDailyMemory(false);
  }, [selectDailyMemory]);

  const currentSpotlightMemory = memories.find(m => m.id === spotlightMemoryId) || (uniqueMemories.length > 0 ? uniqueMemories[0] : null);

  // Reason Generator
  const reasons = [
    "چون با یه لبخندت کل روزم ساخته میشه.",
    "چون امن‌ترین پناهگاه دنیا بغل توئه.",
    "چون هر روز بیشتر از دیروز دلم برات ضعف میره.",
    "چون وقتی صدام می‌کنی، قشنگ‌ترین اسم دنیا رو دارم.",
    "چون تو تنها کسی هستی که دیوونه‌بازیامو درک میکنی.",
    "چون خنده‌هات قشنگ‌ترین موسیقی دنیاست.",
    "چون با تو، ساده‌ترین لحظه‌ها هم رویاییه.",
    "چون صدای نفس‌هات بهم آرامش بی‌نهایت میده.",
    "چون برق چشمات امید به آینده رو توی دلم زنده نگه می‌داره.",
    "چون تو دقیقاً همونی هستی که همیشه آرزوشو داشتم."
  ];
  const [reason, setReason] = useState("چون تو تنها کسی هستی که دیوونه‌بازیامو درک میکنی.");
  const [isRotatingReason, setIsRotatingReason] = useState(false);

  const showReason = () => {
    setIsRotatingReason(true);
    let newReason = reason;
    while (newReason === reason) {
      newReason = reasons[Math.floor(Math.random() * reasons.length)];
    }
    setTimeout(() => {
      setReason(newReason);
      setIsRotatingReason(false);
    }, 200);
  };

  return (
    <PageWrapper>
      <div className="space-y-4 max-w-2xl mx-auto px-2 sm:px-4" dir="rtl">
        
        {/* Title & Badge Header */}
        <section className="text-center pt-1 pb-0.5">
          <motion.div 
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-3xl p-4 sm:p-5 border border-rose-200/80 shadow-2xs relative overflow-hidden"
          >
            <div className="inline-flex items-center gap-1.5 text-rose-700 text-xs sm:text-sm font-black tracking-wide mb-1.5 bg-rose-50 px-3 py-1 rounded-full border border-rose-100">
              <Heart className="w-3.5 h-3.5 fill-rose-500 text-rose-500 shrink-0" />
              <span>پناهگاه اختصاصی امین و نیایش</span>
            </div>

            <h1 className="text-xl sm:text-2xl md:text-3xl font-black text-stone-900 tracking-tight">
              جهان عاشقانمون
            </h1>
          </motion.div>
        </section>

        {/* Modern Romantic Love Timer */}
        <ModernLoveTimer />

        {/* Memory Spotlight (24-Hour Random Memory Rotation) */}
        {currentSpotlightMemory && (
          <motion.section 
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: 0.1 }}
            className="bg-white rounded-3xl p-4 sm:p-5 text-center border border-stone-200/90 shadow-2xs relative overflow-hidden"
          >
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-xs sm:text-sm font-black text-pink-600 flex items-center gap-1.5 tracking-tight">
                <Camera className="w-3.5 h-3.5 text-pink-500" />
                <span>یادآوری خاطره امروز</span>
              </h2>

              {uniqueMemories.length > 1 && (
                <button
                  type="button"
                  onClick={() => selectDailyMemory(true)}
                  className="text-xs font-bold text-stone-500 hover:text-pink-600 flex items-center gap-1 cursor-pointer transition-colors"
                  title="مشاهده یک خاطره تصادفی دیگر"
                >
                  <RefreshCw className="w-3 h-3 text-pink-500" />
                  <span>خاطره دیگر</span>
                </button>
              )}
            </div>

            {/* Photo Thumbnail */}
            {((currentSpotlightMemory.photos && currentSpotlightMemory.photos.length > 0) || currentSpotlightMemory.mediaData) && (
              <div className="mx-auto mb-3 max-w-[240px] aspect-4/3 rounded-2xl overflow-hidden shadow-2xs bg-stone-100">
                <img
                  src={currentSpotlightMemory.photos?.[0] || currentSpotlightMemory.mediaData}
                  alt={currentSpotlightMemory.title}
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
              </div>
            )}

            <p className="text-base sm:text-lg font-extrabold text-stone-900 mb-0.5">{currentSpotlightMemory.title}</p>
            <p className="text-xs text-stone-400 mb-2 font-bold">{currentSpotlightMemory.date}</p>
            
            {currentSpotlightMemory.desc && (
              <p className="text-xs sm:text-sm text-stone-600 line-clamp-2 max-w-md mx-auto mb-3.5 leading-relaxed font-medium">
                {currentSpotlightMemory.desc}
              </p>
            )}

            <NavLink 
              to={`/memories?id=${currentSpotlightMemory.id}`}
              state={{ memoryId: currentSpotlightMemory.id }}
              className="bg-gradient-to-r from-rose-500 to-pink-500 hover:from-rose-600 hover:to-pink-600 text-white px-4 py-2 min-h-[44px] rounded-xl text-xs font-bold transition-all inline-flex items-center gap-1.5 active:scale-95 shadow-md shadow-pink-500/15"
            >
              <span>مرور این خاطره و آلبوم</span>
              <ArrowLeft className="w-3.5 h-3.5 text-white" />
            </NavLink>
          </motion.section>
        )}

        {/* Reason Generator */}
        <motion.section 
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.15 }}
          className="bg-white rounded-3xl p-4 sm:p-5 text-center border border-stone-200/90 shadow-2xs relative overflow-hidden"
        >
          <div className="flex flex-col items-center gap-0.5 mb-1">
            <div className="inline-flex items-center gap-1.5 text-rose-600 text-xs sm:text-sm font-black">
              <Sparkles className="w-3.5 h-3.5 text-rose-500 fill-pink-300" />
              <span>چرا عاشقتم؟</span>
            </div>
            <p className="text-xs text-stone-400 font-bold">یک یادآوری دلی از طرف امین</p>
          </div>

          <div className="my-4 min-h-[56px] flex items-center justify-center px-4 bg-rose-50/50 rounded-2xl border border-rose-100/60 p-3">
            <p className={`text-xs sm:text-sm text-stone-800 font-extrabold leading-relaxed text-center transition-opacity duration-200 ${isRotatingReason ? 'opacity-0' : 'opacity-100'}`}>
              « {reason} »
            </p>
          </div>

          <button 
            onClick={showReason} 
            className="bg-stone-900 hover:bg-stone-800 text-white text-xs font-bold px-4 py-2 min-h-[44px] rounded-xl transition-all inline-flex items-center gap-1.5 active:scale-95 shadow-2xs cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-rose-400 ${isRotatingReason ? 'animate-spin' : ''}`} />
            <span>یک دلیل دیگر</span>
          </button>
        </motion.section>

      </div>
    </PageWrapper>
  );
};

export default Home;
