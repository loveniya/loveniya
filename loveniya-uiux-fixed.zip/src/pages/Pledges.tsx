import { PageWrapper } from "../components/PageWrapper";
import React, { useState } from 'react';
import { HeartHandshake, Plus, Star, Trash2, Edit3, X, Heart, Loader2, Sparkles } from 'lucide-react';
import { useStore } from '../lib/store';
import { Pledge } from '../lib/types';
import { KebabMenu, KebabMenuItem } from '../components/KebabMenu';
import { motion, AnimatePresence } from 'motion/react';
import { fetchLoveAI } from '../lib/ai';
import { usePledgeDraft } from '../lib/draftStore';
import { dedupById } from '../lib/dedup';

export const Pledges: React.FC = () => {
  const { pledges, addPledge, updatePledge, removePledge } = useStore();
  const { draft, setDraft, resetDraft } = usePledgeDraft();
  
  const showForm = draft.showForm;
  const editingId = draft.editingId;
  const text = draft.text;
  const author = draft.author || 'mutual';

  const [activePledge, setActivePledge] = useState<Pledge | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const formRef = React.useRef<HTMLDivElement>(null);

  // Keep activePledge in sync with any updates or removals
  React.useEffect(() => {
    if (activePledge) {
      const fresh = pledges.find(p => p.id === activePledge.id);
      if (fresh) {
        setActivePledge(fresh);
      } else {
        setActivePledge(null);
      }
    }
  }, [pledges]);

  const getAuthorBadge = (authorKey?: string) => {
    if (authorKey === 'amin') {
      return (
        <span className="inline-flex items-center gap-1 text-blue-800 text-[10px] font-extrabold bg-blue-50 px-2.5 py-0.5 rounded-full border border-blue-200">
          <Heart className="w-3 h-3 text-blue-600" />
          <span>قول امین به نیایش</span>
        </span>
      );
    }
    if (authorKey === 'niyayesh') {
      return (
        <span className="inline-flex items-center gap-1 text-rose-800 text-[10px] font-extrabold bg-rose-50 px-2.5 py-0.5 rounded-full border border-rose-200">
          <Heart className="w-3 h-3 text-rose-600" />
          <span>قول نیایش به امین</span>
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 text-purple-800 text-[10px] font-extrabold bg-purple-50 px-2.5 py-0.5 rounded-full border border-purple-200">
        <HeartHandshake className="w-3 h-3 text-purple-600" />
        <span>عهد دونفره</span>
      </span>
    );
  };

  const handleEdit = (plg: Pledge) => {
    setActivePledge(null);
    setDraft({
      editingId: plg.id,
      text: plg.text,
      author: plg.author || 'mutual',
      showForm: true
    });
    setTimeout(() => {
      formRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 120);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSaving || !text.trim()) return;

    setIsSaving(true);
    try {
      let finalText = text;

      if (editingId) {
        const existing = pledges.find(p => p.id === editingId);
        if (existing) {
          updatePledge({
            ...existing,
            text: finalText,
            author: author
          });
        }
      } else {
        const newPledge: Pledge = {
          id: `pledge_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
          text: finalText,
          date: new Date().toLocaleDateString('fa-IR', { timeZone: 'Asia/Tehran' }),
          pinned: false,
          author: author
        };
        addPledge(newPledge);
      }
      resetForm();
    } finally {
      setIsSaving(false);
    }
  };

  const resetForm = () => {
    resetDraft();
  };

  const [showCount, setShowCount] = useState(4);

  // Deduplicate and sort pledges: pinned ones first
  const uniquePledges = React.useMemo(() => dedupById(pledges), [pledges]);
  const sortedPledges = React.useMemo(() => {
    return [...uniquePledges].sort((a, b) => {
      if (a.pinned && !b.pinned) return -1;
      if (!a.pinned && b.pinned) return 1;
      return 0;
    });
  }, [uniquePledges]);

  const displayedPledges = sortedPledges.slice(0, showCount);
  const hasMore = showCount < sortedPledges.length;
  const hasLess = showCount > 4;

  return (
    <PageWrapper>
      <AnimatePresence mode="wait">
        {activePledge ? (
        <motion.div 
          key="detail"
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: -20 }}
          transition={{ type: "spring", stiffness: 300, damping: 30 }}
          className="space-y-6 pb-6 w-full" dir="rtl"
        >
          <div className="glass-card rounded-3xl p-4 sm:p-6 md:p-10 relative overflow-hidden shadow-2xl bg-white/95 border-2 border-purple-100">
            <div className="flex justify-between items-start mb-6 border-b border-purple-100 pb-4 sm:pb-6">
              <div>
                <h2 className="text-xl md:text-3xl font-black text-purple-600 flex items-center gap-2 mb-1.5">
                  <HeartHandshake className="w-5 h-5 sm:w-7 sm:h-7 text-purple-500 shrink-0" /> عهد عاشقانه
                </h2>
                <div className="text-xs md:text-sm text-slate-500 font-bold flex items-center gap-2 flex-wrap mt-1">
                   <span>تاریخ ثبت: {activePledge.date}</span>
                   {activePledge.pinned && (
                     <span className="inline-flex items-center gap-1 bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full text-[10px] font-extrabold">
                       <Star className="w-3 h-3 fill-amber-500 text-amber-500" /> عهد برتر
                     </span>
                   )}
                   {getAuthorBadge(activePledge.author)}
                </div>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <button 
                  onClick={() => handleEdit(activePledge)}
                  className="text-slate-600 hover:text-purple-600 bg-purple-50 hover:bg-purple-100 px-3 py-1.5 rounded-xl font-bold text-xs transition-colors flex items-center gap-1.5"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>ویرایش</span>
                </button>
                <button onClick={() => setActivePledge(null)} className="text-slate-400 hover:text-purple-500 bg-slate-50 p-2 rounded-full transition-colors shrink-0">
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="whitespace-pre-wrap text-base sm:text-lg md:text-xl font-black text-slate-700 leading-relaxed sm:leading-[2.5] mb-6 sm:mb-10 text-center px-2 sm:px-4"
            >
              "{activePledge.text}"
            </motion.div>
          </div>
        </motion.div>
      ) : (
        <motion.div 
          key="list"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          transition={{ type: "spring", stiffness: 300, damping: 30 }}
          className="space-y-6 w-full" dir="rtl"
        >
          {/* Layer 2: Independent Header Banner */}
          <div className="bg-white/95 rounded-3xl p-5 sm:p-7 relative overflow-hidden shadow-xl shadow-purple-900/5">
            <div className="absolute inset-0 overflow-hidden rounded-3xl pointer-events-none">
              <div className="absolute top-0 left-0 w-64 h-64 bg-purple-100/40 rounded-full blur-3xl"></div>
              <div className="absolute bottom-0 right-0 w-64 h-64 bg-fuchsia-100/30 rounded-full blur-3xl"></div>
            </div>

            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 relative z-10">
              <div className="flex items-center gap-3.5">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-purple-500 to-fuchsia-500 text-white flex items-center justify-center shadow-md shadow-purple-500/20 shrink-0">
                  <HeartHandshake className="w-6 h-6" />
                </div>
                <div>
                  <h2 className="text-lg sm:text-xl font-black text-slate-800 flex items-center gap-2">
                    <span>عهدهای عاشقانه</span>
                  </h2>
                  <p className="text-xs text-slate-500 font-bold mt-0.5">
                    قول‌هایی که به همدیگه دادیم و هیچ‌وقت یادمون نمیره
                  </p>
                </div>
              </div>
              <button 
                onClick={() => {
                  if (showForm) {
                    resetForm();
                  } else {
                    setDraft({ showForm: true });
                  }
                }} 
                className="bg-gradient-to-r from-purple-600 to-fuchsia-600 hover:from-purple-700 hover:to-fuchsia-700 text-white text-xs font-bold px-4 py-2 rounded-xl flex items-center gap-1.5 transition-all active:scale-95 shadow-md shadow-purple-500/20 shrink-0 justify-center"
              >
                <Plus className={`w-3.5 h-3.5 text-white transition-transform duration-300 ${showForm ? 'rotate-45' : ''}`} />
                <span>{showForm ? 'انصراف' : 'ثبت عهد جدید'}</span>
              </button>
            </div>

            {/* Add/Edit Form */}
            <AnimatePresence>
              {showForm && (
                <motion.div 
                  ref={formRef}
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="mt-6 relative z-10 pt-4 border-t border-purple-100"
                >
                  <form onSubmit={handleSave} className="space-y-4">
                    {editingId && (
                      <div className="text-purple-600 text-xs font-black flex items-center gap-2 pb-1">
                        <span className="w-2 h-2 rounded-full bg-purple-500 animate-pulse" />
                        <Edit3 className="w-3.5 h-3.5 text-purple-600 shrink-0" />
                        <span>در حال ویرایش عهد عاشقانه</span>
                      </div>
                    )}
                    {/* Pledge Author Selection */}
                    <div>
                      <label className="block text-xs font-extrabold text-slate-700 mb-1.5">نوع قول و طرفین عهد:</label>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                        <button
                          type="button"
                          onClick={() => setDraft({ author: 'mutual' })}
                          className={`py-2.5 px-3 rounded-xl text-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                            author === 'mutual'
                              ? 'bg-purple-600 text-white font-black shadow-sm'
                              : 'bg-stone-100/80 text-stone-600 hover:text-stone-900 font-bold'
                          }`}
                        >
                          <HeartHandshake className="w-3.5 h-3.5" />
                          <span>عهد مشترک (دونفره)</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setDraft({ author: 'amin' })}
                          className={`py-2.5 px-3 rounded-xl text-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                            author === 'amin'
                              ? 'bg-blue-600 text-white font-black shadow-sm'
                              : 'bg-stone-100/80 text-stone-600 hover:text-stone-900 font-bold'
                          }`}
                        >
                          <Heart className="w-3 h-3" />
                          <span>قول امین به نیایش</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setDraft({ author: 'niyayesh' })}
                          className={`py-2.5 px-3 rounded-xl text-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                            author === 'niyayesh'
                              ? 'bg-rose-500 text-white font-black shadow-sm'
                              : 'bg-stone-100/80 text-stone-600 hover:text-stone-900 font-bold'
                          }`}
                        >
                          <Heart className="w-3 h-3" />
                          <span>قول نیایش به امین</span>
                        </button>
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-extrabold text-slate-700 mb-1.5">متن کامل قول یا عهد عاطفی:</label>
                      <textarea 
                        rows={4} 
                        placeholder="متن کامل قول‌مون رو بنویس..." 
                        required 
                        value={text} 
                        onChange={e => setDraft({ text: e.target.value })}
                        className="w-full bg-white border border-slate-200 rounded-xl p-3 text-sm focus:border-purple-400 focus:outline-none leading-relaxed transition-all"
                      ></textarea>
                    </div>
                    <div className="flex justify-end gap-2 pt-1">
                      <button 
                        type="button" 
                        onClick={resetForm} 
                        className="flex items-center justify-center bg-slate-100 text-slate-600 text-xs px-3.5 py-2 rounded-xl font-bold hover:bg-slate-200 transition-colors"
                      >
                        انصراف
                      </button>
                      <button 
                        type="submit" 
                        className="flex items-center justify-center bg-gradient-to-r from-purple-600 to-fuchsia-600 hover:from-purple-700 hover:to-fuchsia-700 text-white text-xs font-bold px-4 py-2 rounded-xl transition-all shadow-md shadow-purple-500/20"
                      >
                        {editingId ? 'ذخیره تغییرات' : 'ثبت قول'}
                      </button>
                    </div>
                  </form>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Layer 2: Pledges Cards directly on page */}
          <div className="space-y-4">
            {sortedPledges.length === 0 ? (
              <div className="bg-white rounded-3xl p-10 text-center text-slate-500 text-xs flex flex-col items-center justify-center gap-3 border border-dashed border-purple-200 shadow-2xs">
                <div className="w-12 h-12 rounded-full bg-purple-50 flex items-center justify-center text-purple-600">
                  <HeartHandshake className="w-6 h-6" />
                </div>
                <p className="font-extrabold text-slate-700 text-base">هنوز عهدی ثبت نشده...</p>
                <p className="text-xs text-slate-400">با زدن دکمه «ثبت عهد جدید» اولین قول عاشقانه را ثبت کن.</p>
              </div>
            ) : (
              displayedPledges.map((plg) => (
                <motion.div 
                  layout 
                  key={plg.id} 
                  onClick={() => setActivePledge(plg)} 
                  className={`cursor-pointer rounded-3xl transition-all duration-300 relative group ${
                    plg.pinned 
                      ? 'bg-[#fffafb] p-5 sm:p-6 shadow-2xs border-2 border-purple-200/90 hover:shadow-xs' 
                      : 'bg-white p-5 sm:p-6 shadow-2xs hover:shadow-xs border border-stone-200/80'
                  }`}
                >
                  {/* Card Top Header */}
                  <div className="flex justify-between items-center gap-2 mb-3">
                    <div className="flex items-center gap-2 flex-wrap min-w-0">
                      {plg.pinned && (
                        <span className="inline-flex items-center gap-1 bg-purple-50 border border-purple-200 text-purple-700 text-[10px] font-black px-2 py-0.5 rounded-full shadow-2xs">
                          <Star className="w-2.5 h-2.5 fill-purple-500 text-purple-500" />
                          <span>عهد برگزیده</span>
                        </span>
                      )}
                      <span className="text-[10px] text-stone-500 font-medium">
                        {plg.date}
                      </span>
                      {getAuthorBadge(plg.author)}
                    </div>
                    
                    <div className="flex items-center gap-2 shrink-0" onClick={e => e.stopPropagation()}>
                      <KebabMenu>
                        <KebabMenuItem 
                          icon={<Star className={`w-4 h-4 ${plg.pinned ? 'text-purple-500 fill-purple-500' : 'text-slate-400'}`} />} 
                          label={plg.pinned ? 'برداشتن نشان برتر' : 'نشان کردن به عنوان برتر'} 
                          onClick={() => updatePledge({ ...plg, pinned: !plg.pinned })} 
                        />
                        <KebabMenuItem 
                          icon={<Edit3 className="w-4 h-4 text-slate-500" />} 
                          label="ویرایش" 
                          onClick={() => handleEdit(plg)} 
                        />
                        <KebabMenuItem 
                          icon={<Trash2 className="w-4 h-4 text-rose-500" />} 
                          label="حذف" 
                          danger 
                          onClick={() => removePledge(plg.id)} 
                        />
                      </KebabMenu>
                    </div>
                  </div>

                  <p className={`text-base whitespace-pre-wrap leading-relaxed ${
                    plg.pinned ? 'text-stone-900 font-bold' : 'text-stone-800 font-medium'
                  }`}>
                    {plg.text}
                  </p>

                  <div className="flex justify-end items-center text-[10px] mt-3 pt-2.5 border-t border-slate-100 font-bold">
                    <span className={`transition-colors font-black text-[11px] ${
                      plg.pinned 
                        ? 'text-purple-700 group-hover:text-purple-900' 
                        : 'text-purple-700 group-hover:text-purple-900'
                    }`}>
                      مشاهده جزئیات ←
                    </span>
                  </div>
                </motion.div>
              ))
            )}
          </div>

          {sortedPledges.length > 4 && (
            <div className="flex justify-center gap-3 mt-6 relative z-10 pb-4">
              {hasMore && (
                <button onClick={() => setShowCount(c => c + 4)} className="bg-white/95 backdrop-blur-sm border border-purple-100 hover:bg-purple-50 text-purple-600 transition-all px-6 py-2.5 rounded-full font-bold text-xs flex items-center gap-2 shadow-sm active:scale-95">
                  <Heart className="w-4 h-4 text-purple-600 fill-purple-600" />
                  نمایش بیشتر ({sortedPledges.length - showCount})
                </button>
              )}
              {hasLess && (
                <button onClick={() => setShowCount(4)} className="bg-white/95 backdrop-blur-sm border border-slate-100 hover:bg-slate-50 text-slate-500 transition-all px-6 py-2.5 rounded-full font-bold text-xs flex items-center gap-2 shadow-sm active:scale-95">
                  نمایش کمتر
                </button>
              )}
            </div>
          )}
        </motion.div>
      )}
    </AnimatePresence>
    </PageWrapper>
  );
};

export default Pledges;
