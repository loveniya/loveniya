import { PageWrapper } from "../components/PageWrapper";
import React, { useState } from 'react';
import { Compass, Plus, Star, Trash2, Edit3, X, Heart, Sparkles } from 'lucide-react';
import { useStore } from '../lib/store';
import { Dream } from '../lib/types';
import { KebabMenu, KebabMenuItem } from '../components/KebabMenu';
import { motion, AnimatePresence } from 'motion/react';
import { useDreamDraft } from '../lib/draftStore';
import { dedupById } from '../lib/dedup';

export const Dreams: React.FC = () => {
  const { dreams, addDream, updateDream, removeDream } = useStore();
  const { draft, setDraft, resetDraft } = useDreamDraft();
  
  const showForm = draft.showForm;
  const editingId = draft.editingId;
  const text = draft.text;

  const [activeDream, setActiveDream] = useState<Dream | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const formRef = React.useRef<HTMLDivElement>(null);
  
  // Keep activeDream in sync
  React.useEffect(() => {
    if (activeDream) {
      const fresh = dreams.find(d => d.id === activeDream.id);
      if (fresh) {
        setActiveDream(fresh);
      } else {
        setActiveDream(null);
      }
    }
  }, [dreams]);

  const handleEdit = (dream: Dream) => {
    setActiveDream(null);
    setDraft({
      editingId: dream.id,
      text: dream.text,
      showForm: true
    });
    setTimeout(() => {
      formRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 120);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSaving || !text.trim()) return;

    setIsSaving(true);
    try {
      let finalText = text.trim();

      if (editingId) {
        const existing = dreams.find(d => d.id === editingId);
        if (existing) {
          updateDream({
            ...existing,
            text: finalText
          });
        }
      } else {
        const newDream: Dream = {
          id: `dream_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
          text: finalText,
          date: new Date().toLocaleDateString('fa-IR', { timeZone: 'Asia/Tehran' }),
          pinned: false
        };
        addDream(newDream);
      }
      resetForm();
    } finally {
      setIsSaving(false);
    }
  };

  const resetForm = () => {
    resetDraft();
  };

  const [showCount, setShowCount] = useState(4);

  // Deduplicate and sort dreams: pinned ones first
  const uniqueDreams = React.useMemo(() => dedupById(dreams), [dreams]);
  const sortedDreams = React.useMemo(() => {
    return [...uniqueDreams].sort((a, b) => {
      if (a.pinned && !b.pinned) return -1;
      if (!a.pinned && b.pinned) return 1;
      return 0;
    });
  }, [uniqueDreams]);

  const displayedDreams = sortedDreams.slice(0, showCount);
  const hasMore = showCount < sortedDreams.length;
  const hasLess = showCount > 4;

  return (
    <PageWrapper>
      <AnimatePresence mode="wait">
        {activeDream ? (
        <motion.div 
          key="detail"
          initial={{ opacity: 0, scale: 0.96, y: 12 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.96, y: -12 }}
          transition={{ duration: 0.25 }}
          className="space-y-6 pb-6 w-full" dir="rtl"
        >
          <div className="rounded-3xl p-5 sm:p-8 relative overflow-hidden bg-white border border-stone-200/90 shadow-sm">
            <div className="flex justify-between items-start mb-6 border-b border-stone-100 pb-4 sm:pb-6">
              <div>
                <h2 className="text-xl md:text-2xl font-black text-stone-900 flex items-center gap-2 mb-1.5">
                  <div className="w-8 h-8 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center border border-rose-100">
                    <Compass className="w-4.5 h-4.5" />
                  </div>
                  <span>آرزوی مشترک ما</span>
                </h2>
                <p className="text-xs text-stone-400 font-bold flex items-center gap-1.5">
                   <span>تاریخ ثبت: {activeDream.date}</span>
                   {activeDream.pinned && (
                     <span className="inline-flex items-center gap-1 bg-amber-50 text-amber-700 px-2 py-0.5 rounded-full mr-2 text-[10px] border border-amber-200/60 font-black">
                       <Star className="w-3 h-3 fill-amber-400 text-amber-500" /> آرزوی برتر
                     </span>
                   )}
                </p>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <button 
                  onClick={() => handleEdit(activeDream)}
                  className="text-stone-700 hover:text-stone-900 bg-stone-100 hover:bg-stone-200 px-3 py-1.5 rounded-xl font-bold text-xs transition-colors flex items-center gap-1.5"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>ویرایش</span>
                </button>
                <button 
                  onClick={() => setActiveDream(null)} 
                  className="text-stone-400 hover:text-stone-800 bg-stone-100 p-2 rounded-xl transition-colors shrink-0"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            <motion.div 
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.15 }}
              className="whitespace-pre-wrap text-base sm:text-lg font-black text-stone-800 leading-relaxed sm:leading-loose mb-6 text-center px-3 sm:px-6"
            >
              « {activeDream.text} »
            </motion.div>
          </div>
        </motion.div>
      ) : (
        <motion.div 
          key="list"
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -8 }}
          transition={{ duration: 0.25 }}
          className="space-y-5 w-full" dir="rtl"
        >
          {/* Top Banner Header */}
          <div className="bg-white/95 rounded-3xl p-5 sm:p-6 relative overflow-hidden shadow-xl shadow-sky-900/5">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 relative z-10">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-sky-500 to-cyan-500 text-white flex items-center justify-center shadow-md shadow-sky-500/20 shrink-0">
                  <Compass className="w-5.5 h-5.5 text-white" />
                </div>
                <div>
                  <h2 className="text-base sm:text-lg font-black text-slate-800 flex items-center gap-2">
                    <span>آرزوها و رویاهای مشترک</span>
                    <Sparkles className="w-3.5 h-3.5 text-sky-500 fill-sky-300" />
                  </h2>
                  <p className="text-xs text-slate-500 font-bold mt-0.5">
                    برنامه‌ها، سفرها و هدف‌هایی که باهم بهشون می‌رسیم
                  </p>
                </div>
              </div>

              <button 
                onClick={() => {
                  if (showForm) {
                    resetForm();
                  } else {
                    setDraft({ showForm: true });
                  }
                }} 
                className="bg-gradient-to-r from-sky-500 to-cyan-500 hover:from-sky-600 hover:to-cyan-600 text-white text-sm font-bold px-5 py-3 rounded-2xl flex items-center gap-2 transition-all active:scale-95 shadow-md shadow-sky-500/20 shrink-0 self-stretch sm:self-auto justify-center cursor-pointer"
              >
                <Plus className={`w-4 h-4 text-white transition-transform duration-300 ${showForm ? 'rotate-45' : ''}`} />
                <span>{showForm ? 'انصراف' : 'ثبت آرزوی جدید'}</span>
              </button>
            </div>

            {/* Add/Edit Form */}
            <AnimatePresence>
              {showForm && (
                <motion.div 
                  ref={formRef}
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="mt-5 relative z-10 pt-4 border-t border-stone-100"
                >
                  <form onSubmit={handleSave} className="space-y-3.5">
                    {editingId && (
                      <div className="text-sky-600 text-xs font-black flex items-center gap-2 pb-1">
                        <span className="w-2 h-2 rounded-full bg-sky-500 animate-pulse" />
                        <Edit3 className="w-3.5 h-3.5 text-sky-600 shrink-0" />
                        <span>در حال ویرایش آرزوی مشترک</span>
                      </div>
                    )}
                    <div>
                      <label className="block text-xs font-black text-stone-700 mb-1.5">متن آرزو یا هدف مشترک ما:</label>
                      <textarea 
                        rows={3} 
                        placeholder="مثلاً: یه سفر دوتایی به شمال بریم و طلوع آفتاب رو باهم ببینیم..." 
                        required 
                        value={text} 
                        onChange={e => setDraft({ text: e.target.value })}
                        className="w-full bg-stone-50 border border-stone-200 rounded-xl p-3 text-xs focus:bg-white focus:border-rose-400 focus:outline-none leading-relaxed transition-all text-stone-900"
                      ></textarea>
                    </div>
                    <div className="flex justify-end gap-2">
                      <button 
                        type="button" 
                        onClick={resetForm} 
                        className="bg-stone-100 text-stone-600 text-xs px-4 py-2 rounded-xl font-bold hover:bg-stone-200 transition-colors"
                      >
                        انصراف
                      </button>
                      <button 
                        type="submit" 
                        className="bg-stone-900 hover:bg-stone-800 text-white text-xs font-bold px-5 py-2 rounded-xl transition-all shadow-xs"
                      >
                        {editingId ? 'ذخیره تغییرات' : 'ثبت آرزو'}
                      </button>
                    </div>
                  </form>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Dreams Cards */}
          <div className="space-y-3">
            {sortedDreams.length === 0 ? (
              <div className="bg-white rounded-3xl p-8 text-center text-stone-500 text-xs flex flex-col items-center justify-center gap-2.5 border border-dashed border-stone-200">
                <div className="w-10 h-10 rounded-2xl bg-stone-100 flex items-center justify-center text-stone-400">
                  <Compass className="w-5 h-5" />
                </div>
                <p className="font-black text-stone-700 text-sm">هنوز رویایی ثبت نشده...</p>
                <p className="text-xs text-stone-400">با زدن دکمه «ثبت آرزوی جدید» اولین رویای مشترک زندگیمون رو ثبت کن.</p>
              </div>
            ) : (
              displayedDreams.map((dream) => (
                <motion.div 
                  layout 
                  key={dream.id} 
                  onClick={() => setActiveDream(dream)} 
                  className={`cursor-pointer rounded-3xl transition-all duration-300 relative group ${
                    dream.pinned 
                      ? 'bg-[#fffafb] p-4 sm:p-5 shadow-2xs border-2 border-rose-200/90 hover:shadow-xs' 
                      : 'bg-white p-4 sm:p-5 shadow-2xs hover:shadow-xs border border-stone-200/80'
                  }`}
                >
                  <div className="flex justify-between items-center gap-2 mb-2.5">
                    <div className="flex items-center gap-2 flex-wrap min-w-0">
                      {dream.pinned && (
                        <span className="inline-flex items-center gap-1 bg-rose-50 border border-rose-200 text-rose-700 text-[10px] font-black px-2 py-0.5 rounded-full shadow-2xs">
                          <Star className="w-2.5 h-2.5 fill-rose-500 text-rose-500" />
                          <span>رویای برگزیده</span>
                        </span>
                      )}
                      <span className="text-[10px] text-stone-500 font-medium">
                        {dream.date}
                      </span>
                    </div>
                    
                    <div className="flex items-center gap-1 shrink-0" onClick={e => e.stopPropagation()}>
                      <KebabMenu>
                        <KebabMenuItem 
                          icon={<Star className={`w-4 h-4 ${dream.pinned ? 'text-amber-500 fill-amber-500' : 'text-stone-400'}`} />} 
                          label={dream.pinned ? 'برداشتن نشان برتر' : 'نشان کردن به عنوان برتر'} 
                          onClick={() => updateDream({ ...dream, pinned: !dream.pinned })} 
                        />
                        <KebabMenuItem 
                          icon={<Edit3 className="w-4 h-4 text-stone-500" />} 
                          label="ویرایش" 
                          onClick={() => handleEdit(dream)} 
                        />
                        <KebabMenuItem 
                          icon={<Trash2 className="w-4 h-4 text-rose-500" />} 
                          label="حذف" 
                          danger 
                          onClick={() => removeDream(dream.id)} 
                        />
                      </KebabMenu>
                    </div>
                  </div>

                  <p className="text-sm whitespace-pre-wrap leading-relaxed text-stone-800 font-bold mb-3">
                    {dream.text}
                  </p>

                  <div className="flex justify-end text-[10px] pt-2.5 border-t border-stone-100 font-bold">
                    <span className="text-rose-600 group-hover:text-rose-700 font-black text-[11px] transition-colors">
                      مشاهده جزئیات ←
                    </span>
                  </div>
                </motion.div>
              ))
            )}
          </div>

          {sortedDreams.length > 4 && (
            <div className="flex justify-center gap-3 mt-5 relative z-10 pb-4">
              {hasMore && (
                <button 
                  onClick={() => setShowCount(c => c + 4)} 
                  className="bg-white border border-stone-200 hover:bg-stone-50 text-stone-700 transition-all px-5 py-2 rounded-full font-bold text-xs flex items-center gap-2 shadow-2xs active:scale-95"
                >
                  <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500" />
                  <span>نمایش بیشتر ({sortedDreams.length - showCount})</span>
                </button>
              )}
              {hasLess && (
                <button 
                  onClick={() => setShowCount(4)} 
                  className="bg-white border border-stone-200 hover:bg-stone-50 text-stone-500 transition-all px-5 py-2 rounded-full font-bold text-xs flex items-center gap-2 shadow-2xs active:scale-95"
                >
                  <span>نمایش کمتر</span>
                </button>
              )}
            </div>
          )}
        </motion.div>
      )}
    </AnimatePresence>
    </PageWrapper>
  );
};
