import React, { useState, useEffect } from 'react';
import { 
  JALALI_MONTH_NAMES, 
  parseDateToJalali, 
  jalaliToIso, 
  getTehranJalaliNow,
  formatJalaliReadable 
} from '../lib/jalali';
import { Calendar as CalendarIcon, Clock, ChevronDown } from 'lucide-react';

interface PersianDateTimePickerProps {
  value: string;
  onChange: (isoString: string) => void;
  required?: boolean;
}

export const PersianDateTimePicker: React.FC<PersianDateTimePickerProps> = ({
  value,
  onChange
}) => {
  const currentNow = getTehranJalaliNow();
  
  // Parse initial state or fallback to tomorrow 20:00
  const initial = value ? parseDateToJalali(value) : {
    jy: currentNow.jy,
    jm: currentNow.jm,
    jd: Math.min(28, currentNow.jd + 1),
    hour: 20,
    minute: 0
  };

  const [jy, setJy] = useState<number>(initial.jy);
  const [jm, setJm] = useState<number>(initial.jm);
  const [jd, setJd] = useState<number>(initial.jd);
  const [hour, setHour] = useState<number>(initial.hour);
  const [minute, setMinute] = useState<number>(initial.minute);

  // Sync state when incoming prop changes
  useEffect(() => {
    if (value) {
      const parsed = parseDateToJalali(value);
      setJy(parsed.jy);
      setJm(parsed.jm);
      setJd(parsed.jd);
      setHour(parsed.hour);
      setMinute(parsed.minute);
    }
  }, [value]);

  // Update parent when any part changes
  const emitChange = (newJy: number, newJm: number, newJd: number, newH: number, newM: number) => {
    let maxDays = 30;
    if (newJm <= 6) maxDays = 31;
    else if (newJm === 12) maxDays = 29;

    const validatedDay = Math.min(newJd, maxDays);
    setJy(newJy);
    setJm(newJm);
    setJd(validatedDay);
    setHour(newH);
    setMinute(newM);

    const iso = jalaliToIso(newJy, newJm, validatedDay, newH, newM);
    onChange(iso);
  };

  // Preset handlers
  const applyPreset = (preset: 'tomorrow' | 'week' | 'month') => {
    const now = new Date();
    const target = new Date(now);

    if (preset === 'tomorrow') {
      target.setDate(target.getDate() + 1);
      target.setHours(20, 0, 0, 0);
    } else if (preset === 'week') {
      target.setDate(target.getDate() + 7);
      target.setHours(20, 0, 0, 0);
    } else if (preset === 'month') {
      target.setMonth(target.getMonth() + 1);
      target.setHours(20, 0, 0, 0);
    }

    const p = parseDateToJalali(target);
    emitChange(p.jy, p.jm, p.jd, p.hour, p.minute);
  };

  // Days list based on selected month
  const maxDaysInSelectedMonth = jm <= 6 ? 31 : jm === 12 ? 29 : 30;
  const daysList = Array.from({ length: maxDaysInSelectedMonth }, (_, i) => i + 1);
  const yearsList = [currentNow.jy, currentNow.jy + 1, currentNow.jy + 2, currentNow.jy + 3, currentNow.jy + 4, currentNow.jy + 5];
  const hoursList = Array.from({ length: 24 }, (_, i) => i);

  const toPersian = (n: number | string) => {
    const pDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    return String(n).replace(/[0-9]/g, w => pDigits[+w]);
  };

  const currentIso = value || jalaliToIso(jy, jm, jd, hour, minute);

  return (
    <div className="bg-white/95 border border-rose-200/90 rounded-2xl p-3 sm:p-4 text-slate-800 shadow-xs space-y-3" dir="rtl">
      
      {/* Readable Date Display and Minimal Presets */}
      <div className="flex flex-wrap items-center justify-between gap-2 pb-2.5 border-b border-rose-100/70">
        <div className="flex items-center gap-1.5 text-xs font-black text-rose-700">
          <CalendarIcon className="w-4 h-4 text-rose-500 shrink-0" />
          <span>{formatJalaliReadable(currentIso) || 'تاریخ بازگشایی'}</span>
        </div>

        {/* Minimal Presets */}
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => applyPreset('tomorrow')}
            className="text-[11px] font-bold bg-rose-50 hover:bg-rose-100 text-rose-700 px-2.5 py-1 rounded-xl transition active:scale-95 cursor-pointer"
          >
            فردا شب
          </button>
          <button
            type="button"
            onClick={() => applyPreset('week')}
            className="text-[11px] font-bold bg-rose-50 hover:bg-rose-100 text-rose-700 px-2.5 py-1 rounded-xl transition active:scale-95 cursor-pointer"
          >
            ۱ هفته بعد
          </button>
          <button
            type="button"
            onClick={() => applyPreset('month')}
            className="text-[11px] font-bold bg-rose-50 hover:bg-rose-100 text-rose-700 px-2.5 py-1 rounded-xl transition active:scale-95 cursor-pointer"
          >
            ۱ ماه بعد
          </button>
        </div>
      </div>

      {/* Sleek, Minimal Selectors Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        {/* Day */}
        <div className="relative">
          <select
            value={jd}
            onChange={(e) => emitChange(jy, jm, parseInt(e.target.value, 10), hour, minute)}
            className="w-full bg-slate-50 hover:bg-slate-100 border border-slate-200/90 rounded-xl px-2.5 py-2 text-base font-bold text-slate-800 appearance-none focus:border-rose-400 focus:bg-white focus:outline-none transition cursor-pointer"
          >
            {daysList.map((d) => (
              <option key={d} value={d}>
                روز {toPersian(d)}
              </option>
            ))}
          </select>
          <ChevronDown className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
        </div>

        {/* Month */}
        <div className="relative">
          <select
            value={jm}
            onChange={(e) => emitChange(jy, parseInt(e.target.value, 10), jd, hour, minute)}
            className="w-full bg-slate-50 hover:bg-slate-100 border border-slate-200/90 rounded-xl px-2.5 py-2 text-base font-bold text-slate-800 appearance-none focus:border-rose-400 focus:bg-white focus:outline-none transition cursor-pointer"
          >
            {JALALI_MONTH_NAMES.map((name, idx) => (
              <option key={idx + 1} value={idx + 1}>
                ماه {name}
              </option>
            ))}
          </select>
          <ChevronDown className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
        </div>

        {/* Year */}
        <div className="relative">
          <select
            value={jy}
            onChange={(e) => emitChange(parseInt(e.target.value, 10), jm, jd, hour, minute)}
            className="w-full bg-slate-50 hover:bg-slate-100 border border-slate-200/90 rounded-xl px-2.5 py-2 text-base font-bold text-slate-800 appearance-none focus:border-rose-400 focus:bg-white focus:outline-none transition cursor-pointer"
          >
            {yearsList.map((y) => (
              <option key={y} value={y}>
                سال {toPersian(y)}
              </option>
            ))}
          </select>
          <ChevronDown className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
        </div>

        {/* Hour */}
        <div className="relative">
          <select
            value={hour}
            onChange={(e) => emitChange(jy, jm, jd, parseInt(e.target.value, 10), 0)}
            className="w-full bg-slate-50 hover:bg-slate-100 border border-slate-200/90 rounded-xl px-2.5 py-2 text-base font-bold text-slate-800 appearance-none focus:border-rose-400 focus:bg-white focus:outline-none transition cursor-pointer"
          >
            {hoursList.map((h) => (
              <option key={h} value={h}>
                ساعت {toPersian(String(h).padStart(2, '0'))}:۰۰
              </option>
            ))}
          </select>
          <ChevronDown className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
        </div>
      </div>

    </div>
  );
};
