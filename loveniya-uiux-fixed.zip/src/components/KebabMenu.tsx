import React, { useState, useRef, useEffect } from 'react';
import { MoreVertical } from 'lucide-react';

export const KebabMenu: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isOpen, setIsOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isOpen]);

  // Elevate the parent card's z-index when the menu is open to prevent overlapping by subsequent cards
  useEffect(() => {
    if (menuRef.current) {
      const parentCard = menuRef.current.closest('div[layout], .group, .rounded-3xl, .rounded-2xl') as HTMLElement;
      if (parentCard) {
        if (isOpen) {
          parentCard.style.setProperty('z-index', '99', 'important');
        } else {
          parentCard.style.removeProperty('z-index');
        }
      }
    }
  }, [isOpen]);

  return (
    <div className="relative inline-block" ref={menuRef}>
      <button 
        onClick={(e) => {
          e.stopPropagation();
          setIsOpen(!isOpen);
        }} 
        className="text-stone-500 hover:text-stone-800 min-w-[44px] min-h-[44px] rounded-full hover:bg-stone-100 active:bg-stone-200 transition-all flex items-center justify-center border border-transparent hover:border-stone-200/80"
        title="عملیات بیشتر"
        aria-expanded={isOpen}
      >
        <MoreVertical className="w-4 h-4" />
      </button>
      {isOpen && (
        <div className="absolute left-0 top-full mt-1.5 w-48 bg-white rounded-2xl shadow-2xl border border-stone-200/90 py-1.5 z-[150] ring-1 ring-black/5 animate-in fade-in duration-150">
          {React.Children.map(children, child => {
            if (React.isValidElement(child)) {
              const originalOnClick = (child.props as any).onClick;
              return React.cloneElement(child, {
                onClick: (e: React.MouseEvent) => {
                  setIsOpen(false);
                  if (originalOnClick) {
                    originalOnClick(e);
                  }
                }
              } as any);
            }
            return child;
          })}
        </div>
      )}
    </div>
  );
};

export const KebabMenuItem: React.FC<{
  icon: React.ReactNode;
  label: string;
  onClick: (e: React.MouseEvent) => void;
  danger?: boolean;
}> = ({ icon, label, onClick, danger }) => {
  return (
    <button
      onClick={(e) => {
        e.stopPropagation();
        onClick(e);
      }}
      className={`w-full min-h-[44px] text-right px-3.5 py-2.5 text-xs font-bold flex items-center gap-2.5 transition-colors ${
        danger 
          ? 'text-rose-600 hover:bg-rose-50 active:bg-rose-100' 
          : 'text-stone-800 hover:bg-rose-50/60 hover:text-rose-700 active:bg-stone-100'
      }`}
    >
      <span className="shrink-0">{icon}</span>
      <span className="truncate">{label}</span>
    </button>
  );
};
