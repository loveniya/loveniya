import React from 'react';

interface CharacterAvatarProps {
  className?: string;
}

/**
 * A simple, warm, flat-illustration style avatar — used as a friendly
 * stand-in "profile picture" for Amin and Niayesh in the chat, since we
 * don't have real uploaded photos. Both float gently (a soft idle bob),
 * which is the "animated" touch requested.
 */

export const MaleAvatar: React.FC<CharacterAvatarProps> = ({ className = 'w-11 h-11' }) => (
  <div className={`${className} rounded-full shrink-0 shadow-sm overflow-hidden animate-avatar-bob`}>
    <svg viewBox="0 0 100 100" className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="maleBg" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#5eead4" />
          <stop offset="100%" stopColor="#0d9488" />
        </linearGradient>
      </defs>
      <circle cx="50" cy="50" r="50" fill="url(#maleBg)" />
      {/* Shoulders / collar */}
      <path d="M14 100 C14 78 30 68 50 68 C70 68 86 78 86 100 Z" fill="#ffffff" opacity="0.95" />
      <path d="M40 70 L50 84 L60 70 L50 76 Z" fill="#0d9488" />
      {/* Neck */}
      <rect x="42" y="56" width="16" height="16" rx="6" fill="#f2b78c" />
      {/* Face */}
      <ellipse cx="50" cy="42" rx="21" ry="22" fill="#f7c79c" />
      {/* Hair */}
      <path d="M29 38 C27 20 34 10 50 10 C66 10 73 20 71 38 C71 30 64 32 62 27 C58 33 42 33 38 27 C36 32 29 30 29 38 Z" fill="#3b2a20" />
      {/* Eyes */}
      <circle cx="42" cy="43" r="2.6" fill="#2c2015" />
      <circle cx="58" cy="43" r="2.6" fill="#2c2015" />
      {/* Eyebrows */}
      <path d="M37 37 Q42 34 47 37" stroke="#3b2a20" strokeWidth="2" fill="none" strokeLinecap="round" />
      <path d="M53 37 Q58 34 63 37" stroke="#3b2a20" strokeWidth="2" fill="none" strokeLinecap="round" />
      {/* Smile */}
      <path d="M42 52 Q50 58 58 52" stroke="#8a4a2e" strokeWidth="2.4" fill="none" strokeLinecap="round" />
    </svg>
  </div>
);

export const FemaleAvatar: React.FC<CharacterAvatarProps> = ({ className = 'w-11 h-11' }) => (
  <div className={`${className} rounded-full shrink-0 shadow-sm overflow-hidden animate-avatar-bob`}>
    <svg viewBox="0 0 100 100" className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="femaleBg" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#fda4af" />
          <stop offset="100%" stopColor="#e11d48" />
        </linearGradient>
      </defs>
      <circle cx="50" cy="50" r="50" fill="url(#femaleBg)" />
      {/* Shoulders / collar */}
      <path d="M12 100 C12 76 29 66 50 66 C71 66 88 76 88 100 Z" fill="#ffffff" opacity="0.95" />
      <path d="M40 68 L50 82 L60 68 L50 74 Z" fill="#e11d48" />
      {/* Hair back layer (behind face, frames shoulders) */}
      <path d="M24 46 C22 70 24 84 30 92 L34 78 C30 68 30 54 24 46 Z" fill="#3a2418" />
      <path d="M76 46 C78 70 76 84 70 92 L66 78 C70 68 70 54 76 46 Z" fill="#3a2418" />
      {/* Neck */}
      <rect x="42" y="55" width="16" height="15" rx="6" fill="#f4c9a3" />
      {/* Face */}
      <ellipse cx="50" cy="41" rx="20" ry="21" fill="#f9d3ac" />
      {/* Hair top */}
      <path d="M27 40 C24 16 38 8 50 8 C62 8 76 16 73 40 C71 26 64 16 50 16 C36 16 29 26 27 40 Z" fill="#3a2418" />
      {/* Eyes */}
      <circle cx="42" cy="42" r="2.5" fill="#2c2015" />
      <circle cx="58" cy="42" r="2.5" fill="#2c2015" />
      {/* Lashes */}
      <path d="M38 39 L36.5 37.5" stroke="#2c2015" strokeWidth="1.4" strokeLinecap="round" />
      <path d="M62 39 L63.5 37.5" stroke="#2c2015" strokeWidth="1.4" strokeLinecap="round" />
      {/* Eyebrows */}
      <path d="M37 36 Q42 33.5 47 36" stroke="#3a2418" strokeWidth="1.8" fill="none" strokeLinecap="round" />
      <path d="M53 36 Q58 33.5 63 36" stroke="#3a2418" strokeWidth="1.8" fill="none" strokeLinecap="round" />
      {/* Smile */}
      <path d="M42 51 Q50 57 58 51" stroke="#b8523f" strokeWidth="2.2" fill="none" strokeLinecap="round" />
      {/* Small bow accent */}
      <path d="M50 12 L45 8 L45 16 Z" fill="#e11d48" />
      <path d="M50 12 L55 8 L55 16 Z" fill="#e11d48" />
      <circle cx="50" cy="12" r="2" fill="#be123c" />
    </svg>
  </div>
);

export default { MaleAvatar, FemaleAvatar };
