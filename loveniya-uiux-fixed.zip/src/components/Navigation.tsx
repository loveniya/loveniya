import React, { useState, useEffect } from 'react';
import { NavLink, useLocation } from 'react-router';
import { 
  Heart, Camera, HeartHandshake, Compass, Music, Mail, 
  Settings, AlertCircle, Sparkles, Home, MessageCircle,
  Gamepad2, Grid, ChevronLeft, X
} from 'lucide-react';
import clsx from 'clsx';
import { useStore } from '../lib/store';
import { motion, AnimatePresence } from 'motion/react';

export const Navigation: React.FC = () => {
  const { syncStatus, syncError } = useStore();
  const [showMoreMenu, setShowMoreMenu] = useState(false);
  const location = useLocation();

  // Lock body scroll when drawer is open
  useEffect(() => {
    if (showMoreMenu) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [showMoreMenu]);

  // Distinct Colorful Items for More Menu (Matching Section Brand Colors)
  const moreNavItems = [
    { 
      to: '/dreams', 
      label: 'آرزوهای مشترک', 
      desc: 'اهداف، سفرها و برنامه‌های دو نفره ما',
      icon: <Compass className="w-5 h-5 text-sky-600" />,
      colorClass: 'bg-sky-50/90 hover:bg-sky-100/90 border-sky-200/80 text-sky-900',
      activeClass: 'bg-sky-100 border-sky-400 ring-2 ring-sky-300 text-sky-950 font-black',
      badge: 'رویاها',
      badgeColor: 'bg-sky-100 text-sky-700 border-sky-200'
    },
    { 
      to: '/music', 
      label: 'موزیک روم مشترک', 
      desc: 'آهنگ‌های دلنشین و خاطره‌ساز',
      icon: <Music className="w-5 h-5 text-fuchsia-600" />,
      colorClass: 'bg-fuchsia-50/90 hover:bg-fuchsia-100/90 border-fuchsia-200/80 text-fuchsia-900',
      activeClass: 'bg-fuchsia-100 border-fuchsia-400 ring-2 ring-fuchsia-300 text-fuchsia-950 font-black',
      badge: 'موسیقی',
      badgeColor: 'bg-fuchsia-100 text-fuchsia-700 border-fuchsia-200'
    },
    { 
      to: '/letters', 
      label: 'صندوق نامه‌ها', 
      desc: 'نامه‌های زمان‌دار و یادداشت‌های قلبی',
      icon: <Mail className="w-5 h-5 text-amber-600" />,
      colorClass: 'bg-amber-50/90 hover:bg-amber-100/90 border-amber-200/80 text-amber-900',
      activeClass: 'bg-amber-100 border-amber-400 ring-2 ring-amber-300 text-amber-950 font-black',
      badge: 'نامه‌ها',
      badgeColor: 'bg-amber-100 text-amber-700 border-amber-200'
    },
    { 
      to: '/settings', 
      label: 'تنظیمات و قفل امن', 
      desc: 'شخصی‌سازی، امنیت و وضعیت اتصال',
      icon: <Settings className="w-5 h-5 text-stone-700" />,
      colorClass: 'bg-stone-50/90 hover:bg-stone-100/90 border-stone-200/80 text-stone-800',
      activeClass: 'bg-stone-100 border-stone-400 ring-2 ring-stone-300 text-stone-900 font-black',
      badge: 'کنترل',
      badgeColor: 'bg-stone-100 text-stone-700 border-stone-200'
    },
  ];

  const isMoreActive = ['/dreams', '/music', '/letters', '/settings'].includes(location.pathname);

  // Bottom Navigation tabs configuration
  const navTabs = [
    {
      to: '/',
      label: 'خانه',
      icon: <Home className="w-5 h-5" />
    },
    {
      to: '/memories',
      label: 'خاطرات',
      icon: <Camera className="w-5 h-5" />
    },
    {
      to: '/pledges',
      label: 'عهدها',
      icon: <HeartHandshake className="w-5 h-5" />
    },
    {
      to: '/magic',
      label: 'چت هوشمند',
      icon: <MessageCircle className="w-5 h-5" />
    },
    {
      to: '/moments',
      label: 'بازی‌ها',
      icon: <Gamepad2 className="w-5 h-5" />
    }
  ];

  return (
    <>
      {/* Top Header - Natural Handwritten "I Love You" with Hand-Drawn Heart on the Right */}
      <nav className="fixed top-0 w-full bg-white z-40 border-b border-stone-200/90 shadow-2xs h-13 sm:h-14">
        <div className="max-w-4xl mx-auto h-full px-3 sm:px-4 flex items-center justify-between relative">
          
          {/* Settings Button on the Left */}
          <NavLink 
            to="/settings" 
            className={({ isActive }) => clsx(
              "w-8 h-8 sm:w-9 sm:h-9 rounded-xl flex items-center justify-center transition-all border shadow-2xs bg-white shrink-0 z-10",
              isActive 
                ? "bg-rose-50 border-rose-200 text-rose-700 font-black shadow-xs" 
                : "border-stone-200/80 text-stone-700 hover:bg-stone-50 hover:text-stone-900"
            )}
            title="تنظیمات"
          >
            <Settings className="w-4 h-4" />
          </NavLink>

          {/* Full-width Natural Handwritten "I Love You" Banner */}
          <NavLink 
            to="/" 
            className="flex-1 flex items-center justify-center sm:justify-end gap-2.5 sm:gap-3.5 group transition-transform active:scale-98 select-none pl-2 pr-1"
            title="صفحه اصلی"
            dir="ltr"
          >
            <span 
              className="text-2xl sm:text-3xl md:text-4xl text-rose-600 group-hover:text-rose-700 font-bold tracking-normal transition-colors whitespace-nowrap drop-shadow-2xs select-none"
              style={{ fontFamily: "'Alex Brush', 'Great Vibes', 'Dancing Script', cursive" }}
            >
              I Love You
            </span>

            {/* Hand-Drawn Sketch Heart on the Right */}
            <div className="shrink-0 flex items-center justify-center">
              <svg 
                viewBox="0 0 100 90" 
                className="w-7 h-7 sm:w-8 sm:h-8 text-rose-500 fill-none group-hover:scale-110 transition-transform duration-300 stroke-rose-500 stroke-[4.5] stroke-linecap-round stroke-linejoin-round"
              >
                {/* Soft Background Tint */}
                <path 
                  d="M50,82 C50,82 12,56 12,28 C12,14 23,8 35,8 C43,8 48,13 50,17 C52,13 57,8 65,8 C77,8 88,14 88,28 C88,56 50,82 50,82 Z" 
                  className="fill-rose-500/20"
                />
                {/* Hand-Drawn Outline */}
                <path 
                  d="M50,82 C50,82 12,56 12,28 C12,14 23,8 35,8 C43,8 48,13 50,17 C52,13 57,8 65,8 C77,8 88,14 88,28 C88,56 50,82 50,82 Z" 
                />
                {/* Accent highlights */}
                <path 
                  d="M24,24 C20,32 22,42 28,50" 
                  className="stroke-rose-400 stroke-[3] fill-none" 
                />
              </svg>
            </div>
          </NavLink>

        </div>
      </nav>

      {syncStatus === 'error' && (
        <div className="fixed top-14 w-full z-40 bg-red-500 text-white text-xs font-bold text-center py-2 px-4 shadow-sm md:hidden" dir="rtl">
          <AlertCircle className="w-4 h-4 inline-block ml-1" />
          {syncError || 'خطای اتصال به سرور'}
        </div>
      )}

      {/* Vibrant Ergonomic Mobile Bottom Navigation Dock — Telegram-style floating glass */}
      <div
        className="fixed bottom-0 inset-x-0 z-40 px-3 pointer-events-none"
        style={{ paddingBottom: 'max(0.75rem, env(safe-area-inset-bottom))' }}
        dir="rtl"
      >
        <nav className="max-w-md mx-auto rounded-[28px] backdrop-blur-xl bg-white/70 border border-white/50 shadow-xl shadow-rose-500/5 px-1 flex items-center justify-around w-full h-[64px] pointer-events-auto">
          
          {navTabs.map((tab) => {
            const isTabActive = location.pathname === tab.to;
            return (
              <NavLink
                key={tab.to}
                to={tab.to}
                className="flex flex-col items-center justify-center flex-1 h-full relative group cursor-pointer"
              >
                <div className={clsx(
                  "flex items-center justify-center transition-all duration-300",
                  isTabActive
                    ? "text-rose-600 scale-110 drop-shadow-[0_0_5px_rgba(244,63,94,0.35)]"
                    : "text-stone-500 group-hover:text-rose-500"
                )}>
                  {tab.icon}
                </div>
                
                <span className={clsx(
                  "text-[11px] tracking-tight leading-none text-center whitespace-nowrap mt-1.5 font-bold transition-colors",
                  isTabActive ? "font-black text-rose-600" : "text-stone-500"
                )}>
                  {tab.label}
                </span>

                {isTabActive && (
                  <span className="absolute top-0 w-8 h-[3px] rounded-full bg-gradient-to-r from-rose-400 via-rose-500 to-pink-500 transition-all duration-300" />
                )}
              </NavLink>
            );
          })}

          {/* More Hub Button */}
          <button
            type="button"
            onClick={() => setShowMoreMenu(true)}
            className="flex flex-col items-center justify-center flex-1 h-full relative group cursor-pointer"
          >
            <div className={clsx(
              "flex items-center justify-center transition-all duration-300",
              isMoreActive
                ? "text-rose-600 scale-110 drop-shadow-[0_0_5px_rgba(244,63,94,0.35)]"
                : "text-stone-500 group-hover:text-rose-500"
            )}>
              <Grid className="w-5 h-5" />
            </div>

            <span className={clsx(
              "text-[11px] tracking-tight leading-none text-center whitespace-nowrap mt-1.5 font-bold transition-colors",
              isMoreActive ? "font-black text-rose-600" : "text-stone-500"
            )}>
              سایر
            </span>

            {isMoreActive && (
              <span className="absolute top-0 w-8 h-[3px] rounded-full bg-gradient-to-r from-rose-400 via-rose-500 to-pink-500 transition-all duration-300" />
            )}
          </button>
        </nav>
      </div>

      {/* More Hub Bottom Sheet Drawer */}
      <AnimatePresence>
        {showMoreMenu && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowMoreMenu(false)}
              className="fixed inset-0 bg-stone-950/60 backdrop-blur-xs z-50 transition-opacity"
            />

            {/* Bottom Drawer */}
            <motion.div
              initial={{ opacity: 0, y: "100%" }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: "100%" }}
              transition={{ type: "spring", stiffness: 360, damping: 32 }}
              className="fixed bottom-3 inset-x-3 backdrop-blur-xl bg-white/70 border border-white/50 rounded-[28px] shadow-xl shadow-rose-500/5 z-50 max-w-xl mx-auto p-4 sm:p-6 text-right overflow-hidden"
              style={{ marginBottom: 'env(safe-area-inset-bottom)' }}
              dir="rtl"
            >
              {/* Drawer Handle */}
              <div className="w-12 h-1.5 bg-stone-300 rounded-full mx-auto mb-4" />

              <div className="flex items-center justify-between mb-4 pb-3 border-b border-stone-100">
                <div className="flex items-center gap-2.5">
                  <div className="p-2.5 rounded-2xl bg-gradient-to-tr from-indigo-600 to-purple-600 text-white shadow-xs">
                    <Sparkles className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm sm:text-base font-black text-stone-900">سایر بخش‌های اختصاصی</h3>
                    <p className="text-[11px] font-bold text-stone-500">امکانات و گنجینه‌های عاشقانه لوینیا</p>
                  </div>
                </div>
                <button 
                  onClick={() => setShowMoreMenu(false)}
                  className="p-2 rounded-xl text-stone-500 hover:text-stone-800 bg-stone-100 hover:bg-stone-200 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Items List with Precise Section Brand Colors */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {moreNavItems.map((item, idx) => {
                  const isActive = location.pathname === item.to;
                  return (
                    <NavLink
                      key={idx}
                      to={item.to}
                      onClick={() => setShowMoreMenu(false)}
                      className={clsx(
                        "p-3 rounded-2xl flex items-center justify-between transition-all border group cursor-pointer",
                        isActive ? item.activeClass : item.colorClass
                      )}
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="p-2.5 rounded-xl bg-white shadow-2xs shrink-0 group-hover:scale-105 transition-transform">
                          {item.icon}
                        </div>
                        <div className="min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="text-xs sm:text-sm font-black text-stone-900 block truncate">
                              {item.label}
                            </span>
                            <span className={`text-[9px] font-black px-2 py-0.5 rounded-md border ${item.badgeColor}`}>
                              {item.badge}
                            </span>
                          </div>
                          <span className="text-[10.5px] text-stone-500 font-bold block truncate mt-0.5">
                            {item.desc}
                          </span>
                        </div>
                      </div>

                      <ChevronLeft className="w-4.5 h-4.5 text-stone-500 group-hover:text-stone-700 transition-transform group-hover:-translate-x-1 shrink-0" />
                    </NavLink>
                  );
                })}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
};
