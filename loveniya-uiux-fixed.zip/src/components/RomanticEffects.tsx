import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Heart } from 'lucide-react';

interface Particle {
  id: string;
  x: number;
  y: number;
}

export const RomanticEffects: React.FC = () => {
  const [clicks, setClicks] = useState<Particle[]>([]);

  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      // Don't spawn hearts if clicking on a button or input
      const target = e.target as HTMLElement;
      if (target.tagName === 'BUTTON' || target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.closest('button')) {
        return;
      }

      const particleId = `particle_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
      const newParticle: Particle = { id: particleId, x: e.clientX, y: e.clientY };
      setClicks((prev) => [...prev, newParticle]);

      // Remove after animation completes
      setTimeout(() => {
        setClicks((prev) => prev.filter(p => p.id !== particleId));
      }, 1000);
    };

    window.addEventListener('click', handleClick);
    return () => window.removeEventListener('click', handleClick);
  }, []);

  // Spawn a handful of floating particles continuously in the background
  const [floaters, setFloaters] = useState<{id: string, left: string, delay: string, duration: string, size: number}[]>([]);
  
  useEffect(() => {
    // A sparse, calm scattering — enough for ambient life, not enough to read as noise.
    // Distributed unevenly on purpose so they never line up into a grid or a wall of hearts.
    const newFloaters = Array.from({ length: 8 }).map((_, i) => ({
      id: `floater_${i}`,
      left: `${(i * 12.5) + (Math.random() * 6 - 3)}vw`,
      delay: `-${Math.random() * 30}s`,
      duration: `${26 + Math.random() * 14}s`, // slower drift reads as ambient rather than busy
      size: Math.random() * 8 + 12 // 12–20px: small enough to stay in the background
    }));
    setFloaters(newFloaters);
  }, []);

  return (
    <>
      {/* Background Floating Particles — faded out near the top of the viewport (header/hero/timer)
          so they never clutter the countdown card, while still drifting freely lower on the page. */}
      <div 
        className="fixed inset-0 pointer-events-none overflow-hidden z-0"
        style={{
          WebkitMaskImage: 'linear-gradient(to bottom, transparent 0, transparent 32vh, black 58vh, black 100%)',
          maskImage: 'linear-gradient(to bottom, transparent 0, transparent 32vh, black 58vh, black 100%)'
        }}
      >
        {floaters.map(f => (
          <div
            key={f.id}
            className="absolute bottom-[-10vh] text-rose-300/35"
            style={{
              left: f.left,
              animation: `floatUp ${f.duration} linear infinite`,
              animationDelay: f.delay,
              fontSize: `${f.size}px`
            }}
          >
            ❤
          </div>
        ))}
      </div>

      {/* Click Hearts */}
      <div className="fixed inset-0 pointer-events-none z-50">
        <AnimatePresence>
          {clicks.map(click => (
            <motion.div
              key={click.id}
              initial={{ scale: 0, opacity: 1, x: click.x - 12, y: click.y - 12 }}
              animate={{ 
                scale: 1.5, 
                opacity: 0,
                y: click.y - 50 
              }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.8, ease: "easeOut" }}
              className="absolute text-rose-500"
            >
              <Heart className="w-6 h-6 fill-rose-500" />
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      <style dangerouslySetInnerHTML={{__html: `
        @keyframes floatUp {
          0% { transform: translate(0, 0) rotate(0deg); opacity: 0; }
          10% { opacity: 0.3; }
          50% { transform: translate(30px, -55vh) rotate(180deg); opacity: 0.3; }
          90% { opacity: 0.3; }
          100% { transform: translate(-20px, -110vh) rotate(360deg); opacity: 0; }
        }
      `}} />
    </>
  );
};
