import { useEffect, useRef, useState } from 'react';

/**
 * Lightweight environmental color sampling for the glass bottom nav.
 *
 * Instead of expensive per-pixel canvas capture, this samples a handful of
 * points along the top edge of the nav via `elementsFromPoint`, reads the
 * *computed* background color / gradient of whatever DOM content is there,
 * blends those into one representative color (closer-to-center points count
 * more), and smoothly lerps the visible color toward that target over time
 * so it never jumps or flickers.
 *
 * Sampling only runs on scroll (throttled) and route change — never on a
 * per-frame timer — which keeps this cheap enough for low-end mobile.
 */

type RGB = { r: number; g: number; b: number };

const FALLBACK: RGB = { r: 255, g: 250, b: 251 }; // neutral near-white, NOT rose — only used when nothing usable is found
const DARK_LUMINANCE_CUTOFF = 60; // ignore near-black content so the glass never looks muddy
const LIGHT_LUMINANCE_CUTOFF = 248; // ignore near-pure-white content too — it carries no real color signal

const luminance = ({ r, g, b }: RGB) => 0.299 * r + 0.587 * g + 0.114 * b;

const parseColorFunctions = (str: string): RGB[] => {
  const matches = str.match(/rgba?\(([^)]+)\)/g);
  if (!matches) return [];
  return matches
    .map((m) => {
      const nums = m.replace(/rgba?\(|\)/g, '').split(',').map((n) => parseFloat(n.trim()));
      const [r, g, b, a = 1] = nums;
      if (Number.isNaN(r) || Number.isNaN(g) || Number.isNaN(b) || a < 0.2) return null;
      return { r, g, b };
    })
    .filter((c): c is RGB => c !== null);
};

// Walk up a couple of ancestors if the hit element itself is transparent —
// often the direct hit is a text node's parent with no background of its own.
const colorAtElement = (el: Element | null): RGB[] => {
  let node: Element | null = el;
  let depth = 0;
  const found: RGB[] = [];
  while (node && depth < 3 && found.length === 0) {
    const style = window.getComputedStyle(node);
    found.push(...parseColorFunctions(style.backgroundImage));
    if (found.length === 0) {
      const bg = parseColorFunctions(style.backgroundColor);
      found.push(...bg);
    }
    node = node.parentElement;
    depth++;
  }
  return found;
};

const blend = (colors: { color: RGB; weight: number }[]): RGB | null => {
  const usable = colors.filter(({ color }) => {
    const l = luminance(color);
    return l >= DARK_LUMINANCE_CUTOFF && l <= LIGHT_LUMINANCE_CUTOFF;
  });
  if (usable.length === 0) return null;
  const totalWeight = usable.reduce((s, c) => s + c.weight, 0);
  const sum = usable.reduce(
    (acc, { color, weight }) => ({
      r: acc.r + color.r * weight,
      g: acc.g + color.g * weight,
      b: acc.b + color.b * weight,
    }),
    { r: 0, g: 0, b: 0 }
  );
  return { r: sum.r / totalWeight, g: sum.g / totalWeight, b: sum.b / totalWeight };
};

const sampleEnvironment = (navEl: HTMLElement): RGB => {
  const rect = navEl.getBoundingClientRect();
  const sampleY = Math.max(rect.top - 6, 0); // just above the glass, in real page content
  const xPositions = [0.08, 0.3, 0.5, 0.7, 0.92].map((f) => rect.left + rect.width * f);
  // center samples weighted more heavily — "colors closer to the nav have greater influence"
  const weights = [0.6, 0.85, 1, 0.85, 0.6];

  const collected: { color: RGB; weight: number }[] = [];
  xPositions.forEach((x, i) => {
    const stack = document.elementsFromPoint(x, sampleY);
    const hit = stack.find((el) => !navEl.contains(el)) || stack[0];
    const colors = colorAtElement(hit || null);
    colors.forEach((c) => collected.push({ color: c, weight: weights[i] }));
  });

  return blend(collected) || FALLBACK;
};

const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

export function useEnvironmentalGlassColor(navRef: React.RefObject<HTMLElement>, routeKey: string) {
  const [cssColor, setCssColor] = useState<string>(`rgb(${FALLBACK.r}, ${FALLBACK.g}, ${FALLBACK.b})`);
  const currentRef = useRef<RGB>(FALLBACK);
  const targetRef = useRef<RGB>(FALLBACK);
  const animRef = useRef<number | null>(null);

  const animate = () => {
    const cur = currentRef.current;
    const target = targetRef.current;
    const next: RGB = {
      r: lerp(cur.r, target.r, 0.08),
      g: lerp(cur.g, target.g, 0.08),
      b: lerp(cur.b, target.b, 0.08),
    };
    currentRef.current = next;
    setCssColor(`rgb(${next.r.toFixed(0)}, ${next.g.toFixed(0)}, ${next.b.toFixed(0)})`);

    const dist = Math.abs(next.r - target.r) + Math.abs(next.g - target.g) + Math.abs(next.b - target.b);
    if (dist > 0.5) {
      animRef.current = requestAnimationFrame(animate);
    } else {
      animRef.current = null;
    }
  };

  const resample = () => {
    const el = navRef.current;
    if (!el) return;
    targetRef.current = sampleEnvironment(el);
    if (animRef.current == null) {
      animRef.current = requestAnimationFrame(animate);
    }
  };

  useEffect(() => {
    // let the new route paint before sampling
    const t = setTimeout(resample, 60);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [routeKey]);

  useEffect(() => {
    let last = 0;
    const onScroll = () => {
      const now = Date.now();
      if (now - last < 180) return; // throttle — a handful of hit-tests per scroll gesture, not per pixel
      last = now;
      resample();
    };
    const opts: AddEventListenerOptions = { passive: true, capture: true };
    window.addEventListener('scroll', onScroll, opts);
    resample();
    return () => {
      window.removeEventListener('scroll', onScroll, opts);
      if (animRef.current != null) cancelAnimationFrame(animRef.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return cssColor;
}
