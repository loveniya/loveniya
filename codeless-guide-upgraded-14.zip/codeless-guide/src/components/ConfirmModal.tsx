import React, { useEffect, useRef } from 'react';
import { AlertTriangle, X, Loader2 } from 'lucide-react';
import { useBodyScrollLock } from '../lib/scroll';

interface ConfirmModalProps {
  open: boolean;
  title: string;
  description: string;
  confirmLabel?: string;
  cancelLabel?: string;
  isLoading?: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}

/**
 * مودال تأیید مشترک برای اقدام‌های غیرقابل‌بازگشت (مثل خالی‌کردن کامل سطل
 * زباله یا حذف همیشگی یک آیتم از آن). قبل از این کامپوننت، این دو دکمه در
 * تنظیمات با یک تپ ساده و بدون هیچ تأییدی اجرا می‌شدند — برای سایتی که قراره
 * یادگاری دائمی باشه، نبود تأیید برای «نقطه بی‌بازگشت» ریسک واقعی داشت.
 * از کلاس مشترک glass-modal (به‌جای بازتعریف افکت شیشه‌ای) استفاده می‌کنه.
 */
export const ConfirmModal: React.FC<ConfirmModalProps> = ({
  open,
  title,
  description,
  confirmLabel = 'مطمئنم، حذف کن',
  cancelLabel = 'انصراف',
  isLoading = false,
  onConfirm,
  onCancel,
}) => {
  const cancelBtnRef = useRef<HTMLButtonElement>(null);
  useBodyScrollLock(open);

  useEffect(() => {
    if (!open) return;
    // فوکوس روی گزینه‌ی امن (انصراف) موقع باز شدن، برای کاربرهای کیبورد/صفحه‌خوان
    cancelBtnRef.current?.focus();

    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && !isLoading) onCancel();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [open, isLoading, onCancel]);

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-100 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-xs"
      dir="rtl"
      role="alertdialog"
      aria-modal="true"
      aria-labelledby="confirm-modal-title"
      aria-describedby="confirm-modal-desc"
      onClick={() => !isLoading && onCancel()}
    >
      <div
        className="glass-modal rounded-3xl p-6 max-w-sm w-full text-center relative"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          type="button"
          onClick={onCancel}
          disabled={isLoading}
          aria-label="انصراف و بستن"
          className="absolute top-3 left-3 w-9 h-9 flex items-center justify-center rounded-full text-stone-400 hover:text-stone-700 hover:bg-stone-100 transition-colors cursor-pointer disabled:opacity-50"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="w-14 h-14 bg-rose-50 border border-rose-100 rounded-2xl flex items-center justify-center mx-auto mb-4 text-rose-500">
          <AlertTriangle className="w-7 h-7" />
        </div>

        <h3 id="confirm-modal-title" className="text-stone-900 font-black text-base mb-2">
          {title}
        </h3>
        <p id="confirm-modal-desc" className="text-stone-500 font-bold text-xs leading-relaxed mb-6">
          {description}
        </p>

        <div className="flex items-center gap-3">
          <button
            type="button"
            ref={cancelBtnRef}
            onClick={onCancel}
            disabled={isLoading}
            className="flex-1 py-3 px-4 rounded-2xl bg-stone-100 hover:bg-stone-200 text-stone-700 font-black text-xs transition-colors cursor-pointer disabled:opacity-50"
          >
            {cancelLabel}
          </button>
          <button
            type="button"
            onClick={onConfirm}
            disabled={isLoading}
            className="flex-1 py-3 px-4 rounded-2xl bg-rose-500 hover:bg-rose-600 text-white font-black text-xs transition-colors flex items-center justify-center gap-2 shadow-md shadow-rose-500/20 disabled:opacity-50 cursor-pointer"
          >
            {isLoading && <Loader2 className="w-4 h-4 animate-spin" />}
            <span>{confirmLabel}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
