import React, { useState, useRef, useEffect } from 'react';
import { MoreVertical } from 'lucide-react';

export const KebabMenu: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isOpen, setIsOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const [openUp, setOpenUp] = useState(false);

  useEffect(() => {
    if (!isOpen) return;
    const handleClickOutside = (event: Event) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    // pointerdown هم لمس و هم ماوس رو پوشش می‌ده (mousedown روی بعضی موبایل‌ها با تأخیر می‌رسید)
    document.addEventListener('pointerdown', handleClickOutside);
    // منو با اسکرول صفحه از کنار دکمه‌اش جدا می‌شد و وسط صفحه معلق می‌موند؛ با اسکرول بسته می‌شه
    const close = () => setIsOpen(false);
    window.addEventListener('scroll', close, { passive: true });
    window.addEventListener('resize', close);
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') setIsOpen(false); };
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('pointerdown', handleClickOutside);
      window.removeEventListener('scroll', close);
      window.removeEventListener('resize', close);
      document.removeEventListener('keydown', onKey);
    };
  }, [isOpen]);

  // Elevate the parent card's z-index when the menu is open to prevent overlapping by subsequent cards
  useEffect(() => {
    if (menuRef.current) {
      const parentCard = menuRef.current.closest('div[layout], .group, .rounded-3xl, .rounded-2xl') as HTMLElement;
      if (parentCard) {
        if (isOpen) {
          parentCard.style.setProperty('z-index', '99', 'important');
        } else {
          parentCard.style.removeProperty('z-index');
        }
      }
    }
  }, [isOpen]);

  return (
    <div className="relative inline-block" ref={menuRef}>
      <button 
        onClick={(e) => {
          e.stopPropagation();
          if (!isOpen && menuRef.current) {
            // فضای زیر دکمه (منهای نوار ناوبری پایین ~۹۰px) کمتر از ارتفاع منو بود → منو رو به بالا باز کن
            const rect = menuRef.current.getBoundingClientRect();
            const spaceBelow = window.innerHeight - rect.bottom - 96;
            setOpenUp(spaceBelow < 230 && rect.top > spaceBelow);
          }
          setIsOpen(!isOpen);
        }} 
        type="button"
        aria-haspopup="menu"
        aria-label="عملیات بیشتر"
        className="text-stone-500 hover:text-stone-800 min-w-[36px] min-h-[36px] rounded-full hover:bg-stone-100 active:bg-stone-200 transition-[color,background-color,border-color,box-shadow,transform] flex items-center justify-center border border-transparent hover:border-stone-200/80"
        title="عملیات بیشتر"
        aria-expanded={isOpen}
      >
        <MoreVertical className="w-4 h-4" />
      </button>
      {isOpen && (
        <div role="menu" className={`absolute left-0 ${openUp ? 'bottom-full mb-1.5' : 'top-full mt-1.5'} w-48 max-w-[calc(100vw-2rem)] bg-white rounded-2xl shadow-2xl border border-stone-200/90 py-1.5 z-[150] ring-1 ring-black/5 animate-in fade-in duration-150`}>
          {React.Children.map(children, child => {
            if (React.isValidElement(child)) {
              const originalOnClick = (child.props as any).onClick;
              return React.cloneElement(child, {
                onClick: (e: React.MouseEvent) => {
                  setIsOpen(false);
                  if (originalOnClick) {
                    originalOnClick(e);
                  }
                }
              } as any);
            }
            return child;
          })}
        </div>
      )}
    </div>
  );
};

export const KebabMenuItem: React.FC<{
  icon: React.ReactNode;
  label: string;
  onClick: (e: React.MouseEvent) => void;
  danger?: boolean;
}> = ({ icon, label, onClick, danger }) => {
  return (
    <button
      onClick={(e) => {
        e.stopPropagation();
        onClick(e);
      }}
      className={`w-full min-h-[40px] text-right px-3.5 py-2 text-xs font-bold flex items-center gap-2.5 transition-colors ${
        danger 
          ? 'text-rose-600 hover:bg-rose-50 active:bg-rose-100' 
          : 'text-stone-800 hover:bg-rose-50/60 hover:text-rose-700 active:bg-stone-100'
      }`}
    >
      <span className="shrink-0">{icon}</span>
      <span className="truncate">{label}</span>
    </button>
  );
};
