import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  Dices, Shuffle, HelpCircle, Flame, MessageCircleHeart,
  Loader2, Send, CheckCircle2, Clock, ChevronDown, Sparkles
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { PageWrapper } from '../components/PageWrapper';
import { generateChallenge, ChallengeKind, ChallengeTone } from '../lib/gameAi';
import { APP_SECRET } from '../lib/appSecret';

const WORKER_URL = "https://niya.am-b-asdfghjkl20112011.workers.dev";
const MOMENTS_PATH = 'loveniya_moments_v3';

type Who = 'amin' | 'niyayesh';

type Challenge = {
  id: string;
  kind: ChallengeKind;
  tone: ChallengeTone;
  text: string;
  createdBy: Who;
  // truth/dare: طرف مقابلِ کسی که ساختتش، یعنی همیشه یک نفر مشخص باید جواب
  // بده/انجامش بده. deep: تعریف‌نشده، چون هر دو نفر باید جدا جواب بدن.
  targetUser?: Who;
  answers: { amin?: string; niyayesh?: string };
  doneAt?: number; // فقط برای dare: لحظه‌ی «انجام دادم»
  createdAt: number;
};

const KIND_META: Record<ChallengeKind, { label: string; icon: typeof HelpCircle; badge: string }> = {
  truth: { label: 'حقیقت', icon: HelpCircle, badge: 'bg-sky-50 text-sky-700 border-sky-200' },
  dare: { label: 'جرأت', icon: Flame, badge: 'bg-rose-50 text-rose-700 border-rose-200' },
  deep: { label: 'سوال عمیق', icon: MessageCircleHeart, badge: 'bg-emerald-50 text-emerald-700 border-emerald-200' }
};

function isDone(c: Challenge): boolean {
  if (c.kind === 'dare') return !!c.doneAt;
  if (c.kind === 'truth') return !!(c.targetUser && c.answers[c.targetUser]);
  return !!(c.answers.amin && c.answers.niyayesh); // deep
}

function needsMe(c: Challenge, me: Who): boolean {
  if (isDone(c)) return false;
  if (c.kind === 'deep') return !c.answers[me];
  return c.targetUser === me;
}

function sanitizeChallenge(id: string, raw: any): Challenge | null {
  if (!raw || typeof raw !== 'object' || typeof raw.text !== 'string') return null;
  const kind: ChallengeKind = raw.kind === 'dare' || raw.kind === 'deep' ? raw.kind : 'truth';
  return {
    id,
    kind,
    tone: raw.tone === 'flirty' || raw.tone === 'deep' ? raw.tone : 'light',
    text: raw.text,
    createdBy: raw.createdBy === 'niyayesh' ? 'niyayesh' : 'amin',
    targetUser: raw.targetUser === 'amin' || raw.targetUser === 'niyayesh' ? raw.targetUser : undefined,
    answers: (raw.answers && typeof raw.answers === 'object') ? raw.answers : {},
    doneAt: typeof raw.doneAt === 'number' ? raw.doneAt : undefined,
    createdAt: typeof raw.createdAt === 'number' ? raw.createdAt : 0
  };
}

export const Moments: React.FC = () => {
  const currentUser: Who = (localStorage.getItem('loveniya_user') as Who) || 'amin';
  const partnerKey: Who = currentUser === 'amin' ? 'niyayesh' : 'amin';
  const partnerName = currentUser === 'amin' ? 'نیایش' : 'امین';

  const [challenges, setChallenges] = useState<Challenge[]>([]);
  const [isDrawing, setIsDrawing] = useState(false);
  const [drafts, setDrafts] = useState<Record<string, string>>({});
  const [showHistory, setShowHistory] = useState(false);

  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const showToast = useCallback((msg: string) => {
    setToastMsg(msg);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToastMsg(null), 3200);
  }, []);
  useEffect(() => () => { if (toastTimer.current) clearTimeout(toastTimer.current); }, []);

  // ---- Sync ----
  // هر چالش زیرِ id خودش ذخیره می‌شه (نه همه با هم توی یک آرایه)، و جواب هر
  // نفر هم زیرِ کلید خودش. یعنی ساختن یه چالش تازه یا جواب‌دادن به یکی، هیچ‌وقت
  // چالش/جواب دیگه‌ای رو لمس یا پاک نمی‌کنه — نه رقابتی، نه قابل دور زدن.
  const inFlightRef = useRef(0);
  const lastWriteDoneRef = useRef(0);
  const persistLocal = (list: Challenge[]) => {
    try { localStorage.setItem(MOMENTS_PATH, JSON.stringify(list)); } catch { /* ignore */ }
  };

  const writeScoped = useCallback(async (path: string, body: unknown) => {
    inFlightRef.current += 1;
    try {
      // تا ۳ بار با فاصله تلاش می‌کنیم؛ قبلاً با یک قطعی کوتاه، چالش/جواب فقط روی همین گوشی
      // دیده می‌شد و ۴ ثانیه بعد با نسخه‌ی سرور جایگزین و ناپدید می‌شد.
      let lastErr: unknown = null;
      for (let attempt = 0; attempt < 3; attempt++) {
        try {
          const res = await fetch(`${WORKER_URL}/${path}.json`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json', 'X-App-Secret': APP_SECRET },
            body: JSON.stringify(body)
          });
          if (res.ok) { lastErr = null; break; }
          lastErr = new Error(String(res.status));
          if (res.status >= 400 && res.status < 500 && res.status !== 429) break; // با تکرار درست نمی‌شه
        } catch (e) {
          lastErr = e;
        }
        await new Promise(r => setTimeout(r, 700 * (attempt + 1)));
      }
      if (lastErr) throw lastErr;
    } catch {
      showToast('ذخیره نشد — اتصال رو چک کن و دوباره امتحان کن');
    } finally {
      inFlightRef.current -= 1;
      lastWriteDoneRef.current = Date.now();
    }
  }, [showToast]);

  const fetchAll = useCallback(async () => {
    if (inFlightRef.current > 0 || Date.now() - lastWriteDoneRef.current < 1200) return;
    try {
      const res = await fetch(`${WORKER_URL}/${MOMENTS_PATH}/challenges.json?_t=${Date.now()}`, {
        cache: 'no-store',
        headers: { 'X-App-Secret': APP_SECRET }
      });
      if (!res.ok) return;
      const raw = await res.json();
      if (inFlightRef.current > 0) return;
      const list = raw && typeof raw === 'object'
        ? Object.entries(raw).map(([id, v]) => sanitizeChallenge(id, v)).filter((c): c is Challenge => !!c)
        : [];
      list.sort((a, b) => b.createdAt - a.createdAt);
      // اگه چیزی عوض نشده، نه دوباره رندر کن و نه حافظه‌ی محلی رو بازنویسی
      setChallenges(prev => (JSON.stringify(prev) === JSON.stringify(list) ? prev : list));
      persistLocal(list);
    } catch { /* آفلاین: همون نسخه‌ی محلی می‌مونه */ }
  }, []);

  useEffect(() => {
    try {
      const saved = localStorage.getItem(MOMENTS_PATH);
      if (saved) setChallenges(JSON.parse(saved));
    } catch { /* ignore */ }
    fetchAll();
    const interval = setInterval(() => {
      if (document.visibilityState === 'visible') fetchAll();
    }, 4000);
    const onVisible = () => { if (document.visibilityState === 'visible') fetchAll(); };
    document.addEventListener('visibilitychange', onVisible);
    return () => { clearInterval(interval); document.removeEventListener('visibilitychange', onVisible); };
  }, [fetchAll]);

  // اطلاع‌رسانی زنده: چالش تازه‌ای که برای منه، یا جوابی که به چالش من رسید
  const prevIdsRef = useRef<Set<string>>(new Set());
  const prevDoneRef = useRef<Set<string>>(new Set());
  const readyRef = useRef(false);
  useEffect(() => {
    const ids = new Set(challenges.map(c => c.id));
    const doneIds = new Set(challenges.filter(isDone).map(c => c.id));
    if (!readyRef.current) {
      readyRef.current = true;
      prevIdsRef.current = ids;
      prevDoneRef.current = doneIds;
      return;
    }
    for (const c of challenges) {
      const isNew = !prevIdsRef.current.has(c.id);
      const justFinished = doneIds.has(c.id) && !prevDoneRef.current.has(c.id);
      if (isNew && c.createdBy !== currentUser && (c.targetUser === currentUser || c.kind === 'deep')) {
        showToast(`${partnerName} یه ${KIND_META[c.kind].label} تازه فرستاد`);
      } else if (justFinished && c.createdBy === currentUser) {
        showToast(c.kind === 'dare' ? `${partnerName} انجامش داد ✅` : `${partnerName} جواب داد — بازش کن`);
      } else if (justFinished && c.kind === 'deep' && c.createdBy !== currentUser) {
        showToast('هر دوتون جواب دادید — جواب‌ها بازه');
      }
    }
    prevIdsRef.current = ids;
    prevDoneRef.current = doneIds;
  }, [challenges, currentUser, partnerName, showToast]);

  // ---- Actions ----
  const drawChallenge = async () => {
    if (isDrawing) return;
    setIsDrawing(true);
    try {
      const { kind, tone, text } = await generateChallenge();
      if (!text || !text.trim()) throw new Error('empty challenge');
      const item: Challenge = {
        id: 'ch_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7),
        kind, tone, text,
        createdBy: currentUser,
        targetUser: kind === 'deep' ? undefined : partnerKey,
        answers: {},
        createdAt: Date.now()
      };
      setChallenges(prev => {
        const next = [item, ...prev];
        persistLocal(next);
        return next;
      });
      await writeScoped(`${MOMENTS_PATH}/challenges/${item.id}`, item);
    } catch {
      showToast('ساخت چالش انجام نشد؛ دوباره امتحان کن');
    } finally {
      setIsDrawing(false);
    }
  };

  const submitAnswer = async (c: Challenge) => {
    const text = (drafts[c.id] || '').trim();
    if (!text) return;
    setDrafts(prev => ({ ...prev, [c.id]: '' }));
    setChallenges(prev => {
      const next = prev.map(x => x.id === c.id ? { ...x, answers: { ...x.answers, [currentUser]: text } } : x);
      persistLocal(next);
      return next;
    });
    await writeScoped(`${MOMENTS_PATH}/challenges/${c.id}/answers/${currentUser}`, text);
  };

  const markDareDone = async (c: Challenge) => {
    const now = Date.now();
    setChallenges(prev => {
      const next = prev.map(x => x.id === c.id ? { ...x, doneAt: now } : x);
      persistLocal(next);
      return next;
    });
    await writeScoped(`${MOMENTS_PATH}/challenges/${c.id}/doneAt`, now);
  };

  const pendingForMe = challenges.filter(c => needsMe(c, currentUser));
  const pendingForPartner = challenges.filter(c => !isDone(c) && !needsMe(c, currentUser));
  const history = challenges.filter(isDone);
  const visibleHistory = showHistory ? history : history.slice(0, 3);

  return (
    <PageWrapper>
      <div className="space-y-4 max-w-2xl mx-auto px-2 sm:px-4 py-2" dir="rtl">

        <AnimatePresence>
          {toastMsg && (
            <motion.div
              role="status"
              aria-live="polite"
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="fixed top-[calc(env(safe-area-inset-top)+4.25rem)] left-1/2 -translate-x-1/2 z-50 bg-stone-900/95 text-white text-sm font-black px-5 py-3 rounded-2xl shadow-lg max-w-[90vw] text-center"
            >
              {toastMsg}
            </motion.div>
          )}
        </AnimatePresence>

        <section className="bg-white rounded-3xl p-5 shadow-[0_16px_50px_-12px_rgba(28,25,23,0.06)] text-center space-y-3">
          <div>
            <h1 className="text-2xl font-black text-stone-900 tracking-tight">گفتگوی دونفره</h1>
            <p className="text-xs text-stone-500 font-bold mt-1.5">
              هر بار یه چیز متفاوت — گاهی سبک، گاهی شیطنت‌آمیز، گاهی واقعاً عمیق
            </p>
          </div>
          <button
            onClick={drawChallenge}
            disabled={isDrawing}
            className="w-full min-h-[48px] bg-stone-900 hover:bg-stone-800 disabled:opacity-60 text-white text-sm font-black rounded-xl flex items-center justify-center gap-2 cursor-pointer transition-colors"
          >
            {isDrawing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Shuffle className="w-4 h-4" />}
            <span>{isDrawing ? 'در حال ساختن...' : 'یه چالش تازه بساز'}</span>
          </button>
        </section>

        {pendingForMe.length > 0 && (
          <section className="space-y-2.5">
            <h2 className="text-xs font-black text-stone-500 px-1">برای تو ({pendingForMe.length.toLocaleString('fa-IR')})</h2>
            {pendingForMe.map(c => (
              <ChallengeCard
                key={c.id} c={c} mine
                partnerName={partnerName}
                draft={drafts[c.id] || ''}
                onDraftChange={(v) => setDrafts(prev => ({ ...prev, [c.id]: v }))}
                onSubmitAnswer={() => submitAnswer(c)}
                onMarkDone={() => markDareDone(c)}
              />
            ))}
          </section>
        )}

        {pendingForPartner.length > 0 && (
          <section className="space-y-2.5">
            <h2 className="text-xs font-black text-stone-500 px-1">منتظر {partnerName} ({pendingForPartner.length.toLocaleString('fa-IR')})</h2>
            {pendingForPartner.map(c => (
              <ChallengeCard
                key={c.id} c={c} mine={false}
                partnerName={partnerName}
                draft=""
                onDraftChange={() => {}}
                onSubmitAnswer={() => {}}
                onMarkDone={() => {}}
              />
            ))}
          </section>
        )}

        {history.length > 0 && (
          <section className="space-y-2.5">
            <h2 className="text-xs font-black text-stone-500 px-1">تاریخچه ({history.length.toLocaleString('fa-IR')})</h2>
            {visibleHistory.map(c => (
              <ChallengeCard
                key={c.id} c={c} mine={false} done
                partnerName={partnerName}
                draft="" onDraftChange={() => {}} onSubmitAnswer={() => {}} onMarkDone={() => {}}
              />
            ))}
            {history.length > 3 && (
              <button
                onClick={() => setShowHistory(v => !v)}
                className="w-full min-h-[36px] flex items-center justify-center gap-1.5 text-xs font-black text-stone-500 hover:text-stone-800 cursor-pointer"
              >
                <span>{showHistory ? 'نمایش کمتر' : `نمایش ${(history.length - 3).toLocaleString('fa-IR')} مورد قبلی`}</span>
                <ChevronDown className={`w-3.5 h-3.5 transition-transform ${showHistory ? 'rotate-180' : ''}`} />
              </button>
            )}
          </section>
        )}

        {challenges.length === 0 && (
          <div className="bg-white rounded-3xl p-8 text-center border border-dashed border-stone-200">
            <Sparkles className="w-6 h-6 text-stone-300 mx-auto mb-2" />
            <p className="text-xs font-bold text-stone-400">هنوز چیزی نساختید — دکمه‌ی بالا رو بزن</p>
          </div>
        )}

      </div>
    </PageWrapper>
  );
};

const ChallengeCard: React.FC<{
  c: Challenge;
  mine: boolean;
  done?: boolean;
  partnerName: string;
  draft: string;
  onDraftChange: (v: string) => void;
  onSubmitAnswer: () => void;
  onMarkDone: () => void;
}> = ({ c, mine, done, partnerName, draft, onDraftChange, onSubmitAnswer, onMarkDone }) => {
  const meta = KIND_META[c.kind];
  const Icon = meta.icon;
  const finished = done ?? isDone(c);

  return (
    <motion.div
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      className={`bg-white rounded-2xl p-4 border space-y-3 ${finished ? 'border-stone-200' : mine ? 'border-stone-900/15' : 'border-stone-200'}`}
    >
      <div className="flex items-center justify-between gap-2">
        <span className={`inline-flex items-center gap-1.5 text-[11px] font-black px-2.5 py-1 rounded-full border ${meta.badge}`}>
          <Icon className="w-3.5 h-3.5" />
          <span>{meta.label}</span>
        </span>
        {c.tone === 'flirty' && <span className="text-[10px] font-black text-fuchsia-500">شیطنت‌آمیز 😉</span>}
      </div>

      <p className="text-sm font-black text-stone-900 leading-7">{c.text}</p>

      {c.kind === 'deep' ? (
        finished ? (
          <div className="space-y-2">
            {(['amin', 'niyayesh'] as const).map(k => (
              <div key={k} className="bg-stone-50 rounded-xl p-3 border border-stone-200">
                <span className="text-[10px] font-black text-stone-500 block mb-1">{k === 'amin' ? 'امین' : 'نیایش'}</span>
                <p className="text-xs font-bold text-stone-800 leading-6 whitespace-pre-wrap">{c.answers[k]}</p>
              </div>
            ))}
          </div>
        ) : mine ? (
          <div className="space-y-2">
            <textarea
              value={draft}
              onChange={(e) => onDraftChange(e.target.value)}
              placeholder="صادقانه بنویس، تا هر دو جواب ندید دیده نمی‌شه"
              rows={3}
              className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3 py-2.5 text-xs font-bold text-stone-900 placeholder:text-stone-400 placeholder:font-medium focus:outline-hidden focus:border-stone-400 resize-none leading-6"
            />
            <button
              onClick={onSubmitAnswer}
              disabled={!draft.trim()}
              className="w-full min-h-[40px] bg-stone-900 hover:bg-stone-800 disabled:opacity-40 text-white text-xs font-black rounded-xl flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
            >
              <Send className="w-3.5 h-3.5" />
              <span>ثبت جواب</span>
            </button>
          </div>
        ) : (
          <span className="inline-flex items-center gap-1.5 text-[11px] font-black text-stone-400">
            <Clock className="w-3.5 h-3.5" /> منتظر جواب {partnerName}
          </span>
        )
      ) : c.kind === 'truth' ? (
        finished ? (
          <div className="bg-stone-50 rounded-xl p-3 border border-stone-200">
            <span className="text-[10px] font-black text-stone-500 block mb-1">جواب</span>
            <p className="text-xs font-bold text-stone-800 leading-6 whitespace-pre-wrap">{c.answers[c.targetUser!]}</p>
          </div>
        ) : mine ? (
          <div className="space-y-2">
            <textarea
              value={draft}
              onChange={(e) => onDraftChange(e.target.value)}
              placeholder="جوابت..."
              rows={2}
              className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3 py-2.5 text-xs font-bold text-stone-900 placeholder:text-stone-400 placeholder:font-medium focus:outline-hidden focus:border-stone-400 resize-none leading-6"
            />
            <button
              onClick={onSubmitAnswer}
              disabled={!draft.trim()}
              className="w-full min-h-[40px] bg-stone-900 hover:bg-stone-800 disabled:opacity-40 text-white text-xs font-black rounded-xl flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
            >
              <Send className="w-3.5 h-3.5" />
              <span>ثبت جواب</span>
            </button>
          </div>
        ) : (
          <span className="inline-flex items-center gap-1.5 text-[11px] font-black text-stone-400">
            <Clock className="w-3.5 h-3.5" /> منتظر جواب {partnerName}
          </span>
        )
      ) : ( // dare
        finished ? (
          <span className="inline-flex items-center gap-1.5 text-[11px] font-black text-emerald-600">
            <CheckCircle2 className="w-3.5 h-3.5" /> انجام شد
          </span>
        ) : mine ? (
          <button
            onClick={onMarkDone}
            className="w-full min-h-[40px] bg-stone-900 hover:bg-stone-800 text-white text-xs font-black rounded-xl cursor-pointer transition-colors"
          >
            انجام دادم
          </button>
        ) : (
          <span className="inline-flex items-center gap-1.5 text-[11px] font-black text-stone-400">
            <Clock className="w-3.5 h-3.5" /> منتظر {partnerName}
          </span>
        )
      )}
    </motion.div>
  );
};
