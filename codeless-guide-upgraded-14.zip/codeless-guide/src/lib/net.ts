/**
 * fetch با سقف زمانی. بدون این، اگه یک درخواست روی شبکه‌ی ضعیف بی‌پاسخ می‌موند، چرخه‌ی
 * همگام‌سازی (که منتظر همون درخواست بود) برای همیشه می‌ایستاد: چت روی «در حال همگام‌سازی»
 * می‌موند و پیام‌ها دیگه به‌روز نمی‌شدن تا کاربر صفحه رو رفرش کنه.
 */
export async function fetchT(url: string, init: RequestInit = {}, timeoutMs = 10000): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...init, signal: controller.signal });
  } catch (err: any) {
    if (err?.name === 'AbortError') throw new Error('زمان پاسخ‌دهی سرور تمام شد');
    throw err;
  } finally {
    clearTimeout(timer);
  }
}
