export const AI_WORKER_URL = "https://purple-cloud-1df2.am-b-asdfghjkl20112011.workers.dev";

// هر درخواست یک سقف زمانی دارد؛ بدون این، اگر ورکر گیر کند، چت برای همیشه در حالت
// «درحال پردازش» می‌ماند و جعبه‌ی تایپ قفل می‌شد.
const REQUEST_TIMEOUT_MS = 25000;
const STREAM_IDLE_TIMEOUT_MS = 20000;

async function fetchWithTimeout(url: string, options: RequestInit, timeoutMs: number): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...options, signal: controller.signal });
  } catch (err: any) {
    if (err?.name === 'AbortError') throw new Error('پاسخ هوش مصنوعی خیلی طول کشید؛ دوباره امتحان کن.');
    throw err;
  } finally {
    clearTimeout(timer);
  }
}

// فقط خطاهای گذرا (شبکه، ۵xx و ۴۲۹) دوباره تلاش می‌شن؛ خطای ۴xx با تکرار درست نمی‌شه.
async function fetchWithRetry(url: string, options: RequestInit, retries = 3, backoff = 1000): Promise<Response> {
  let lastRes: Response | null = null;
  for (let i = 0; i < retries; i++) {
    try {
      const res = await fetchWithTimeout(url, options, REQUEST_TIMEOUT_MS);
      if (res.ok) return res;
      lastRes = res;
      if (res.status < 500 && res.status !== 429) return res;
    } catch (err: any) {
      if (typeof err?.message === 'string' && err.message.includes('خیلی طول کشید')) throw err;
      // network error → retry
    }
    if (i < retries - 1) {
      await new Promise(resolve => setTimeout(resolve, backoff * Math.pow(2, i)));
    }
  }
  if (lastRes) return lastRes;
  throw new Error('اتصال به هوش مصنوعی برقرار نشد؛ اینترنت رو بررسی کن.');
}

/**
 * Extracts AI text from various response structures of Cloudflare Workers AI
 */
function extractAIResponseText(data: any): string | null {
  if (!data) return null;
  
  if (typeof data === 'string') {
    const trimmed = data.trim();
    if (trimmed === 'SKIP') return 'SKIP';
    return trimmed.length > 0 ? trimmed : 'SKIP';
  }
  
  if (typeof data.response === 'string') {
    if (data.response.trim() === 'SKIP') return 'SKIP';
    return data.response.trim() || 'SKIP';
  }

  if (data.result !== undefined) {
    if (typeof data.result === 'string') {
      if (data.result.trim() === 'SKIP') return 'SKIP';
      return data.result.trim() || 'SKIP';
    }
    if (typeof data.result.response === 'string') {
      if (data.result.response.trim() === 'SKIP') return 'SKIP';
      return data.result.response.trim() || 'SKIP';
    }
    if (typeof data.result.text === 'string') {
      if (data.result.text.trim() === 'SKIP') return 'SKIP';
      return data.result.text.trim() || 'SKIP';
    }
    if (typeof data.result.reply === 'string') {
      if (data.result.reply.trim() === 'SKIP') return 'SKIP';
      return data.result.reply.trim() || 'SKIP';
    }
  }

  if (typeof data.reply === 'string') {
    if (data.reply.trim() === 'SKIP') return 'SKIP';
    return data.reply.trim() || 'SKIP';
  }
  if (typeof data.text === 'string') {
    if (data.text.trim() === 'SKIP') return 'SKIP';
    return data.text.trim() || 'SKIP';
  }
  if (typeof data.message === 'string') {
    if (data.message.trim() === 'SKIP') return 'SKIP';
    return data.message.trim() || 'SKIP';
  }
  if (Array.isArray(data.choices) && data.choices[0]?.message) {
    let raw = data.choices[0].message.content || data.choices[0].message.reasoning_content || data.choices[0].message.reasoning;
    if (typeof raw === 'string') {
        const content = raw.trim();
        if (content === 'SKIP') return 'SKIP';
        return content;
    }
  }

  return null;
}

/**
 * Universal Cloudflare AI Caller:
 * 1. Direct Cloudflare Worker AI with exact exact payload
 * 2. Backend Server proxy (/api/loveai)
 * 3. Heartfelt contextual Persian response generator
 */
export async function fetchLoveAI(payload: {
  type?: string;
  message?: string;
  prompt?: string;
  userMessage?: string;
  history?: string;
  contextData?: any;
}) {
  const textPrompt = payload.message || payload.prompt || payload.userMessage || '';
  const promptType = payload.type || 'chat';

  const exactPayload = {
    type: promptType,
    userMessage: textPrompt,
    contextData: payload.contextData || {},
    history: payload.history || ''
  };

  // Strategy 1: Direct Cloudflare AI Worker
  try {
    const res = await fetchWithRetry(`${AI_WORKER_URL}/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(exactPayload)
    }, 3, 1000);

    if (res.ok) {
      const rawText = await res.text();
      try {
        const parsed = JSON.parse(rawText);
        const result = extractAIResponseText(parsed);
        if (result !== null) return result;
        throw new Error(`پاسخ خالی یا نامعتبر: ${rawText.substring(0, 100)}`);
      } catch (e: any) {
        if (e.message.startsWith('پاسخ خالی')) throw e;
        const result = extractAIResponseText(rawText);
        if (result !== null) return result;
        throw new Error(`متن نامشخص: ${rawText.substring(0, 100)}`);
      }
    } else {
      const errText = await res.text();
      try {
        const errJson = JSON.parse(errText);
        if (errJson.message) throw new Error(errJson.message);
        if (errJson.error) throw new Error(errJson.error);
      } catch (e: any) {
        if (e.message && e.message !== 'Unexpected end of JSON input') throw e;
        throw new Error(`خطای ${res.status} در ارتباط با هوش مصنوعی: ${errText.substring(0, 100)}`);
      }
    }
  } catch (err: any) {
    throw err; // Let the UI handle network/HTTP errors via Toast
  }

  // Fallback shouldn't be reached unless fetch fails completely, 
  // but if we are here, we just throw error to let UI know
  throw new Error('عدم دریافت پاسخ معتبر از سرور');
}

// فقط متن «پاسخ» برداشته می‌شه. بخش reasoning/تفکر مدل قبلاً به متن پیام اضافه می‌شد و
// افکار داخلی مدل داخل چت نمایش داده می‌شد.
function extractStreamChunk(data: any): string {
  const delta = data?.choices?.[0]?.delta;
  if (typeof delta?.content === 'string') return delta.content;
  if (delta) return '';
  if (typeof data?.result === 'string') return data.result;
  if (typeof data?.text === 'string') return data.text;
  if (typeof data?.response === 'string') return data.response;
  return '';
}

export async function streamLoveAI(
  payload: {
    type?: string;
    message?: string;
    prompt?: string;
    userMessage?: string;
    history?: string;
    contextData?: any;
  },
  onChunk: (text: string) => void
): Promise<string> {
  const textPrompt = payload.message || payload.prompt || payload.userMessage || '';
  const promptType = payload.type || 'chat';

  const exactPayload = {
    type: promptType,
    userMessage: textPrompt,
    contextData: payload.contextData || {},
    history: payload.history || ''
  };

  const controller = new AbortController();
  let idleTimer: ReturnType<typeof setTimeout> | undefined;
  const armIdle = () => {
    if (idleTimer) clearTimeout(idleTimer);
    idleTimer = setTimeout(() => controller.abort(), STREAM_IDLE_TIMEOUT_MS);
  };

  let fullText = '';
  const handleLine = (rawLine: string) => {
    const line = rawLine.trim();
    if (!line) return;
    const payloadStr = line.startsWith('data:') ? line.slice(5).trim() : line;
    if (!payloadStr || payloadStr === '[DONE]' || payloadStr === 'SKIP') return;
    try {
      const chunk = extractStreamChunk(JSON.parse(payloadStr));
      if (chunk && chunk !== 'SKIP') {
        fullText += chunk;
        onChunk(fullText);
      }
    } catch {
      // خط غیر JSON: فقط وقتی متن ساده باشد (نه تکه‌ای از JSON) به پاسخ اضافه می‌شود
      if (!payloadStr.startsWith('{') && !payloadStr.startsWith('}') && !payloadStr.startsWith('[')) {
        fullText += payloadStr;
        onChunk(fullText);
      }
    }
  };

  try {
    armIdle();
    const res = await fetch(`${AI_WORKER_URL}/chat-stream`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(exactPayload),
      signal: controller.signal
    });

    if (res.ok && res.body) {
      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        armIdle();
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';
        lines.forEach(handleLine);
      }
      buffer += decoder.decode();
      if (buffer.trim()) handleLine(buffer);

      const finalText = fullText.trim();
      if (finalText === 'SKIP') return 'SKIP';
      if (finalText) return fullText;
      // استریم چیزی (جز تفکر مدل) نداد؛ یک‌بار با درخواست معمولی امتحان می‌کنیم
      return await fetchLoveAI(payload);
    }
    return await fetchLoveAI(payload);
  } catch (err) {
    console.error("Stream failed, falling back to /chat", err);
    // اگه قبل از قطع‌شدن متن قابل‌قبولی رسیده بود، همون رو نگه می‌داریم (درخواست دوم هزینه و تأخیر داره)
    if (fullText.trim().length > 20) return fullText;
    return await fetchLoveAI(payload);
  } finally {
    if (idleTimer) clearTimeout(idleTimer);
  }
}
