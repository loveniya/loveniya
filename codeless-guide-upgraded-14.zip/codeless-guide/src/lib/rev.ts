import { APP_SECRET } from './appSecret';
import { fetchT } from './net';

// آدرس پُل niya (همون که store و presence استفاده می‌کنن)
const WORKER_URL = "https://niya.am-b-asdfghjkl20112011.workers.dev";

/**
 * «شماره‌ی نسخه»ی سبک برای هر مجموعه‌ی داده.
 *
 * مشکل قبلی: هر ۵ ثانیه کل خاطره‌ها (با عکس‌های base64) و بقیه‌ی مجموعه‌ها
 * دوباره دانلود می‌شد، حتی وقتی هیچ چیزی عوض نشده بود. حالا بعد از هر نوشتن
 * موفق، یک عدد کوچک (زمان) زیر loveniya_rev/<مسیر> ذخیره می‌شه و دستگاه
 * مقابل فقط همین شیء ریز رو می‌خونه؛ اگه عدد عوض نشده بود، چیزی دانلود نمی‌شه.
 * اگه شیء نسخه‌ها در دسترس نبود، همه‌چیز مثل قبل کامل همگام می‌شه (بدون افت).
 */
export type RevMap = Record<string, number> | null;

export async function bumpRev(path: string): Promise<void> {
  try {
    await fetchT(`${WORKER_URL}/loveniya_rev/${path}.json`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', 'X-App-Secret': APP_SECRET },
      body: JSON.stringify(Date.now()),
    }, 8000);
  } catch {
    // شکست این درخواست مهم نیست؛ دستگاه مقابل حداکثر تا همگام‌سازی کامل بعدی صبر می‌کنه
  }
}

let lastFetchAt = 0;
let lastResult: Promise<RevMap> | null = null;

/** نسخه‌ها رو می‌خونه؛ چند صدازدن پشت‌سرهم در ~۱٫۵ ثانیه یک درخواست مشترک می‌شن. */
export function fetchRevs(): Promise<RevMap> {
  const now = Date.now();
  if (lastResult && now - lastFetchAt < 1500) return lastResult;
  lastFetchAt = now;
  lastResult = (async () => {
    try {
      const res = await fetchT(`${WORKER_URL}/loveniya_rev.json?_t=${now}`, {
        cache: 'no-store',
        headers: { 'X-App-Secret': APP_SECRET },
      }, 6000);
      if (!res.ok) return null;
      const data = await res.json();
      return data && typeof data === 'object' ? (data as Record<string, number>) : null;
    } catch {
      return null;
    }
  })();
  return lastResult;
}
