import { useEffect, useLayoutEffect, useRef } from 'react';

/**
 * صبر می‌کنه تا عنصر واقعاً روی صفحه بیاد (مثلاً بعد از پایان انیمیشن خروج صفحه‌ی قبلی) و
 * بعد به‌طور نرم بهش اسکرول می‌کنه. جایگزین setTimeout(…, 120)های ثابت که اگه انیمیشن
 * طول می‌کشید، عنصر هنوز وجود نداشت و اسکرول بی‌صدا انجام نمی‌شد.
 * هدر ثابت بالا با scroll-margin-top روی خود عنصر (scroll-mt-20) در نظر گرفته می‌شه.
 */
export function scrollToWhenReady(getEl: () => HTMLElement | null, maxMs = 1200): void {
  const start = performance.now();
  const tick = () => {
    const el = getEl();
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
      return;
    }
    if (performance.now() - start < maxMs) requestAnimationFrame(tick);
  };
  requestAnimationFrame(tick);
}

/**
 * وقتی یک «نمای باز شده» (جزئیات خاطره/عهد/آرزو/نامه) باز می‌شه، صفحه بالا می‌ره تا
 * عنوان دیده بشه؛ وقتی بسته می‌شه، جای قبلیِ لیست (همون کارتی که کلیک شده بود) برمی‌گرده.
 * قبلاً جزئیات در همون موقعیتِ اسکرولِ لیست باز می‌شد (وسط متن) و بعد از بستن، لیست از بالا شروع می‌شد.
 */
export function useDetailScroll(isOpen: boolean): void {
  const savedY = useRef<number | null>(null);
  const wasOpen = useRef(false);

  useLayoutEffect(() => {
    if (isOpen && !wasOpen.current) {
      savedY.current = window.scrollY;
      window.scrollTo({ top: 0, left: 0, behavior: 'instant' as ScrollBehavior });
    }
    wasOpen.current = isOpen;
  }, [isOpen]);

  useEffect(() => {
    if (isOpen) return;
    const y = savedY.current;
    if (y == null) return;
    savedY.current = null;
    // لیست بعد از انیمیشن خروج دوباره رندر می‌شه؛ تا وقتی ارتفاع کافی نشده صبر می‌کنیم
    const start = performance.now();
    let raf = 0;
    const tick = () => {
      const maxY = document.documentElement.scrollHeight - window.innerHeight;
      if (maxY >= y - 2 || performance.now() - start > 900) {
        window.scrollTo({ top: Math.min(y, Math.max(0, maxY)), left: 0, behavior: 'instant' as ScrollBehavior });
        return;
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [isOpen]);
}

/**
 * قفل اسکرول صفحه‌ی پشت مودال‌ها. شمارنده داره تا چند مودالِ هم‌زمان همدیگه رو باز نکنن
 * (قبلاً Navigation در cleanup خودش overflow رو خالی می‌کرد، حتی اگه مودال دیگه‌ای باز بود)،
 * و عرض اسکرول‌بار رو جبران می‌کنه تا صفحه روی دسکتاپ نپره.
 */
let lockCount = 0;
let prev = { html: '', body: '', pad: '' };

export function useBodyScrollLock(active: boolean): void {
  useEffect(() => {
    if (!active) return;
    const html = document.documentElement;
    const body = document.body;
    if (lockCount === 0) {
      prev = { html: html.style.overflow, body: body.style.overflow, pad: body.style.paddingRight };
      const sbw = window.innerWidth - html.clientWidth;
      html.style.overflow = 'hidden';
      body.style.overflow = 'hidden';
      if (sbw > 0) body.style.paddingRight = `${sbw}px`;
    }
    lockCount += 1;
    return () => {
      lockCount = Math.max(0, lockCount - 1);
      if (lockCount === 0) {
        html.style.overflow = prev.html;
        body.style.overflow = prev.body;
        body.style.paddingRight = prev.pad;
      }
    };
  }, [active]);
}
