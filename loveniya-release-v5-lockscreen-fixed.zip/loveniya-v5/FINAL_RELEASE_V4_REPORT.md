# Loveniya — Release V4

## Scope
این release بر پایه‌ی آخرین snapshot پایدار V3 ساخته شده است. snapshot پایه قبل از حذف «دوز عاشقی» در مسیر `../continuation-v3-before-tictactoe-removal` نگه داشته شده و release قبلی نیز در `/mnt/data/loveniya-next/loveniya-continuation-v3.zip` دست‌نخورده باقی مانده است.

## حذف امن «دوز عاشقی»
- تب، UI و منطق Tic-Tac-Toe حذف شد.
- `board` / `turn` / `scores` / `winner` از مدل اجرایی Moments حذف شدند.
- منطق server-authoritative مخصوص Tic-Tac-Toe حذف شد.
- CSS و smoke test اختصاصی آن حذف شد.
- bookmark قدیمی `?tab=tictactoe` بدون خطا به `bottle` fallback می‌شود.
- route `/games` برای سازگاری باقی مانده و همچنان صفحه‌ی بازی‌های باقی‌مانده را باز می‌کند.
- داده‌های قدیمی Tic-Tac-Toe هنگام read/write حذف می‌شوند و داده‌های Truth/Dare و Telepathy حفظ می‌شوند.

## Runtime target
- Node.js `24.21.0`
- npm `11.19.0`
- `.nvmrc` و `.node-version` روی `24.21.0`
- CI روی `24.21.0`
- `package.json` engines روی Node 24.x و npm 11.x

## Verification انجام‌شده در sandbox
- `node scripts/qa.mjs` → PASS
- `node scripts/syntax-smoke.mjs` → PASS — 38 فایل TypeScript، صفر diagnostic نحوی
- `npm run test:games` → PASS
  - `MOMENTS_ENGINE_SMOKE_PASS`
  - `TRUTH_DARE_SMOKE_PASS`
- `npm ci --dry-run --offline --ignore-scripts` → PASS برای graph قفل‌شده‌ی 179 package

## Build / E2E
اجرای clean install واقعی و production build داخل sandbox به‌دلیل محدودیت دسترسی شبکه/registry و نبود runtime Node 24.21.0 در خود محیط تکمیل نشد. محیط فعلی Node 22.16.0 است و پروژه عمداً آن را با engines جدید نمی‌پذیرد. بنابراین build موفق production یا browser E2E به‌صورت جعلی اعلام نشده است.

CI پروژه برای اجرای clean install، QA، typecheck و build روی Node 24.21.0 آماده و pin شده است.
