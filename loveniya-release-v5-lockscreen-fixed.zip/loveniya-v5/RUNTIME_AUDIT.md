# Runtime audit

Node.js v24.21.0 is the audited runtime target for this release. The official Node.js archive lists v24.21.0 and npm v11.19.0.

The container used during this pass has no DNS/network path for downloading Node binaries, so the final build is not claimed as executed under Node 24 inside the sandbox. CI is configured for Node 24 and package engines are constrained to Node 24.x / npm 11.x.
