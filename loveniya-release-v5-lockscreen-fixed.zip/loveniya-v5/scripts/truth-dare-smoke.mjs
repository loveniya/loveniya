// Lightweight regression checks for the Truth/Dare state machine.
import { createTruthOrDareRound, answerTruthOrDare, skipTruthOrDare, canSpinTruthOrDare, sanitizeTruthOrDareRound } from '../dist-test/truthOrDare.js';

const round = createTruthOrDareRound('amin', 'truth', [], 1000);
if (round.spinnerId !== 'amin' || round.answererId !== 'niyayesh' || round.status !== 'waiting') throw new Error('round initialization failed');
if (canSpinTruthOrDare('amin', round) || !canSpinTruthOrDare('niyayesh', null)) throw new Error('turn gating failed');
const answered = answerTruthOrDare(round, 2000);
if (answered.status !== 'answered' || answered.answeredAt !== 2000) throw new Error('answer transition failed');
if (!canSpinTruthOrDare('niyayesh', answered)) throw new Error('next turn failed');
const skipped = skipTruthOrDare(round, 3000);
if (skipped.status !== 'skipped') throw new Error('skip transition failed');
if (sanitizeTruthOrDareRound({ ...round, text: 'x'.repeat(501) }) !== null) throw new Error('oversized payload accepted');

const legacy = sanitizeTruthOrDareRound({ type: 'truth', text: 'سوال قدیمی', timestamp: 4000, spinnerId: 'niyayesh' });
if (!legacy || legacy.id !== 'legacy-td-4000' || legacy.answererId !== 'amin' || legacy.status !== 'waiting') throw new Error('legacy migration failed');
console.log('TRUTH_DARE_SMOKE_PASS');
