import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const srcRoot = path.join(root, 'src');
const files = [];

function walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(full);
    else if (/\.(ts|tsx|js|jsx|mjs|cjs)$/.test(entry.name)) files.push(full);
  }
}
walk(srcRoot);

const failures = [];
const text = files.map(file => ({ file, text: fs.readFileSync(file, 'utf8') }));

const retiredGamePattern = /دوز عاشقی|Tic[-\s]?Tac[-\s]?Toe|tictactoe|getTicTacToeWinner|game-panel--tictactoe/;

for (const { file, text: source } of text) {
  const rel = path.relative(root, file);
  if (/dangerouslySetInnerHTML\s*=/.test(source) && !rel.endsWith('src/components/RomanticEffects.tsx')) {
    failures.push(`${rel}: unexpected dangerouslySetInnerHTML`);
  }
  if (/\beval\s*\(|\bnew\s+Function\s*\(/.test(source)) {
    failures.push(`${rel}: dynamic code execution detected`);
  }
  if (/X-App-Secret|APP_SECRET|CLOUDFLARE_AI_WORKER_URL|DATA_WORKER_URL/.test(source) && rel.startsWith('src/')) {
    failures.push(`${rel}: server-only secret/upstream token leaked into client source`);
  }
  if (/<button(?![^>]*\btype=)[^>]*>/i.test(source)) {
    failures.push(`${rel}: button without explicit type`);
  }
  if (retiredGamePattern.test(source)) {
    failures.push(`${rel}: retired Tic-Tac-Toe references detected`);
  }
}

const vite = fs.readFileSync(path.join(root, 'vite.config.ts'), 'utf8');
if (vite.includes('__dirname')) failures.push('vite.config.ts: __dirname is not ESM-safe');

const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
for (const forbidden of ['html2canvas', 'tailwind-merge']) {
  if (pkg.dependencies?.[forbidden] || pkg.devDependencies?.[forbidden]) {
    failures.push(`package.json: unused dependency still present: ${forbidden}`);
  }
}

const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
if (!/viewport-fit=cover/.test(html)) failures.push('index.html: viewport-fit=cover missing');

if (failures.length) {
  console.error('QA FAILED');
  for (const failure of failures) console.error(`- ${failure}`);
  process.exit(1);
}

console.log(`QA PASS — ${files.length} source files scanned.`);
