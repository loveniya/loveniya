import { mergeMomentsPatch, sanitizeMomentsForViewer } from '../dist-test/momentsEngine.js';

const empty = {};
const td = { id: 'td-1', type: 'truth', text: 'آخرین چیزی که واقعاً خوشحالت کرد چی بود؟', spinnerId: 'amin', answererId: 'niyayesh', status: 'waiting', createdAt: 10 };
const withTd = mergeMomentsPatch({ board: ['X', null, null], scores: { amin: 9, niyayesh: 8, draws: 1 } }, { lastBottleResult: td }, 'amin');
if ('board' in withTd || 'turn' in withTd || 'winner' in withTd || 'scores' in withTd || withTd.lastBottleResult?.status !== 'waiting') throw new Error('retired state or truth/dare start failed');
const ended = mergeMomentsPatch(withTd, { lastBottleResult: { ...td, status: 'answered', answeredAt: 20 } }, 'niyayesh');
if (ended.lastBottleResult?.status !== 'answered') throw new Error('truth/dare answer failed');
const q = { id: 'q-1', q: 'چای یا قهوه؟', a: 'چای', b: 'قهوه' };
const withQ = mergeMomentsPatch(ended, { currentTelepathyQuestion: q }, 'amin');
const withA = mergeMomentsPatch(withQ, { telepathyChoices: { 'q-1': { amin: 'A' } } }, 'amin');
const viewerB = sanitizeMomentsForViewer(withA, 'niyayesh');
if (viewerB.telepathyChoices?.['q-1']?.amin) throw new Error('telepathy answer leaked before both players answered');
const withB = mergeMomentsPatch(withA, { telepathyChoices: { 'q-1': { niyayesh: 'B' } } }, 'niyayesh');
const viewerBoth = sanitizeMomentsForViewer(withB, 'niyayesh');
if (viewerBoth.telepathyChoices?.['q-1']?.amin !== 'A' || viewerBoth.telepathyChoices?.['q-1']?.niyayesh !== 'B') throw new Error('telepathy reveal failed');
const next = mergeMomentsPatch(withB, { currentTelepathyQuestion: { id: 'q-2', q: 'شب یا روز؟', a: 'شب', b: 'روز' } }, 'amin');
if (next.currentTelepathyQuestion?.id !== 'q-2') throw new Error('next telepathy question failed');
console.log('MOMENTS_ENGINE_SMOKE_PASS');
