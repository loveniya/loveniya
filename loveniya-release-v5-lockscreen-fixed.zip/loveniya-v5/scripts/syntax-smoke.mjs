import fs from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { createRequire } from 'node:module';

const root = process.cwd();
const candidate = path.resolve(process.execPath, '..', '..', 'lib', 'node_modules', 'typescript', 'lib', 'typescript.js');
const require = createRequire(import.meta.url);
const ts = fs.existsSync(candidate)
  ? require(candidate)
  : require('typescript');

const files = [];
function walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      if (!['node_modules', 'dist', 'dist-test'].includes(entry.name)) walk(full);
    } else if (/\.(ts|tsx)$/.test(entry.name)) {
      files.push(full);
    }
  }
}
walk(path.join(root, 'src'));
files.push(path.join(root, 'server.ts'));

let errors = 0;
for (const file of files) {
  const source = fs.readFileSync(file, 'utf8');
  const ext = file.endsWith('.tsx') ? ts.ScriptKind.TSX : ts.ScriptKind.TS;
  const result = ts.transpileModule(source, {
    fileName: file,
    reportDiagnostics: true,
    compilerOptions: {
      target: ts.ScriptTarget.ES2022,
      module: ts.ModuleKind.ESNext,
      jsx: ts.JsxEmit.ReactJSX,
      moduleResolution: ts.ModuleResolutionKind.Bundler,
      isolatedModules: true,
      skipLibCheck: true,
    },
  });
  const diagnostics = (result.diagnostics || []).filter(d => d.category === ts.DiagnosticCategory.Error);
  for (const diagnostic of diagnostics) {
    errors += 1;
    const message = ts.flattenDiagnosticMessageText(diagnostic.messageText, '\n');
    console.error(`${path.relative(root, file)}: ${message}`);
  }
}

if (errors) process.exit(1);
console.log(`SYNTAX_SMOKE_PASS — ${files.length} TypeScript files parsed with zero syntax diagnostics.`);
