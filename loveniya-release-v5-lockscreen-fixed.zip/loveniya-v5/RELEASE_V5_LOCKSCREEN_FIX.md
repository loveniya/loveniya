# Release V5 — Auth UI & password restoration

## What was restored

- The legacy application passphrase behavior is restored server-side. The normalized passphrase is `دوست دارم عشقم` and is represented by a SHA-256 hash in `.env.example`.
- The password is never placed in the browser bundle.
- The selected user colors are distinct again:
  - Amin: sky/cyan
  - Niyayesh: rose/fuchsia
- The login surface is a glassier, warmer, more expressive composition instead of a flat neutral card.
- Backend-unavailable errors are no longer incorrectly presented as "wrong password".

## Important deployment finding

The screenshot shows the app being served from GitHub Pages. GitHub Pages is static hosting and cannot execute the secure Express `/api/auth/*` and `/api/data/*` routes used by this release.

Therefore the secure production release must be served with the secure gateway on the same origin (or an equivalent properly configured API origin). A client-side password fallback was intentionally NOT added because it would put the password back in the public JavaScript bundle.

## Verification

- Syntax smoke: PASS
- Static QA: PASS
- Pure game engine compile: PASS
- Full production build: NOT claimed in this sandbox because the current runtime is Node 22.16 while the release requires Node 24.21+ and the dependency install cannot complete from the available registry/cache.
