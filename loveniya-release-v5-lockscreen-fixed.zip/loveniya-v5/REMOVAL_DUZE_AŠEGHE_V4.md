# Release V4 — حذف امن دوز عاشقی

این نسخه از آخرین snapshot پایدار V3 ساخته شده و snapshot قبلی دست‌نخورده در `../continuation-v3-before-tictactoe-removal` نگه داشته شده است.

## حذف‌ها
- تب و UI بازی «دوز عاشقی» حذف شد.
- stateهای `board` / `turn` / `scores` / `winner` از مدل Moments حذف شد.
- منطق Tic-Tac-Toe از `src/lib/momentsEngine.ts` حذف شد.
- route `/games` برای سازگاری باقی مانده و همچنان به صفحه‌ی بازی‌های باقی‌مانده می‌رود.
- `/moments?tab=tictactoe` به‌صورت امن به تب `bottle` fallback می‌کند.
- CSS و smoke test مخصوص Tic-Tac-Toe حذف شدند.

## حفظ داده
داده‌های قدیمی Tic-Tac-Toe در خواندن و نوشتن به‌صورت silent discard حذف می‌شوند؛ بنابراین وجود snapshot قدیمی باعث crash یا بازگشت بازی حذف‌شده نمی‌شود. داده‌های Truth/Dare و Telepathy حفظ می‌شوند.

## تست
- Static QA باید بدون reference به Tic-Tac-Toe سبز شود.
- Moments smoke اکنون فقط Truth/Dare، Telepathy redaction و migration state قدیمی را بررسی می‌کند.
- Snapshot قبلی قابل بازیابی است.
