import React from 'react';

interface CharacterAvatarProps {
  className?: string;
}

/**
 * Modern, warm flat-illustration avatars for Amin and Niayesh — used as a
 * friendly "profile picture" in chat since there are no uploaded photos.
 */

export const MaleAvatar: React.FC<CharacterAvatarProps> = ({ className = 'w-11 h-11' }) => (
  <div className={`${className} rounded-full shrink-0 shadow-md overflow-hidden ring-2 ring-white`}>
    <svg viewBox="0 0 100 100" className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="maleBg" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#7dd3c8" />
          <stop offset="100%" stopColor="#0f766e" />
        </linearGradient>
        <linearGradient id="maleHair" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#4a372a" />
          <stop offset="100%" stopColor="#2b1d15" />
        </linearGradient>
        <linearGradient id="maleSkin" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#ffd9b0" />
          <stop offset="100%" stopColor="#f3b787" />
        </linearGradient>
      </defs>
      <circle cx="50" cy="50" r="50" fill="url(#maleBg)" />

      {/* Shirt / shoulders */}
      <path d="M10 100 C10 76 28 66 50 66 C72 66 90 76 90 100 Z" fill="#f8fafc" />
      <path d="M38 69 L50 86 L62 69 L57 72 L50 80 L43 72 Z" fill="#0f766e" />
      <circle cx="30" cy="88" r="2.2" fill="#0f766e" opacity="0.5" />
      <circle cx="70" cy="88" r="2.2" fill="#0f766e" opacity="0.5" />

      {/* Neck shadow */}
      <path d="M40 58 Q50 66 60 58 L60 68 Q50 74 40 68 Z" fill="#e6a476" />
      {/* Neck */}
      <rect x="41" y="52" width="18" height="14" rx="7" fill="url(#maleSkin)" />

      {/* Ears */}
      <circle cx="27.5" cy="45" r="4.2" fill="url(#maleSkin)" />
      <circle cx="72.5" cy="45" r="4.2" fill="url(#maleSkin)" />

      {/* Face */}
      <ellipse cx="50" cy="41" rx="21.5" ry="22.5" fill="url(#maleSkin)" />
      {/* Soft cheek shading */}
      <ellipse cx="35" cy="49" rx="5" ry="3.4" fill="#f2a06c" opacity="0.45" />
      <ellipse cx="65" cy="49" rx="5" ry="3.4" fill="#f2a06c" opacity="0.45" />

      {/* Modern textured crop hair with side part */}
      <path d="M27 34 C24 14 36 6 50 6 C64 6 76 14 73 34 C72 24 68 30 64 25 C64 32 59 20 50 20 C41 20 36 32 36 25 C32 30 28 24 27 34 Z" fill="url(#maleHair)" />
      <path d="M27 34 C26 28 27 22 30 18 C29 24 30 29 33 32 Z" fill="#5a4433" opacity="0.6" />

      {/* Eyebrows */}
      <path d="M36 35 Q41.5 32 47 35" stroke="#2b1d15" strokeWidth="2.2" fill="none" strokeLinecap="round" />
      <path d="M53 35 Q58.5 32 64 35" stroke="#2b1d15" strokeWidth="2.2" fill="none" strokeLinecap="round" />

      {/* Eyes — bigger, friendlier, with catchlight */}
      <ellipse cx="42" cy="42.5" rx="3.4" ry="4" fill="#2c2015" />
      <ellipse cx="58" cy="42.5" rx="3.4" ry="4" fill="#2c2015" />
      <circle cx="43.1" cy="41" r="1.1" fill="#ffffff" />
      <circle cx="59.1" cy="41" r="1.1" fill="#ffffff" />

      {/* Nose */}
      <path d="M50 44 Q51.5 49 49 50.5" stroke="#d99565" strokeWidth="1.6" fill="none" strokeLinecap="round" />

      {/* Smile */}
      <path d="M41 53 Q50 60 59 53" stroke="#8a4a2e" strokeWidth="2.4" fill="none" strokeLinecap="round" />
      <path d="M45 55.5 Q50 58 55 55.5" stroke="#ffffff" strokeWidth="1.6" fill="none" strokeLinecap="round" opacity="0.7" />
    </svg>
  </div>
);

export const FemaleAvatar: React.FC<CharacterAvatarProps> = ({ className = 'w-11 h-11' }) => (
  <div className={`${className} rounded-full shrink-0 shadow-md overflow-hidden ring-2 ring-white`}>
    <svg viewBox="0 0 100 100" className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="femaleBg" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#ffc2cc" />
          <stop offset="100%" stopColor="#e11d5e" />
        </linearGradient>
        <linearGradient id="femaleHair" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#5a3a28" />
          <stop offset="100%" stopColor="#372317" />
        </linearGradient>
        <linearGradient id="femaleSkin" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#ffdfc0" />
          <stop offset="100%" stopColor="#f6c199" />
        </linearGradient>
      </defs>
      <circle cx="50" cy="50" r="50" fill="url(#femaleBg)" />

      {/* Shirt / shoulders */}
      <path d="M9 100 C9 74 27 64 50 64 C73 64 91 74 91 100 Z" fill="#fff5f7" />
      <path d="M38 67 L50 81 L62 67 L56 70 L50 76 L44 70 Z" fill="#e11d5e" />

      {/* Hair — back layer, flows past the shoulders */}
      <path d="M21 42 C18 66 21 86 29 96 L35 84 C29 72 28 56 23 42 Z" fill="url(#femaleHair)" />
      <path d="M79 42 C82 66 79 86 71 96 L65 84 C71 72 72 56 77 42 Z" fill="url(#femaleHair)" />

      {/* Neck shadow + neck */}
      <path d="M40 57 Q50 65 60 57 L60 67 Q50 73 40 67 Z" fill="#eab088" />
      <rect x="41" y="52" width="18" height="13" rx="6.5" fill="url(#femaleSkin)" />

      {/* Ears + simple stud earrings */}
      <circle cx="26.5" cy="44" r="4" fill="url(#femaleSkin)" />
      <circle cx="73.5" cy="44" r="4" fill="url(#femaleSkin)" />
      <circle cx="26.5" cy="47.5" r="1.4" fill="#ffd66b" />
      <circle cx="73.5" cy="47.5" r="1.4" fill="#ffd66b" />

      {/* Face */}
      <ellipse cx="50" cy="40" rx="20.5" ry="21.5" fill="url(#femaleSkin)" />
      {/* Blush */}
      <ellipse cx="35.5" cy="47" rx="5" ry="3.2" fill="#f78ba0" opacity="0.55" />
      <ellipse cx="64.5" cy="47" rx="5" ry="3.2" fill="#f78ba0" opacity="0.55" />

      {/* Hair — top layer with soft center-part waves */}
      <path d="M25 38 C21 12 37 4 50 4 C63 4 79 12 75 38 C74 22 66 12 50 12 C34 12 26 22 25 38 Z" fill="url(#femaleHair)" />
      <path d="M31 20 C34 16 40 13 50 13 C60 13 66 16 69 20 C63 17 57 16 50 16 C43 16 37 17 31 20 Z" fill="#6b4632" opacity="0.6" />

      {/* Eyebrows */}
      <path d="M36 34 Q41.5 31 47 34" stroke="#372317" strokeWidth="2" fill="none" strokeLinecap="round" />
      <path d="M53 34 Q58.5 31 64 34" stroke="#372317" strokeWidth="2" fill="none" strokeLinecap="round" />

      {/* Eyes — bigger, with lashes and catchlight */}
      <ellipse cx="42" cy="41.5" rx="3.6" ry="4.3" fill="#2c2015" />
      <ellipse cx="58" cy="41.5" rx="3.6" ry="4.3" fill="#2c2015" />
      <circle cx="43.2" cy="39.8" r="1.2" fill="#ffffff" />
      <circle cx="59.2" cy="39.8" r="1.2" fill="#ffffff" />
      <path d="M37.5 38 L35.5 36" stroke="#2c2015" strokeWidth="1.5" strokeLinecap="round" />
      <path d="M62.5 38 L64.5 36" stroke="#2c2015" strokeWidth="1.5" strokeLinecap="round" />

      {/* Nose */}
      <path d="M50 43 Q51.3 47.5 49 49" stroke="#d99565" strokeWidth="1.5" fill="none" strokeLinecap="round" />

      {/* Smile */}
      <path d="M41.5 52 Q50 59 58.5 52" stroke="#b8523f" strokeWidth="2.2" fill="none" strokeLinecap="round" />
      <path d="M45 54.5 Q50 57 55 54.5" stroke="#ffffff" strokeWidth="1.5" fill="none" strokeLinecap="round" opacity="0.7" />

      {/* Small bow accent */}
      <path d="M50 9 L44.5 5 L44.5 13 Z" fill="#e11d5e" />
      <path d="M50 9 L55.5 5 L55.5 13 Z" fill="#e11d5e" />
      <circle cx="50" cy="9" r="2.1" fill="#be123c" />
    </svg>
  </div>
);

export default { MaleAvatar, FemaleAvatar };
