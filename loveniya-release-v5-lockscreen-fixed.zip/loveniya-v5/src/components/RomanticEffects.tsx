import React, { useEffect, useState, useMemo, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Heart } from 'lucide-react';

interface Particle {
  id: string;
  x: number;
  y: number;
}

export const RomanticEffects: React.FC = () => {
  const [clicks, setClicks] = useState<Particle[]>([]);
  const particleTimersRef = useRef<number[]>([]);
  const prefersReducedMotion = useMemo(
    () => typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches,
    []
  );

  useEffect(() => {
    if (prefersReducedMotion) return; // بدون افکت‌های تزئینی اضافه برای کاربرانی که حرکت کم را ترجیح می‌دهند

    const handleClick = (e: MouseEvent) => {
      // Don't spawn hearts if clicking on a button or input
      const target = e.target as HTMLElement;
      if (target.tagName === 'BUTTON' || target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.closest('button')) {
        return;
      }

      const particleId = `particle_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
      const newParticle: Particle = { id: particleId, x: e.clientX, y: e.clientY };
      setClicks((prev) => [...prev, newParticle]);

      // Remove after animation completes
      const timer = window.setTimeout(() => {
        setClicks((prev) => prev.filter(p => p.id !== particleId));
        particleTimersRef.current = particleTimersRef.current.filter(id => id !== timer);
      }, 900);
      particleTimersRef.current.push(timer);
    };

    window.addEventListener('click', handleClick);
    return () => {
      window.removeEventListener('click', handleClick);
      particleTimersRef.current.forEach(window.clearTimeout);
      particleTimersRef.current = [];
    };
  }, []);

  // Spawn some floating particles continuously in the background
  const [floaters, setFloaters] = useState<{id: string, left: string, delay: string, duration: string, size: number}[]>([]);
  
  useEffect(() => {
    if (prefersReducedMotion) return;

    // Subtle background ambience: intentionally sparse so content stays primary.
    const newFloaters = Array.from({ length: 8 }).map((_, i) => ({
      id: `floater_${i}`,
      left: `${(i * 12.5) + (Math.random() * 5 - 2.5)}vw`,
      delay: `-${Math.random() * 24}s`,
      duration: `${22 + Math.random() * 12}s`,
      size: 12 + Math.random() * 10
    }));
    setFloaters(newFloaters);
  }, []);

  return (
    <>
      {/* Background Floating Particles */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        {floaters.map(f => (
          <div
            key={f.id}
            className="ambient-floater absolute bottom-[-10vh] text-rose-300/35"
            style={{
              left: f.left,
              animation: `floatUp ${f.duration} linear infinite`,
              animationDelay: f.delay,
              fontSize: `${f.size}px`
            }}
          >
            ❤
          </div>
        ))}
      </div>

      {/* Click Hearts */}
      <div className="fixed inset-0 pointer-events-none z-50">
        <AnimatePresence>
          {clicks.map(click => (
            <motion.div
              key={click.id}
              initial={{ scale: 0, opacity: 1, x: click.x - 12, y: click.y - 12 }}
              animate={{ 
                scale: 1.5, 
                opacity: 0,
                y: click.y - 50 
              }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.8, ease: "easeOut" }}
              className="absolute text-rose-500"
            >
              <Heart className="w-6 h-6 fill-rose-500" />
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </>
  );
};
