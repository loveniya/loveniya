import React from 'react';
import { AlertTriangle, RotateCcw } from 'lucide-react';

interface Props { children: React.ReactNode }
interface State { hasError: boolean; message: string }

export class AppErrorBoundary extends React.Component<Props, State> {
  state: State = { hasError: false, message: '' };

  static getDerivedStateFromError(error: unknown): State {
    return {
      hasError: true,
      message: error instanceof Error ? error.message : 'خطای غیرمنتظره‌ای رخ داد.',
    };
  }

  componentDidCatch(error: unknown, info: React.ErrorInfo) {
    console.error('Loveniya UI Error:', error, info.componentStack);
  }

  render() {
    if (!this.state.hasError) return this.props.children;
    return (
      <div className="min-h-[100dvh] flex items-center justify-center bg-rose-50 px-5 py-10" dir="rtl">
        <section role="alert" className="w-full max-w-md rounded-[28px] border border-rose-100 bg-white p-6 sm:p-8 text-center shadow-xl shadow-rose-900/10">
          <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-rose-50 text-rose-600">
            <AlertTriangle className="h-7 w-7" />
          </div>
          <h1 className="text-lg font-black text-stone-900">یک خطای غیرمنتظره رخ داد</h1>
          <p className="mt-2 text-sm font-bold leading-6 text-stone-500">
            صفحه را دوباره باز کن. اطلاعات ذخیره‌شده محلی دست‌نخورده می‌ماند.
          </p>
          <button
            type="button"
            onClick={() => window.location.reload()}
            className="mt-6 inline-flex min-h-11 items-center justify-center gap-2 rounded-2xl bg-rose-500 px-5 text-sm font-black text-white shadow-md transition hover:bg-rose-600 active:scale-[0.98]"
          >
            <RotateCcw className="h-4 w-4" />
            تلاش دوباره
          </button>
          <details className="mt-5 text-right">
            <summary className="cursor-pointer text-[11px] font-bold text-stone-400">جزئیات فنی</summary>
            <code className="mt-2 block max-h-24 overflow-auto rounded-xl bg-stone-50 p-3 text-[10px] leading-5 text-stone-500 break-words">
              {this.state.message || 'Unknown error'}
            </code>
          </details>
        </section>
      </div>
    );
  }
}
