import React, { useEffect, useRef, useState } from 'react';
import { Lock, Eye, EyeOff, AlertCircle, UserRound, Heart } from 'lucide-react';
import clsx from 'clsx';
import { unlock } from '../lib/api';

export const LockScreen: React.FC<{ onUnlock: () => void }> = ({ onUnlock }) => {
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedUser, setSelectedUser] = useState<'amin' | 'niyayesh' | null>(null);
  const [busy, setBusy] = useState(false);
  const passwordRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    passwordRef.current?.focus();
  }, []);

  const userTheme = selectedUser === 'amin'
    ? {
        accent: 'text-sky-700',
        muted: 'text-sky-600',
        border: 'border-sky-300',
        soft: 'bg-sky-50',
        ring: 'focus:border-sky-300 focus:ring-sky-100',
        button: 'from-sky-500 to-cyan-500',
        glow: 'rgba(14,165,233,0.22)',
      }
    : selectedUser === 'niyayesh'
      ? {
          accent: 'text-rose-700',
          muted: 'text-rose-600',
          border: 'border-rose-300',
          soft: 'bg-rose-50',
          ring: 'focus:border-rose-300 focus:ring-rose-100',
          button: 'from-rose-500 to-fuchsia-500',
          glow: 'rgba(244,63,94,0.20)',
        }
      : {
          accent: 'text-stone-700',
          muted: 'text-stone-500',
          border: 'border-stone-200',
          soft: 'bg-white',
          ring: 'focus:border-stone-300 focus:ring-stone-100',
          button: 'from-rose-500 to-violet-500',
          glow: 'rgba(189,66,111,0.18)',
        };

  const checkPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUser || busy) return;
    if (!password) {
      setError('رمز عبور را وارد کن.');
      passwordRef.current?.focus();
      return;
    }

    setBusy(true);
    setError(null);
    try {
      const user = await unlock(password, selectedUser);
      localStorage.setItem('loveniya_user', user);
      onUnlock();
    } catch (err) {
      const code = err instanceof Error ? err.message : '';
      if (code === 'AUTH_BACKEND_UNAVAILABLE') {
        setError('درگاه امن ورود در دسترس نیست. این نسخه باید همراه سرور امن اجرا شود.');
      } else {
        setError('رمز عبور درست نیست.');
        setPassword('');
        passwordRef.current?.focus();
      }
    } finally {
      setBusy(false);
    }
  };

  return (
    <div role="dialog" aria-modal="true" aria-labelledby="lock-title" className="fixed inset-0 z-[100] flex items-center justify-center px-5 py-7 sm:px-6 bg-[radial-gradient(circle_at_12%_8%,rgba(125,211,252,0.20),transparent_30%),radial-gradient(circle_at_88%_12%,rgba(244,114,182,0.18),transparent_32%),linear-gradient(160deg,#f8fbff_0%,#fff7fb_48%,#f5f1fb_100%)] backdrop-blur-xl" dir="rtl">
      <div className="absolute inset-0 pointer-events-none overflow-hidden" aria-hidden="true">
        <div className="absolute -top-24 -right-20 w-72 h-72 rounded-full bg-sky-200/35 blur-3xl" />
        <div className="absolute -bottom-24 -left-16 w-80 h-80 rounded-full bg-rose-200/30 blur-3xl" />
        <div className="absolute top-1/2 left-1/2 w-56 h-56 -translate-x-1/2 -translate-y-1/2 rounded-full bg-violet-200/20 blur-3xl" />
      </div>

      <div className="relative w-full max-w-[26rem] glass-modal rounded-[2rem] px-5 py-6 sm:px-7 sm:py-7 text-center overflow-hidden">
        <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-sky-400 via-fuchsia-400 to-rose-400" aria-hidden="true" />

        <div
          className="mx-auto mb-4 w-16 h-16 rounded-[1.35rem] flex items-center justify-center text-white shadow-lg"
          style={{ background: 'linear-gradient(135deg,#38bdf8 0%,#8b5cf6 48%,#f43f5e 100%)', boxShadow: `0 16px 36px ${userTheme.glow}` }}
        >
          <Lock className="w-7 h-7" strokeWidth={2.2} />
        </div>

        <div className="flex items-center justify-center gap-1.5 text-[11px] font-black text-rose-600 mb-2">
          <Heart className="w-3.5 h-3.5 fill-current" />
          <span>به جهان ما خوش آمدی</span>
        </div>
        <h2 id="lock-title" className="text-[1.65rem] leading-none font-black text-slate-900 tracking-tight">امین × نیایش</h2>
        <p className="mt-2 text-[0.72rem] font-bold leading-relaxed text-slate-500">اول خودت را انتخاب کن، بعد رمز ورود را وارد کن.</p>

        <form onSubmit={checkPassword} className="mt-6 space-y-3.5">
          <div className="grid grid-cols-2 gap-3" aria-label="انتخاب کاربر">
            {([
              ['amin', 'امین', 'sky'],
              ['niyayesh', 'نیایش', 'rose'],
            ] as const).map(([id, label, theme]) => {
              const active = selectedUser === id;
              const isAmin = theme === 'sky';
              const activeClass = isAmin
                ? 'border-sky-300 bg-sky-50 text-sky-700 shadow-[0_10px_24px_rgba(14,165,233,0.12)]'
                : 'border-rose-300 bg-rose-50 text-rose-700 shadow-[0_10px_24px_rgba(244,63,94,0.12)]';
              const iconClass = active
                ? (isAmin ? 'text-sky-500' : 'text-rose-500')
                : 'text-slate-400';
              return (
                <button
                  key={id}
                  type="button"
                  onClick={() => { setSelectedUser(id); setError(null); }}
                  className={clsx(
                    'relative min-h-[4.15rem] rounded-[1.2rem] border-2 text-sm font-black transition-all flex flex-col items-center justify-center gap-1.5',
                    active ? activeClass : 'border-slate-200/90 bg-white/75 text-slate-500 hover:bg-white hover:-translate-y-0.5'
                  )}
                  aria-pressed={active}
                >
                  <UserRound className={clsx('w-5 h-5', iconClass)} />
                  <span>{label}</span>
                  <span className={clsx('absolute bottom-2 w-1.5 h-1.5 rounded-full', isAmin ? 'bg-sky-400' : 'bg-rose-400', active ? 'opacity-100' : 'opacity-30')} aria-hidden="true" />
                </button>
              );
            })}
          </div>

          <div className="relative">
            <label htmlFor="lock-password" className="sr-only">رمز عبور</label>
            <input
              id="lock-password"
              ref={passwordRef}
              type={showPassword ? 'text' : 'password'}
              value={password}
              autoComplete="current-password"
              onChange={e => { setPassword(e.target.value); setError(null); }}
              placeholder="رمز عبور"
              className={clsx('w-full h-13 rounded-[1.15rem] bg-white/85 border-2 px-12 pr-4 text-center text-sm font-bold text-slate-800 placeholder:text-slate-400 focus:ring-4 focus:outline-none', userTheme.border, userTheme.ring)}
            />
            <button
              type="button"
              onClick={() => setShowPassword(prev => !prev)}
              aria-label={showPassword ? 'مخفی کردن رمز' : 'نمایش رمز'}
              aria-pressed={showPassword}
              className="absolute left-2.5 top-2.5 w-8 h-8 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 flex items-center justify-center"
            >
              {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>

          {error && (
            <div role="alert" className="rounded-xl border border-rose-200 bg-rose-50 px-3 py-2 text-[11px] leading-relaxed text-rose-700 font-bold flex items-center justify-center gap-1.5">
              <AlertCircle className="w-3.5 h-3.5 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <button
            type="submit"
            disabled={busy || !selectedUser || !password}
            aria-busy={busy}
            className={clsx('w-full h-13 rounded-[1.15rem] text-white text-sm font-black shadow-lg disabled:opacity-45 disabled:cursor-not-allowed transition-all active:scale-[0.99] bg-gradient-to-r', userTheme.button)}
          >
            {busy ? 'در حال بررسی…' : 'ورود به جهان ما'}
          </button>
        </form>
      </div>
    </div>
  );
};
