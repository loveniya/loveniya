import React from 'react';

interface SkeletonListProps {
  count?: number;
}

/**
 * چند کارت خاکستری پالس‌دار به‌جای لیست، برای وقتی که هنوز اولین
 * دریافت اطلاعات از فایربیس تمام نشده. جلوی این حالت گمراه‌کننده رو
 * می‌گیره که کاربر لحظه‌ای فکر کنه «هنوز چیزی ثبت نشده» درحالی‌که
 * صرفاً داره لود می‌شه.
 */
export const SkeletonList: React.FC<SkeletonListProps> = ({ count = 3 }) => {
  return (
    <div className="space-y-4" aria-hidden="true">
      {Array.from({ length: count }).map((_, i) => (
        <div
          key={i}
          className="bg-white rounded-3xl p-4 sm:p-5 border border-stone-200/80 shadow-2xs animate-pulse"
        >
          <div className="flex items-center gap-2 mb-3">
            <div className="h-3 w-16 bg-stone-200/80 rounded-full" />
            <div className="h-3 w-10 bg-stone-100 rounded-full" />
          </div>
          <div className="h-3.5 bg-stone-200/80 rounded-full w-full mb-2" />
          <div className="h-3.5 bg-stone-100 rounded-full w-4/5" />
        </div>
      ))}
    </div>
  );
};

export default SkeletonList;
