import React, { useEffect, useRef, useState } from 'react';
import { NavLink, useLocation } from 'react-router';
import {
  AlertCircle,
  Camera,
  ChevronLeft,
  Compass,
  Dices,
  Grid2X2,
  HeartHandshake,
  Home,
  Mail,
  MessagesSquare,
  Music,
  Settings,
  Sparkles,
  X,
} from 'lucide-react';
import clsx from 'clsx';
import { useStore } from '../lib/store';
import { motion, AnimatePresence } from 'motion/react';

const navTabs = [
  { to: '/', label: 'خانه', icon: Home },
  { to: '/memories', label: 'خاطرات', icon: Camera },
  { to: '/pledges', label: 'عهدها', icon: HeartHandshake },
  { to: '/chat', label: 'چت', icon: MessagesSquare },
  { to: '/games', label: 'بازی‌ها', icon: Dices },
] as const;

const moreItems = [
  { to: '/dreams', label: 'آرزوها', desc: 'هدف‌ها و برنامه‌های مشترک', icon: Compass, tone: 'cyan' },
  { to: '/music', label: 'موزیک', desc: 'آهنگ‌ها و لحظه‌های مشترک', icon: Music, tone: 'violet' },
  { to: '/letters', label: 'نامه‌ها', desc: 'نامه‌ها و پیام‌های زمان‌دار', icon: Mail, tone: 'gold' },
  { to: '/settings', label: 'تنظیمات', desc: 'امنیت، اتصال و شخصی‌سازی', icon: Settings, tone: 'neutral' },
] as const;

export const Navigation: React.FC = () => {
  const { syncStatus, syncError } = useStore();
  const [showMoreMenu, setShowMoreMenu] = useState(false);
  const location = useLocation();
  const closeButtonRef = useRef<HTMLButtonElement>(null);

  const moreActive = moreItems.some(item => item.to === location.pathname);

  useEffect(() => {
    if (!showMoreMenu) return;
    const previousOverflow = document.body.style.overflow;
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setShowMoreMenu(false);
        return;
      }
      if (event.key === 'Tab') {
        const dialog = document.querySelector<HTMLElement>('[role=\"dialog\"][aria-labelledby=\"more-menu-title\"]');
        if (!dialog) return;
        const focusable = Array.from(dialog.querySelectorAll<HTMLElement>('button, a, [tabindex]:not([tabindex=\"-1\"])')).filter(el => !el.hasAttribute('disabled'));
        if (!focusable.length) return;
        const first = focusable[0];
        const last = focusable[focusable.length - 1];
        if (event.shiftKey && document.activeElement === first) {
          event.preventDefault();
          last.focus();
        } else if (!event.shiftKey && document.activeElement === last) {
          event.preventDefault();
          first.focus();
        }
      }
    };
    document.body.style.overflow = 'hidden';
    document.addEventListener('keydown', handleKeyDown);
    requestAnimationFrame(() => closeButtonRef.current?.focus());
    return () => {
      document.body.style.overflow = previousOverflow;
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [showMoreMenu]);

  return (
    <>
      <header className="app-header" dir="rtl">
        <div className="app-header__inner">
          <NavLink to="/" className="app-brand" aria-label="صفحه اصلی">
            <span className="app-brand__mark"><HeartHandshake className="w-4 h-4" /></span>
            <span>
              <strong>جهان ما</strong>
              <small>امین × نیایش</small>
            </span>
          </NavLink>

          <div className="app-header__status" aria-live="polite">
            <span className={clsx('status-dot', syncStatus === 'connected' && 'is-ok', syncStatus === 'error' && 'is-error', syncStatus === 'syncing' && 'is-syncing')} />
            <span>{syncStatus === 'connected' ? 'همگام' : syncStatus === 'syncing' ? 'در حال همگام‌سازی' : syncStatus === 'error' ? 'اختلال اتصال' : 'آفلاین'}</span>
          </div>
        </div>
      </header>

      {syncStatus === 'error' && (
        <div className="sync-banner" role="status" dir="rtl">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{syncError || 'اتصال به سرور با مشکل روبه‌رو شده؛ تلاش دوباره ادامه دارد.'}</span>
        </div>
      )}

      <div className="bottom-nav-wrap" dir="rtl">
        <nav className="bottom-nav" aria-label="نوار ناوبری اصلی">
          {navTabs.map(({ to, label, icon: Icon }) => {
            const active = location.pathname === to || (to === '/games' && location.pathname === '/moments');
            return (
              <NavLink
                key={to}
                to={to}
                aria-current={active ? 'page' : undefined}
                className={clsx('bottom-nav__item', active && 'is-active')}
              >
                <span className="bottom-nav__icon"><Icon size={19} strokeWidth={active ? 2.4 : 1.9} /></span>
                <span>{label}</span>
              </NavLink>
            );
          })}

          <button
            type="button"
            className={clsx('bottom-nav__item', moreActive && 'is-active')}
            onClick={() => setShowMoreMenu(true)}
            aria-haspopup="dialog"
            aria-expanded={showMoreMenu}
          >
            <span className="bottom-nav__icon"><Grid2X2 size={19} strokeWidth={moreActive ? 2.4 : 1.9} /></span>
            <span>بیشتر</span>
          </button>
        </nav>
      </div>

      <AnimatePresence>
        {showMoreMenu && (
          <>
            <motion.button
              type="button"
              aria-label="بستن منوی بیشتر"
              className="sheet-backdrop"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowMoreMenu(false)}
            />
            <motion.section
              role="dialog"
              aria-modal="true"
              aria-labelledby="more-menu-title"
              className="more-sheet"
              initial={{ opacity: 0, y: 28 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 28 }}
              transition={{ type: 'spring', stiffness: 320, damping: 28 }}
              dir="rtl"
            >
              <div className="more-sheet__handle" aria-hidden="true" />
              <div className="more-sheet__head">
                <div>
                  <h2 id="more-menu-title">بخش‌های بیشتر</h2>
                  <p>دسترسی سریع به بخش‌های دیگر.</p>
                </div>
                <button ref={closeButtonRef} type="button" onClick={() => setShowMoreMenu(false)} className="icon-button" aria-label="بستن">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="more-sheet__grid">
                {moreItems.map(item => {
                  const Icon = item.icon;
                  const active = location.pathname === item.to;
                  return (
                    <NavLink
                      key={item.to}
                      to={item.to}
                      onClick={() => setShowMoreMenu(false)}
                      className={clsx('more-link', `more-link--${item.tone}`, active && 'is-active')}
                    >
                      <span className="more-link__icon"><Icon className="w-5 h-5" /></span>
                      <span className="min-w-0">
                        <strong>{item.label}</strong>
                        <small>{item.desc}</small>
                      </span>
                      <ChevronLeft className="w-4 h-4 shrink-0 opacity-60" />
                    </NavLink>
                  );
                })}
              </div>

            </motion.section>
          </>
        )}
      </AnimatePresence>
    </>
  );
};
