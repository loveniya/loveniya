export type GameUser = 'amin' | 'niyayesh';
export type TruthDareKind = 'truth' | 'dare';
export type TruthDareStatus = 'waiting' | 'answered' | 'skipped';

export type TruthDareRound = {
  id: string;
  type: TruthDareKind;
  text: string;
  spinnerId: GameUser;
  answererId: GameUser;
  status: TruthDareStatus;
  createdAt: number;
  answeredAt?: number;
};

const TRUTHS = [
  'یک کاری که همیشه می‌خواستی امتحانش کنی ولی عقبش انداختی چیه؟',
  'آخرین چیزی که واقعاً خوشحالت کرد چی بود؟',
  'کدام عادت کوچیکت بیشتر از چیزی که فکر می‌کنی روی روزت اثر می‌گذاره؟',
  'اگر می‌توانستی یک خاطره را دوباره تجربه کنی، کدام را انتخاب می‌کردی؟',
  'یک ویژگی خوب در خودت که کمتر درباره‌اش حرف می‌زنی چیه؟',
  'وقتی روز سختی داری، چه چیزی سریع‌تر حالت را بهتر می‌کند؟',
  'کدام تصمیم کوچک اخیراً باعث شد از خودت راضی باشی؟',
  'اگر قرار بود یک مهارت را همین امسال خیلی خوب یاد بگیری، چی بود؟',
  'کدام آهنگ تو را خیلی سریع یاد یک خاطره می‌اندازد؟',
  'یک چیز ساده که دوست داری طرف مقابل بیشتر در طول روز انجام بده چیه؟',
  'بامزه‌ترین سوتی‌ای که هنوز یادت مانده چیه؟',
  'اگر امروز را با یک کلمه توصیف کنی، آن کلمه چیست؟',
  'چه چیزی بیشتر از چیزی که نشان می‌دهی خوشحالت می‌کند؟',
  'کدام ویژگی اخلاقی را در آدم‌ها سریع‌تر از بقیه می‌بینی؟',
  'یک تصمیم قدیمی که امروز نگاهت به آن عوض شده چیست؟',
  'اگر یک روز کامل هیچ مسئولیتی نداشته باشی، چه کار می‌کنی؟',
  'آخرین باری که به خودت افتخار کردی کی بود و چرا؟',
  'چه چیزی باعث می‌شود احساس کنی واقعاً شنیده شده‌ای؟',
  'یک خاطره معمولی که بعداً فهمیدی برایت خیلی باارزش بوده چیست؟',
  'چه چیزی همیشه می‌تواند تو را از حالت بد بیرون بیاورد؟',
  'اگر بتوانی یک عادت خوب را همین امروز اضافه کنی، چیست؟',
  'چه چیزی را دوست داری بیشتر از خودت یاد بگیری؟',
  'کدام انتخاب کوچک زندگی‌ات نتیجه‌ی بزرگی داشت؟',
  'یک آرزوی کوچک و کاملاً واقعی که دوست داری به آن برسی چیست؟',
];

const DARES = [
  'در ۱۰ ثانیه سه کلمه بگو که امروز حالت را توصیف می‌کنند.',
  'یک ویس ۱۰ ثانیه‌ای با یک جمله خنده‌دار برای طرف مقابل بفرست.',
  'یک عکس از نزدیک‌ترین چیزی که الان کنار دستت است بفرست و بگذار حدس بزند چیست.',
  'در سه حرکت کوتاه، چیزی را که طرف مقابل انتخاب می‌کند پانتومیم کن.',
  'یک جمله را با لحن گوینده خبر بگو و برای طرف مقابل بفرست.',
  'تا دور بعد فقط با استیکر یا ایموجی جواب بده.',
  'یک لقب بامزه برای خودت بساز و تا پایان این دور از آن استفاده کن.',
  'یک آهنگ کوتاه انتخاب کن و حسش را فقط با سه کلمه توضیح بده.',
  '۱۰ ثانیه با انگشت‌ها یک ریتم بساز و برای طرف مقابل بفرست.',
  'یک جمله خیلی کوتاه را با سه لحن مختلف بگو: جدی، هیجانی و خنده‌دار.',
  'سه ایموجی انتخاب کن که حال امروزت را نشان می‌دهند و دلیلش را بگو.',
  'بدون استفاده از کلمه «من» یک جمله درباره امروزت بگو.',
  'یک اسم خنده‌دار برای حالت فعلی‌ات انتخاب کن.',
  'یک شیء نزدیکت را ۱۵ ثانیه تبلیغ کن؛ انگار گران‌ترین محصول دنیاست.',
  'در یک جمله کوتاه از طرف مقابل تشکر کن، بدون استفاده از کلمه «مرسی».',
  'فقط با صدا، حال امروزت را تقلید کن و بگذار طرف مقابل حدس بزند.',
  'سه حدس سریع درباره چیزی که طرف مقابل الان می‌پوشد بزن.',
  'یک خاطره شیرین را در دقیقاً پنج کلمه تعریف کن.',
  'یک پیام ۵ ثانیه‌ای فقط با ایموجی بفرست.',
  'یک جمله را خیلی آهسته و بعد خیلی سریع بگو.',
  'یک حرکت کوتاه و بامزه برای شروع دور بعد انتخاب کن.',
  'یک کلمه ممنوع برای خودت تا پایان این دور انتخاب کن و حواست باشد نگوییش.',
  'سه چیز کوچک که امروز بابتشان خوشحال شدی را پشت سر هم بگو.',
  'برای دور بعد یک قانون بامزه و ساده پیشنهاد بده.',
];

function otherUser(user: GameUser): GameUser {
  return user === 'amin' ? 'niyayesh' : 'amin';
}

function pick(items: readonly string[], recentTexts: Set<string>): string {
  const available = items.filter(item => !recentTexts.has(item));
  const source = available.length ? available : items;
  return source[Math.floor(Math.random() * source.length)];
}

export function isValidTruthOrDareText(kind: TruthDareKind, text: string): boolean {
  if (typeof text !== 'string' || text.length === 0 || text.length > 500) return false;
  return (kind === 'truth' ? TRUTHS : DARES).includes(text);
}

export function createTruthOrDareRound(
  spinnerId: GameUser,
  kind: TruthDareKind,
  recentTexts: Iterable<string> = [],
  now = Date.now(),
): TruthDareRound {
  const recent = new Set(recentTexts);
  return {
    id: `td-${now}-${Math.random().toString(36).slice(2, 8)}`,
    type: kind,
    text: pick(kind === 'truth' ? TRUTHS : DARES, recent),
    spinnerId,
    answererId: otherUser(spinnerId),
    status: 'waiting',
    createdAt: now,
  };
}

export function answerTruthOrDare(round: TruthDareRound, now = Date.now()): TruthDareRound {
  if (round.status !== 'waiting') return round;
  return { ...round, status: 'answered', answeredAt: now };
}

export function skipTruthOrDare(round: TruthDareRound, now = Date.now()): TruthDareRound {
  if (round.status !== 'waiting') return round;
  return { ...round, status: 'skipped', answeredAt: now };
}

export function canSpinTruthOrDare(
  currentUser: GameUser,
  round: TruthDareRound | null | undefined,
): boolean {
  // هر دو نفر می‌توانند بازی را از دور اول شروع کنند. بعد از هر دور،
  // نوبت به پاسخ‌دهنده‌ی دور قبل منتقل می‌شود.
  if (!round) return true;
  if (round.status === 'waiting') return false;
  return currentUser === round.answererId;
}

export function sanitizeTruthOrDareRound(value: unknown): TruthDareRound | null {
  if (!value || typeof value !== 'object') return null;
  const input = value as Record<string, unknown>;

  // v1 -> v2 migration: the old game stored timestamp instead of id/status/answererId.
  // Preserve that round instead of silently throwing it away after the UI redesign.
  if (typeof input.spinnerId === 'string' && typeof input.text === 'string' && typeof input.timestamp === 'number') {
    const spinnerId = input.spinnerId === 'niyayesh' ? 'niyayesh' : input.spinnerId === 'amin' ? 'amin' : null;
    const type = input.type === 'truth' || input.type === 'dare' ? input.type : null;
    if (!spinnerId || !type || input.text.length > 500) return null;
    const answererId = otherUser(spinnerId);
    const answeredAt = typeof input.answeredAt === 'number' ? input.answeredAt : undefined;
    return {
      id: `legacy-td-${input.timestamp}`,
      type,
      text: input.text,
      spinnerId,
      answererId,
      status: answeredAt ? 'answered' : 'waiting',
      createdAt: input.timestamp,
      ...(answeredAt ? { answeredAt } : {}),
    };
  }

  const spinnerId = input.spinnerId === 'niyayesh' ? 'niyayesh' : input.spinnerId === 'amin' ? 'amin' : null;
  const answererId = input.answererId === 'niyayesh' ? 'niyayesh' : input.answererId === 'amin' ? 'amin' : null;
  const type = input.type === 'truth' || input.type === 'dare' ? input.type : null;
  const status = input.status === 'waiting' || input.status === 'answered' || input.status === 'skipped' ? input.status : null;
  if (!input.id || typeof input.id !== 'string' || !type || !spinnerId || !answererId || !status || typeof input.text !== 'string') return null;
  if (input.text.length > 500) return null;
  return {
    id: input.id,
    type,
    text: input.text,
    spinnerId,
    answererId,
    status,
    createdAt: Number(input.createdAt) || Date.now(),
    ...(typeof input.answeredAt === 'number' ? { answeredAt: input.answeredAt } : {}),
  };
}
