/**
 * Client-side Image Compression Utility
 * Resizes and compresses images using HTML5 Canvas before uploading or storing
 */

export interface CompressionOptions {
  maxWidth?: number;
  maxHeight?: number;
  quality?: number;
  maxSizeKB?: number;
  mimeType?: string;
}

export async function compressImage(
  file: File,
  options: CompressionOptions = {}
): Promise<{ base64: string; sizeKB: number; originalSizeKB: number }> {
  const {
    maxWidth = 1024,
    maxHeight = 1024,
    quality = 0.75,
    maxSizeKB = 250,
    mimeType = 'image/jpeg'
  } = options;

  const originalSizeKB = Math.round(file.size / 1024);
  if (!file.type.startsWith('image/')) throw new Error('فایل انتخاب‌شده تصویر نیست.');
  if (file.size > 25 * 1024 * 1024) throw new Error('حجم تصویر اولیه بیش از ۲۵ مگابایت است.');

  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onerror = () => reject(new Error('خطا در خواندن فایل تصویر'));

    reader.onload = (e) => {
      const img = new Image();
      img.onerror = () => reject(new Error('خطا در بارگذاری تصویر'));

      img.onload = () => {
        let width = img.naturalWidth || img.width;
        let height = img.naturalHeight || img.height;

        // Calculate aspect ratio
        if (width > height) {
          if (width > maxWidth) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          }
        } else {
          if (height > maxHeight) {
            width = Math.round((width * maxHeight) / height);
            height = maxHeight;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;

        const ctx = canvas.getContext('2d');
        if (!ctx) {
          reject(new Error('Canvas 2D context not available'));
          return;
        }

        // Draw image onto canvas
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';
        ctx.drawImage(img, 0, 0, width, height);

        // Compress
        let currentQuality = quality;
        let resultBase64 = canvas.toDataURL(mimeType, currentQuality);
        let resultSizeKB = Math.round((resultBase64.length * 3) / 4 / 1024);

        // If size is still above maxSizeKB, progressively reduce quality
        if (resultSizeKB > maxSizeKB && currentQuality > 0.4) {
          currentQuality = 0.55;
          resultBase64 = canvas.toDataURL(mimeType, currentQuality);
          resultSizeKB = Math.round((resultBase64.length * 3) / 4 / 1024);
        }

        if (resultSizeKB > maxSizeKB && currentQuality > 0.3) {
          currentQuality = 0.4;
          resultBase64 = canvas.toDataURL(mimeType, currentQuality);
          resultSizeKB = Math.round((resultBase64.length * 3) / 4 / 1024);
        }
        if (resultSizeKB > maxSizeKB) {
          reject(new Error(`تصویر حتی پس از فشرده‌سازی هنوز بیش از ${maxSizeKB} کیلوبایت است.`));
          return;
        }

        resolve({
          base64: resultBase64,
          sizeKB: resultSizeKB,
          originalSizeKB
        });
      };

      img.src = e.target?.result as string;
    };

    reader.readAsDataURL(file);
  });
}
