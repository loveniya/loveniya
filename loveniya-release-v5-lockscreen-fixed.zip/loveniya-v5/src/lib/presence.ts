import { useEffect, useCallback } from 'react';
import { apiFetch, dataApi } from './api';

export interface PresenceData {
  user: 'amin' | 'niyayesh';
  lastSeen: number;
  lastVisit: number;
  isOnline: boolean;
  isTyping?: boolean;
  page?: string;
  updatedAt?: number;
}

/**
 * Updates the user's presence / last visit timestamp on Cloudflare
 */
export async function updateUserPresence(
  user?: 'amin' | 'niyayesh',
  options?: { isTyping?: boolean; isOnline?: boolean; page?: string }
): Promise<void> {
  try {
    const activeUser = user || (localStorage.getItem('loveniya_user') as 'amin' | 'niyayesh') || 'amin';
    const now = Date.now();
    
    const payload: PresenceData = {
      user: activeUser,
      lastSeen: now,
      lastVisit: now,
      isOnline: options?.isOnline !== false,
      isTyping: Boolean(options?.isTyping),
      page: options?.page || (typeof window !== 'undefined' ? window.location.pathname : '/'),
      updatedAt: now
    };

    if (typeof localStorage !== 'undefined') {
      try {
        localStorage.setItem(`loveniya_presence_${activeUser}`, JSON.stringify(payload));
      } catch (e) {
        // ignore storage quota
      }
    }

    await apiFetch(dataApi(`loveniya_presence_${activeUser}`), {
      method: 'PUT',
      body: JSON.stringify(payload)
    });
  } catch (e) {
    // Offline or network error handled gracefully
  }
}

/**
 * Fetches the partner's latest presence data from Cloudflare
 */
export async function fetchPartnerPresenceData(partnerId: 'amin' | 'niyayesh'): Promise<PresenceData | null> {
  try {
    const res = await apiFetch(`${dataApi(`loveniya_presence_${partnerId}`)}?_t=${Date.now()}`);
    if (res.ok) {
      const data = await res.json();
      if (data && typeof data === 'object') {
        return {
          user: partnerId,
          lastSeen: Number(data.lastSeen || data.lastVisit || data.updatedAt) || 0,
          lastVisit: Number(data.lastVisit || data.lastSeen || data.updatedAt) || 0,
          isOnline: Boolean(data.isOnline),
          isTyping: Boolean(data.isTyping),
          page: data.page,
          updatedAt: Number(data.updatedAt || data.lastSeen) || 0
        };
      }
    }
  } catch (e) {
    // ignore
  }

  // Fallback to local cache if present
  if (typeof localStorage !== 'undefined') {
    try {
      const saved = localStorage.getItem(`loveniya_presence_${partnerId}`);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {}
  }

  return null;
}

/**
 * Formats the last seen / online timestamp strictly in Iran Standard Time (Asia/Tehran)
 */
export function formatIranLastSeen(
  presence: PresenceData | null | undefined,
  currentTypingState?: boolean
): string {
  if (!presence) {
    return 'آفلاین (اطلاعاتی ثبت نشده)';
  }

  if (currentTypingState || presence.isTyping) {
    return 'در حال نوشتن...';
  }

  const timestamp = presence.lastSeen || presence.lastVisit || presence.updatedAt;
  if (!timestamp || isNaN(timestamp) || timestamp <= 0) {
    return 'آفلاین';
  }

  const now = Date.now();
  const diffMs = Math.max(0, now - timestamp);

  // If active within 35 seconds, consider online
  if (diffMs < 35000) {
    return 'آنلاین';
  }

  // Within 90 seconds
  if (diffMs < 90000) {
    return 'آخرین بازدید چند لحظه پیش';
  }

  const targetDate = new Date(timestamp);
  const nowDate = new Date(now);

  // Iran timezone date strings (YYYY-MM-DD format in Asia/Tehran)
  const tehranNow = nowDate.toLocaleDateString('en-CA', { timeZone: 'Asia/Tehran' });
  const tehranTarget = targetDate.toLocaleDateString('en-CA', { timeZone: 'Asia/Tehran' });

  // Exact time in Iran (24-hour Persian numerals, e.g. "۱۶:۱۱")
  const iranTimeStr = targetDate.toLocaleTimeString('fa-IR', {
    timeZone: 'Asia/Tehran',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false
  });

  // Visited today
  if (tehranNow === tehranTarget) {
    return `آخرین بازدید امروز ساعت ${iranTimeStr}`;
  }

  // Check yesterday in Iran
  const yesterday = new Date(now - 24 * 60 * 60 * 1000);
  const tehranYesterday = yesterday.toLocaleDateString('en-CA', { timeZone: 'Asia/Tehran' });

  if (tehranTarget === tehranYesterday) {
    return `آخرین بازدید دیروز ساعت ${iranTimeStr}`;
  }

  // Persian month and day in Iran timezone
  const iranDateStr = targetDate.toLocaleDateString('fa-IR', {
    timeZone: 'Asia/Tehran',
    month: 'long',
    day: 'numeric'
  });

  return `آخرین بازدید ${iranDateStr} ساعت ${iranTimeStr}`;
}

/**
 * Global React hook to automatically track presence whenever the user opens, browses, or returns to the site
 */
export function useGlobalPresenceTracker() {
  const syncPresence = useCallback((typing = false, online = true) => {
    const user = (localStorage.getItem('loveniya_user') as 'amin' | 'niyayesh') || 'amin';
    updateUserPresence(user, { isTyping: typing, isOnline: online });
  }, []);

  useEffect(() => {
    // Initial visit track
    syncPresence(false, true);

    // Heartbeat every 15 seconds to keep "Online" status fresh while browsing
    const interval = setInterval(() => {
      if (typeof document !== 'undefined' && document.visibilityState === 'visible') {
        syncPresence(false, true);
      }
    }, 15000);

    const handleVisibility = () => {
      if (document.visibilityState === 'visible') {
        syncPresence(false, true);
      } else {
        syncPresence(false, false);
      }
    };

    const handleFocus = () => syncPresence(false, true);
    const handleBeforeUnload = () => {
      // Record exit timestamp
      syncPresence(false, false);
    };

    window.addEventListener('visibilitychange', handleVisibility);
    window.addEventListener('focus', handleFocus);
    window.addEventListener('beforeunload', handleBeforeUnload);

    return () => {
      clearInterval(interval);
      window.removeEventListener('visibilitychange', handleVisibility);
      window.removeEventListener('focus', handleFocus);
      window.removeEventListener('beforeunload', handleBeforeUnload);
    };
  }, [syncPresence]);
}
