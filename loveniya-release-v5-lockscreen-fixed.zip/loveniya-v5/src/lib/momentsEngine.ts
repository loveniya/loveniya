import { sanitizeTruthOrDareRound, isValidTruthOrDareText, type TruthDareRound } from './truthOrDare.js';

export type MomentsUser = 'amin' | 'niyayesh';

export type MomentsGameState = {
  telepathyChoices?: Record<string, { amin?: string; niyayesh?: string }>;
  telepathyStatus?: Record<string, { amin: boolean; niyayesh: boolean }>;
  currentTelepathyQuestion?: { id: string; q: string; a: string; b: string };
  lastBottleResult?: TruthDareRound | null;
  truthDareHistory?: string[];
};

export function otherUser(user: MomentsUser): MomentsUser {
  return user === 'amin' ? 'niyayesh' : 'amin';
}

function stripRetiredGameState(current: MomentsGameState): void {
  const retired = current as MomentsGameState & Record<string, unknown>;
  delete retired.board;
  delete retired.turn;
  delete retired.scores;
  delete retired.winner;
}

function mergeTruthDare(current: MomentsGameState, incoming: any, user: MomentsUser) {
  if (!Object.prototype.hasOwnProperty.call(incoming, 'lastBottleResult')) return;
  const round = sanitizeTruthOrDareRound(incoming.lastBottleResult);
  if (!round || !isValidTruthOrDareText(round.type, round.text)) throw new Error('متن دور جرأت یا حقیقت معتبر نیست.');

  const previous = current.lastBottleResult ? sanitizeTruthOrDareRound(current.lastBottleResult) : null;
  if (previous && previous.id === round.id && previous.status === round.status && previous.text === round.text) return;

  if (!previous || previous.status !== 'waiting') {
    if (round.spinnerId !== user || round.answererId !== otherUser(user) || round.status !== 'waiting') {
      throw new Error('نوبت بازی جرأت یا حقیقت نامعتبر است.');
    }
    current.lastBottleResult = round;
    current.truthDareHistory = [...(Array.isArray(current.truthDareHistory) ? current.truthDareHistory : []), round.text].slice(-12);
    return;
  }

  if (round.id !== previous.id || round.text !== previous.text || round.spinnerId !== previous.spinnerId || round.answererId !== previous.answererId) {
    throw new Error('دور فعال هنوز تمام نشده است.');
  }
  if (previous.answererId !== user || (round.status !== 'answered' && round.status !== 'skipped')) {
    throw new Error('فقط پاسخ‌دهنده می‌تواند این دور را تمام کند.');
  }
  current.lastBottleResult = { ...previous, status: round.status, answeredAt: round.answeredAt ?? Date.now() };
}

function mergeTelepathy(current: MomentsGameState, incoming: any, user: MomentsUser) {
  const currentQuestion = current.currentTelepathyQuestion;
  if (incoming.currentTelepathyQuestion && typeof incoming.currentTelepathyQuestion === 'object') {
    const q = incoming.currentTelepathyQuestion;
    if (typeof q.id !== 'string' || typeof q.q !== 'string' || typeof q.a !== 'string' || typeof q.b !== 'string') throw new Error('سوال تله‌پاتی نامعتبر است.');
    const existingChoices = current.telepathyChoices?.[currentQuestion?.id || ''];
    const complete = !!existingChoices?.amin && !!existingChoices?.niyayesh;
    if (!currentQuestion || complete) {
      current.currentTelepathyQuestion = { id: q.id.slice(0, 120), q: q.q.slice(0, 300), a: q.a.slice(0, 300), b: q.b.slice(0, 300) };
      current.telepathyChoices = current.telepathyChoices || {};
    }
  }

  if (incoming.telepathyChoices && typeof incoming.telepathyChoices === 'object' && current.currentTelepathyQuestion?.id) {
    const id = current.currentTelepathyQuestion.id;
    const incomingChoice = incoming.telepathyChoices?.[id]?.[user];
    if (incomingChoice === 'A' || incomingChoice === 'B') {
      current.telepathyChoices = current.telepathyChoices || {};
      const prev = current.telepathyChoices[id] || {};
      current.telepathyChoices[id] = { ...prev, [user]: incomingChoice };
    }
  }
}

export function sanitizeMomentsForViewer(state: MomentsGameState | null | undefined, viewer: MomentsUser): MomentsGameState {
  const current: MomentsGameState = JSON.parse(JSON.stringify(state || {}));
  stripRetiredGameState(current);
  const choices = current.telepathyChoices || {};
  const redacted: Record<string, { amin?: string; niyayesh?: string }> = {};
  const status: Record<string, { amin: boolean; niyayesh: boolean }> = {};

  for (const [questionId, choice] of Object.entries(choices)) {
    const amin = choice?.amin === 'A' || choice?.amin === 'B' ? choice.amin : undefined;
    const niyayesh = choice?.niyayesh === 'A' || choice?.niyayesh === 'B' ? choice.niyayesh : undefined;
    status[questionId] = { amin: !!amin, niyayesh: !!niyayesh };
    const bothAnswered = !!amin && !!niyayesh;
    redacted[questionId] = bothAnswered
      ? { amin, niyayesh }
      : viewer === 'amin'
        ? { ...(amin ? { amin } : {}) }
        : { ...(niyayesh ? { niyayesh } : {}) };
  }

  current.telepathyChoices = redacted;
  current.telepathyStatus = status;
  return current;
}

export function mergeMomentsPatch(currentState: MomentsGameState | null | undefined, incomingPatch: any, user: MomentsUser): MomentsGameState {
  const current: MomentsGameState = JSON.parse(JSON.stringify(currentState || {}));
  stripRetiredGameState(current);
  if (!incomingPatch || typeof incomingPatch !== 'object' || Array.isArray(incomingPatch)) throw new Error('داده بازی نامعتبر است.');
  mergeTruthDare(current, incomingPatch, user);
  mergeTelepathy(current, incomingPatch, user);
  stripRetiredGameState(current);
  return current;
}
