// انیمیشن ورود کارت‌های لیست (خاطرات، عهدها، آرزوها، نامه‌ها).
// به‌جای اینکه همه‌ی کارت‌ها همون لحظه‌ی باز شدن صفحه با تاخیر پشت‌سرهم
// و یک چرخش سه‌بعدی سنگین ظاهر بشن، هر کارت وقتی موقع اسکرول به دیدرس
// می‌رسه، جدا از بقیه، سبک و ساده بالا میاد — همون حس «یکی‌یکی با اسکرول».
// هر کارتی که این افکت رو می‌خواد فقط کافیه این props رو باز کنه:
// <motion.div layout key={...} {...cardScrollReveal} className="...">

export const cardScrollReveal = {
  initial: { opacity: 0, y: 22 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, amount: 0.25 },
  transition: { duration: 0.4, ease: 'easeOut' as const },
};
