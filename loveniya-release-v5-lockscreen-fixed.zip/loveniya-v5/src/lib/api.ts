export type AppUser = 'amin' | 'niyayesh';

const SAFE_METHODS = new Set(['GET', 'HEAD', 'OPTIONS']);

function dispatchSessionExpired() {
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('loveniya:session-expired'));
  }
}

function isAbortError(error: unknown) {
  return error instanceof DOMException && error.name === 'AbortError';
}

async function fetchWithClientTimeout(input: string, init: RequestInit, timeoutMs: number) {
  if (init.signal) return fetch(input, init);

  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(input, { ...init, signal: controller.signal });
  } finally {
    window.clearTimeout(timer);
  }
}

export async function apiFetch(input: string, init: RequestInit = {}): Promise<Response> {
  const headers = new Headers(init.headers || {});
  if (init.body && !headers.has('Content-Type')) headers.set('Content-Type', 'application/json');
  const method = (init.method || 'GET').toUpperCase();
  const safeMethod = SAFE_METHODS.has(method);
  if (!safeMethod) headers.set('X-Loveniya-Request', '1');

  const request = {
    ...init,
    credentials: 'same-origin' as RequestCredentials,
    headers,
    cache: init.cache ?? 'no-store' as RequestCache,
  } satisfies RequestInit;

  // GETs can be retried safely on transient network failures. Writes are never
  // automatically retried here because idempotency belongs to the outbox/gateway.
  const attempts = safeMethod ? 2 : 1;
  let lastError: unknown = null;

  for (let attempt = 0; attempt < attempts; attempt++) {
    try {
      const response = await fetchWithClientTimeout(input, request, safeMethod ? 12_000 : 20_000);
      if (response.status === 401 && !input.startsWith('/api/auth/unlock') && !input.startsWith('/api/auth/status')) {
        dispatchSessionExpired();
      }
      return response;
    } catch (error) {
      lastError = error;
      if (attempt + 1 < attempts && !isAbortError(error)) {
        await new Promise(resolve => window.setTimeout(resolve, 250));
        continue;
      }
      throw error;
    }
  }

  throw lastError instanceof Error ? lastError : new Error('درخواست ناموفق بود.');
}

export function dataApi(path: string): string {
  const clean = path.replace(/^\/+/, '').replace(/\.json$/, '');
  return `/api/data/${clean}`;
}

export async function unlock(password: string, user: AppUser): Promise<AppUser> {
  let res: Response;
  try {
    res = await apiFetch('/api/auth/unlock', {
      method: 'POST',
      body: JSON.stringify({ password, user }),
    });
  } catch {
    throw new Error('AUTH_BACKEND_UNAVAILABLE');
  }

  const contentType = res.headers.get('content-type') || '';
  const data = contentType.includes('application/json') ? await res.json().catch(() => ({})) : {};
  if (!res.ok) {
    if (res.status === 404 || res.status === 405 || !contentType.includes('application/json')) {
      throw new Error('AUTH_BACKEND_UNAVAILABLE');
    }
    throw new Error(data?.error || 'ورود ناموفق بود.');
  }
  if (data?.user !== 'amin' && data?.user !== 'niyayesh') throw new Error('AUTH_BACKEND_UNAVAILABLE');
  return data.user as AppUser;
}

export async function authStatus(): Promise<{ authenticated: boolean; user?: AppUser }> {
  const res = await apiFetch('/api/auth/status');
  if (!res.ok) return { authenticated: false };
  return res.json();
}

export async function lockSession(): Promise<void> {
  await apiFetch('/api/auth/lock', { method: 'POST' }).catch(() => undefined);
}
