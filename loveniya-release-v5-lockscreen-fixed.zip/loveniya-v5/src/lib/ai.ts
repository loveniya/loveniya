import { apiFetch } from './api';

/**
 * Extracts AI text from various response structures of Cloudflare Workers AI
 */
function extractAIResponseText(data: any): string | null {
  if (!data) return null;
  
  if (typeof data === 'string') {
    const trimmed = data.trim();
    if (trimmed === 'SKIP') return 'SKIP';
    return trimmed.length > 0 ? trimmed : 'SKIP';
  }
  
  if (typeof data.response === 'string') {
    if (data.response.trim() === 'SKIP') return 'SKIP';
    return data.response.trim() || 'SKIP';
  }

  if (data.result !== undefined) {
    if (typeof data.result === 'string') {
      if (data.result.trim() === 'SKIP') return 'SKIP';
      return data.result.trim() || 'SKIP';
    }
    if (typeof data.result.response === 'string') {
      if (data.result.response.trim() === 'SKIP') return 'SKIP';
      return data.result.response.trim() || 'SKIP';
    }
    if (typeof data.result.text === 'string') {
      if (data.result.text.trim() === 'SKIP') return 'SKIP';
      return data.result.text.trim() || 'SKIP';
    }
    if (typeof data.result.reply === 'string') {
      if (data.result.reply.trim() === 'SKIP') return 'SKIP';
      return data.result.reply.trim() || 'SKIP';
    }
  }

  if (typeof data.reply === 'string') {
    if (data.reply.trim() === 'SKIP') return 'SKIP';
    return data.reply.trim() || 'SKIP';
  }
  if (typeof data.text === 'string') {
    if (data.text.trim() === 'SKIP') return 'SKIP';
    return data.text.trim() || 'SKIP';
  }
  if (typeof data.message === 'string') {
    if (data.message.trim() === 'SKIP') return 'SKIP';
    return data.message.trim() || 'SKIP';
  }
  if (Array.isArray(data.choices) && data.choices[0]?.message) {
    let raw = data.choices[0].message.content || data.choices[0].message.reasoning_content || data.choices[0].message.reasoning;
    if (typeof raw === 'string') {
        const content = raw.trim();
        if (content === 'SKIP') return 'SKIP';
        return content;
    }
  }

  return null;
}

function isAbortError(error: unknown): boolean {
  return error instanceof DOMException && error.name === 'AbortError';
}

/**
 * Unified AI caller through the same-origin backend gateway.
 * The browser never contacts the AI worker directly.
 */
export async function fetchLoveAI(payload: {
  type?: string;
  message?: string;
  prompt?: string;
  userMessage?: string;
  history?: string;
  contextData?: any;
}, signal?: AbortSignal) {
  const textPrompt = payload.message || payload.prompt || payload.userMessage || '';
  const promptType = payload.type || 'chat';

  const exactPayload = {
    type: promptType,
    userMessage: textPrompt,
    contextData: payload.contextData || {},
    history: payload.history || ''
  };

  // Strategy 1: Direct Cloudflare AI Worker
  try {
    const res = await apiFetch('/api/loveai', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(exactPayload),
      signal
    });

    if (res.ok) {
      const rawText = await res.text();
      try {
        const parsed = JSON.parse(rawText);
        const result = extractAIResponseText(parsed);
        if (result !== null) return result;
        throw new Error(`پاسخ خالی یا نامعتبر: ${rawText.substring(0, 100)}`);
      } catch (e: any) {
        if (e.message.startsWith('پاسخ خالی')) throw e;
        const result = extractAIResponseText(rawText);
        if (result !== null) return result;
        throw new Error(`متن نامشخص: ${rawText.substring(0, 100)}`);
      }
    } else {
      const errText = await res.text();
      try {
        const errJson = JSON.parse(errText);
        if (errJson.message) throw new Error(errJson.message);
        if (errJson.error) throw new Error(errJson.error);
      } catch (e: any) {
        if (e.message && e.message !== 'Unexpected end of JSON input') throw e;
        throw new Error(`خطای ${res.status} در ارتباط با هوش مصنوعی: ${errText.substring(0, 100)}`);
      }
    }
  } catch (err: any) {
    throw err; // Let the UI handle network/HTTP errors via Toast
  }

  // Fallback shouldn't be reached unless fetch fails completely, 
  // but if we are here, we just throw error to let UI know
  throw new Error('عدم دریافت پاسخ معتبر از سرور');
}

export async function streamLoveAI(
  payload: {
    type?: string;
    message?: string;
    prompt?: string;
    userMessage?: string;
    history?: string;
    contextData?: any;
  },
  onChunk: (text: string) => void,
  signal?: AbortSignal
): Promise<string> {
  const textPrompt = payload.message || payload.prompt || payload.userMessage || '';
  const promptType = payload.type || 'chat';
  
  const exactPayload = {
    type: promptType,
    userMessage: textPrompt,
    contextData: payload.contextData || {},
    history: payload.history || ''
  };

  try {
    const res = await apiFetch('/api/loveai/stream', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(exactPayload),
      signal
    });

    if (res.ok && res.body) {
      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let fullText = '';
      let buffer = '';
      
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        
        // Keep the last incomplete line in the buffer
        buffer = lines.pop() || '';
        
        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed) continue;
          
          if (trimmed.startsWith('data:')) {
            const dataStr = trimmed.slice(5).trim();
            if (dataStr === '[DONE]') continue;
            try {
              const data = JSON.parse(dataStr);
              
              let textChunk = '';
              if (data.choices?.[0]?.delta?.content) {
                textChunk = data.choices[0].delta.content;
              } else if (data.choices?.[0]?.delta?.reasoning_content) {
                textChunk = data.choices[0].delta.reasoning_content;
              } else if (data.choices?.[0]?.delta?.reasoning) {
                textChunk = data.choices[0].delta.reasoning;
              } else if (data.result) {
                textChunk = data.result;
              } else if (data.text) {
                textChunk = data.text;
              } else if (data.response) {
                textChunk = data.response;
              }

              if (textChunk && textChunk !== 'SKIP') {
                fullText += textChunk;
                onChunk(fullText);
              }
            } catch (e) {
              if (dataStr && dataStr !== 'SKIP' && !dataStr.startsWith('{')) {
                fullText += dataStr;
                onChunk(fullText);
              }
            }
          } else {
            try {
              const data = JSON.parse(trimmed);
              let textChunk = '';
              if (data.choices?.[0]?.delta?.content) {
                textChunk = data.choices[0].delta.content;
              } else if (data.choices?.[0]?.delta?.reasoning_content) {
                textChunk = data.choices[0].delta.reasoning_content;
              } else if (data.choices?.[0]?.delta?.reasoning) {
                textChunk = data.choices[0].delta.reasoning;
              } else if (data.result) {
                textChunk = data.result;
              } else if (data.text) {
                textChunk = data.text;
              } else if (data.response) {
                textChunk = data.response;
              }

              if (textChunk && textChunk !== 'SKIP') {
                fullText += textChunk;
                onChunk(fullText);
              }
            } catch (e) {
               // Ignore non-JSON raw chunks if they are just formatting
               if (trimmed !== 'SKIP' && !trimmed.startsWith('{') && !trimmed.startsWith('}')) {
                 fullText += trimmed;
                 onChunk(fullText);
               }
            }
          }
        }
      }
      
      // Process any remaining buffer
      if (buffer.trim()) {
         const trimmed = buffer.trim();
         if (trimmed.startsWith('data:')) {
            const dataStr = trimmed.slice(5).trim();
            if (dataStr !== '[DONE]') {
              try {
                const data = JSON.parse(dataStr);
                let textChunk = '';
                if (data.choices?.[0]?.delta?.content) {
                textChunk = data.choices[0].delta.content;
              } else if (data.choices?.[0]?.delta?.reasoning_content) {
                textChunk = data.choices[0].delta.reasoning_content;
              } else if (data.choices?.[0]?.delta?.reasoning) {
                textChunk = data.choices[0].delta.reasoning;
              } else if (data.result) {
                  textChunk = data.result;
                } else if (data.text) {
                  textChunk = data.text;
                } else if (data.response) {
                  textChunk = data.response;
                }
                if (textChunk && textChunk !== 'SKIP') {
                  fullText += textChunk;
                  onChunk(fullText);
                }
              } catch(e) {}
            }
         }
      }

      // Never issue a second AI generation after a successful stream that was empty.
      // An empty stream is a real server-side failure and the UI can retry explicitly.
      if (!fullText.trim()) throw new Error('پاسخ هوش مصنوعی خالی بود. دوباره تلاش کنید.');
      return fullText.trim() === 'SKIP' ? 'SKIP' : fullText;
    } else {
      // A compatibility fallback is safe only when the stream endpoint itself is unavailable.
      if ([404, 405, 501].includes(res.status)) return await fetchLoveAI(payload, signal);
      const errText = await res.text().catch(() => '');
      throw new Error(`خطای ${res.status} در استریم هوش مصنوعی${errText ? `: ${errText.slice(0, 120)}` : ''}`);
    }
  } catch (err) {
    if (isAbortError(err) || signal?.aborted) throw err;
    throw err;
  }
}

