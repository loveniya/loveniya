export function sanitizeHttpUrl(value: string): string {
  try {
    const url = new URL(value.trim());
    if (url.protocol !== 'http:' && url.protocol !== 'https:') return '';
    return url.href;
  } catch {
    return '';
  }
}

export function isHost(url: URL, hosts: string[]): boolean {
  const hostname = url.hostname.toLowerCase();
  return hosts.some(host => hostname === host || hostname.endsWith(`.${host}`));
}
