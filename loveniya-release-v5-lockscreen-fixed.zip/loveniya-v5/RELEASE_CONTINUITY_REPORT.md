# Loveniya — Continuity & Game/UX Phase

## Preservation

This snapshot is based on the previously packaged `loveniya-final-hardened.zip`.
The original archive is preserved outside this working tree and its SHA-256 is copied to `BASE_ARCHIVE_SHA256_COPY.txt`.
No prior packaged source changes were intentionally removed.

Changes discussed after the last packaged archive but not persisted to a file were not treated as completed; only verified source changes are included here.

## This phase

### Truth / Dare
- Introduced a standalone, deterministic Truth/Dare state machine.
- The challenge no longer depends on AI availability or network latency.
- Turn ownership is explicit: spinner -> answerer -> next spinner.
- The active round cannot be overwritten until it is answered or skipped.
- Added an explicit skip action.
- Added payload sanitization and round IDs.
- Added backward-compatible migration from the previous timestamp-based round format.
- Added client-side UX that clearly shows whose turn it is.
- Bottle control is now keyboard/screen-reader usable.

### Shared game authority
- Added `momentsEngine.ts` as the server/client-safe rules layer.
- Server now serializes writes to `loveniya_moments_v2`.
- Tic-Tac-Toe moves are validated server-side: exactly one valid cell may change on the correct turn.
- Scores/winner are derived server-side instead of trusting client-provided values.
- Duplicate retries are idempotent.
- Truth/Dare round transitions are validated server-side.
- Telepathy choice writes are narrowed to the authenticated player's current choice.

### UI/UX
- Game tabs expose `aria-pressed` state.
- Bottle emoji interaction is now a real button with keyboard/focus support.
- Turn status is visible before the primary action.
- Page scroll reset uses standards-compatible `behavior: auto`.
- Home reason rotation timeout has explicit cleanup.
- Memory images use lazy loading/async decoding where appropriate.
- Global horizontal overscroll is suppressed and scrollbar gutter is stabilized.

## Verification

- Static QA: PASS — 39 source files scanned.
- TypeScript parser: PASS — 39 project TS/TSX sources plus server parsed with 0 parse errors.
- Truth/Dare smoke: PASS.
- Shared Moments engine smoke: PASS.
- `npm ci --dry-run --offline`: PASS — dependency graph is lockfile-resolvable in cache metadata.
- Full `npm ci --offline`: BLOCKED by missing cached `yallist` registry metadata; no dependency files are included in the release archive.
- Full Vite/typecheck build: not claimed as verified in this sandbox.
