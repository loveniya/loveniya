# Loveniya — Continuation V3 / Game & UI-UX Checkpoint

## Base preservation

This phase starts from `loveniya-continuation-v2.zip`.

Base SHA-256:
`a2120b8988085ae09d8cc97a43ceba2d2dba5f61de1cb28cd7f0a8472a072621`

The base archive remains untouched. This working tree is a separate continuation copy.

## Changes completed in this phase

### Truth / Dare
- Both users can start the first round; the old hard-coded Amin-only first turn was removed.
- Server-side round rules remain authoritative.
- A second user cannot overwrite an active round.
- A finished round transfers the next turn to the previous answerer.
- Failed/conflicting writes no longer leave the UI permanently believing a lost challenge was saved.
- Answer/skip actions wait for persistence before presenting the completed state.
- Direct controls now use clearer Persian labels (`حقیقت`, `جرأت`).

### Tic-Tac-Toe
- A live reset is blocked while a round is still in progress.
- Server rejects mid-round board wipes.
- Reset remains available after a completed round and preserves the scoreboard.
- Conflict handling refreshes the authoritative state instead of leaving a false local board.

### Telepathy
- The partner's actual choice is redacted by the server until both users have answered.
- The UI receives answer-status flags separately, so it can still show `پاسخ داده` without leaking the partner's A/B selection.
- Only Amin creates the initial AI question when there is no active question, preventing two devices from racing to create different first questions.
- Selecting is locked once the round is complete.

### Server / security / resilience
- `/api/data/loveniya_moments_v2` GET responses are sanitized per authenticated viewer.
- Moments writes use the existing serialized server queue.
- Data gateway upstream reads now use the retry/timeout helper rather than a raw `fetch`.
- CSP now applies to every non-API HTML route, not only `/`.
- Conflict (`409`) handling in the Moments outbox clears the rejected pending patch and reloads authoritative server state.
- Fast successive local updates read the latest pending outbox payload when serialized writes execute.

### UI/UX
- Added a compact live game-status strip above the game tabs: current turn, score, and two-player mode.
- Game tabs now sit in a clearer grouped navigation surface and have a larger touch target.
- Turn state is surfaced before the primary action.
- Reset action is visibly disabled until a Tic-Tac-Toe round is actually finished.
- Accessibility semantics from the previous phase remain intact.

## Verification

- Static QA: PASS — 39 source files scanned.
- TypeScript syntax transpile: PASS — 40 project TS/TSX/server files.
- Moments engine smoke test: PASS.
- Truth/Dare smoke test: PASS.
- Pure game modules compile under NodeNext: PASS.
- Full dependency install / production build is still environment-blocked by the sandbox's missing offline registry metadata.

## Important continuation rule

Do not overwrite the previous packaged archive when extending this work. Always create a new snapshot and record its SHA-256 before continuing.
