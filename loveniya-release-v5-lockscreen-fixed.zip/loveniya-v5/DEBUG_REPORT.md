# Loveniya — Deep QA / Hardening Report

آخرین snapshot پروژه پس از چند دور refactor، امنیت، پایداری داده، UX و QA است.

## وضعیت تأییدشده

- Static QA: **PASS** — 37 فایل source اسکن شد.
- TypeScript syntax parsing: **PASS** — 39 فایل TS/TSX با parser رسمی TypeScript بررسی شد.
- Explicit `<button type>` audit: **PASS** — 0 مورد بدون `type`.
- `target="_blank"` audit: لینک‌های جدید باید `rel="noopener"` داشته باشند و QA آن را بررسی می‌کند.
- Client secret sweep: **PASS** — `APP_SECRET`/`X-App-Secret`/upstream worker URL در `src/` وجود ندارند.
- Dynamic code execution sweep: **PASS** — `eval` و `new Function` وجود ندارد.
- Vite ESM config: **FIXED** — استفاده از `__dirname` حذف شده و `fileURLToPath(import.meta.url)` استفاده می‌شود.
- Lockfile: **CONSISTENT** — پس از حذف dependencyهای بلااستفاده دوباره با `npm install --package-lock-only` همگام شد.

## اصلاحات مهم این دور

### Session / Authentication

- Session از Map داخل حافظه به cookie امضاشده و stateless تبدیل شد؛ restart سرور sessionهای معتبر را بی‌دلیل از بین نمی‌برد.
- signatureها قبل از `timingSafeEqual` از نظر طول و فرمت بررسی می‌شوند تا cookie خراب باعث exception نشود.
- cookie دارای `HttpOnly` و `SameSite=Lax` است و در production `Secure` می‌شود.
- production بدون `SESSION_SECRET` fail-fast می‌شود.
- production بدون credential ورود fail-fast می‌شود.
- درخواست‌های mutating به gateway به header داخلی `X-Loveniya-Request: 1` نیاز دارند تا CSRF ساده cross-site بسته شود.
- API responseها `Cache-Control: no-store` می‌گیرند.

### Data Sync

- outbox پایدار برای داده‌های Store اضافه شد؛ write ناموفق در localStorage نگه‌داری می‌شود.
- outbox بر اساس target path آخرین عملیات را نگه می‌دارد تا retryها idempotent بمانند.
- polling هنگام وجود write pending، داده محلی را با snapshot قدیمی overwrite نمی‌کند.
- Moments نیز outbox مستقل برای PATCHهای ناموفق دارد.

### LDR Secret Envelope

- «پاکت راز» اکنون server-authoritative است.
- در GET بازی، `secretText` برای طرف مقابلِ صاحب پاکت و تا قبل از unlock حذف می‌شود.
- PUTهای معمولی نمی‌توانند `secretText`، `creator`، `status` یا `unlockedAt` پاکت موجود را دستکاری کنند.
- unlock فقط از `/api/ldr/secret-unlock` انجام می‌شود.
- سرور خودش جواب واقعی را می‌خواند و با حدس مقایسه می‌کند.
- برای unlock rate limit مستقل وجود دارد.
- local cache قدیمی نیز قبل از نمایش برای کاربر غیرمالک redact می‌شود.
- کاربر نمی‌تواند با PATCH/PUT جعلی وضعیت پاکت را `unlocked` کند.

### Media / URL Safety

- URLهای ویدیو و موسیقی قبل از مصرف به HTTP/HTTPS محدود شدند.
- تشخیص YouTube / Aparat / Google Drive / Dropbox بر اساس hostname واقعی انجام می‌شود، نه `includes()` روی رشته خام.
- لینک خروجی ویدیوی مستقیم با URL sanitized ساخته می‌شود.
- upload فایل صوتی سقف حجم دارد.

### UX / Accessibility

- LockScreen روی password field focus اولیه می‌دهد.
- `autocomplete="current-password"` اضافه شد.
- خطاهای ورود role=alert دارند.
- Kebab menu دارای ARIA menu semantics، focus اولیه، Escape و Arrow navigation است.
- تعویض کاربر از Settings دیگر با تغییر localStorage جعل هویت نمی‌کند؛ ابتدا session را قفل می‌کند تا کاربر با credential وارد هویت دیگر شود.
- heartbeat چت با تغییر هر کلید reset نمی‌شود؛ typing presence debounce شده است.
- viewport موبایل با `viewport-fit=cover` تثبیت شد.
- safe-area برای chrome پایین برنامه رعایت می‌شود.

### Project Quality

- package name به `loveniya` و نسخه به `1.0.0` رسید.
- dependencyهای بلااستفاده `html2canvas` و `tailwind-merge` حذف شدند.
- QA script قابل تکرار به پروژه اضافه شد.
- CI واقعی در `.github/workflows/ci.yml` اضافه شد و Node 24 را استفاده می‌کند.
- `npm run verify` برای QA + typecheck + build تعریف شده است.

## وضعیت Build در محیط فعلی

`npm run build` اجرا شد اما با این خطا متوقف شد:

```text
vite: not found
```

علت: `node_modules` کامل در محیط موجود نیست. اجرای `npm ci` نیز در این محیط به دلیل نبود برخی بسته‌ها در cache محلی و timeout شبکه کامل نشد. بنابراین build production **تأییدشده در همین sandbox نیست** و عمداً PASS اعلام نشده است.

CI پروژه برای محیط تمیز روی Node 24 آماده است و آنجا باید `npm ci`, `npm run qa`, `npm run lint` و `npm run build` اجرا شوند.

## Known limitations

- type-check کامل نیز بدون نصب dependencyها قابل تأیید نیست.
- تست end-to-end واقعی مرورگر و تست multi-device به سرویس‌های upstream و محیط اجرای کامل نیاز دارد.
- برای production بهتر است `APP_UNLOCK_PASSWORD_SHA256` در یک secret manager نگه‌داری شود و در یک مرحله بعدی به password hashing مقاوم‌تر مانند scrypt/Argon2 مهاجرت کند.

## دستور verify نهایی

```bash
npm ci
npm run verify
npm start
```
