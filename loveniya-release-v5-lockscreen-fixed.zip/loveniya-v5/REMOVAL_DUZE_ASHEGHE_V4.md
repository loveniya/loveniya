# Release V4 — حذف امن دوز عاشقی

این نسخه از آخرین snapshot پایدار V3 ساخته شده است. snapshot پایه قبل از تغییر در `../continuation-v3-before-tictactoe-removal` نگه داشته شده و هیچ overwriteای روی آن انجام نشده است.

## حذف امن
- تب و UI بازی «دوز عاشقی» از `Moments` حذف شد.
- stateهای قدیمی `board`، `turn`، `scores` و `winner` دیگر بخشی از مدل اجرایی نیستند.
- منطق Tic-Tac-Toe از `momentsEngine` حذف شد.
- CSS و smoke test مخصوص آن حذف شد.
- `?tab=tictactoe` در bookmarkهای قدیمی بدون crash به تب بازی اصلی fallback می‌کند.
- مسیر `/games` برای backward compatibility باقی می‌ماند و به صفحه بازی‌های باقی‌مانده می‌رسد.
- داده‌های قدیمی Tic-Tac-Toe هنگام read/write به شکل silent migration کنار گذاشته می‌شوند؛ داده‌های Truth/Dare و Telepathy حفظ می‌شوند.

## Runtime
- پروژه روی Node.js 24.21.x و npm 11.x pin شده است.
- CI همچنان روی Node 24 اجرا می‌شود.

## Verification
- QA و syntax smoke باید سبز باشند.
- game smoke فقط Truth/Dare، Telepathy redaction و حذف state قدیمی را تست می‌کند.
