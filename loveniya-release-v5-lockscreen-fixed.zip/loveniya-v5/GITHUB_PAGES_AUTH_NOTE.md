# Deployment note

The secure auth flow in this release expects `/api/auth/*` and `/api/data/*` to be served by the same-origin secure gateway.

A static GitHub Pages deployment cannot execute `server.ts` or provide these API routes. Do not add the password to client-side code as a workaround; deploy the frontend with the secure gateway (or configure an equivalent same-origin backend) instead.

The legacy Loveniya passphrase is restored server-side as a SHA-256 hash in `.env.example`; it is not embedded in the client bundle.
