# Loveniya Continuity Manifest

This working tree starts from the packaged snapshot `loveniya-final-hardened.zip`.
No earlier packaged changes are intentionally discarded.

- Base archive: `../loveniya-final-hardened.zip`
- Base SHA-256 is recorded in `BASE_SNAPSHOT_SHA256.txt`.
- Future edits in this phase are made only in this working tree.
- Before release, QA, syntax checks, and a new archive are produced separately.

Important: edits discussed after the last packaged archive but not persisted to a file are not silently represented as completed. They are re-applied only when verified in source.
