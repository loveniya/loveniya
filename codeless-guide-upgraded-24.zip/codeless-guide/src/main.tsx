import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
// فونت وزیرمتن روی خود سایت (بدون وابستگی به CDN خارجی)
import '@fontsource-variable/vazirmatn';
// فونت اسکریپت لوگوی هدر (I Love You)
import '@fontsource/alex-brush';
import App from './App.tsx';
import './index.css';

// بازیابی خودکار اسکرول مرورگر با HashRouter + انیمیشن‌های ورود با هم تداخل می‌کنن و صفحه رو وسط محتوا باز می‌کنن؛
// اسکرول رو خودمون مدیریت می‌کنیم (PageWrapper بالا، useDetailScroll جای قبلی).
if ('scrollRestoration' in history) history.scrollRestoration = 'manual';

// قفل زوم: متای viewport در اندروید کافیه، ولی iOS Safari اون رو نادیده می‌گیره و
// pinch-zoom رو با رویدادهای gesture* انجام می‌ده؛ فقط همین‌ها رو مسدود می‌کنیم.
// دابل‌تپ-زوم هم با touch-action: manipulation در index.css بسته شده.
// نکته: قبلاً یک listener غیرفعال (non-passive) روی touchmove بود که با touches.length > 1 جلوی رویداد رو
// می‌گرفت. نتیجه: اگه حین اسکرول یک انگشت دوم (شست/کف دست/لبه‌ی صفحه) روی صفحه می‌موند، کل اسکرول مرده بود
// تا همه‌ی انگشت‌ها برداشته بشن؛ ضمناً هر touchmove رو هم کند می‌کرد. حذف شد.
const blockZoom = (e: Event) => e.preventDefault();
document.addEventListener('gesturestart', blockZoom);
document.addEventListener('gesturechange', blockZoom);
document.addEventListener('gestureend', blockZoom);
createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
