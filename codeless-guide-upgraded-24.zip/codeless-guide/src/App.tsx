/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { HashRouter, Routes, Route, Navigate, useLocation } from 'react-router';
import { useState, Suspense } from 'react';
import { motion, MotionConfig } from 'motion/react';
import { StoreProvider } from './lib/store';
import { Navigation } from './components/Navigation';
import { LockScreen } from './components/LockScreen';
import { Home } from './pages/Home';
import { Memories } from './pages/Memories';
import { Pledges } from './pages/Pledges';
import { Dreams } from './pages/Dreams';
import { Music } from './pages/Music';
import { Letters } from './pages/Letters';
import { Settings } from './pages/Settings';
import { RomanticEffects } from './components/RomanticEffects';
import { MediaPlayer } from './components/MediaPlayer';
import { useGlobalPresenceTracker } from './lib/presence';
import { GameProvider } from './lib/gameStore';
import { GameToaster } from './components/GameNotifications';
import { ErrorBoundary } from './components/ErrorBoundary';
import { lazyRetry } from './lib/lazyRetry';

// این دو صفحه (چت هوش مصنوعی و بازی‌ها) سنگین‌ترین صفحات پروژه‌اند؛
// جدا لودشون می‌کنیم تا حجم اولیه‌ای که کاربر موقع باز کردن سایت دانلود
// می‌کنه کمتر بشه. فقط با تاخیر کوتاه، هنگام اولین ورود به همون صفحه لود می‌شن.
const AIChat = lazyRetry(() => import('./pages/AIChat').then(m => ({ default: m.AIChat })));
const Moments = lazyRetry(() => import('./pages/Moments').then(m => ({ default: m.Moments })));

const RouteLoadingFallback = () => (
  <div className="flex items-center justify-center py-24" dir="rtl">
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="flex flex-col items-center gap-3 text-rose-400"
    >
      <div className="w-8 h-8 border-2 border-rose-200 border-t-rose-500 rounded-full animate-spin" />
      <span className="text-xs font-bold text-stone-400">در حال آماده‌سازی...</span>
    </motion.div>
  </div>
);

function AppContent({ handleLock }: { handleLock: () => void }) {
  useGlobalPresenceTracker();

  return (
    <HashRouter basename="/">
      {/* موتور «دونفره» و اعلان‌هاش باید داخل router باشن و روی همه‌ی صفحه‌ها فعال بمونن */}
      <GameProvider>
        <AppLayout handleLock={handleLock} />
      </GameProvider>
    </HashRouter>
  );
}

function AppLayout({ handleLock }: { handleLock: () => void }) {
  const location = useLocation();
  const isChatPage = location.pathname === '/magic' || location.pathname === '/chat';

  if (isChatPage) {
    return (
      <div className="fixed inset-0 z-50 bg-[#fff0f5] overflow-hidden overscroll-none">
        <ErrorBoundary resetKey={location.pathname}>
          <Suspense fallback={<RouteLoadingFallback />}>
            <AIChat />
          </Suspense>
        </ErrorBoundary>
      </div>
    );
  }

  return (
    <>
      <Navigation />
      <GameToaster />
      <MediaPlayer />
      <main className="max-w-4xl mx-auto px-4 md:px-6 pt-16 sm:pt-18 pb-28 relative z-10">
        <ErrorBoundary resetKey={location.pathname}>
        <Suspense fallback={<RouteLoadingFallback />}>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/memories" element={<Memories />} />
            <Route path="/pledges" element={<Pledges />} />
            <Route path="/dreams" element={<Dreams />} />
            <Route path="/music" element={<Music />} />
            <Route path="/letters" element={<Letters />} />
            <Route path="/moments" element={<Moments />} />
            <Route path="/games" element={<Moments />} />
            <Route path="/settings" element={<Settings onLock={handleLock} />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </Suspense>
        </ErrorBoundary>
      </main>
    </>
  );
}

export default function App() {
  // مقدار اولیه مستقیم از localStorage خونده می‌شه؛ قبلاً با useEffect بعد از اولین رندر
  // تنظیم می‌شد و صفحه‌ی قفل در هر بار باز شدن سایت یک لحظه فلش می‌زد.
  const [isUnlocked, setIsUnlocked] = useState(
    () => localStorage.getItem('loveniya_unlocked') === 'true' && !!localStorage.getItem('loveniya_user')
  );

  const handleUnlock = () => setIsUnlocked(true);
  const handleLock = () => {
    // هر دو کلید قفل باید با هم پاک بشن؛ اگه فقط یکی پاک بشه (باگ قبلی)،
    // دفعه بعد که سایت باز میشه بازم از LockScreen رد میشه چون شرط
    // بازشدن قفل توی useEffect بالا هر دو کلید رو با هم چک می‌کنه —
    // ولی چون خود کاربر و هویتش (loveniya_user) پاک نمی‌شد، قفل کردن
    // واقعی و کامل حساب رخ نمی‌داد.
    localStorage.removeItem('loveniya_unlocked');
    localStorage.removeItem('loveniya_user');
    setIsUnlocked(false);
  };

  if (!isUnlocked) {
    return <LockScreen onUnlock={handleUnlock} />;
  }

  return (
    <MotionConfig reducedMotion="user">
      <ErrorBoundary>
        <StoreProvider>
          <RomanticEffects />
          <AppContent handleLock={handleLock} />
        </StoreProvider>
      </ErrorBoundary>
    </MotionConfig>
  );
}

