import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { Memory, Pledge, Dream, Music, Capsule, TrashItem, SyncStatus } from './types';

// آدرس پُل اختصاصی شما در کلودفلر
const WORKER_URL = "https://niya.am-b-asdfghjkl20112011.workers.dev";

interface StoreContextType {
  memories: Memory[];
  pledges: Pledge[];
  dreams: Dream[];
  playlist: Music[];
  capsules: Capsule[];
  trashItems: TrashItem[];
  letterContent: string;
  syncStatus: SyncStatus;
  syncError: string | null;
  addMemory: (m: Memory) => void;
  updateMemory: (m: Memory) => void;
  removeMemory: (id: string) => void;
  addPledge: (p: Pledge) => void;
  updatePledge: (p: Pledge) => void;
  removePledge: (id: string) => void;
  addDream: (d: Dream) => void;
  updateDream: (d: Dream) => void;
  removeDream: (id: string) => void;
  addMusic: (m: Music) => void;
  updateMusic: (m: Music) => void;
  removeMusic: (id: string) => void;
  addCapsule: (c: Capsule) => void;
  updateCapsule: (c: Capsule) => void;
  removeCapsule: (id: string) => void;
  setLetterContent: (text: string) => void;
  moveToTrash: (type: TrashItem['type'], item: any) => void;
  emptyTrash: () => void;
  restoreFromTrash: (trashId: string) => void;
  permanentlyDeleteFromTrash: (trashId: string) => void;
}

const StoreContext = createContext<StoreContextType | null>(null);

export const useStore = () => {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error('useStore must be used within StoreProvider');
  return ctx;
};

export const StoreProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const load = <T,>(key: string, def: T): T => {
    try {
      const stored = localStorage.getItem(key);
      return stored ? JSON.parse(stored) : def;
    } catch {
      return def;
    }
  };

  const [memories, setMemoriesState] = useState<Memory[]>(() => load('loveniya_mems', []));
  const [pledges, setPledgesState] = useState<Pledge[]>(() => load('loveniya_plg', []));
  const [dreams, setDreamsState] = useState<Dream[]>(() => load('loveniya_dreams', []));
  const [playlist, setPlaylistState] = useState<Music[]>(() => load('loveniya_msc', []));
  const [capsules, setCapsulesState] = useState<Capsule[]>(() => load('loveniya_capsules', []));
  const [trashItems, setTrashItemsState] = useState<TrashItem[]>(() => load('loveniya_trash', []));
  const [letterContent, setLetterContentState] = useState<string>(() => {
    return localStorage.getItem('loveniya_letter') || '';
  });

  const [syncStatus, setSyncStatus] = useState<SyncStatus>('connected');
  const [syncError, setSyncError] = useState<string | null>(null);

  // نگهداری زمان آخرین تغییر محلی برای هر کلید تا پاسخی از سرور نتواند تغییرات را موقتاً بازگرداند
  const mutatedAtRef = React.useRef<Record<string, number>>({});
  const consecutiveFailuresRef = React.useRef<number>(0);

  // تابع ارسال مستقیم اطلاعات به فایربیس از طریق کلودفلر و ذخیره همزمان در حافظه گوشی
  const safeSet = useCallback(async (path: string, localKey: string, data: any) => {
    mutatedAtRef.current[path] = Date.now();
    try {
      localStorage.setItem(localKey, typeof data === 'string' ? data : JSON.stringify(data));
    } catch (e) {}

    try {
      setSyncStatus('syncing');
      const res = await fetch(`${WORKER_URL}/${path}.json`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });

      if (!res.ok) throw new Error(`خطای HTTP: ${res.status}`);
      
      consecutiveFailuresRef.current = 0;
      setSyncStatus('connected');
      setSyncError(null);
    } catch (err: any) {
      consecutiveFailuresRef.current += 1;
      if (consecutiveFailuresRef.current >= 3) {
        setSyncStatus('disconnected');
        setSyncError(err.message || 'خطا در ارتباط با سرور.');
      } else {
        setSyncStatus('connected');
      }
    }
  }, []);

  // دریافت تمام اطلاعات از دیتابیس بدون نیاز به وب‌سوکت با ادغام هوشمند جهت عدم از دست رفتن داده‌ها
  const fetchAllData = useCallback(async () => {
    const isRecentlyMutated = (key: string) => {
      const lastMutated = mutatedAtRef.current[key] || 0;
      return Date.now() - lastMutated < 8000;
    };

    try {
      const t = Date.now();
      const [mRes, pRes, dRes, msRes, cRes, tRes, lRes] = await Promise.all([
        fetch(`${WORKER_URL}/loveniya_mems.json?_t=${t}`, { cache: 'no-store' }),
        fetch(`${WORKER_URL}/loveniya_plg.json?_t=${t}`, { cache: 'no-store' }),
        fetch(`${WORKER_URL}/loveniya_dreams.json?_t=${t}`, { cache: 'no-store' }),
        fetch(`${WORKER_URL}/loveniya_msc.json?_t=${t}`, { cache: 'no-store' }),
        fetch(`${WORKER_URL}/loveniya_capsules.json?_t=${t}`, { cache: 'no-store' }),
        fetch(`${WORKER_URL}/loveniya_trash.json?_t=${t}`, { cache: 'no-store' }),
        fetch(`${WORKER_URL}/loveniya_letter.json?_t=${t}`, { cache: 'no-store' }),
      ]);

      // ۱. ابتدا سطل زباله به‌روزرسانی می‌شود تا آی‌دی‌های حذف‌شده مشخص شوند
      let currentTrash: TrashItem[] = [];
      if (tRes.ok && !isRecentlyMutated('loveniya_trash')) {
        const tData = await tRes.json();
        if (tData !== null) {
          let serverTrash: TrashItem[] = Array.isArray(tData) ? tData : Object.values(tData);
          serverTrash = serverTrash.filter(x => x && x.trashId);
          if (serverTrash.length > 0) {
            setTrashItemsState(prevTrash => {
              const trashMap = new Map<string, TrashItem>();
              for (const item of serverTrash) trashMap.set(item.trashId, item);
              for (const item of prevTrash) {
                if (!trashMap.has(item.trashId)) trashMap.set(item.trashId, item);
              }
              currentTrash = Array.from(trashMap.values());
              try {
                localStorage.setItem('loveniya_trash', JSON.stringify(currentTrash));
              } catch (e) {}
              return currentTrash;
            });
          }
        }
      }

      // مجموعه آی‌دی‌های حذف شده برای جلوگیری از بازگشت مجدد آیتم‌های پاک‌شده
      const deletedMemoryIds = new Set(currentTrash.filter(t => t.type === 'memory' && t.itemPayload?.id).map(t => t.itemPayload.id));
      const deletedPledgeIds = new Set(currentTrash.filter(t => t.type === 'pledge' && t.itemPayload?.id).map(t => t.itemPayload.id));
      const deletedDreamIds = new Set(currentTrash.filter(t => t.type === 'dream' && t.itemPayload?.id).map(t => t.itemPayload.id));
      const deletedMusicIds = new Set(currentTrash.filter(t => t.type === 'music' && t.itemPayload?.id).map(t => t.itemPayload.id));
      const deletedCapsuleIds = new Set(currentTrash.filter(t => t.type === 'capsule' && t.itemPayload?.id).map(t => t.itemPayload.id));

      // تابع ادغام هوشمند و امن داده‌ها با استفاده از تابع به‌روزرسانی حالت
      const mergeAndSync = <T extends { id: string }>(
        serverData: any,
        setLocalList: React.Dispatch<React.SetStateAction<T[]>>,
        storageKey: string,
        deletedSet: Set<string>
      ) => {
        setLocalList(prevList => {
          if (serverData === null || serverData === undefined) {
            if (prevList.length > 0) {
              safeSet(storageKey, storageKey, prevList);
            }
            return prevList;
          }

          let serverArr: T[] = Array.isArray(serverData) ? serverData : Object.values(serverData);
          serverArr = serverArr.filter(x => x && typeof x === 'object' && x.id && !deletedSet.has(x.id));

          if (serverArr.length === 0 && prevList.length > 0) {
            safeSet(storageKey, storageKey, prevList);
            return prevList;
          }

          const map = new Map<string, T>();
          for (const item of serverArr) map.set(item.id, item);

          let localAdded = false;
          for (const item of prevList) {
            if (item && item.id && !deletedSet.has(item.id)) {
              if (!map.has(item.id)) {
                map.set(item.id, item);
                localAdded = true;
              }
            }
          }

          const merged = Array.from(map.values());
          try {
            localStorage.setItem(storageKey, JSON.stringify(merged));
          } catch (e) {}

          if (localAdded) {
            safeSet(storageKey, storageKey, merged);
          }
          return merged;
        });
      };

      if (mRes.ok && !isRecentlyMutated('loveniya_mems')) {
        const mData = await mRes.json();
        mergeAndSync(mData, setMemoriesState, 'loveniya_mems', deletedMemoryIds);
      }

      if (pRes.ok && !isRecentlyMutated('loveniya_plg')) {
        const pData = await pRes.json();
        mergeAndSync(pData, setPledgesState, 'loveniya_plg', deletedPledgeIds);
      }

      if (dRes.ok && !isRecentlyMutated('loveniya_dreams')) {
        const dData = await dRes.json();
        mergeAndSync(dData, setDreamsState, 'loveniya_dreams', deletedDreamIds);
      }

      if (msRes.ok && !isRecentlyMutated('loveniya_msc')) {
        const msData = await msRes.json();
        mergeAndSync(msData, setPlaylistState, 'loveniya_msc', deletedMusicIds);
      }

      if (cRes.ok && !isRecentlyMutated('loveniya_capsules')) {
        const cData = await cRes.json();
        mergeAndSync(cData, setCapsulesState, 'loveniya_capsules', deletedCapsuleIds);
      }

      if (lRes.ok && !isRecentlyMutated('loveniya_letter')) {
        const lData = await lRes.json();
        if (typeof lData === 'string' && lData.trim().length > 0) {
          setLetterContentState(lData);
          try { localStorage.setItem('loveniya_letter', lData); } catch (e) {}
        } else if (lData === null || (typeof lData === 'string' && lData.trim().length === 0)) {
          setLetterContentState(prev => {
            if (prev.trim().length > 0) {
              safeSet('loveniya_letter', 'loveniya_letter', prev);
            }
            return prev;
          });
        }
      }

      consecutiveFailuresRef.current = 0;
      setSyncStatus('connected');
      setSyncError(null);
    } catch (err: any) {
      consecutiveFailuresRef.current += 1;
      if (consecutiveFailuresRef.current >= 3) {
        setSyncStatus('disconnected');
      }
    }
  }, [safeSet]);

  useEffect(() => {
    fetchAllData();
    // همگام‌سازی آرام و بدون فشار بر شبکه هر ۱۰ ثانیه
    const interval = setInterval(fetchAllData, 10000);
    return () => clearInterval(interval);
  }, [fetchAllData]);

  const setMemories = (v: Memory[]) => {
    setMemoriesState(v);
    safeSet('loveniya_mems', 'loveniya_mems', v);
  };

  const setPledges = (v: Pledge[]) => {
    setPledgesState(v);
    safeSet('loveniya_plg', 'loveniya_plg', v);
  };

  const setDreams = (v: Dream[]) => {
    setDreamsState(v);
    safeSet('loveniya_dreams', 'loveniya_dreams', v);
  };

  const setPlaylist = (v: Music[]) => {
    setPlaylistState(v);
    safeSet('loveniya_msc', 'loveniya_msc', v);
  };

  const setCapsules = (v: Capsule[]) => {
    setCapsulesState(v);
    safeSet('loveniya_capsules', 'loveniya_capsules', v);
  };

  const setTrashItems = (v: TrashItem[]) => {
    setTrashItemsState(v);
    safeSet('loveniya_trash', 'loveniya_trash', v);
  };

  const handleSetLetterContent = (text: string) => {
    setLetterContentState(text);
    safeSet('loveniya_letter', 'loveniya_letter', text);
  };

  const moveToTrash = (type: TrashItem['type'], item: any) => {
    const trashObj: TrashItem = {
      trashId: 'trash_' + Date.now(),
      type,
      deletedAt: new Date().toLocaleDateString('fa-IR'),
      itemPayload: item
    };
    setTrashItems([trashObj, ...trashItems]);
  };

  const restoreFromTrash = (trashId: string) => {
    const item = trashItems.find(t => t.trashId === trashId);
    if (!item) return;
    
    if (item.type === 'memory') setMemories([...memories, item.itemPayload]);
    if (item.type === 'pledge') setPledges([...pledges, item.itemPayload]);
    if (item.type === 'dream') setDreams([...dreams, item.itemPayload]);
    if (item.type === 'music') setPlaylist([...playlist, item.itemPayload]);
    if (item.type === 'capsule') setCapsules([...capsules, item.itemPayload]);
    
    setTrashItems(trashItems.filter(t => t.trashId !== trashId));
  };

  const permanentlyDeleteFromTrash = (trashId: string) => {
    setTrashItems(trashItems.filter(t => t.trashId !== trashId));
  };

  const emptyTrash = () => setTrashItems([]);

  const addMemory = (m: Memory) => setMemories([m, ...memories]);
  const updateMemory = (m: Memory) => setMemories(memories.map(x => x.id === m.id ? m : x));
  const removeMemory = (id: string) => {
    const item = memories.find(x => x.id === id);
    if (item) moveToTrash('memory', item);
    setMemories(memories.filter(x => x.id !== id));
  };

  const addPledge = (p: Pledge) => setPledges([p, ...pledges]);
  const updatePledge = (p: Pledge) => setPledges(pledges.map(x => x.id === p.id ? p : x));
  const removePledge = (id: string) => {
    const item = pledges.find(x => x.id === id);
    if (item) moveToTrash('pledge', item);
    setPledges(pledges.filter(x => x.id !== id));
  };

  const addDream = (d: Dream) => setDreams([d, ...dreams]);
  const updateDream = (d: Dream) => setDreams(dreams.map(x => x.id === d.id ? d : x));
  const removeDream = (id: string) => {
    const item = dreams.find(x => x.id === id);
    if (item) moveToTrash('dream', item);
    setDreams(dreams.filter(x => x.id !== id));
  };

  const addMusic = (m: Music) => setPlaylist([m, ...playlist]);
  const updateMusic = (m: Music) => setPlaylist(playlist.map(x => x.id === m.id ? m : x));
  const removeMusic = (id: string) => {
    const item = playlist.find(x => x.id === id);
    if (item) moveToTrash('music', item);
    setPlaylist(playlist.filter(x => x.id !== id));
  };

  const addCapsule = (c: Capsule) => setCapsules([c, ...capsules]);
  const updateCapsule = (c: Capsule) => setCapsules(capsules.map(x => x.id === c.id ? c : x));
  const removeCapsule = (id: string) => {
    const item = capsules.find(x => x.id === id);
    if (item) moveToTrash('capsule', item);
    setCapsules(capsules.filter(x => x.id !== id));
  };

  return (
    <StoreContext.Provider value={{
      memories, pledges, dreams, playlist, capsules, trashItems, letterContent,
      syncStatus, syncError,
      addMemory, updateMemory, removeMemory,
      addPledge, updatePledge, removePledge,
      addDream, updateDream, removeDream,
      addMusic, updateMusic, removeMusic,
      addCapsule, updateCapsule, removeCapsule,
      setLetterContent: handleSetLetterContent,
      moveToTrash, emptyTrash, restoreFromTrash, permanentlyDeleteFromTrash
    }}>
      {children}
    </StoreContext.Provider>
  );
};