/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { HashRouter, Routes, Route, Navigate, useLocation } from 'react-router';
import { useState, useEffect, Suspense, lazy } from 'react';
import { motion, MotionConfig } from 'motion/react';
import { StoreProvider } from './lib/store';
import { Navigation } from './components/Navigation';
import { LockScreen } from './components/LockScreen';
import { Home } from './pages/Home';
import { Memories } from './pages/Memories';
import { Pledges } from './pages/Pledges';
import { Dreams } from './pages/Dreams';
import { Music } from './pages/Music';
import { Letters } from './pages/Letters';
import { Settings } from './pages/Settings';
import { RomanticEffects } from './components/RomanticEffects';
import { MediaPlayer } from './components/MediaPlayer';
import { useGlobalPresenceTracker } from './lib/presence';
import { AppErrorBoundary } from './components/AppErrorBoundary';
import { authStatus, lockSession } from './lib/api';

// این دو صفحه (چت هوش مصنوعی و بازی‌ها) سنگین‌ترین صفحات پروژه‌اند؛
// جدا لودشون می‌کنیم تا حجم اولیه‌ای که کاربر موقع باز کردن سایت دانلود
// می‌کنه کمتر بشه. فقط با تاخیر کوتاه، هنگام اولین ورود به همون صفحه لود می‌شن.
const AIChat = lazy(() => import('./pages/AIChat').then(m => ({ default: m.AIChat })));
const Moments = lazy(() => import('./pages/Moments').then(m => ({ default: m.Moments })));

const RouteLoadingFallback = () => (
  <div className="flex items-center justify-center py-24" dir="rtl">
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="flex flex-col items-center gap-3 text-rose-400"
    >
      <div className="w-8 h-8 border-2 border-rose-200 border-t-rose-500 rounded-full animate-spin" />
      <span className="text-xs font-bold text-stone-400">در حال آماده‌سازی...</span>
    </motion.div>
  </div>
);

function AppContent({ handleLock }: { handleLock: () => void }) {
  useGlobalPresenceTracker();

  return (
    <HashRouter basename="/">
      <AppLayout handleLock={handleLock} />
    </HashRouter>
  );
}

function AppLayout({ handleLock }: { handleLock: () => void }) {
  const location = useLocation();
  const isChatPage = location.pathname === '/magic' || location.pathname === '/chat';

  if (isChatPage) {
    return (
      <div className="fixed inset-0 z-50 bg-[#fbfbfb] overflow-hidden">
        <Suspense fallback={<RouteLoadingFallback />}>
          <AIChat />
        </Suspense>
      </div>
    );
  }

  return (
    <>
      <Navigation />
      <MediaPlayer />
      <main className="max-w-4xl mx-auto px-4 md:px-6 pt-16 sm:pt-18 pb-28 relative z-10">
        <Suspense fallback={<RouteLoadingFallback />}>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/memories" element={<Memories />} />
            <Route path="/pledges" element={<Pledges />} />
            <Route path="/dreams" element={<Dreams />} />
            <Route path="/music" element={<Music />} />
            <Route path="/letters" element={<Letters />} />
            <Route path="/moments" element={<Moments />} />
            <Route path="/games" element={<Moments />} />
            <Route path="/settings" element={<Settings onLock={handleLock} />} />
            <Route path="/magic" element={<AIChat />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </Suspense>
      </main>
    </>
  );
}

export default function App() {
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [checkingSession, setCheckingSession] = useState(true);

  useEffect(() => {
    let active = true;
    authStatus().then((status) => {
      if (!active) return;
      if (status.authenticated && status.user) {
        localStorage.setItem('loveniya_user', status.user);
        setIsUnlocked(true);
      } else {
        localStorage.removeItem('loveniya_unlocked');
      }
    }).catch(() => {
      // Offline/server unavailable: keep the lock visible rather than exposing app data.
    }).finally(() => {
      if (active) setCheckingSession(false);
    });
    return () => { active = false; };
  }, []);

  const handleUnlock = () => setIsUnlocked(true);
  const handleLock = () => {
    void lockSession();
    localStorage.removeItem('loveniya_unlocked');
    setIsUnlocked(false);
  };

  if (checkingSession) {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-rose-50 px-6" dir="rtl">
        <div className="rounded-3xl bg-white/90 border border-white p-6 shadow-xl text-center">
          <div className="mx-auto mb-3 h-9 w-9 rounded-full border-2 border-rose-200 border-t-rose-500 animate-spin" />
          <p className="text-sm font-bold text-stone-600">در حال بررسی نشست...</p>
        </div>
      </div>
    );
  }

  if (!isUnlocked) {
    return <LockScreen onUnlock={handleUnlock} />;
  }

  return (
    <AppErrorBoundary>
      <MotionConfig reducedMotion="user">
        <StoreProvider>
        <RomanticEffects />
          <AppContent handleLock={handleLock} />
        </StoreProvider>
      </MotionConfig>
    </AppErrorBoundary>
  );
}

