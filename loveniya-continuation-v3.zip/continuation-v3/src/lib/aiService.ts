import { ChatMessage } from './types';

export interface StructuredAiResponse {
  message: string;
  emotion: string;
  auto_reaction: string | null;
  action_trigger: string;
}

/**
 * Task 2: Formats recent messages into structured history labeled with [Amin] and [Niyayesh]
 */
export function formatChatHistory(messages: ChatMessage[], limit: number = 8): string {
  const recent = messages.slice(-limit);
  return recent
    .map(m => {
      let label = '[Loveniya AI]';
      if (m.senderId === 'amin' || m.sender === 'Amin') {
        label = '[Amin]';
      } else if (m.senderId === 'niyayesh' || m.sender === 'Niyaish') {
        label = '[Niyayesh]';
      }
      const text = m.text || m.content || '';
      return `${label}: ${text}`;
    })
    .join('\n');
}

/**
 * Task 1 & 2: Sends formatted chat history to server-side AI gateway (/api/loveai)
 * and returns structured JSON with fallback safety.
 */
export async function generateAiResponse(
  messages: ChatMessage[],
  customPrompt?: string,
  promptType: string = 'chat'
): Promise<StructuredAiResponse> {
  try {
    const formattedHistory = formatChatHistory(messages);
    const latestMessage = messages[messages.length - 1]?.text || messages[messages.length - 1]?.content || '';
    const userMessage = (customPrompt || latestMessage || '').trim();

    const res = await fetch('/api/loveai', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        type: promptType,
        userMessage,
        contextData: {},
        history: formattedHistory,
      }),
    });

    if (!res.ok) {
      throw new Error(`HTTP error ${res.status}`);
    }

    const contentType = res.headers.get('content-type') || '';
    if (!contentType.includes('application/json')) {
      throw new Error('Response is not JSON (static host)');
    }

    const data = await res.json();

    // Fallback parsing safety
    const message = data.message || data.text || data.result || 'امین جان و نیایش عزیز! من همیشه کنار شما هستم. ❤️✨';
    const emotion = data.emotion || 'caring';
    const auto_reaction = typeof data.auto_reaction === 'string' ? data.auto_reaction : null;
    const action_trigger = data.action_trigger || promptType || 'chat_reply';

    return {
      message,
      emotion,
      auto_reaction,
      action_trigger,
    };
  } catch (err: any) {
    console.error('generateAiResponse Error:', err?.message || err);
    return {
      message: 'یک لحظه ارتباطم قطع شد امین و نیایش عزیزم، اما همیشه با تمام وجود کنارتون هستم! 🌸✨',
      emotion: 'caring',
      auto_reaction: '✨',
      action_trigger: 'fallback',
    };
  }
}
