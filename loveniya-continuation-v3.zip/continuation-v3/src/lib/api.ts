export type AppUser = 'amin' | 'niyayesh';

export async function apiFetch(input: string, init: RequestInit = {}): Promise<Response> {
  const headers = new Headers(init.headers || {});
  if (init.body && !headers.has('Content-Type')) headers.set('Content-Type', 'application/json');
  const method = (init.method || 'GET').toUpperCase();
  if (!['GET', 'HEAD', 'OPTIONS'].includes(method)) headers.set('X-Loveniya-Request', '1');
  return fetch(input, {
    ...init,
    credentials: 'same-origin',
    headers,
    cache: init.cache ?? 'no-store',
  });
}

export function dataApi(path: string): string {
  const clean = path.replace(/^\/+/, '').replace(/\.json$/, '');
  return `/api/data/${clean}`;
}

export async function unlock(password: string, user: AppUser): Promise<AppUser> {
  const res = await apiFetch('/api/auth/unlock', {
    method: 'POST',
    body: JSON.stringify({ password, user }),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data?.error || 'ورود ناموفق بود.');
  return data.user as AppUser;
}

export async function authStatus(): Promise<{ authenticated: boolean; user?: AppUser }> {
  const res = await apiFetch('/api/auth/status');
  if (!res.ok) return { authenticated: false };
  return res.json();
}

export async function lockSession(): Promise<void> {
  await apiFetch('/api/auth/lock', { method: 'POST' }).catch(() => undefined);
}
