import { sanitizeTruthOrDareRound, type TruthDareRound } from './truthOrDare.js';

export type MomentsUser = 'amin' | 'niyayesh';

export type MomentsGameState = {
  board?: (string | null)[];
  turn?: MomentsUser;
  scores?: { amin: number; niyayesh: number; draws: number };
  winner?: string | null;
  telepathyChoices?: Record<string, { amin?: string; niyayesh?: string }>;
  telepathyStatus?: Record<string, { amin: boolean; niyayesh: boolean }>;
  currentTelepathyQuestion?: { id: string; q: string; a: string; b: string };
  lastBottleResult?: TruthDareRound | null;
};

export function otherUser(user: MomentsUser): MomentsUser {
  return user === 'amin' ? 'niyayesh' : 'amin';
}

export function getTicTacToeWinner(board: (string | null)[]): string | null {
  if (!Array.isArray(board) || board.length !== 9) return null;
  const lines = [
    [0, 1, 2], [3, 4, 5], [6, 7, 8],
    [0, 3, 6], [1, 4, 7], [2, 5, 8],
    [0, 4, 8], [2, 4, 6],
  ];
  for (const [a, b, c] of lines) {
    if (board[a] && board[a] === board[b] && board[a] === board[c]) return board[a];
  }
  return board.every(Boolean) ? 'draw' : null;
}

function cleanBoard(value: unknown): (string | null)[] {
  if (!Array.isArray(value) || value.length !== 9) throw new Error('زمین بازی نامعتبر است.');
  const board = value.map(cell => cell === 'X' || cell === 'O' || cell === null ? cell : null);
  if (board.some((cell, index) => cell !== value[index])) throw new Error('حرکت بازی نامعتبر است.');
  return board;
}

function cleanScores(value: any) {
  return {
    amin: Math.max(0, Number(value?.amin) || 0),
    niyayesh: Math.max(0, Number(value?.niyayesh) || 0),
    draws: Math.max(0, Number(value?.draws) || 0),
  };
}

function mergeTicTacToe(current: MomentsGameState, incoming: any, user: MomentsUser) {
  if (!('board' in incoming) && !('turn' in incoming) && !('winner' in incoming)) return;
  const currentBoard = Array.isArray(current.board) && current.board.length === 9 ? current.board : Array(9).fill(null);
  const board = cleanBoard(incoming.board ?? currentBoard);
  const sameBoard = board.every((cell, i) => cell === currentBoard[i]);

  // ریست فقط وقتی مجاز است که دست قبلی واقعاً تمام شده باشد؛
  // ریست وسط بازی می‌توانست با یک PATCH دستی، بازی طرف مقابل را حذف کند.
  if (board.every(cell => cell === null)) {
    if (currentBoard.every(cell => cell === null)) return;
    if (!current.winner) throw new Error('تا پایان این دست نمی‌توانید بازی را ریست کنید.');
    current.board = board;
    current.turn = 'amin';
    current.winner = null;
    return;
  }

  if (sameBoard) return; // idempotent retry
  if (current.winner) throw new Error('این دور تمام شده است.');
  const currentTurn = current.turn === 'niyayesh' ? 'niyayesh' : 'amin';
  if (currentTurn !== user) throw new Error('هنوز نوبت شما نیست.');

  let changed = 0;
  let symbol = '';
  for (let i = 0; i < 9; i++) {
    if (currentBoard[i] !== board[i]) {
      changed++;
      symbol = String(board[i] ?? '');
      if (currentBoard[i] !== null || (symbol !== 'X' && symbol !== 'O')) throw new Error('حرکت بازی نامعتبر است.');
    }
  }
  const expectedSymbol = user === 'amin' ? 'X' : 'O';
  if (changed !== 1 || symbol !== expectedSymbol) throw new Error('حرکت بازی نامعتبر است.');

  const winner = getTicTacToeWinner(board);
  const scores = cleanScores(current.scores);
  if (winner === 'X') scores.amin += 1;
  else if (winner === 'O') scores.niyayesh += 1;
  else if (winner === 'draw') scores.draws += 1;

  current.board = board;
  current.turn = otherUser(user);
  current.winner = winner;
  current.scores = scores;
}

function mergeTruthDare(current: MomentsGameState, incoming: any, user: MomentsUser) {
  if (!Object.prototype.hasOwnProperty.call(incoming, 'lastBottleResult')) return;
  const round = sanitizeTruthOrDareRound(incoming.lastBottleResult);
  if (!round) throw new Error('دور جرأت یا حقیقت نامعتبر است.');

  const previous = current.lastBottleResult ? sanitizeTruthOrDareRound(current.lastBottleResult) : null;
  if (previous && previous.id === round.id && previous.status === round.status && previous.text === round.text) return;

  if (!previous || previous.status !== 'waiting') {
    if (round.spinnerId !== user || round.answererId !== otherUser(user) || round.status !== 'waiting') {
      throw new Error('نوبت بازی جرأت یا حقیقت نامعتبر است.');
    }
    current.lastBottleResult = round;
    return;
  }

  if (round.id !== previous.id || round.text !== previous.text || round.spinnerId !== previous.spinnerId || round.answererId !== previous.answererId) {
    throw new Error('دور فعال هنوز تمام نشده است.');
  }
  if (previous.answererId !== user || (round.status !== 'answered' && round.status !== 'skipped')) {
    throw new Error('فقط پاسخ‌دهنده می‌تواند این دور را تمام کند.');
  }
  current.lastBottleResult = { ...previous, status: round.status, answeredAt: round.answeredAt ?? Date.now() };
}

function mergeTelepathy(current: MomentsGameState, incoming: any, user: MomentsUser) {
  const currentQuestion = current.currentTelepathyQuestion;
  if (incoming.currentTelepathyQuestion && typeof incoming.currentTelepathyQuestion === 'object') {
    const q = incoming.currentTelepathyQuestion;
    if (typeof q.id !== 'string' || typeof q.q !== 'string' || typeof q.a !== 'string' || typeof q.b !== 'string') throw new Error('سوال تله‌پاتی نامعتبر است.');
    const existingChoices = current.telepathyChoices?.[currentQuestion?.id || ''];
    const complete = !!existingChoices?.amin && !!existingChoices?.niyayesh;
    if (!currentQuestion || complete) {
      current.currentTelepathyQuestion = { id: q.id, q: q.q.slice(0, 300), a: q.a.slice(0, 300), b: q.b.slice(0, 300) };
      current.telepathyChoices = current.telepathyChoices || {};
    }
  }

  if (incoming.telepathyChoices && typeof incoming.telepathyChoices === 'object' && current.currentTelepathyQuestion?.id) {
    const id = current.currentTelepathyQuestion.id;
    const incomingChoice = incoming.telepathyChoices?.[id]?.[user];
    if (incomingChoice === 'A' || incomingChoice === 'B') {
      current.telepathyChoices = current.telepathyChoices || {};
      const prev = current.telepathyChoices[id] || {};
      current.telepathyChoices[id] = { ...prev, [user]: incomingChoice };
    }
  }
}

export function sanitizeMomentsForViewer(state: MomentsGameState | null | undefined, viewer: MomentsUser): MomentsGameState {
  const current: MomentsGameState = JSON.parse(JSON.stringify(state || {}));
  const choices = current.telepathyChoices || {};
  const redacted: Record<string, { amin?: string; niyayesh?: string }> = {};
  const status: Record<string, { amin: boolean; niyayesh: boolean }> = {};

  for (const [questionId, choice] of Object.entries(choices)) {
    const amin = choice?.amin === 'A' || choice?.amin === 'B' ? choice.amin : undefined;
    const niyayesh = choice?.niyayesh === 'A' || choice?.niyayesh === 'B' ? choice.niyayesh : undefined;
    status[questionId] = { amin: !!amin, niyayesh: !!niyayesh };
    const bothAnswered = !!amin && !!niyayesh;
    redacted[questionId] = bothAnswered
      ? { amin, niyayesh }
      : viewer === 'amin'
        ? { ...(amin ? { amin } : {}) }
        : { ...(niyayesh ? { niyayesh } : {}) };
  }

  current.telepathyChoices = redacted;
  (current as MomentsGameState & { telepathyStatus?: typeof status }).telepathyStatus = status;
  return current;
}

export function mergeMomentsPatch(currentState: MomentsGameState | null | undefined, incomingPatch: any, user: MomentsUser): MomentsGameState {
  const current: MomentsGameState = JSON.parse(JSON.stringify(currentState || {}));
  if (!incomingPatch || typeof incomingPatch !== 'object' || Array.isArray(incomingPatch)) throw new Error('داده بازی نامعتبر است.');
  mergeTicTacToe(current, incomingPatch, user);
  mergeTruthDare(current, incomingPatch, user);
  mergeTelepathy(current, incomingPatch, user);
  return current;
}
