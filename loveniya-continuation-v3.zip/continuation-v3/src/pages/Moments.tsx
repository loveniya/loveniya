import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { 
  Heart, Trophy, 
  Dices, Zap, Shuffle, Gamepad2,
  Award, HelpCircle, Flame,
  RotateCcw, Loader2, Lock
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useSearchParams } from 'react-router';
import { PageWrapper } from '../components/PageWrapper';
import { generateTelepathyQuestion, AiTelepathyQuestion } from '../lib/gameAi';
import { answerTruthOrDare, canSpinTruthOrDare, createTruthOrDareRound, skipTruthOrDare, sanitizeTruthOrDareRound, TruthDareRound } from '../lib/truthOrDare';
import { getTicTacToeWinner } from '../lib/momentsEngine';
import { apiFetch, dataApi } from '../lib/api';

export type MomentsTab = 'bottle' | 'tictactoe' | 'telepathy';

// --- DATASETS FOR VIRTUAL LDR COUPLE ---

// یک سوال پیش‌فرض یکسان که فقط برای یک لحظه‌ی کوتاه، تا قبل از رسیدن اولین
// سوال از هوش مصنوعی، روی هر دو گوشی یکسان نمایش داده می‌شه (بدون سینک هم یکیه).
const FALLBACK_FIRST_QUESTION = {
  q: 'برای شب‌های خستگی کدوم رو ترجیح میدی؟',
  a: 'ویس‌کال شبانه تا وقتی خوابمون ببره 🌙',
  b: 'تماشای همزمان فیلم با واچ‌پارتی 🎬'
};

// State Structure
type MomentsData = {
  // Tic-Tac-Toe
  board: (string | null)[];
  turn: 'amin' | 'niyayesh';
  scores: { amin: number; niyayesh: number; draws: number };
  winner: string | null;
  // Telepathy
  telepathyChoices: { [qId: string]: { amin?: string; niyayesh?: string } };
  telepathyStatus?: { [qId: string]: { amin: boolean; niyayesh: boolean } };
  currentTelepathyQuestion?: AiTelepathyQuestion & { id: string };
  // Bottle
  lastBottleResult?: TruthDareRound | null;
};

const INITIAL_DATA: MomentsData = {
  board: Array(9).fill(null),
  turn: 'amin',
  scores: { amin: 0, niyayesh: 0, draws: 0 },
  winner: null,
  telepathyChoices: {},
  currentTelepathyQuestion: undefined,
  lastBottleResult: undefined
};

const MOMENTS_OUTBOX_KEY = 'loveniya_moments_outbox_v1';

type MomentsOutbox = { id: string; patch: Partial<MomentsData> };

function readMomentsOutbox(): MomentsOutbox | null {
  try {
    const raw = localStorage.getItem(MOMENTS_OUTBOX_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    return parsed?.id && parsed?.patch ? parsed : null;
  } catch {
    return null;
  }
}

function writeMomentsOutbox(patch: Partial<MomentsData>): MomentsOutbox {
  const current = readMomentsOutbox();
  const next = {
    id: `${Date.now()}_${Math.random().toString(36).slice(2, 10)}`,
    patch: { ...(current?.patch || {}), ...patch }
  };
  try { localStorage.setItem(MOMENTS_OUTBOX_KEY, JSON.stringify(next)); } catch {}
  return next;
}

function clearMomentsOutbox(id: string) {
  const current = readMomentsOutbox();
  if (current?.id === id) {
    try { localStorage.removeItem(MOMENTS_OUTBOX_KEY); } catch {}
  }
}


function sanitizeMomentsData(data: any, viewer: 'amin' | 'niyayesh'): MomentsData {
  if (!data || typeof data !== 'object') return INITIAL_DATA;
  return {
    board: Array.isArray(data.board) && data.board.length === 9 ? data.board : Array(9).fill(null),
    turn: data.turn === 'niyayesh' ? 'niyayesh' : 'amin',
    scores: {
      amin: Number(data.scores?.amin) || 0,
      niyayesh: Number(data.scores?.niyayesh) || 0,
      draws: Number(data.scores?.draws) || 0
    },
    winner: typeof data.winner === 'string' ? data.winner : null,
    telepathyChoices: (data.telepathyChoices && typeof data.telepathyChoices === 'object') ? data.telepathyChoices : {},
    telepathyStatus: (data.telepathyStatus && typeof data.telepathyStatus === 'object') ? data.telepathyStatus : {},
    currentTelepathyQuestion: (data.currentTelepathyQuestion && typeof data.currentTelepathyQuestion === 'object' && data.currentTelepathyQuestion.id)
      ? data.currentTelepathyQuestion : undefined,
    lastBottleResult: sanitizeTruthOrDareRound(data.lastBottleResult)
  };
}

export const Moments: React.FC = () => {
  const [searchParams] = useSearchParams();
  const requestedTab = searchParams.get('tab') as MomentsTab;
  const initialTab: MomentsTab = (requestedTab && ['bottle', 'tictactoe', 'telepathy'].includes(requestedTab))
    ? requestedTab
    : 'bottle';

  // Read identity
  const currentUser = (localStorage.getItem('loveniya_user') as 'amin' | 'niyayesh') || 'amin';
  const partnerName = currentUser === 'amin' ? 'نیایش' : 'امین';
  const partnerKey: 'amin' | 'niyayesh' = currentUser === 'amin' ? 'niyayesh' : 'amin';

  const [activeTab, setActiveTab] = useState<MomentsTab>(initialTab);
  const [gameData, setGameData] = useState<MomentsData>(INITIAL_DATA);
  const mutatedAtRef = useRef<number>(0);
  const syncQueueRef = useRef<Promise<void>>(Promise.resolve());

  // Telepathy — question itself now lives in synced gameData.currentTelepathyQuestion
  const [isGeneratingQuestion, setIsGeneratingQuestion] = useState(false);

  // Bottle Spinner & Truth/Dare
  const [isBottleSpinning, setIsBottleSpinning] = useState(false);
  const [bottleAngle, setBottleAngle] = useState(0);
  const [selectedDare, setSelectedDare] = useState<TruthDareRound | null>(null);

  // Toast
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 3000);
  };

  const sendMomentsPatch = useCallback(async (patch: Partial<MomentsData>) => {
    const res = await apiFetch(dataApi('loveniya_moments_v2'), {
      method: 'PATCH',
      body: JSON.stringify(patch)
    });
    if (res.status === 401) {
      const error = new Error('نشست ورود منقضی شده است؛ دوباره وارد شوید.');
      (error as Error & { status?: number }).status = 401;
      throw error;
    }
    if (!res.ok) {
      const error = new Error(`خطای همگام‌سازی بازی: ${res.status}`);
      (error as Error & { status?: number }).status = res.status;
      throw error;
    }
  }, []);

  const flushMomentsOutbox = useCallback(async () => {
    const pending = readMomentsOutbox();
    if (!pending) return;
    await sendMomentsPatch(pending.patch);
    clearMomentsOutbox(pending.id);
  }, [sendMomentsPatch]);

  // Sync with Cloudflare Worker — sends only the changed fields (PATCH/merge),
  // and keeps the latest unsent patch in an outbox so refresh/offline periods
  // cannot silently erase a local game move.
  const syncState = useCallback(async (patch: Partial<MomentsData>): Promise<boolean> => {
    mutatedAtRef.current = Date.now();
    setGameData(prev => {
      const merged = sanitizeMomentsData({ ...prev, ...patch }, currentUser);
      try { localStorage.setItem('loveniya_moments_v2', JSON.stringify(merged)); } catch(e) {}
      return merged;
    });

    writeMomentsOutbox(patch);
    syncQueueRef.current = syncQueueRef.current
      .catch(() => undefined)
      .then(async () => {
        const pending = readMomentsOutbox();
        if (!pending) return;
        await sendMomentsPatch(pending.patch);
        clearMomentsOutbox(pending.id);
      });

    try {
      await syncQueueRef.current;
      return true;
    } catch (error) {
      const status = (error as Error & { status?: number })?.status;
      if (status === 409) {
        const pending = readMomentsOutbox();
        if (pending) clearMomentsOutbox(pending.id);
        try {
          const res = await apiFetch(`${dataApi('loveniya_moments_v2')}?_t=${Date.now()}`);
          if (res.ok) {
            const clean = sanitizeMomentsData(await res.json(), currentUser);
            setGameData(clean);
            try { localStorage.setItem('loveniya_moments_v2', JSON.stringify(clean)); } catch {}
          }
        } catch {}
        showToast('🔄 بازی هم‌زمان تغییر کرده بود؛ وضعیت تازه بارگذاری شد.');
        return false;
      }
      showToast(status === 401 ? '🔐 نشست شما منقضی شده است.' : '📡 تغییر شما ذخیره نشد؛ بعد از اتصال دوباره تلاش می‌کنیم.');
      return false;
    }
  }, [currentUser, sendMomentsPatch]);

  const fetchData = useCallback(async () => {
    if (Date.now() - mutatedAtRef.current < 8000) return;
    if (readMomentsOutbox()) {
      try { await flushMomentsOutbox(); } catch { return; }
    }

    try {
      const res = await apiFetch(`${dataApi('loveniya_moments_v2')}?_t=${Date.now()}`);
      if (res.ok) {
        const data = await res.json();
        const clean = sanitizeMomentsData(data, currentUser);
        setGameData(clean);
        try { localStorage.setItem('loveniya_moments_v2', JSON.stringify(clean)); } catch(e) {}
      }
    } catch {
      const saved = localStorage.getItem('loveniya_moments_v2');
      if (saved) {
        try { setGameData(sanitizeMomentsData(JSON.parse(saved), currentUser)); } catch(e) {}
      }
    }
  }, [flushMomentsOutbox]);

  useEffect(() => {
    const saved = localStorage.getItem('loveniya_moments_v2');
    if (saved) {
      try { setGameData(sanitizeMomentsData(JSON.parse(saved), currentUser)); } catch(e) {}
    }
    fetchData();
    const interval = setInterval(() => {
      if (typeof document !== 'undefined' && document.visibilityState !== 'visible') return;
      fetchData();
    }, 6000);
    return () => clearInterval(interval);
  }, [fetchData]);

  // --- 1. TIC-TAC-TOE LOGIC ---
  const checkWinner = getTicTacToeWinner;

  const handleSquareClick = (index: number) => {
    const currentBoard = gameData.board || Array(9).fill(null);
    if (currentBoard[index] || gameData.winner) return;
    if (gameData.turn !== currentUser) return; // نوبت طرف مقابله؛ اجازه حرکت نده

    // Symbol: X for Amin, O for Niyayesh
    const symbol = currentUser === 'amin' ? 'X' : 'O';
    const newBoard = [...currentBoard];
    newBoard[index] = symbol;

    const winnerResult = checkWinner(newBoard);
    let newScores = { ...(gameData.scores || { amin: 0, niyayesh: 0, draws: 0 }) };

    if (winnerResult === 'X') {
      newScores.amin += 1;
    } else if (winnerResult === 'O') {
      newScores.niyayesh += 1;
    } else if (winnerResult === 'draw') {
      newScores.draws += 1;
    }

    const nextTurn = gameData.turn === 'amin' ? 'niyayesh' : 'amin';

    syncState({
      board: newBoard,
      turn: nextTurn,
      winner: winnerResult,
      scores: newScores
    });
  };

  const handleResetBoard = async () => {
    if (!gameData.winner) {
      showToast('⏳ اول این دست باید تمام شود.');
      return;
    }
    const ok = await syncState({
      board: Array(9).fill(null),
      winner: null,
      turn: 'amin'
    });
    if (ok) showToast('✨ دست جدید آماده است.');
  };

  // اعلام برد/تساوی — روی هر دو گوشی یکسان، چه کسی که حرکت آخر رو زده باشه
  // چه کسی که فقط داره نتیجه رو از طریق سینک می‌بینه. اولین رندر (بارگذاری
  // صفحه با یک نتیجه‌ی قدیمی از قبل) نادیده گرفته می‌شه تا نتیجه‌ی بازی
  // قبلی دوباره اعلام نشه.
  const winnerWatcherMounted = useRef(false);
  const lastSeenWinnerRef = useRef<string | null>(null);
  useEffect(() => {
    const w = gameData.winner;
    if (!winnerWatcherMounted.current) {
      winnerWatcherMounted.current = true;
      lastSeenWinnerRef.current = w;
      return;
    }
    if (w === lastSeenWinnerRef.current) return;
    lastSeenWinnerRef.current = w;
    if (w === 'X') showToast('🎉 امین برنده این دست شد!');
    else if (w === 'O') showToast('🎉 نیایش برنده این دست شد!');
    else if (w === 'draw') showToast('🤝 این دست مساوی شد!');
  }, [gameData.winner]);

  // --- 2. TELEPATHY (THIS OR THAT) LOGIC — fully AI-generated & synced ---
  const currentQ = gameData.currentTelepathyQuestion || { id: 'default', ...FALLBACK_FIRST_QUESTION };
  const allChoices = gameData.telepathyChoices || {};
  const qChoices = allChoices[currentQ.id] || {};
  const myChoice = qChoices[currentUser];
  const partnerChoice = qChoices[partnerKey];
  const qStatus = gameData.telepathyStatus?.[currentQ.id];
  const partnerAnswered = !!qStatus?.[partnerKey] || !!partnerChoice;
  const bothAnswered = !!myChoice && (!!partnerChoice || !!qStatus?.amin && !!qStatus?.niyayesh);
  const isMatch = bothAnswered && myChoice === partnerChoice;

  const handleSelectTelepathy = (choiceKey: 'A' | 'B') => {
    if (bothAnswered) return;
    const updatedChoices = {
      ...(gameData.telepathyChoices || {}),
      [currentQ.id]: {
        ...qChoices,
        [currentUser]: choiceKey
      }
    };
    syncState({ telepathyChoices: updatedChoices });
    showToast('✨ انتخاب شما با ۱ کلیک ثبت شد!');
  };

  // درخواست یک سوال تازه از هوش مصنوعی — چون امین و نیایش وقت نوشتن سوال ندارن،
  // این تنها راه گرفتن سوال بعدیه (گزینه دستی وجود نداره).
  const handleNextAiQuestion = async () => {
    if (isGeneratingQuestion) return;
    setIsGeneratingQuestion(true);
    try {
      const generated = await generateTelepathyQuestion();
      syncState({
        currentTelepathyQuestion: { id: `ai-${Date.now()}`, ...generated }
      });
    } finally {
      setIsGeneratingQuestion(false);
    }
  };

  // اولین بار که صفحه باز می‌شه و هنوز هیچ سوالی سینک نشده، یک سوال تازه بساز.
  useEffect(() => {
    if (!gameData.currentTelepathyQuestion && currentUser === 'amin' && !isGeneratingQuestion) {
      handleNextAiQuestion();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [gameData.currentTelepathyQuestion, currentUser]);

  // Telepathy Match Rate — روی همه سوالاتی که واقعاً پاسخ داده شدن حساب می‌شه
  // (نه فقط بانک ثابت قدیمی)، چون سوالات حالا به‌صورت نامحدود از AI میان.
  const matchRate = useMemo(() => {
    let total = 0;
    let matches = 0;
    const choices: { [qId: string]: { amin?: string; niyayesh?: string } } = gameData.telepathyChoices || {};
    Object.values(choices).forEach(c => {
      if (c && c.amin && c.niyayesh) {
        total++;
        if (c.amin === c.niyayesh) matches++;
      }
    });
    return total > 0 ? Math.round((matches / total) * 100) : 100;
  }, [gameData.telepathyChoices]);

  // وقتی طرف مقابل به سوال فعلی جواب می‌ده و من هنوز جواب ندادم، خبر بده —
  // این‌جوری منتظر نمی‌مونم تا خودم بیام چک کنم. اگه هر دومون جواب داده
  // باشیم، بنر تطابق همین الان توی کارت دیده می‌شه و نیازی به toast اضافه نیست.
  const telepathyWatcherMounted = useRef(false);
  const lastSeenPartnerChoiceRef = useRef<string | undefined>(undefined);
  useEffect(() => {
    const partnerSignal = partnerAnswered ? 'answered' : undefined;
    if (!telepathyWatcherMounted.current) {
      telepathyWatcherMounted.current = true;
      lastSeenPartnerChoiceRef.current = partnerSignal;
      return;
    }
    if (partnerSignal && partnerSignal !== lastSeenPartnerChoiceRef.current && !myChoice) {
      showToast(`💭 ${partnerName} به این سوال جواب داد، نوبت توئه!`);
    }
    lastSeenPartnerChoiceRef.current = partnerSignal;
  }, [partnerAnswered, myChoice, partnerName]);


  // --- 3. BOTTLE SPINNER & TRUTH/DARE ---
  const currentBottleRound = gameData.lastBottleResult ?? null;
  const canCurrentUserSpin = canSpinTruthOrDare(currentUser, currentBottleRound);

  const handleSpinBottle = async (forcedKind?: 'truth' | 'dare') => {
    if (isBottleSpinning || !canCurrentUserSpin) return;
    setIsBottleSpinning(true);
    setSelectedDare(null);

    const randomRotations = 1440 + Math.floor(Math.random() * 720);
    setBottleAngle(prev => prev + randomRotations);
    const kind: 'truth' | 'dare' = forcedKind || (Math.random() > 0.5 ? 'truth' : 'dare');
    const recent = currentBottleRound ? [currentBottleRound.text] : [];
    const result = createTruthOrDareRound(currentUser, kind, recent);

    await new Promise<void>(resolve => setTimeout(resolve, 1400));
    const ok = await syncState({ lastBottleResult: result });
    setIsBottleSpinning(false);
    if (ok) {
      lastSeenBottleTs.current = result.createdAt;
      setSelectedDare(result);
    } else {
      setSelectedDare(gameData.lastBottleResult ?? null);
    }
  };

  // Shows the bottle result on the *other* device too, with its own short
  // suspense animation, instead of it only ever appearing for whoever spun it.
  // همین watcher مسئول بازیابیه: اگه صفحه رو ببندی و بعداً برگردی (خیلی محتمله
  // چون رابطه مجاردوره)، آخرین چالش رو بلافاصله نشون می‌ده، بدون انیمیشن
  // ساختگیِ چرخش — چون این یه رویداد زنده نیست، بازیابی یه چیز قدیمیه.
  const lastSeenBottleTs = useRef<number>(0);
  useEffect(() => {
    const result = gameData.lastBottleResult;
    if (!result || result.createdAt === lastSeenBottleTs.current) return;
    const isRestoreOnLoad = lastSeenBottleTs.current === 0;
    lastSeenBottleTs.current = result.createdAt;

    if (isRestoreOnLoad) {
      setSelectedDare(result);
      return;
    }

    if (result.spinnerId === currentUser) return; // this device triggered it live, already animating

    setIsBottleSpinning(true);
    setSelectedDare(null);
    setBottleAngle(prev => prev + 1440 + Math.floor(Math.random() * 720));
    setTimeout(() => {
      setIsBottleSpinning(false);
      setSelectedDare(result);
    }, 1800);
  }, [gameData.lastBottleResult, currentUser]);

  // چالش/سوال همیشه برای طرف مقابل کسیه که بطری رو چرخونده — نه برای خود
  // چرخوننده. این‌جوری هر دو گوشی دقیقاً می‌دونن نوبت جواب دادن با کیه.
  const bottleAnswererKey: 'amin' | 'niyayesh' | undefined = gameData.lastBottleResult?.answererId;
  const isBottleAnswerer = bottleAnswererKey === currentUser;
  const bottleAnswered = gameData.lastBottleResult?.status === 'answered' || gameData.lastBottleResult?.status === 'skipped';

  const handleAcknowledgeDare = async () => {
    if (!gameData.lastBottleResult || !isBottleAnswerer || gameData.lastBottleResult.status !== 'waiting') return;
    const answered = answerTruthOrDare(gameData.lastBottleResult);
    const ok = await syncState({ lastBottleResult: answered });
    if (ok) {
      setSelectedDare(answered);
      showToast('✅ انجام شد؛ نوبت بعدی رسید.');
    }
  };

  const handleSkipDare = async () => {
    if (!gameData.lastBottleResult || !isBottleAnswerer || gameData.lastBottleResult.status !== 'waiting') return;
    const skipped = skipTruthOrDare(gameData.lastBottleResult);
    const ok = await syncState({ lastBottleResult: skipped });
    if (ok) {
      setSelectedDare(skipped);
      showToast('↪️ این دور رد شد؛ نوبت بعدی رسید.');
    }
  };

  // به چرخوننده‌ی بطری خبر بده که طرف مقابل به چالش جواب داد.
  const bottleAckWatcherMounted = useRef(false);
  const lastSeenAnsweredAtRef = useRef<number | undefined>(undefined);
  useEffect(() => {
    const answeredAt = gameData.lastBottleResult?.answeredAt;
    if (!bottleAckWatcherMounted.current) {
      bottleAckWatcherMounted.current = true;
      lastSeenAnsweredAtRef.current = answeredAt;
      return;
    }
    if (answeredAt === lastSeenAnsweredAtRef.current) return;
    lastSeenAnsweredAtRef.current = answeredAt;
    if (answeredAt && gameData.lastBottleResult?.spinnerId === currentUser) {
      showToast(`🎉 ${partnerName} به چالش جواب داد!`);
    }
  }, [gameData.lastBottleResult?.answeredAt, gameData.lastBottleResult?.spinnerId, currentUser, partnerName]);

  return (
    <PageWrapper>
      <div className="space-y-4 max-w-2xl mx-auto px-2 sm:px-4 py-2" dir="rtl">
        
        {/* Floating Toast Notification */}
        <AnimatePresence>
          {toastMsg && (
            <motion.div 
              initial={{ opacity: 0, y: -10 }} 
              animate={{ opacity: 1, y: 0 }} 
              exit={{ opacity: 0, y: -10 }}
              className="fixed top-4 left-1/2 -translate-x-1/2 z-50 bg-stone-900/90 text-white text-sm font-black px-5 py-3 rounded-2xl shadow-lg border border-stone-700 flex items-center gap-2"
            >
              
              <span>{toastMsg}</span>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Header Title in a solid card */}
        <section className="text-center space-y-1.5 pt-1 pb-1">
          <div className="bg-white/95 rounded-3xl p-5 sm:p-6 shadow-[0_16px_50px_-12px_rgba(28,25,23,0.06)] mb-2 relative overflow-hidden">
            <div className="inline-flex items-center justify-center gap-2 text-emerald-700 text-xs font-black tracking-wide flex-wrap mb-2">
              <Gamepad2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>بازی‌ها و سرگرمی‌های آنلاین امین و نیایش</span>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-stone-500 font-bold flex items-center gap-1">شما: {currentUser === 'amin' ? <><span className="text-sky-600">امین</span><Award className="w-3.5 h-3.5 text-sky-500" /></> : <><span className="text-fuchsia-600">نیایش</span><Award className="w-3.5 h-3.5 text-fuchsia-500" /></>}</span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-black text-stone-900 tracking-tight">
              کل‌کل و تفریحات دونفره
            </h1>
            <p className="text-xs text-stone-500 font-bold max-w-md mx-auto mt-2">
              بازی‌های آماده، سریع و بدون نیاز به طراحی سوال — مخصوص روزهای شلوغ و رابطه مجازی
            </p>
          </div>
        </section>

        <div className="grid grid-cols-3 gap-2" aria-label="وضعیت بازی">
          <div className="rounded-2xl border border-stone-200 bg-white px-3 py-2.5 text-center shadow-[0_8px_24px_-18px_rgba(28,25,23,0.35)]">
            <span className="block text-[10px] font-black text-stone-400">نوبت فعلی</span>
            <span className="mt-0.5 block text-xs font-black text-stone-800">{gameData.turn === currentUser ? 'شما' : partnerName}</span>
          </div>
          <div className="rounded-2xl border border-stone-200 bg-white px-3 py-2.5 text-center shadow-[0_8px_24px_-18px_rgba(28,25,23,0.35)]">
            <span className="block text-[10px] font-black text-stone-400">بردها</span>
            <span className="mt-0.5 block text-xs font-black text-stone-800">{gameData.scores?.amin || 0} — {gameData.scores?.niyayesh || 0}</span>
          </div>
          <div className="rounded-2xl border border-stone-200 bg-white px-3 py-2.5 text-center shadow-[0_8px_24px_-18px_rgba(28,25,23,0.35)]">
            <span className="block text-[10px] font-black text-stone-400">حالت بازی</span>
            <span className="mt-0.5 block text-xs font-black text-emerald-700">دونفره</span>
          </div>
        </div>

        {/* 3-Tab Navigation Bar — بازی‌ها با حالت فعال واضح و قابل لمس */}
        <div className="grid grid-cols-3 gap-1.5 rounded-3xl bg-stone-100/80 p-1.5 border border-stone-200">
          <button type="button"
            onClick={() => setActiveTab('bottle')}
            aria-pressed={activeTab === 'bottle'}
            className={`min-h-[58px] py-2 px-1 rounded-2xl text-xs sm:text-sm font-black transition-[color,background-color,border-color,box-shadow,transform] flex flex-col items-center justify-center gap-1 cursor-pointer border ${
              activeTab === 'bottle'
                ? 'bg-amber-50 text-amber-700 border-amber-200 shadow-sm'
                : 'bg-white border-stone-200 text-stone-600 hover:text-stone-900 hover:border-stone-300'
            }`}
          >
            <Dices className={`w-3.5 h-3.5 ${activeTab === 'bottle' ? 'text-amber-500' : 'text-stone-400'}`} />
            <span>جرأت یا حقیقت</span>
          </button>

          <button type="button"
            onClick={() => setActiveTab('tictactoe')}
            aria-pressed={activeTab === 'tictactoe'}
            className={`min-h-[58px] py-2 px-1 rounded-2xl text-xs sm:text-sm font-black transition-[color,background-color,border-color,box-shadow,transform] flex flex-col items-center justify-center gap-1 cursor-pointer border ${
              activeTab === 'tictactoe'
                ? 'bg-emerald-50 text-emerald-700 border-emerald-200 shadow-sm'
                : 'bg-white border-stone-200 text-stone-600 hover:text-stone-900 hover:border-stone-300'
            }`}
          >
            <Gamepad2 className={`w-3.5 h-3.5 ${activeTab === 'tictactoe' ? 'text-emerald-600' : 'text-stone-400'}`} />
            <span>دوز عاشقی</span>
          </button>

          <button type="button"
            onClick={() => setActiveTab('telepathy')}
            aria-pressed={activeTab === 'telepathy'}
            className={`min-h-[58px] py-2 px-1 rounded-2xl text-xs sm:text-sm font-black transition-[color,background-color,border-color,box-shadow,transform] flex flex-col items-center justify-center gap-1 cursor-pointer border ${
              activeTab === 'telepathy'
                ? 'bg-indigo-50 text-indigo-700 border-indigo-200 shadow-sm'
                : 'bg-white border-stone-200 text-stone-600 hover:text-stone-900 hover:border-stone-300'
            }`}
          >
            <Zap className={`w-3.5 h-3.5 ${activeTab === 'telepathy' ? 'text-indigo-500' : 'text-stone-400'}`} />
            <span>تله‌پاتی آماده</span>
          </button>
        </div>

        {/* TAB 1: TIC-TAC-TOE GAME */}
        {activeTab === 'tictactoe' && (
          <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
            
            {/* Scoreboard */}
            <div className="bg-white rounded-3xl p-4 border border-rose-200 shadow-2xs flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-amber-50 border border-amber-200 flex items-center justify-center text-sm font-black text-amber-800">
                  X
                </div>
                <div>
                  <span className="text-xs font-black text-stone-900 block">امین</span>
                  <span className="text-[11px] font-bold text-stone-500">{gameData.scores?.amin || 0} برد</span>
                </div>
              </div>

              <div className="text-center">
                <span className="text-[10px] font-bold text-stone-400 block">مساوی</span>
                <span className="text-xs font-black text-stone-700">{gameData.scores?.draws || 0}</span>
              </div>

              <div className="flex items-center gap-2 text-left">
                <div>
                  <span className="text-xs font-black text-stone-900 block">نیایش</span>
                  <span className="text-[11px] font-bold text-stone-500">{gameData.scores?.niyayesh || 0} برد</span>
                </div>
                <div className="w-8 h-8 rounded-xl bg-rose-50 border border-rose-200 flex items-center justify-center text-sm font-black text-rose-800">
                  O
                </div>
              </div>
            </div>

            {/* 3x3 Grid Board */}
            <div className="bg-white rounded-3xl p-6 border border-stone-200 shadow-xs max-w-sm mx-auto text-center space-y-4">
              
              {/* Turn Banner */}
              <div className="flex justify-center">
                {gameData.winner ? (
                  <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-2xl text-xs font-black shadow-sm ${
                    gameData.winner === 'draw' 
                      ? 'bg-amber-100 text-amber-800 border border-amber-200'
                      : 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                  }`}>
                    {gameData.winner === 'draw' ? (
                      <>
                        <Heart className="w-4 h-4 text-amber-600" />
                        <span>بازی مساوی شد!</span>
                      </>
                    ) : (
                      <>
                        <Trophy className="w-4 h-4 text-emerald-600" />
                        <span>برنده این دست: {gameData.winner === 'X' ? 'امین' : 'نیایش'}</span>
                      </>
                    )}
                  </div>
                ) : (
                  <div className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-xs font-black ${
                    gameData.turn === currentUser
                      ? 'bg-rose-50 text-rose-700 border-rose-200'
                      : 'bg-stone-100 text-stone-500 border-stone-200'
                  }`}>
                    {gameData.turn !== currentUser && <Lock className="w-3 h-3" />}
                    <span>
                      {gameData.turn === currentUser
                        ? `نوبت توئه (${currentUser === 'amin' ? 'X' : 'O'})`
                        : `منتظر حرکت ${partnerName}...`}
                    </span>
                  </div>
                )}
              </div>

              {/* Grid */}
              <div className="grid grid-cols-3 gap-2.5 max-w-[260px] mx-auto aspect-square">
                {(gameData.board || Array(9).fill(null)).map((cell, idx) => (
                  <button type="button"
                    key={idx}
                    onClick={() => handleSquareClick(idx)}
                    disabled={!!cell || !!gameData.winner || gameData.turn !== currentUser}
                    className={`rounded-2xl border flex items-center justify-center text-3xl font-black transition-[color,background-color,border-color,box-shadow,transform] select-none ${
                      cell 
                        ? 'bg-rose-50/60 border-rose-200 shadow-2xs cursor-not-allowed' 
                        : gameData.turn !== currentUser
                          ? 'bg-stone-50 border-stone-200/90 cursor-not-allowed opacity-60'
                          : 'bg-stone-50 hover:bg-rose-50/40 border-stone-200/90 hover:border-rose-300 cursor-pointer'
                    }`}
                  >
                    {cell}
                  </button>
                ))}
              </div>

              {/* Reset Game Action */}
              <div className="pt-2">
                <button type="button"
                  onClick={handleResetBoard}
                  disabled={!gameData.winner}
                  className="inline-flex items-center gap-1.5 min-h-[44px] px-4 py-2 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-xs font-black transition-[color,background-color,border-color,box-shadow,transform] cursor-pointer disabled:cursor-not-allowed disabled:opacity-45"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>دست جدید / بازی مجدد</span>
                </button>
              </div>

            </div>

          </motion.div>
        )}

        {/* TAB 2: READY TELEPATHY QUESTIONS */}
        {activeTab === 'telepathy' && (
          <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
            
            {/* Header Banner */}
            <div className="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-3xl p-5 text-white shadow-sm flex items-center justify-between">
              <div>
                <span className="text-[10px] font-bold bg-white/20 px-2.5 py-0.5 rounded-full inline-block mb-1">
                  تله‌پاتی و هماهنگی فکری
                </span>
                <h3 className="text-xl font-black flex items-center gap-1.5">
                  <Zap className="w-5 h-5 text-amber-300" />
                  <span>تطابق ذهنی: {matchRate}٪</span>
                </h3>
              </div>

              <button type="button"
                onClick={handleNextAiQuestion}
                disabled={isGeneratingQuestion}
                className={`bg-white/20 hover:bg-white/30 disabled:opacity-60 text-white text-xs font-black px-3 py-2 rounded-xl transition-[color,background-color,border-color,box-shadow,transform] flex items-center gap-1.5 cursor-pointer shrink-0 ${
                  bothAnswered ? 'ring-2 ring-amber-300 animate-pulse' : ''
                }`}
              >
                {isGeneratingQuestion ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Shuffle className="w-3.5 h-3.5" />}
                <span>{isGeneratingQuestion ? 'در حال ساخت سوال...' : 'سوال بعدی'}</span>
              </button>
            </div>

            {/* Question Card */}
            <div className="bg-white rounded-3xl p-5 sm:p-7 border border-indigo-200 shadow-xs text-center space-y-4">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-200 text-xs font-black text-indigo-800">
                
                <span>سوال تازه، ساخته‌شده توسط هوش مصنوعی</span>
              </span>

              <h3 className="text-sm sm:text-base font-black text-stone-900">
                {currentQ.q}
              </h3>

              {/* 2 Big Choice Buttons */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                <button type="button"
                  onClick={() => handleSelectTelepathy('A')}
                  className={`p-4 rounded-2xl border text-right transition-[color,background-color,border-color,box-shadow,transform] cursor-pointer flex flex-col justify-between gap-3 ${
                    myChoice === 'A'
                      ? 'bg-indigo-600 text-white border-indigo-700 shadow-xs'
                      : 'bg-stone-50 hover:bg-indigo-50/50 border-stone-200 text-stone-800'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-lg">گزینه اول</span>
                    {myChoice === 'A' && <span className="text-[10px] bg-white/20 px-2 py-0.5 rounded-md font-bold">انتخاب شما ✓</span>}
                  </div>
                  <p className="text-xs sm:text-sm font-bold leading-relaxed">{currentQ.a}</p>
                </button>

                <button type="button"
                  onClick={() => handleSelectTelepathy('B')}
                  className={`p-4 rounded-2xl border text-right transition-[color,background-color,border-color,box-shadow,transform] cursor-pointer flex flex-col justify-between gap-3 ${
                    myChoice === 'B'
                      ? 'bg-indigo-600 text-white border-indigo-700 shadow-xs'
                      : 'bg-stone-50 hover:bg-indigo-50/50 border-stone-200 text-stone-800'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-lg">گزینه دوم</span>
                    {myChoice === 'B' && <span className="text-[10px] bg-white/20 px-2 py-0.5 rounded-md font-bold">انتخاب شما ✓</span>}
                  </div>
                  <p className="text-xs sm:text-sm font-bold leading-relaxed">{currentQ.b}</p>
                </button>
              </div>

              {/* Partner Status */}
              <div className="bg-stone-50 rounded-2xl p-3 border border-stone-200 text-xs font-bold text-stone-700 flex items-center justify-between">
                <span>وضعیت {partnerName}: {partnerAnswered ? 'پاسخ داده ✓' : 'منتظر انتخاب...'}</span>
                {bothAnswered && (
                  <span className={`px-2.5 py-0.5 rounded-lg text-[11px] font-black ${isMatch ? 'bg-emerald-100 text-emerald-800' : 'bg-stone-200 text-stone-700'}`}>
                    {isMatch ? '🎉 تطابق ۱۰۰٪ تله‌پاتی!' : '❤️ سلایق مکمل'}
                  </span>
                )}
              </div>
            </div>

          </motion.div>
        )}

        {/* TAB 3: TRUTH OR DARE — بازی اصلی امین و نیایش */}
        {activeTab === 'bottle' && (
          <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
            
            <div className="bg-white rounded-3xl p-6 sm:p-8 text-center border border-amber-200 shadow-xs space-y-5">
              <div>
                <h3 className="text-base font-black text-stone-900">
                  جرأت یا حقیقت
                </h3>
                <p className="text-xs text-stone-500 font-medium mt-0.5">
                  هر دور یک نفر انتخاب می‌کند و نفر مقابل جواب می‌دهد؛ بعد نوبت‌ها جابه‌جا می‌شوند.
                </p>
              </div>

              {/* Rotating Bottle Animation */}
              <div className="relative w-36 h-36 mx-auto flex items-center justify-center" aria-live="polite">
                <div className="absolute inset-0 rounded-full border-2 border-dashed border-amber-200/80 animate-spin-slow pointer-events-none" />
                <button
                  type="button"
                  aria-label={canCurrentUserSpin ? 'چرخاندن بطری' : `منتظر نوبت ${partnerName}`}
                  aria-disabled={!canCurrentUserSpin || isBottleSpinning}
                  disabled={!canCurrentUserSpin || isBottleSpinning}
                  className="relative z-10 w-24 h-24 rounded-full flex items-center justify-center text-5xl select-none transition-transform duration-[1400ms] ease-out disabled:cursor-not-allowed disabled:opacity-60 hover:bg-amber-50/60 focus-visible:outline-2 focus-visible:outline-amber-600"
                  style={{ transform: `rotate(${bottleAngle}deg)` }}
                  onClick={() => handleSpinBottle()}
                >
                  <span aria-hidden="true">🍾</span>
                </button>
              </div>

              <div className={`mx-auto max-w-sm rounded-2xl px-4 py-3 border text-xs font-black ${
                canCurrentUserSpin ? 'bg-emerald-50 border-emerald-200 text-emerald-900' : 'bg-stone-50 border-stone-200 text-stone-700'
              }`} role="status">
                {canCurrentUserSpin ? '🎯 نوبت شماست؛ یک نوع بازی را انتخاب کنید.' : `⏳ نوبت ${partnerName} است؛ بعد از ثبت جواب، نوبت شما می‌رسد.`}
              </div>

              <button type="button"
                onClick={() => handleSpinBottle()}
                disabled={isBottleSpinning || !canCurrentUserSpin}
                className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white text-sm font-black px-6 py-3 rounded-xl transition-[color,background-color,border-color,box-shadow,transform] shadow-xs cursor-pointer active:scale-95 disabled:opacity-50 flex items-center justify-center gap-2 mx-auto"
              >
                <Dices className="w-4 h-4" />
                <span>{isBottleSpinning ? 'در حال آماده‌سازی دور...' : canCurrentUserSpin ? 'چرخاندن بطری (شانسی)' : `منتظر نوبت ${partnerName}...`}</span>
              </button>

              {/* Direct choice — برای وقتی که می‌خوای خودت انتخاب کنی، نه شانسی */}
              <div className="grid grid-cols-2 gap-2.5 max-w-xs mx-auto">
                <button type="button"
                  onClick={() => handleSpinBottle('truth')}
                  disabled={isBottleSpinning || !canCurrentUserSpin}
                  className="bg-sky-50 hover:bg-sky-100 text-sky-800 border border-sky-200 text-xs font-black py-2.5 rounded-xl transition-[color,background-color,border-color,box-shadow,transform] cursor-pointer active:scale-95 disabled:opacity-50 flex items-center justify-center gap-1.5"
                >
                  <HelpCircle className="w-3.5 h-3.5" />
                  <span>حقیقت</span>
                </button>
                <button type="button"
                  onClick={() => handleSpinBottle('dare')}
                  disabled={isBottleSpinning || !canCurrentUserSpin}
                  className="bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-200 text-xs font-black py-2.5 rounded-xl transition-[color,background-color,border-color,box-shadow,transform] cursor-pointer active:scale-95 disabled:opacity-50 flex items-center justify-center gap-1.5"
                >
                  <Flame className="w-3.5 h-3.5" />
                  <span>جرأت</span>
                </button>
              </div>

              {/* Dare / Truth Result */}
              {selectedDare && (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className={`p-4 rounded-2xl border text-center space-y-2.5 ${
                    selectedDare.type === 'truth'
                      ? 'bg-sky-50 border-sky-200 text-sky-950'
                      : 'bg-rose-50 border-rose-200 text-rose-950'
                  }`}
                >
                  <span className="text-xs font-black px-3 py-1 rounded-full bg-white shadow-2xs inline-flex items-center gap-1.5">
                    {selectedDare.type === 'truth' ? <><HelpCircle className="w-3.5 h-3.5 text-sky-500" /><span>سوال حقیقت</span></> : <><Flame className="w-3.5 h-3.5 text-rose-500" /><span>چالش شجاعت</span></>}
                  </span>
                  <p className="text-xs sm:text-sm font-bold leading-relaxed">
                    {selectedDare.text}
                  </p>

                  {/* مشخص می‌کنه دقیقاً نوبت جواب دادن با کیه */}
                  <div className="pt-1 space-y-2">
                    <div className="text-[11px] font-black text-stone-600">
                      {gameData.lastBottleResult?.status === 'waiting'
                        ? (isBottleAnswerer ? '🎯 نوبت شماست' : `⏳ منتظر جواب ${partnerName}...`)
                        : gameData.lastBottleResult?.status === 'skipped'
                          ? '↪️ این دور رد شد'
                          : '✅ این دور تمام شد'}
                    </div>
                    {isBottleAnswerer && gameData.lastBottleResult?.status === 'waiting' && (
                      <div className="flex flex-col sm:flex-row justify-center gap-2">
                        <button type="button" onClick={handleAcknowledgeDare} className="min-h-[44px] px-5 py-2.5 rounded-xl bg-stone-900 hover:bg-stone-800 text-white text-xs font-black transition-[color,background-color,border-color,box-shadow,transform] cursor-pointer active:scale-95">
                          انجام دادم ✅
                        </button>
                        <button type="button" onClick={handleSkipDare} className="min-h-[44px] px-4 py-2.5 rounded-xl bg-white hover:bg-stone-50 text-stone-700 border border-stone-300 text-xs font-black transition-[color,background-color,border-color,box-shadow,transform] cursor-pointer active:scale-95">
                          رد کردن ↪️
                        </button>
                      </div>
                    )}
                  </div>
                </motion.div>
              )}
            </div>

          </motion.div>
        )}

      </div>
    </PageWrapper>
  );
};
