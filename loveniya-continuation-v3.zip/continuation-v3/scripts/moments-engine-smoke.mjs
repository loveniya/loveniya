import { mergeMomentsPatch, getTicTacToeWinner } from '../dist-test/momentsEngine.js';

const empty = { board: Array(9).fill(null), turn: 'amin', scores: { amin: 0, niyayesh: 0, draws: 0 }, winner: null };
const a1 = ['X', null, null, null, null, null, null, null, null];
const afterA = mergeMomentsPatch(empty, { board: a1 }, 'amin');
if (afterA.turn !== 'niyayesh' || afterA.board[0] !== 'X') throw new Error('tic move failed');
let rejected = false;
try { mergeMomentsPatch(afterA, { board: ['X', 'X', null, null, null, null, null, null, null] }, 'amin'); } catch { rejected = true; }
if (!rejected) throw new Error('turn validation failed');
const afterB = mergeMomentsPatch(afterA, { board: ['X', 'O', null, null, null, null, null, null, null] }, 'niyayesh');
if (afterB.turn !== 'amin' || getTicTacToeWinner(afterB.board) !== null) throw new Error('second move failed');
const td = { id: 'td-1', type: 'truth', text: 'یک سوال', spinnerId: 'amin', answererId: 'niyayesh', status: 'waiting', createdAt: 10 };
const withTd = mergeMomentsPatch(afterB, { lastBottleResult: td }, 'amin');
if (withTd.lastBottleResult?.status !== 'waiting') throw new Error('truth/dare start failed');
const ended = mergeMomentsPatch(withTd, { lastBottleResult: { ...td, status: 'answered', answeredAt: 20 } }, 'niyayesh');
if (ended.lastBottleResult?.status !== 'answered') throw new Error('truth/dare answer failed');
console.log('MOMENTS_ENGINE_SMOKE_PASS');
