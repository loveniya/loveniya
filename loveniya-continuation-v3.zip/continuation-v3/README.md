# Loveniya

## اجرا

پیش‌نیاز: Node.js `22.22+`

1. `npm install`
2. فایل `.env` را بر اساس `.env.example` تنظیم کنید.
3. `npm run dev`

## تولید

`npm run build` سپس `npm start`

این نسخه از gateway سمت سرور برای احراز هویت، داده و AI استفاده می‌کند؛ رازهای Worker هرگز داخل bundle مرورگر قرار نمی‌گیرند.

## متغیرهای محیطی

`APP_SECRET`، `SESSION_SECRET` و اعتبار ورود فقط سمت سرور هستند. در production باید `SESSION_SECRET` و یکی از `APP_UNLOCK_PASSWORD_SHA256` یا `APP_UNLOCK_PASSWORD` تنظیم شود؛ ترجیح با hash است.

## کنترل کیفیت

- `npm run qa` — اسکن ایستا برای secret leak، dynamic code execution، buttonهای بدون type و چند خطای رایج.
- `npm run typecheck:global` — type-check با TypeScript.
- `npm run build` — build کامل Vite + server bundle.

همگام‌سازی داده دارای outbox پایدار است؛ تغییرات ناموفق در localStorage نگه‌داری و پس از برگشت اتصال دوباره ارسال می‌شوند. گزارش تغییرات در `DEBUG_REPORT.md` قرار دارد.

CI در `.github/workflows/ci.yml` همین سه مرحله را روی Node 24 و هر push/PR اجرا می‌کند.
