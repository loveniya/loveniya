// Loveniya production/development gateway.
// The browser never receives the database secret or unlock password.
import express from "express";
import path from "path";
import crypto from "crypto";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";
import { mergeMomentsPatch, sanitizeMomentsForViewer } from "./src/lib/momentsEngine";

dotenv.config();

const DATA_WORKER_URL = process.env.DATA_WORKER_URL || "https://niya.am-b-asdfghjkl20112011.workers.dev";
const CLOUDFLARE_AI_WORKER_URL = process.env.AI_WORKER_URL || "https://purple-cloud-1df2.am-b-asdfghjkl20112011.workers.dev";
const APP_SECRET = process.env.APP_SECRET || "";
const configuredPassword = process.env.APP_UNLOCK_PASSWORD || null;
const configuredPasswordHash = process.env.APP_UNLOCK_PASSWORD_SHA256 || "";
const isProduction = process.env.NODE_ENV === "production";
const SESSION_SECRET = process.env.SESSION_SECRET || (isProduction ? "" : crypto.randomBytes(32).toString("hex"));
const loginFailures = new Map<string, { count: number; resetAt: number }>();
const SESSION_TTL_MS = 7 * 24 * 60 * 60 * 1000;
const ALLOWED_DATA_PATH = /^loveniya_[A-Za-z0-9_-]+(?:\/[A-Za-z0-9._~-]+)?$/;
let ldrWriteQueue: Promise<void> = Promise.resolve();
let momentsWriteQueue: Promise<void> = Promise.resolve();
const secretUnlockFailures = new Map<string, { count: number; resetAt: number }>();

function parseCookie(header: string | undefined, name: string): string | null {
  if (!header) return null;
  const pair = header.split(";").map(part => part.trim()).find(part => part.startsWith(`${name}=`));
  if (!pair) return null;
  try {
    return decodeURIComponent(pair.slice(name.length + 1));
  } catch {
    return null;
  }
}

function safeEqualHex(a: string, b: string): boolean {
  if (!/^[a-f0-9]+$/i.test(a) || !/^[a-f0-9]+$/i.test(b)) return false;
  const left = Buffer.from(a, "hex");
  const right = Buffer.from(b, "hex");
  return left.length === right.length && left.length > 0 && crypto.timingSafeEqual(left, right);
}

function encodeSessionPayload(payload: { user: "amin" | "niyayesh"; exp: number; iat: number; nonce: string }): string {
  return Buffer.from(JSON.stringify(payload), "utf8").toString("base64url");
}

function signSessionPayload(payload: string): string {
  return crypto.createHmac("sha256", SESSION_SECRET).update(payload).digest("hex");
}

function createSession(user: "amin" | "niyayesh") {
  const now = Date.now();
  const payload = encodeSessionPayload({
    user,
    iat: now,
    exp: now + SESSION_TTL_MS,
    nonce: crypto.randomBytes(16).toString("hex"),
  });
  return `${payload}.${signSessionPayload(payload)}`;
}

function getSession(req: express.Request) {
  const raw = parseCookie(req.headers.cookie, "loveniya_session");
  if (!raw || !SESSION_SECRET) return null;
  const [payload, signature] = raw.split(".");
  if (!payload || !signature || !safeEqualHex(signature, signSessionPayload(payload))) return null;
  try {
    const parsed = JSON.parse(Buffer.from(payload, "base64url").toString("utf8"));
    if ((parsed?.user !== "amin" && parsed?.user !== "niyayesh") || typeof parsed.exp !== "number" || parsed.exp <= Date.now()) {
      return null;
    }
    return { user: parsed.user as "amin" | "niyayesh", expiresAt: parsed.exp };
  } catch {
    return null;
  }
}

function requireAuth(req: express.Request, res: express.Response): { user: "amin" | "niyayesh" } | null {
  const session = getSession(req);
  if (!session) {
    res.status(401).json({ error: "نیاز به ورود دوباره دارید." });
    return null;
  }
  return { user: session.user };
}

function setSessionCookie(res: express.Response, value: string) {
  const parts = [
    `loveniya_session=${encodeURIComponent(value)}`,
    "Path=/",
    `Max-Age=${Math.floor(SESSION_TTL_MS / 1000)}`,
    "HttpOnly",
    "SameSite=Lax",
  ];
  if (isProduction) parts.push("Secure");
  res.setHeader("Set-Cookie", parts.join("; "));
}

function clearSessionCookie(res: express.Response) {
  res.setHeader("Set-Cookie", "loveniya_session=; Path=/; Max-Age=0; HttpOnly; SameSite=Lax" + (isProduction ? "; Secure" : ""));
}


function normalizeSecretGuess(value: unknown): string {
  return String(value ?? '')
    .normalize('NFKC')
    .trim()
    .toLocaleLowerCase('fa-IR')
    .replace(/ي/g, 'ی')
    .replace(/ك/g, 'ک')
    .replace(/\s+/g, ' ');
}

function safeEqualUtf8(a: string, b: string): boolean {
  const left = Buffer.from(a, 'utf8');
  const right = Buffer.from(b, 'utf8');
  return left.length === right.length && left.length > 0 && crypto.timingSafeEqual(left, right);
}

async function readWorkerJson(pathname: string): Promise<any> {
  const response = await fetch(`${DATA_WORKER_URL}/${pathname}.json`, {
    headers: { 'X-App-Secret': APP_SECRET, Accept: 'application/json' },
  });
  const text = await response.text();
  if (!response.ok) throw new Error(text || `Worker returned ${response.status}`);
  try { return text ? JSON.parse(text) : null; } catch { throw new Error('پاسخ نامعتبر از پایگاه داده دریافت شد.'); }
}

async function writeWorkerJson(pathname: string, body: unknown, method: 'PUT' | 'PATCH' = 'PUT'): Promise<void> {
  const response = await fetch(`${DATA_WORKER_URL}/${pathname}.json`, {
    method,
    headers: { 'X-App-Secret': APP_SECRET, 'Content-Type': 'application/json', Accept: 'application/json' },
    body: JSON.stringify(body),
  });
  if (!response.ok) {
    const text = await response.text().catch(() => '');
    throw new Error(text || `Worker returned ${response.status}`);
  }
}

function sanitizeLdrForViewer(state: any, viewer: 'amin' | 'niyayesh') {
  if (!state || typeof state !== 'object') return state;
  const secretEnvelopes = Array.isArray(state.secretEnvelopes) ? state.secretEnvelopes.map((secret: any) => {
    if (!secret || secret.creator === viewer || secret.status === 'unlocked') return secret;
    const safe = { ...secret };
    delete safe.secretText;
    delete safe.guesserChoice;
    delete safe.unlockedAt;
    return safe;
  }) : [];
  return { ...state, secretEnvelopes };
}

function mergeLdrWrite(currentState: any, incomingState: any, user: 'amin' | 'niyayesh') {
  const next = { ...(incomingState || {}) };
  const currentSecrets = Array.isArray(currentState?.secretEnvelopes) ? currentState.secretEnvelopes : [];
  const incomingSecrets = Array.isArray(incomingState?.secretEnvelopes) ? incomingState.secretEnvelopes : [];
  const byId = new Map(currentSecrets.filter((s: any) => s?.id).map((s: any) => [s.id, s]));

  const mergedSecrets = incomingSecrets
    .filter((secret: any) => secret && secret.id)
    .map((secret: any) => {
      const current = byId.get(secret.id);
      if (!current) {
        if (secret.creator !== user || typeof secret.secretText !== 'string') return null;
        return {
          id: String(secret.id),
          question: String(secret.question || ''),
          secretText: secret.secretText,
          creator: user,
          status: 'locked',
          createdAt: Number(secret.createdAt) || Date.now(),
        };
      }
      return {
        ...secret,
        creator: current.creator,
        createdAt: current.createdAt,
        secretText: current.secretText,
        status: current.status,
        ...(current.unlockedAt ? { unlockedAt: current.unlockedAt } : {}),
        ...(current.guesserChoice ? { guesserChoice: current.guesserChoice } : {}),
      };
    })
    .filter(Boolean);

  // Never let a viewer accidentally delete server-side secrets by PUTting a redacted snapshot.
  for (const current of currentSecrets) {
    if (current?.id && !mergedSecrets.some((secret: any) => secret?.id === current.id)) mergedSecrets.push(current);
  }

  next.secretEnvelopes = mergedSecrets;
  return next;
}

function timingSafePasswordEquals(input: unknown): boolean {
  const candidate = String(input ?? "");
  if (configuredPassword) {
    const a = Buffer.from(candidate, "utf8");
    const b = Buffer.from(configuredPassword, "utf8");
    return a.length === b.length && a.length > 0 && crypto.timingSafeEqual(a, b);
  }
  if (!configuredPasswordHash) return false;
  const candidateHash = crypto.createHash("sha256").update(candidate, "utf8").digest("hex");
  return safeEqualHex(candidateHash, configuredPasswordHash);
}

async function fetchWithRetry(url: string, options: RequestInit, retries = 3, backoff = 700): Promise<Response> {
  let lastRes: Response | null = null;
  let lastError: unknown = null;
  for (let i = 0; i < retries; i++) {
    try {
      const res = await fetch(url, options);
      if (res.ok) return res;
      lastRes = res;
      if (res.status < 500 && res.status !== 429) return res;
    } catch (err) {
      lastError = err;
    }
    if (i < retries - 1) await new Promise(resolve => setTimeout(resolve, backoff * Math.pow(2, i)));
  }
  if (lastRes) return lastRes;
  throw lastError instanceof Error ? lastError : new Error(`Failed to fetch after ${retries} retries`);
}

function extractAIResponse(data: any): string | null {
  if (!data) return null;
  if (typeof data === "string") return data.trim() || null;
  const candidates = [data.response, data.reply, data.text, data.message, data.result?.response, data.result?.text, data.result?.reply, data.result];
  for (const candidate of candidates) {
    if (typeof candidate === "string" && candidate.trim()) return candidate.trim();
  }
  if (Array.isArray(data.choices) && typeof data.choices[0]?.message?.content === "string") {
    return data.choices[0].message.content.trim() || null;
  }
  return null;
}

async function callCloudflareAI(payload: unknown) {
  const response = await fetchWithRetry(CLOUDFLARE_AI_WORKER_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });

  const text = await response.text();
  if (!response.ok) {
    let message = text.slice(0, 300) || `خطای ${response.status}`;
    try {
      const parsed = JSON.parse(text);
      message = parsed.message || parsed.error || message;
    } catch {}
    throw new Error(message);
  }

  try {
    const parsed = JSON.parse(text);
    const result = extractAIResponse(parsed);
    if (result) return result;
  } catch {}

  const result = extractAIResponse(text);
  if (result) return result;
  throw new Error("پاسخ معتبر و قابل‌خواندن از هوش مصنوعی دریافت نشد.");
}

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT || 3000);

  app.disable("x-powered-by");
  app.use(express.json({ limit: "2mb" }));
  app.use((req, res, next) => {
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
    res.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
    if (req.path.startsWith("/api/")) res.setHeader("Cache-Control", "no-store");
    if (isProduction && !req.path.startsWith('/api/')) {
      res.setHeader("Content-Security-Policy", [
        "default-src 'self'",
        "base-uri 'self'",
        "form-action 'self'",
        "frame-ancestors 'none'",
        "object-src 'none'",
        "script-src 'self'",
        "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://cdn.jsdelivr.net",
        "font-src 'self' data: https://fonts.gstatic.com https://cdn.jsdelivr.net",
        "img-src 'self' data: blob: https:",
        "media-src 'self' data: blob: https:",
        "connect-src 'self' https:",
        "frame-src 'self' https://www.youtube.com https://www.youtube-nocookie.com https://www.aparat.com https://*.aparat.com",
      ].join("; "));
    }
    next();
  });
  app.use((req, res, next) => {
    const mutating = ["POST", "PUT", "PATCH", "DELETE"].includes(req.method);
    const exempt = req.method === "POST" && req.path === "/api/auth/unlock";
    if (mutating && !exempt && req.headers["x-loveniya-request"] !== "1") {
      return res.status(403).json({ error: "درخواست نامعتبر است." });
    }
    next();
  });

  if (!APP_SECRET) {
    console.warn("[security] APP_SECRET is not configured. Database requests will fail closed.");
  }
  if (isProduction && !SESSION_SECRET) {
    throw new Error("SESSION_SECRET must be configured in production.");
  }
  if (isProduction && !configuredPassword && !configuredPasswordHash) {
    throw new Error("Configure APP_UNLOCK_PASSWORD_SHA256 in production.");
  }

  app.get("/api/health", (_req, res) => {
    res.json({ ok: true, time: Date.now() });
  });

  app.get("/api/auth/status", (req, res) => {
    const session = getSession(req);
    if (!session) return res.status(401).json({ authenticated: false });
    res.json({ authenticated: true, user: session.user });
  });

  app.post("/api/auth/unlock", (req, res) => {
    const ip = req.ip || req.socket.remoteAddress || 'unknown';
    const now = Date.now();
    const failure = loginFailures.get(ip);
    if (failure && failure.resetAt > now && failure.count >= 5) {
      return res.status(429).json({ error: 'تعداد تلاش‌ها زیاد است؛ کمی بعد دوباره امتحان کنید.' });
    }
    const user = req.body?.user === "niyayesh" ? "niyayesh" : req.body?.user === "amin" ? "amin" : null;
    if (!user || !timingSafePasswordEquals(req.body?.password)) {
      const next = failure && failure.resetAt > now ? { count: failure.count + 1, resetAt: failure.resetAt } : { count: 1, resetAt: now + 60_000 };
      loginFailures.set(ip, next);
      return res.status(401).json({ error: 'رمز عبور نادرست است.' });
    }
    loginFailures.delete(ip);
    setSessionCookie(res, createSession(user));
    res.json({ authenticated: true, user });
  });

  app.post("/api/auth/lock", (_req, res) => {
    clearSessionCookie(res);
    res.status(204).end();
  });

  // All database reads/writes go through this same-origin gateway.
  // The worker secret therefore stays on the server.
  app.all("/api/data/*", async (req, res) => {
    if (!requireAuth(req, res)) return;
    if (!APP_SECRET) return res.status(503).json({ error: "اتصال دیتابیس هنوز تنظیم نشده است." });

    const rawPath = req.params[0] || "";
    let decodedPath = "";
    try {
      decodedPath = decodeURIComponent(rawPath).replace(/^\/+|\/+$/g, "");
    } catch {
      return res.status(400).json({ error: "مسیر داده نامعتبر است." });
    }
    if (!ALLOWED_DATA_PATH.test(decodedPath) || decodedPath.split('/').some(segment => segment === '.' || segment === '..')) {
      return res.status(400).json({ error: "مسیر داده نامعتبر است." });
    }

    const qs = new URLSearchParams(req.query as Record<string, string>);
    const query = qs.toString() ? `?${qs.toString()}` : "";
    const url = `${DATA_WORKER_URL}/${decodedPath}.json${query}`;
    const method = req.method.toUpperCase();
    if (!["GET", "PUT", "PATCH", "DELETE"].includes(method)) {
      return res.status(405).json({ error: "این عملیات پشتیبانی نمی‌شود." });
    }

    const session = getSession(req);
    if (decodedPath === 'loveniya_moments_v2' && session && (method === 'PATCH' || method === 'PUT')) {
      const previousQueue = momentsWriteQueue;
      let release!: () => void;
      momentsWriteQueue = new Promise<void>(resolve => { release = resolve; });
      await previousQueue.catch(() => undefined);
      try {
        const currentState = await readWorkerJson(decodedPath);
        const mergedState = mergeMomentsPatch(currentState, req.body ?? {}, session.user);
        await writeWorkerJson(decodedPath, mergedState, 'PUT');
        return res.status(200).json(mergedState);
      } catch (error: any) {
        const message = error?.message || 'ذخیره وضعیت بازی ناموفق بود.';
        return res.status(409).json({ error: message });
      } finally {
        release();
      }
    }

    if (decodedPath === 'loveniya_ldr_games_async' && session && method === 'PUT') {
      const previousQueue = ldrWriteQueue;
      let release!: () => void;
      ldrWriteQueue = new Promise<void>(resolve => { release = resolve; });
      await previousQueue.catch(() => undefined);
      try {
        const currentState = await readWorkerJson(decodedPath);
        const mergedState = mergeLdrWrite(currentState, req.body ?? {}, session.user);
        await writeWorkerJson(decodedPath, mergedState, 'PUT');
        return res.status(200).json(mergedState);
      } catch (error: any) {
        return res.status(502).json({ error: error?.message || "ذخیره وضعیت بازی ناموفق بود." });
      } finally {
        release();
      }
    }

    try {
      const upstream = await fetchWithRetry(url, {
        method,
        headers: {
          "Content-Type": "application/json",
          "X-App-Secret": APP_SECRET,
          "Accept": "application/json",
        },
        body: method === "GET" || method === "DELETE" ? undefined : JSON.stringify(req.body ?? {}),
      });
      const body = await upstream.text();
      const contentType = upstream.headers.get("content-type");
      if (contentType) res.setHeader("Content-Type", contentType);
      if (decodedPath === 'loveniya_moments_v2' && method === 'GET' && upstream.ok && session) {
        try {
          const parsed = body ? JSON.parse(body) : null;
          return res.status(upstream.status).json(sanitizeMomentsForViewer(parsed, session.user));
        } catch {
          return res.status(502).json({ error: "داده بازی معتبر نیست." });
        }
      }
      if (decodedPath === 'loveniya_ldr_games_async' && method === 'GET' && upstream.ok && session) {
        try {
          const parsed = body ? JSON.parse(body) : null;
          return res.status(upstream.status).json(sanitizeLdrForViewer(parsed, session.user));
        } catch {
          return res.status(502).json({ error: "داده بازی معتبر نیست." });
        }
      }
      res.status(upstream.status).send(body);
    } catch (error: any) {
      res.status(502).json({ error: error?.message || "ارتباط با پایگاه داده برقرار نشد." });
    }
  });

  app.post('/api/ldr/secret-unlock', async (req, res) => {
    const auth = requireAuth(req, res);
    if (!auth) return;
    if (!APP_SECRET) return res.status(503).json({ error: 'اتصال دیتابیس هنوز تنظیم نشده است.' });

    const secretId = typeof req.body?.secretId === 'string' ? req.body.secretId : '';
    const guess = typeof req.body?.guess === 'string' ? req.body.guess : '';
    if (!secretId || !guess.trim() || secretId.length > 120 || guess.length > 1000) {
      return res.status(400).json({ error: 'اطلاعات حدس نامعتبر است.' });
    }

    const key = `${auth.user}:${secretId}`;
    const now = Date.now();
    const failure = secretUnlockFailures.get(key);
    if (failure && failure.resetAt > now && failure.count >= 20) {
      return res.status(429).json({ error: 'تعداد حدس‌ها زیاد است؛ کمی بعد دوباره امتحان کن.' });
    }

    const previousQueue = ldrWriteQueue;
    let release!: () => void;
    ldrWriteQueue = new Promise<void>(resolve => { release = resolve; });
    await previousQueue.catch(() => undefined);
    try {
      const state = await readWorkerJson('loveniya_ldr_games_async');
      const secrets = Array.isArray(state?.secretEnvelopes) ? state.secretEnvelopes : [];
      const secret = secrets.find((item: any) => item?.id === secretId);
      if (!secret) return res.status(404).json({ error: 'این پاکت پیدا نشد.' });
      if (secret.creator === auth.user) return res.status(403).json({ error: 'سازنده نمی‌تواند پاکت خودش را بازگشایی کند.' });
      if (secret.status === 'unlocked') return res.json({ unlocked: true, secret });

      const normalizedGuess = normalizeSecretGuess(guess);
      const normalizedAnswer = normalizeSecretGuess(secret.secretText);
      if (!normalizedGuess || !normalizedAnswer || !safeEqualUtf8(normalizedGuess, normalizedAnswer)) {
        const next = failure && failure.resetAt > now
          ? { count: failure.count + 1, resetAt: failure.resetAt }
          : { count: 1, resetAt: now + 60_000 };
        secretUnlockFailures.set(key, next);
        return res.status(409).json({ error: 'این حدس درست نیست.' });
      }

      secretUnlockFailures.delete(key);
      const updated = secrets.map((item: any) => item?.id === secretId
        ? { ...item, status: 'unlocked', unlockedAt: now, guesserChoice: guess.trim() }
        : item);
      await writeWorkerJson('loveniya_ldr_games_async', { ...state, secretEnvelopes: updated }, 'PUT');
      const unlocked = updated.find((item: any) => item?.id === secretId);
      return res.json({ unlocked: true, secret: unlocked });
    } catch (error: any) {
      return res.status(502).json({ error: error?.message || 'بازگشایی پاکت ناموفق بود.' });
    } finally {
      release();
    }
  });

  app.post("/api/loveai", async (req, res) => {
    if (!requireAuth(req, res)) return;
    try {
      const reply = await callCloudflareAI(req.body);
      res.json({ result: reply });
    } catch (error: any) {
      console.error("LoveAI Error:", error);
      res.status(502).json({ error: error?.message || "خطا در ارتباط با هوش مصنوعی." });
    }
  });

  app.post("/api/loveai/stream", async (req, res) => {
    if (!requireAuth(req, res)) return;
    try {
      const upstream = await fetchWithRetry(`${CLOUDFLARE_AI_WORKER_URL}/chat-stream`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(req.body),
      });
      if (!upstream.ok || !upstream.body) {
        const text = await upstream.text();
        return res.status(upstream.status || 502).send(text || "stream unavailable");
      }
      res.status(200);
      res.setHeader("Content-Type", upstream.headers.get("content-type") || "text/event-stream; charset=utf-8");
      res.setHeader("Cache-Control", "no-cache, no-transform");
      res.setHeader("Connection", "keep-alive");
      const reader = upstream.body.getReader();
      try {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          res.write(Buffer.from(value));
        }
      } finally {
        reader.releaseLock();
      }
      res.end();
    } catch (error: any) {
      if (!res.headersSent) res.status(502).json({ error: error?.message || "خطا در استریم هوش مصنوعی." });
      else res.end();
    }
  });

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({ server: { middlewareMode: true }, appType: "spa" });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath, { index: false }));
    app.get("*", (_req, res) => res.sendFile(path.join(distPath, "index.html")));
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch(error => {
  console.error("Fatal server error:", error);
  process.exit(1);
});
