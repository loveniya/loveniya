import React, { useState, useRef, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router';
import { dedupById } from '../lib/dedup';
import { MaleAvatar, FemaleAvatar } from '../components/CharacterAvatar';
import { 
  Send, ArrowRight, MoreVertical, Trash2, CheckCheck, Reply, 
  Heart, Loader2, AlertTriangle, X, Copy, Check, Search, ArrowUp, ChevronUp, ChevronDown
} from 'lucide-react';
import { streamLoveAI } from '../lib/ai';
import { 
  updateUserPresence, 
  fetchPartnerPresenceData, 
  formatIranLastSeen, 
  PresenceData 
} from '../lib/presence';
import { APP_SECRET } from '../lib/appSecret';

const WORKER_URL = "https://niya.am-b-asdfghjkl20112011.workers.dev";

interface ChatMessage {
  id: string;
  senderId: 'amin' | 'niyayesh' | 'ai';
  senderName?: string;
  text: string;
  timestamp: string;
  createdAt: number;
  status: 'sent' | 'read';
  replyTo?: {
    id: string;
    sender: string;
    text: string;
  };
}

// Cloudflare Workers AI occasionally echoes back a fragment of the prompt formatting
// (the "[در پاسخ به ...]" reply-context bracket, or a "-> نام:" / "نام:" speaker label
// copied from the conversation history) at the start of its reply. Strip that defensively
// before the text ever reaches the UI, without touching normal conversational text.
const sanitizeAiText = (raw: string): string => {
  let t = (raw || '').trim();
  t = t.replace(/^\[[^\]]{0,200}\]\s*/, '');
  t = t.replace(/^(?:-+>\s*)?(?:امین|نیایش|لوینیا)\s*[:\-]\s*/, '');
  return t.trim();
};

export function AIChat() {
  const navigate = useNavigate();
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const syncMutatedAtRef = useRef<number>(0);
  const lastAiReplyTimeRef = useRef<number>(0);
  const [hasFetchedChat, setHasFetchedChat] = useState(false);

  const [currentUser] = useState<'amin' | 'niyayesh'>(
    (localStorage.getItem('loveniya_user') as 'amin' | 'niyayesh') || 'amin'
  );

  const isAmin = currentUser === 'amin';
  const partnerId = isAmin ? 'niyayesh' : 'amin';
  const partnerName = isAmin ? 'نیایش' : 'امین';
  const myName = isAmin ? 'امین' : 'نیایش';

  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    const saved = localStorage.getItem('chat_messages_synced');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          return parsed.sort((a: ChatMessage, b: ChatMessage) => (a.createdAt || 0) - (b.createdAt || 0));
        }
      } catch (e) {}
    }
    return [];
  });

  const [inputText, setInputText] = useState('');
  const [partnerPresence, setPartnerPresence] = useState<PresenceData | null>(null);
  const [partnerStatusText, setPartnerStatusText] = useState('در حال بررسی وضعیت...');
  const [isPartnerTyping, setIsPartnerTyping] = useState(false);
  const [isGeneratingAI, setIsGeneratingAI] = useState(false);
  const [isAiStreamingChunk, setIsAiStreamingChunk] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [showSearch, setShowSearch] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResultIndex, setSearchResultIndex] = useState(0);
  const searchInputRef = useRef<HTMLInputElement>(null);
  const [showConfirmClearModal, setShowConfirmClearModal] = useState(false);
  const [isClearing, setIsClearing] = useState(false);
  const [replyingTo, setReplyingTo] = useState<ChatMessage | null>(null);
  const [selectedMsgForAction, setSelectedMsgForAction] = useState<ChatMessage | null>(null);
  const [copiedMsgId, setCopiedMsgId] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (message: string) => {
    setToastMessage(message);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Start reply and auto-focus keyboard
  const handleStartReply = (msg: ChatMessage) => {
    setReplyingTo(msg);
    setSelectedMsgForAction(null);
    setTimeout(() => {
      if (inputRef.current) {
        inputRef.current.focus();
      }
    }, 80);
  };

  // Copy message text
  const handleCopyMessage = async (msg: ChatMessage) => {
    try {
      await navigator.clipboard.writeText(msg.text);
      setCopiedMsgId(msg.id);
      showToast("متن پیام با موفقیت کپی شد ✨");
      setTimeout(() => {
        setCopiedMsgId(null);
        setSelectedMsgForAction(null);
      }, 900);
    } catch (e) {
      showToast("خطا در کپی کردن متن");
    }
  };

  // Delete message
  const handleDeleteMessage = async (msgId: string) => {
    try {
      setSelectedMsgForAction(null);
      setMessages(prev => {
        const filtered = prev.filter(m => m.id !== msgId);
        try { localStorage.setItem('chat_messages_synced', JSON.stringify(filtered)); } catch(e) {}
        return filtered;
      });
      await fetch(`${WORKER_URL}/loveniya_chat/${msgId}.json`, { method: 'DELETE', headers: { 'X-App-Secret': APP_SECRET } });
      syncMutatedAtRef.current = Date.now();
      showToast("پیام حذف شد");
    } catch (e) {
      console.error("Error deleting message:", e);
      showToast("خطا در حذف پیام از سرور");
    }
  };

  // اسکرول به پیام رفرنس داده شده
  const scrollToMessage = (msgId: string) => {
    const elem = document.getElementById(`msg-${msgId}`);
    if (elem) {
      elem.scrollIntoView({ behavior: 'smooth', block: 'center' });
      // رنگ ring-offset قبلاً برای پس‌زمینه‌ی تیره‌ی یک تم دیگه تنظیم شده بود
      // (#0e1621) — درحالی‌که این صفحه‌ی چت پس‌زمینه‌ی روشن و گرم داره؛ همون
      // رنگ تیره باعث می‌شد هایلایت به‌جای برجسته‌شدن، عجیب/ناهماهنگ دیده بشه.
      elem.classList.add('ring-2', 'ring-sky-400', 'ring-offset-2', 'ring-offset-white');
      setTimeout(() => {
        elem.classList.remove('ring-2', 'ring-sky-400', 'ring-offset-2', 'ring-offset-white');
      }, 1600);
    }
  };

  // --- جستجو در گفتگو ---
  // پیام‌های واقعی رندرشده رو دست نمی‌زنیم (چون گروه‌بندی و جداکننده‌ی
  // تاریخ به ترتیب پیوسته‌ی messages وابسته‌ست)؛ فقط نتیجه‌ها رو پیدا و به
  // نوبت به‌شون اسکرول می‌کنیم — دقیقاً همون مکانیزم scrollToMessage بالا.
  const searchResults = React.useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return [];
    return messages.filter(m => m.text && m.text.toLowerCase().includes(q));
  }, [searchQuery, messages]);

  useEffect(() => {
    setSearchResultIndex(0);
  }, [searchQuery]);

  useEffect(() => {
    if (showSearch && searchResults.length > 0) {
      const target = searchResults[searchResultIndex];
      if (target) scrollToMessage(target.id);
    }
  }, [searchResultIndex, searchResults, showSearch]);

  useEffect(() => {
    if (showSearch) {
      setTimeout(() => searchInputRef.current?.focus(), 50);
    } else {
      setSearchQuery('');
    }
  }, [showSearch]);

  const goToNextResult = () => {
    if (searchResults.length === 0) return;
    setSearchResultIndex(i => (i + 1) % searchResults.length);
  };
  const goToPrevResult = () => {
    if (searchResults.length === 0) return;
    setSearchResultIndex(i => (i - 1 + searchResults.length) % searchResults.length);
  };

  const handleScrollToStart = () => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollTo({ top: 0, behavior: 'smooth' });
    }
    setShowMenu(false);
  };


  const getDayLabel = (ts: number) => {
    if (!ts) return '';
    const d = new Date(ts);
    const now = new Date();
    const startOfDay = (date: Date) => new Date(date.getFullYear(), date.getMonth(), date.getDate()).getTime();
    const diffDays = Math.round((startOfDay(now) - startOfDay(d)) / 86400000);
    if (diffDays === 0) return 'امروز';
    if (diffDays === 1) return 'دیروز';
    return d.toLocaleDateString('fa-IR', { year: 'numeric', month: 'long', day: 'numeric' });
  };

  const isSameDay = (a: number, b: number) => {
    if (!a || !b) return false;
    const da = new Date(a), db = new Date(b);
    return da.getFullYear() === db.getFullYear() && da.getMonth() === db.getMonth() && da.getDate() === db.getDate();
  };


  const updateMyPresence = useCallback(async (typing: boolean) => {
    await updateUserPresence(currentUser, { isTyping: typing, isOnline: true });
  }, [currentUser]);

  // دریافت وضعیت آنلاین و آخرین بازدید دقیق پارتنر به وقت ایران
  const refreshPartnerPresence = useCallback(async () => {
    const data = await fetchPartnerPresenceData(partnerId);
    if (data) {
      setPartnerPresence(data);
      setIsPartnerTyping(Boolean(data.isTyping));
      const formatted = formatIranLastSeen(data, Boolean(data.isTyping));
      setPartnerStatusText(formatted);
    } else {
      setPartnerStatusText('آفلاین');
    }
  }, [partnerId]);

  // بروزرسانی وضعیت هنگام تایپ کاربر
  useEffect(() => {
    updateMyPresence(inputText.trim().length > 0);
  }, [inputText, updateMyPresence]);

  // تایمر همگام‌سازی وضعیت آنلاین و تایپ پارتنر
  useEffect(() => {
    refreshPartnerPresence();
    const presenceInterval = setInterval(() => {
      if (typeof document !== 'undefined' && document.visibilityState !== 'visible') return;
      updateMyPresence(inputText.trim().length > 0);
      refreshPartnerPresence();
    }, 3000);
    return () => clearInterval(presenceInterval);
  }, [refreshPartnerPresence, updateMyPresence, inputText]);

  // همگام‌سازی چت دو نفره با کلودفلر
  const fetchCloudflareChat = useCallback(async (force = false) => {
    if (!force && typeof force !== 'object' && Date.now() - syncMutatedAtRef.current < 5000) return;

    try {
      const res = await fetch(`${WORKER_URL}/loveniya_chat.json?_t=${Date.now()}`, { cache: 'no-store', headers: { 'X-App-Secret': APP_SECRET } });
      if (res.ok) {
        const data = await res.json();
        const rawArr: any[] = data ? (Array.isArray(data) ? data : Object.values(data)) : [];
        
        const messagesArr: ChatMessage[] = rawArr
          .filter(m => m && typeof m === 'object' && m.id && m.text)
          .map(m => {
            const rawCreatedAt = Number(m.createdAt) || (typeof m.timestamp === 'number' ? m.timestamp : Date.now());
            return {
              id: String(m.id),
              senderId: m.senderId || (m.sender === 'Amin' ? 'amin' : m.sender === 'Niyaish' ? 'niyayesh' : 'ai'),
              senderName: m.senderName || (m.senderId === 'amin' ? 'امین' : m.senderId === 'niyayesh' ? 'نیایش' : 'لوینیا'),
              text: String(m.text || m.content || ''),
              timestamp: m.timestamp && typeof m.timestamp === 'string' && !m.timestamp.includes('NaN')
                ? m.timestamp 
                : new Date(rawCreatedAt).toLocaleTimeString('fa-IR', { timeZone: 'Asia/Tehran', hour: '2-digit', minute: '2-digit', hour12: false }),
              createdAt: rawCreatedAt,
              status: m.status || 'read',
              replyTo: m.replyTo
            };
          })
          .sort((a, b) => (a.createdAt || 0) - (b.createdAt || 0));

        const cleanMessages = dedupById(messagesArr);
        setMessages(prev => {
          // Keep active streaming temp messages if any
          const tempMsgs = prev.filter(m => String(m.id).startsWith('ai_temp_'));
          const finalMessages = [...cleanMessages];
          for (const temp of tempMsgs) {
             const isAlreadyInReal = cleanMessages.some(m => 
                m.id === temp.id || (m.senderId === 'ai' && m.text === temp.text)
             );
             if (!isAlreadyInReal) {
                finalMessages.push(temp);
             }
          }
          return finalMessages.sort((a, b) => (a.createdAt || 0) - (b.createdAt || 0));
        });
        setHasFetchedChat(true);
        try { localStorage.setItem('chat_messages_synced', JSON.stringify(cleanMessages)); } catch(e) {}
      }
    } catch (e) {
      console.warn("Error fetching chat:", e);
      setHasFetchedChat(true);
    }
  }, []);

  const syncChatToServer = async (newMessages: ChatMessage[], changedMessage?: ChatMessage, isClear?: boolean) => {
    try {
      syncMutatedAtRef.current = Date.now();
      localStorage.setItem('chat_messages_synced', JSON.stringify(newMessages.filter(m => !m.id.startsWith('ai_temp_'))));
      
      if (isClear) {
        await Promise.allSettled([
          fetch(`${WORKER_URL}/loveniya_chat.json`, { method: 'DELETE', headers: { 'X-App-Secret': APP_SECRET } }),
          fetch(`${WORKER_URL}/loveniya_chat.json`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json', 'X-App-Secret': APP_SECRET },
            body: JSON.stringify({})
          })
        ]);
        return;
      }

      if (changedMessage) {
        if (!changedMessage.id.startsWith('ai_temp_')) {
          await fetch(`${WORKER_URL}/loveniya_chat/${changedMessage.id}.json`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json', 'X-App-Secret': APP_SECRET },
            body: JSON.stringify(changedMessage)
          });
        }
      } else {
        const payload: Record<string, ChatMessage> = {};
        newMessages.forEach(m => {
          if (!m.id.startsWith('ai_temp_')) {
            payload[m.id] = m;
          }
        });
        await fetch(`${WORKER_URL}/loveniya_chat.json`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json', 'X-App-Secret': APP_SECRET },
          body: JSON.stringify(payload)
        });
      }
    } catch (e) {
      console.error("Error syncing chat to server:", e);
    }
  };

  useEffect(() => {
    fetchCloudflareChat();
    const interval = setInterval(() => {
      if (typeof document !== 'undefined' && document.visibilityState !== 'visible') return;
      fetchCloudflareChat(false);
    }, 3500);
    return () => clearInterval(interval);
  }, [fetchCloudflareChat]);

  // ردیابی اینکه آیا کاربر همین الان نزدیک پایین صفحه اسکرول کرده یا نه
  const isNearBottomRef = useRef(true);
  const lastMessageIdRef = useRef<string | null>(null);

  useEffect(() => {
    const el = scrollContainerRef.current;
    if (!el) return;
    const handleScroll = () => {
      const threshold = 120;
      isNearBottomRef.current = el.scrollHeight - el.scrollTop - el.clientHeight < threshold;
    };
    el.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();
    return () => el.removeEventListener('scroll', handleScroll);
  }, []);

  // اسکرول خودکار به آخرین پیام — فقط وقتی پیام واقعاً جدیدی اضافه شده (نه هر بار که polling
  // یک آرایه‌ی جدید با همون داده‌ها برمی‌گردونه)، و فقط اگر کاربر از قبل نزدیک پایین صفحه بوده
  // یا خودش همین الان پیام فرستاده — تا وسط خوندن پیام‌های قدیمی، اسکرولش به زور پایین کشیده نشه.
  useEffect(() => {
    const lastMsg = messages[messages.length - 1];
    const lastId = lastMsg ? lastMsg.id : null;
    const isNewMessage = lastId !== lastMessageIdRef.current;
    lastMessageIdRef.current = lastId;

    if (!scrollContainerRef.current) return;

    const shouldFollow = isNearBottomRef.current || lastMsg?.senderId === currentUser;
    if ((isNewMessage || isPartnerTyping || isGeneratingAI) && shouldFollow) {
      scrollContainerRef.current.scrollTo({
        top: scrollContainerRef.current.scrollHeight,
        behavior: 'smooth'
      });
    }
  }, [messages, isPartnerTyping, isGeneratingAI, currentUser]);

  // پاک کردن کامل تاریخچه چت همراه با بستن فوری منو و مودال
  const confirmAndClearHistory = async () => {
    setIsClearing(true);
    try {
      syncMutatedAtRef.current = Date.now();
      setMessages([]);
      localStorage.setItem('chat_messages_synced', '[]');
      await syncChatToServer([], undefined, true);
    } catch (e) {
      console.error("Error clearing chat:", e);
    } finally {
      setIsClearing(false);
      setShowConfirmClearModal(false);
      setShowMenu(false);
    }
  };

  // فراخوانی تضمینی هوش مصنوعی کلودفلر و ریپلای دقیق به پیام مورد نظر
  const triggerAiEvaluation = async (sourceUserMessage: ChatMessage) => {
    if (isGeneratingAI) return;

    setIsGeneratingAI(true);
    setIsAiStreamingChunk(false);

    const tempId = `ai_temp_${Date.now()}`;
    const finalId = `msg_ai_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;

    // هدف دقیق ریپلای هوش مصنوعی، حتماً پیام همین کاربری است که صحبت کرده است
    const aiReplyTarget = {
      id: sourceUserMessage.id,
      sender: sourceUserMessage.senderName || (sourceUserMessage.senderId === 'amin' ? 'امین' : 'نیایش'),
      text: sourceUserMessage.text
    };

    try {
      const cleanHistory = messages.filter(m => !String(m.id).startsWith('ai_temp_')).slice(-8);
      const historyContext = cleanHistory.map(m => 
        `${m.senderName || (m.senderId === 'amin' ? 'امین' : m.senderId === 'niyayesh' ? 'نیایش' : 'لوینیا')}: ${m.text}`
      ).join('\n');

      let targetPrompt = sourceUserMessage.text.trim();
      if (sourceUserMessage.replyTo) {
        targetPrompt = `[در پاسخ به "${sourceUserMessage.replyTo.sender}: ${sourceUserMessage.replyTo.text}"] ${sourceUserMessage.text}`;
      }

      const rawResult = await streamLoveAI({
        type: 'chat',
        userMessage: targetPrompt,
        history: historyContext,
        contextData: {
          user: currentUser,
          userName: myName,
          partner: partnerName,
          replyingTo: { sender: aiReplyTarget.sender, text: aiReplyTarget.text }
        }
      }, (chunkText) => {
          setIsAiStreamingChunk(true);
          setMessages(prev => {
             const hasTemp = prev.some(m => m.id === tempId);
             if (!hasTemp) {
                return [...prev, {
                  id: tempId,
                  senderId: 'ai',
                  senderName: 'لوینیا',
                  text: sanitizeAiText(chunkText),
                  timestamp: new Date().toLocaleTimeString('fa-IR', { timeZone: 'Asia/Tehran', hour: '2-digit', minute: '2-digit', hour12: false }),
                  createdAt: Date.now(),
                  status: 'read',
                  replyTo: aiReplyTarget
                }];
             }
             return prev.map(m => m.id === tempId ? { ...m, text: sanitizeAiText(chunkText) } : m);
          });
      });

      if (rawResult === 'SKIP' || !rawResult || rawResult.trim().length === 0) {
        setMessages(prev => prev.filter(m => m.id !== tempId));
      } else {
        const finalAiMessage: ChatMessage = {
          id: finalId,
          senderId: 'ai',
          senderName: 'لوینیا',
          text: sanitizeAiText(rawResult),
          timestamp: new Date().toLocaleTimeString('fa-IR', { timeZone: 'Asia/Tehran', hour: '2-digit', minute: '2-digit', hour12: false }),
          createdAt: Date.now(),
          status: 'read',
          replyTo: aiReplyTarget
        };
        
        setMessages(prev => {
          const updated = prev.map(m => m.id === tempId ? finalAiMessage : m);
          syncChatToServer(updated, finalAiMessage);
          return updated;
        });
        lastAiReplyTimeRef.current = Date.now();
        setTimeout(() => fetchCloudflareChat(true), 2000);
      }
    } catch (err: any) {
      console.error("AI Evaluation Error:", err);
      setMessages(prev => prev.filter(m => m.id !== tempId));
      showToast(err.message || "خطا در ارتباط با سرور هوش مصنوعی");
    } finally {
      setIsGeneratingAI(false);
      setIsAiStreamingChunk(false);
    }
  };

  // ارسال پیام متنی
  const handleSend = async (forcedText?: string) => {
    const textToSend = (forcedText || inputText).trim();
    if (!textToSend) return;

    const currentReplyTarget = replyingTo;
    const now = Date.now();
    const iranTime = new Date(now).toLocaleTimeString('fa-IR', {
      timeZone: 'Asia/Tehran',
      hour: '2-digit',
      minute: '2-digit',
      hour12: false
    });

    const userMessage: ChatMessage = {
      id: `msg_${now}_${Math.random().toString(36).substring(2, 7)}`,
      senderId: currentUser,
      senderName: myName,
      text: textToSend,
      timestamp: iranTime,
      createdAt: now,
      status: 'sent',
      replyTo: currentReplyTarget ? { 
        id: currentReplyTarget.id, 
        sender: currentReplyTarget.senderName || (currentReplyTarget.senderId === 'amin' ? 'امین' : currentReplyTarget.senderId === 'niyayesh' ? 'نیایش' : 'لوینیا'), 
        text: currentReplyTarget.text 
      } : undefined
    };
    
    setReplyingTo(null);

    if (!forcedText) {
      setInputText('');
    }

    let updatedList: ChatMessage[] = [];
    setMessages((prev) => {
      updatedList = [...prev, userMessage].sort((a, b) => a.createdAt - b.createdAt);
      syncChatToServer(updatedList, userMessage);
      return updatedList;
    });

    // بررسی درخواست از هوش مصنوعی
    const lower = textToSend.toLowerCase();
    const isDirectlyInvoked = 
      lower.includes('لوینیا') || 
      lower.includes('@ai') || 
      lower.includes('هوش مصنوعی') || 
      lower.includes('ai') ||
      lower.includes('ربات') ||
      lower.includes('جواب بده') ||
      lower.includes('کمک کن') ||
      lower.includes('چرا جواب نمیدی') ||
      lower.includes('شعر بگو') ||
      lower.includes('فال بگو') ||
      lower.includes('نظرت چیه') ||
      textToSend.endsWith('؟') ||
      textToSend.endsWith('?');

    const isReplyingToAi = currentReplyTarget?.senderId === 'ai';
    if (isDirectlyInvoked || isReplyingToAi) {
      setTimeout(() => {
        triggerAiEvaluation(userMessage);
      }, 350);
    }
  };

  return (
    <div 
      className="flex flex-col h-[100dvh] w-full bg-gradient-to-b from-orange-100/80 via-rose-100/60 to-violet-100/50 text-stone-900 overflow-hidden select-none relative" 
      dir="rtl"
    >
      {/* Background: subtle repeating pattern over the warm multi-hue wash, so the chat has real visual depth and color presence instead of reading as flat or washed out */}
      <div 
        className="absolute inset-0 pointer-events-none opacity-[0.5]"
        style={{
          backgroundImage: "radial-gradient(circle at 2px 2px, rgba(190,60,90,0.16) 1.5px, transparent 0)",
          backgroundSize: '28px 28px'
        }}
      />
      <div className="absolute top-[-10%] left-[-10%] w-[45%] h-[40%] rounded-full bg-rose-200/25 blur-[90px] pointer-events-none" />
      <div className="absolute bottom-[15%] right-[-10%] w-[45%] h-[40%] rounded-full bg-purple-200/25 blur-[90px] pointer-events-none" />

      {/* Modern Header */}
      <header className="flex-none bg-white min-h-[64px] pt-[max(env(safe-area-inset-top),_12px)] pb-3 px-4 flex items-center justify-between z-20 relative border-b border-stone-200/70 shadow-[0_1px_0_0_rgba(0,0,0,0.02)]">
        
        <div className="flex items-center gap-3">
          <button onClick={() => navigate('/')} className="w-10 h-10 flex items-center justify-center rounded-full bg-white shadow-xs border border-stone-200/50 hover:bg-stone-50 transition-colors text-stone-600 active:scale-95 cursor-pointer" title="بازگشت">
            <ArrowRight className="w-5 h-5" />
          </button>
          
          <div className="flex items-center gap-3">
            <div className="relative">
              {isAmin ? <FemaleAvatar className="w-11 h-11" /> : <MaleAvatar className="w-11 h-11" />}
              {/* Online Indicator Dot */}
              <div className={`absolute bottom-0 right-0 w-3.5 h-3.5 rounded-full border-2 border-white ${partnerStatusText === 'آنلاین' ? 'bg-emerald-500' : 'bg-stone-300'}`} />
            </div>
            
            <div className="flex flex-col justify-center">
              <span className="text-stone-900 font-black text-base leading-tight tracking-tight">{partnerName}</span>
              <span className={`text-[11px] mt-0.5 transition-colors duration-300 font-bold ${
                isPartnerTyping 
                  ? 'text-sky-500' 
                  : partnerStatusText === 'آنلاین' 
                    ? 'text-emerald-500' 
                    : 'text-stone-400'
              }`}>
                {isPartnerTyping ? 'در حال نوشتن...' : partnerStatusText}
              </span>
            </div>
          </div>
        </div>

        <div className="relative" onClick={e => e.stopPropagation()}>
          <button 
            onClick={() => setShowMenu(!showMenu)} 
            aria-label="منوی گفتگو"
            aria-expanded={showMenu}
            className="w-10 h-10 flex items-center justify-center rounded-full bg-white shadow-xs border border-stone-200/50 hover:bg-stone-50 transition-colors text-stone-600 active:scale-95 cursor-pointer"
          >
            <MoreVertical className="w-5 h-5" />
          </button>

          {showMenu && (
            <>
              <div className="fixed inset-0 z-40" onClick={() => setShowMenu(false)} />
              
              <div className="absolute left-0 top-12 bg-white/95 backdrop-blur-xl border border-stone-200/50 shadow-2xl rounded-2xl py-1.5 w-60 z-50 text-right overflow-hidden animate-fadeIn origin-top-left">
                <button
                  onClick={() => { setShowMenu(false); setShowSearch(true); }}
                  className="w-full flex items-center gap-3 px-3.5 py-2.5 hover:bg-stone-50 text-stone-700 transition-colors cursor-pointer"
                >
                  <div className="w-8 h-8 rounded-xl bg-sky-50 text-sky-600 flex items-center justify-center shrink-0">
                    <Search className="w-4 h-4" />
                  </div>
                  <span className="font-black text-[12.5px]">جستجو در گفتگو</span>
                </button>

                <button
                  onClick={handleScrollToStart}
                  className="w-full flex items-center gap-3 px-3.5 py-2.5 hover:bg-stone-50 text-stone-700 transition-colors cursor-pointer"
                >
                  <div className="w-8 h-8 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center shrink-0">
                    <ArrowUp className="w-4 h-4" />
                  </div>
                  <span className="font-black text-[12.5px]">رفتن به ابتدای گفتگو</span>
                </button>

                <div className="h-px bg-stone-100 my-1.5 mx-2" />

                <button
                  onClick={() => {
                    setShowMenu(false);
                    setShowConfirmClearModal(true);
                  }}
                  className="w-full flex items-center gap-3 px-3.5 py-2.5 hover:bg-rose-50 text-rose-600 transition-colors cursor-pointer"
                >
                  <div className="w-8 h-8 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center shrink-0">
                    <Trash2 className="w-4 h-4" />
                  </div>
                  <span className="font-black text-[12.5px]">پاک کردن تاریخچه چت</span>
                </button>
              </div>
            </>
          )}
        </div>
      </header>

      {/* نوار جستجوی گفتگو */}
      {showSearch && (
        <div className="flex-none bg-white border-b border-stone-200/70 px-4 py-2.5 flex items-center gap-2 z-20 relative animate-fadeIn">
          <Search className="w-4 h-4 text-stone-400 shrink-0" />
          <input
            ref={searchInputRef}
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') { e.preventDefault(); e.shiftKey ? goToPrevResult() : goToNextResult(); }
              if (e.key === 'Escape') setShowSearch(false);
            }}
            placeholder="دنبال کدوم پیام می‌گردی؟"
            dir="rtl"
            className="flex-1 min-w-0 bg-transparent text-stone-900 font-bold placeholder-stone-400 text-[13.5px] focus:outline-hidden"
          />
          {searchQuery.trim() && (
            <span className="shrink-0 text-[11px] font-bold text-stone-400 whitespace-nowrap">
              {searchResults.length > 0 ? `${searchResultIndex + 1} از ${searchResults.length}` : 'یافت نشد'}
            </span>
          )}
          <button
            onClick={goToPrevResult}
            disabled={searchResults.length === 0}
            aria-label="نتیجه‌ی قبلی"
            className="shrink-0 w-8 h-8 rounded-full flex items-center justify-center text-stone-500 hover:bg-stone-100 disabled:opacity-30 cursor-pointer transition-colors"
          >
            <ChevronUp className="w-4 h-4" />
          </button>
          <button
            onClick={goToNextResult}
            disabled={searchResults.length === 0}
            aria-label="نتیجه‌ی بعدی"
            className="shrink-0 w-8 h-8 rounded-full flex items-center justify-center text-stone-500 hover:bg-stone-100 disabled:opacity-30 cursor-pointer transition-colors"
          >
            <ChevronDown className="w-4 h-4" />
          </button>
          <button
            onClick={() => setShowSearch(false)}
            aria-label="بستن جستجو"
            className="shrink-0 w-8 h-8 rounded-full flex items-center justify-center text-stone-500 hover:bg-stone-100 cursor-pointer transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* لیست پیام‌ها */}
      <main 
        ref={scrollContainerRef} 
        className="flex-1 min-h-0 overflow-y-auto overscroll-contain px-4 sm:px-6 pt-6 pb-2 flex flex-col gap-3 select-text z-10" 
        style={{ WebkitOverflowScrolling: 'touch', touchAction: 'pan-y' }}
      >
        {!hasFetchedChat ? (
          <div className="flex-1 flex flex-col items-center justify-center text-stone-400 text-xs gap-4 py-12 my-auto">
            <div className="w-12 h-12 bg-white rounded-2xl shadow-sm border border-stone-100 flex items-center justify-center">
              <Loader2 className="w-6 h-6 animate-spin text-rose-400" />
            </div>
            <span className="text-[13px] font-bold">در حال همگام‌سازی...</span>
          </div>
        ) : messages.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center gap-3 py-12 my-auto">
            <div className="bg-white/60 backdrop-blur-md border border-white rounded-[32px] p-8 shadow-xl shadow-rose-900/5 text-center max-w-sm relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-rose-200/20 blur-2xl rounded-full mix-blend-multiply" />
              <div className="absolute bottom-0 left-0 w-32 h-32 bg-sky-200/20 blur-2xl rounded-full mix-blend-multiply" />
              <div className="w-16 h-16 rounded-3xl bg-gradient-to-br from-rose-100 to-pink-100 flex items-center justify-center mx-auto mb-4 border border-white shadow-sm relative z-10">
                <Heart className="w-8 h-8 text-rose-500 fill-rose-500/20" />
              </div>
              <h4 className="text-stone-900 font-black text-[18px] mb-2 relative z-10">یک شروع عاشقانه</h4>
              <p className="text-[14px] text-stone-500 leading-relaxed font-bold relative z-10">
                پیام‌های شما به‌صورت کاملاً خصوصی و زنده همگام می‌شوند. اولین پیامت رو بفرست!
              </p>
            </div>
          </div>
        ) : null}

        {hasFetchedChat && messages.length > 0 && <div className="flex-1 shrink-0 min-h-0" />}
        {hasFetchedChat && messages.map((msg, index) => {
          const isMe = msg.senderId === currentUser;
          const isAI = msg.senderId === 'ai';
          const showDateSeparator = index === 0 || !isSameDay(messages[index - 1].createdAt, msg.createdAt);

          const handleMsgClick = (e: React.MouseEvent) => {
            e.stopPropagation();
            setSelectedMsgForAction(msg);
          };

          const replyMarkup = msg.replyTo && (
            <div 
              onClick={(e) => {
                e.stopPropagation();
                if (msg.replyTo?.id) {
                  scrollToMessage(msg.replyTo.id);
                }
              }}
              className={`mb-2 pl-3 py-1.5 pr-2.5 border-r-[3px] rounded-l-xl text-[13px] cursor-pointer hover:opacity-80 transition-opacity active:scale-[0.99] ${
                isAI ? 'border-purple-400 bg-purple-50/50' : isMe ? 'border-white/70 bg-white/10' : 'border-teal-400 bg-teal-50'
              }`}
              title="مشاهده پیام اصلی"
            >
              <div className={`text-[11px] font-black mb-0.5 flex items-center gap-1.5 ${
                isAI ? 'text-purple-700' : isMe ? 'text-white' : 'text-teal-700'
              }`}>
                <Reply className="w-3 h-3" />
                <span>{msg.replyTo.sender}</span>
              </div>
              <div className={`line-clamp-1 opacity-90 text-[12px] font-bold ${isMe ? 'text-white' : 'text-stone-700'}`}>{msg.replyTo.text}</div>
            </div>
          );

          const dateSeparator = showDateSeparator && (
            <div className="flex items-center justify-center my-3 select-none" key={`sep-${msg.id || index}`}>
              <span className="bg-white/80 backdrop-blur-sm border border-stone-200/70 text-stone-500 text-[11px] font-bold px-3.5 py-1 rounded-full shadow-xs">
                {getDayLabel(msg.createdAt)}
              </span>
            </div>
          );

          if (isAI) {
            return (
              <React.Fragment key={msg.id ? `${msg.id}-${index}` : `ai-${index}`}>
                {dateSeparator}
                <div 
                  id={`msg-${msg.id}`}
                  className="flex w-full justify-end relative group transition-all duration-300"
                >
                  <div 
                    onClick={handleMsgClick}
                    className="relative max-w-[82%] sm:max-w-[70%] px-3.5 py-2 text-sm font-bold leading-snug break-words cursor-pointer transition-all active:scale-[0.98] shadow-sm bg-gradient-to-br from-purple-50 to-fuchsia-50/70 border border-purple-100 text-stone-800 rounded-2xl"
                  >
                    <div className="text-[11px] font-black mb-1 text-purple-600 flex items-center gap-1.5">
                      <span>لوینیا</span>
                    </div>

                    {replyMarkup}

                    <div className="whitespace-pre-wrap break-words">
                      {msg.text.trim()}
                    </div>
                    <div className="flex justify-end mt-1">
                      <span className="text-[10px] font-bold text-purple-400 select-none">
                        {msg.timestamp}
                      </span>
                    </div>
                  </div>
                </div>
              </React.Fragment>
            );
          }

          return (
            <React.Fragment key={msg.id ? `${msg.id}-${index}` : `user-${index}`}>
              {dateSeparator}
              <div 
                id={`msg-${msg.id}`}
                className={`flex w-full ${isMe ? 'justify-start' : 'justify-end'} relative group transition-all duration-300`}
              >
                <div 
                  onClick={handleMsgClick}
                  className={`relative max-w-[82%] sm:max-w-[70%] px-3.5 py-2 text-sm font-bold leading-snug break-words cursor-pointer transition-all active:scale-[0.98] shadow-sm rounded-2xl
                  ${isMe 
                    ? 'bg-gradient-to-br from-rose-500 to-pink-500 text-white' 
                    : 'bg-gradient-to-br from-teal-50 to-emerald-50/70 border border-teal-100 text-stone-800'
                  }`}
                >
                  {!isMe && (
                    <div className="text-[11px] font-black mb-1 text-teal-700">
                      {msg.senderName || (msg.senderId === 'amin' ? 'امین' : 'نیایش')}
                    </div>
                  )}

                  {replyMarkup}

                  <div className="whitespace-pre-wrap break-words">
                    {msg.text.trim()}
                  </div>
                  <div className="flex items-center gap-1 justify-end mt-1 select-none">
                    <span className={`text-[10px] font-bold ${isMe ? 'text-white/75' : 'text-teal-600/80'}`}>
                      {msg.timestamp}
                    </span>
                    {isMe && <CheckCheck className="w-3 h-3 text-white/75" />}
                  </div>
                </div>
              </div>
            </React.Fragment>
          );
        })}

        {/* نشانگر در حال تایپ هوش مصنوعی */}
        {isGeneratingAI && !isAiStreamingChunk && (
          <div className="flex w-full justify-end animate-fadeIn">
            <div className="bg-gradient-to-br from-purple-50 to-fuchsia-50/70 border border-purple-100 text-purple-700 font-bold rounded-[20px] rounded-bl-[6px] px-5 py-3 text-xs flex items-center gap-3 shadow-sm">
              <div className="flex gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-purple-500 animate-bounce" style={{ animationDelay: '0ms' }} />
                <span className="w-1.5 h-1.5 rounded-full bg-purple-500 animate-bounce" style={{ animationDelay: '150ms' }} />
                <span className="w-1.5 h-1.5 rounded-full bg-purple-500 animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
              <span className="font-black text-stone-500 tracking-tight">لوینیا در حال فکر کردن...</span>
            </div>
          </div>
        )}

        <div className="h-4 flex-none" />
      </main>

      {/* Floating Modern Input Footer */}
      <footer className="flex-none bg-white border-t border-stone-200/70 px-3 sm:px-4 pt-3 pb-[max(env(safe-area-inset-bottom),_16px)] flex flex-col z-20">
        
        {replyingTo && (
          <div className="flex items-center justify-between bg-stone-50 px-4 py-2.5 mb-3 rounded-[20px] border border-stone-200 shadow-sm animate-fadeIn mx-1">
            <div className="flex flex-col overflow-hidden">
              <span className="text-rose-500 text-[11.5px] font-black flex items-center gap-1.5 mb-0.5">
                <Reply className="w-3.5 h-3.5" />
                <span>پاسخ به {replyingTo.senderName || (replyingTo.senderId === 'amin' ? 'امین' : replyingTo.senderId === 'niyayesh' ? 'نیایش' : 'لوینیا')}</span>
              </span>
              <span className="text-stone-500 font-bold text-xs truncate line-clamp-1">{replyingTo.text}</span>
            </div>
            <button 
              onClick={() => setReplyingTo(null)} 
              aria-label="لغو پاسخ"
              className="w-7 h-7 rounded-full bg-white border border-stone-200 text-stone-400 hover:text-stone-700 hover:bg-stone-100 flex items-center justify-center transition cursor-pointer shrink-0 shadow-xs"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
        
        <div className="flex items-end gap-2 w-full">
          <div className="flex-1 min-w-0 bg-stone-100/70 rounded-[28px] flex items-end min-h-[52px] max-h-[144px] relative border border-stone-200/60 focus-within:border-rose-300 focus-within:bg-white transition-all shadow-xs inset-shadow-sm">
            <textarea
              ref={inputRef}
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              disabled={isGeneratingAI}
              onKeyDown={(e) => { 
                if (e.key === 'Enter' && !e.shiftKey && !isGeneratingAI) { 
                  e.preventDefault(); 
                  handleSend(); 
                } 
              }}
              placeholder={isGeneratingAI ? 'درحال پردازش...' : `پیام به ${partnerName}...`}
              dir="rtl"
              className="flex-1 bg-transparent text-stone-900 font-bold placeholder-stone-400 text-[14.5px] px-4 py-3.5 resize-none focus:outline-none max-h-[144px] overflow-y-auto disabled:opacity-50"
              rows={1}
              style={{ minHeight: '52px' }}
            />
          </div>

          <button 
            onClick={() => handleSend()} 
            disabled={!inputText.trim() || isGeneratingAI}
            className="w-[52px] h-[52px] bg-gradient-to-br from-rose-500 to-rose-600 hover:from-rose-600 hover:to-rose-700 disabled:from-stone-200 disabled:to-stone-200 disabled:text-stone-400 text-white rounded-[24px] flex items-center justify-center flex-none transition-all shadow-sm active:scale-95 cursor-pointer shrink-0"
          >
            <Send className="w-5 h-5 mr-0.5" />
          </button>
        </div>
      </footer>

      {/* Modern Action Sheet */}
      {selectedMsgForAction && (
        <div 
          className="fixed inset-0 z-50 bg-stone-900/40 backdrop-blur-sm flex flex-col justify-end p-3 sm:p-5 animate-fadeIn"
          onClick={() => setSelectedMsgForAction(null)}
        >
          <div 
            className="bg-white/95 backdrop-blur-xl border border-white/50 rounded-[32px] p-5 sm:p-6 max-w-md w-full mx-auto shadow-2xl animate-slideUp text-right"
            onClick={e => e.stopPropagation()}
          >
            {/* Grab handle */}
            <div className="w-12 h-1.5 bg-stone-200 rounded-full mx-auto mb-6" />

            {/* Message Preview Card */}
            <div className="bg-stone-50 rounded-[24px] border border-stone-200 mb-5 p-4 shadow-xs">
              <div className="flex items-center justify-between mb-2">
                <span className={`text-[11px] font-black px-3 py-1 rounded-full ${
                  selectedMsgForAction.senderId === 'ai' 
                    ? 'bg-purple-100 text-purple-700' 
                    : selectedMsgForAction.senderId === currentUser
                      ? 'bg-rose-100 text-rose-700'
                      : 'bg-teal-100 text-teal-700'
                }`}>
                  {selectedMsgForAction.senderName || (selectedMsgForAction.senderId === 'amin' ? 'امین' : selectedMsgForAction.senderId === 'niyayesh' ? 'نیایش' : 'لوینیا')}
                </span>
                <span className="text-[10.5px] text-stone-400 font-bold">{selectedMsgForAction.timestamp}</span>
              </div>
              <p className="text-[13.5px] font-bold text-stone-700 line-clamp-3 leading-relaxed">
                {selectedMsgForAction.text}
              </p>
            </div>

            {/* Action Buttons List */}
            <div className="flex flex-col gap-2.5">
              
              <button
                onClick={() => handleStartReply(selectedMsgForAction)}
                className="flex items-center w-full px-5 py-4 rounded-[24px] bg-stone-50 hover:bg-stone-100 text-stone-700 transition-colors active:scale-[0.98] cursor-pointer border border-stone-200/70"
              >
                <div className="w-10 h-10 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center shrink-0 ml-4">
                  <Reply className="w-5 h-5" />
                </div>
                <div className="flex flex-col text-right">
                  <span className="text-[14px] font-black text-stone-900 mb-0.5">پاسخ دادن</span>
                  <span className="text-[11px] font-bold text-stone-500">نوشتن پیام با ارجاع به این متن</span>
                </div>
              </button>

              <button
                onClick={() => handleCopyMessage(selectedMsgForAction)}
                className="flex items-center w-full px-5 py-4 rounded-[24px] bg-stone-50 hover:bg-stone-100 text-stone-700 transition-colors active:scale-[0.98] cursor-pointer border border-stone-200/70"
              >
                <div className="w-10 h-10 rounded-full bg-stone-200/70 text-stone-600 flex items-center justify-center shrink-0 ml-4">
                  {copiedMsgId === selectedMsgForAction.id ? <Check className="w-5 h-5" /> : <Copy className="w-5 h-5" />}
                </div>
                <div className="flex flex-col text-right">
                  <span className="text-[14px] font-black text-stone-900 mb-0.5">
                    {copiedMsgId === selectedMsgForAction.id ? 'متن کپی شد ✔' : 'کپی کردن متن'}
                  </span>
                  <span className="text-[11px] font-bold text-stone-500">کپی کامل پیام در کلیپ‌بورد</span>
                </div>
              </button>

              <button
                onClick={() => handleDeleteMessage(selectedMsgForAction.id)}
                className="flex items-center w-full px-5 py-4 rounded-[24px] bg-rose-50 hover:bg-rose-100 text-rose-700 transition-colors active:scale-[0.98] cursor-pointer border border-rose-200/70"
              >
                <div className="w-10 h-10 rounded-full bg-white text-rose-600 flex items-center justify-center shrink-0 ml-4 shadow-sm border border-rose-100">
                  <Trash2 className="w-5 h-5" />
                </div>
                <div className="flex flex-col text-right">
                  <span className="text-[14px] font-black text-rose-700 mb-0.5">حذف پیام</span>
                  <span className="text-[11px] font-bold text-rose-500">حذف دائمی از تاریخچه</span>
                </div>
              </button>

            </div>

            <button
              onClick={() => setSelectedMsgForAction(null)}
              className="w-full py-4 mt-4 rounded-[24px] bg-stone-100 hover:bg-stone-200 text-stone-600 text-[14px] font-black transition-colors text-center cursor-pointer"
            >
              بستن منو
            </button>
          </div>
        </div>
      )}

      {/* Toast Feedback Message */}
      {toastMessage && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 animate-fadeIn pointer-events-none">
          <div className="bg-gradient-to-br from-stone-900/95 to-rose-950/95 backdrop-blur text-white px-4 py-2 rounded-2xl shadow-xl flex items-center gap-2 text-xs font-bold border border-rose-800/40">
            
            <span>{toastMessage}</span>
          </div>
        </div>
      )}

      {/* مودال تأیید پاک کردن تاریخچه */}
      {showConfirmClearModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-xs animate-fadeIn">
          <div className="bg-white border border-stone-200 rounded-3xl p-6 max-w-sm w-full shadow-2xl text-center relative animate-scaleUp">
            <button 
              onClick={() => setShowConfirmClearModal(false)}
              aria-label="انصراف و بستن"
              className="absolute top-4 left-4 p-1.5 rounded-full text-stone-400 hover:text-stone-700 hover:bg-stone-100 transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="w-14 h-14 bg-rose-50 border border-rose-100 rounded-2xl flex items-center justify-center mx-auto mb-4 text-rose-500">
              <AlertTriangle className="w-7 h-7" />
            </div>

            <h3 className="text-stone-900 font-black text-base mb-2">پاک کردن تاریخچه چت</h3>
            <p className="text-stone-500 font-bold text-xs leading-relaxed mb-6">
              آیا مطمئن هستید؟ با این کار تمامی پیام‌های ثبت‌شده در گفتگوی دونفره برای همیشه حذف خواهند شد.
            </p>

            <div className="flex items-center gap-3">
              <button
                onClick={() => setShowConfirmClearModal(false)}
                disabled={isClearing}
                className="flex-1 py-3 px-4 rounded-2xl bg-stone-100 hover:bg-stone-200 text-stone-700 font-black text-xs transition cursor-pointer"
              >
                انصراف
              </button>
              
              <button
                onClick={confirmAndClearHistory}
                disabled={isClearing}
                className="flex-1 py-3 px-4 rounded-2xl bg-rose-500 hover:bg-rose-600 text-white font-black text-xs transition flex items-center justify-center gap-2 shadow-md shadow-rose-500/20 disabled:opacity-50 cursor-pointer"
              >
                {isClearing ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>در حال حذف...</span>
                  </>
                ) : (
                  <span>بله، پاک کن</span>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}

export default AIChat;
