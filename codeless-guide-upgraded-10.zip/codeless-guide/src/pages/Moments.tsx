import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  Dices, Shuffle, HelpCircle, Flame,
  RotateCcw, Loader2, Send, MessageCircleHeart, CheckCircle2, Clock
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useSearchParams } from 'react-router';
import { PageWrapper } from '../components/PageWrapper';
import { generateTruthOrDare, generateDeepQuestion } from '../lib/gameAi';
import { APP_SECRET } from '../lib/appSecret';

const WORKER_URL = "https://niya.am-b-asdfghjkl20112011.workers.dev";
const MOMENTS_PATH = 'loveniya_moments_v2';

type MomentsTab = 'deep' | 'truth';
type DeepQuestionLevel = 'light' | 'close' | 'deep';
type Who = 'amin' | 'niyayesh';

type DeepQuestionState = {
  id: string;
  level: DeepQuestionLevel;
  question: string;
  answers: { amin?: string; niyayesh?: string };
} | null;

type MomentsData = {
  deepQuestion: DeepQuestionState;
  deepAnsweredCount: number;
  lastBottleResult?: { type: 'truth' | 'dare'; text: string; timestamp: number; spinnerId: Who; answeredAt?: number };
  completedDareCount: number;
};

const INITIAL_DATA: MomentsData = {
  deepQuestion: null,
  deepAnsweredCount: 0,
  lastBottleResult: undefined,
  completedDareCount: 0
};

// فقط فیلدهایی که همچنان استفاده می‌شن نگه داشته می‌شن؛ فیلدهای قدیمی
// (دوز، تله‌پاتی، پاکت راز، یادداشت) اگه هنوز روی سرور مونده باشن نادیده گرفته می‌شن.
function sanitizeMomentsData(data: any): MomentsData {
  if (!data || typeof data !== 'object') return INITIAL_DATA;
  const dq = data.deepQuestion;
  return {
    deepQuestion: (dq && typeof dq === 'object' && dq.id && typeof dq.question === 'string')
      ? { id: dq.id, level: dq.level || 'close', question: dq.question, answers: (dq.answers && typeof dq.answers === 'object') ? dq.answers : {} }
      : null,
    deepAnsweredCount: Number(data.deepAnsweredCount) || 0,
    lastBottleResult: data.lastBottleResult && typeof data.lastBottleResult === 'object' ? data.lastBottleResult : undefined,
    completedDareCount: Number(data.completedDareCount) || 0
  };
}

const LEVELS: { level: DeepQuestionLevel; title: string; desc: string }[] = [
  { level: 'light', title: 'سبک', desc: 'شروع راحت، بدون فشار' },
  { level: 'close', title: 'صمیمی', desc: 'حس‌ها و چیزهایی که کمتر گفته می‌شن' },
  { level: 'deep', title: 'عمیق', desc: 'ترس‌ها، آینده و چیزهای واقعاً مهم' }
];

export const Moments: React.FC = () => {
  const [searchParams] = useSearchParams();
  const requestedTab = searchParams.get('tab');
  const initialTab: MomentsTab = requestedTab === 'truth' || requestedTab === 'bottle' ? 'truth' : 'deep';

  const currentUser: Who = (localStorage.getItem('loveniya_user') as Who) || 'amin';
  const partnerKey: Who = currentUser === 'amin' ? 'niyayesh' : 'amin';
  const partnerName = currentUser === 'amin' ? 'نیایش' : 'امین';

  const [activeTab, setActiveTab] = useState<MomentsTab>(initialTab);
  const [gameData, setGameData] = useState<MomentsData>(INITIAL_DATA);

  // Truth / Dare
  const [isPicking, setIsPicking] = useState(false);
  const [selectedDare, setSelectedDare] = useState<{ type: 'truth' | 'dare'; text: string } | null>(null);

  // Deep questions
  const [deepAnswerInput, setDeepAnswerInput] = useState('');
  const [isGeneratingDeep, setIsGeneratingDeep] = useState(false);

  // Toast
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const showToast = useCallback((msg: string) => {
    setToastMsg(msg);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToastMsg(null), 3000);
  }, []);
  useEffect(() => () => { if (toastTimer.current) clearTimeout(toastTimer.current); }, []);

  // ---- Sync ----
  // به‌جای «۸ ثانیه بعد از هر تغییر نخون» (که جواب طرف مقابل رو تا ۸ ثانیه
  // دیرتر نشون می‌داد)، فقط وقتی نوشتنی در جریانه یا همین الان تموم شده نخون.
  const inFlightRef = useRef(0);
  const lastWriteDoneRef = useRef(0);

  const persistLocal = (data: MomentsData) => {
    try { localStorage.setItem(MOMENTS_PATH, JSON.stringify(data)); } catch { /* ignore */ }
  };

  const writeToServer = useCallback(async (url: string, method: 'PATCH' | 'PUT', body: unknown) => {
    inFlightRef.current += 1;
    try {
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json', 'X-App-Secret': APP_SECRET },
        body: JSON.stringify(body)
      });
      if (!res.ok) throw new Error(String(res.status));
    } catch {
      showToast('ذخیره نشد — اتصال رو چک کن و دوباره امتحان کن');
    } finally {
      inFlightRef.current -= 1;
      lastWriteDoneRef.current = Date.now();
    }
  }, [showToast]);

  const syncState = useCallback((patch: Partial<MomentsData>) => {
    setGameData(prev => {
      const merged = sanitizeMomentsData({ ...prev, ...patch });
      persistLocal(merged);
      return merged;
    });
    return writeToServer(`${WORKER_URL}/${MOMENTS_PATH}.json`, 'PATCH', patch);
  }, [writeToServer]);

  const fetchData = useCallback(async () => {
    if (inFlightRef.current > 0 || Date.now() - lastWriteDoneRef.current < 1500) return;
    try {
      const res = await fetch(`${WORKER_URL}/${MOMENTS_PATH}.json?_t=${Date.now()}`, {
        cache: 'no-store',
        headers: { 'X-App-Secret': APP_SECRET }
      });
      if (!res.ok) return;
      const clean = sanitizeMomentsData(await res.json());
      if (inFlightRef.current > 0) return; // یک نوشتن وسط راه شروع شد؛ نتیجه‌ی خوندن قدیمیه
      setGameData(clean);
      persistLocal(clean);
    } catch { /* آفلاین: همون نسخه‌ی محلی می‌مونه */ }
  }, []);

  useEffect(() => {
    try {
      const saved = localStorage.getItem(MOMENTS_PATH);
      if (saved) setGameData(sanitizeMomentsData(JSON.parse(saved)));
    } catch { /* ignore */ }
    fetchData();
    const interval = setInterval(() => {
      if (document.visibilityState === 'visible') fetchData();
    }, 5000);
    return () => clearInterval(interval);
  }, [fetchData]);

  // ---- Deep questions ----
  const startDeepQuestion = async (level: DeepQuestionLevel) => {
    if (isGeneratingDeep) return;
    setIsGeneratingDeep(true);
    try {
      const question = await generateDeepQuestion(level);
      setDeepAnswerInput('');
      await syncState({ deepQuestion: { id: 'dq_' + Date.now(), level, question, answers: {} } });
    } finally {
      setIsGeneratingDeep(false);
    }
  };

  // جواب هر نفر روی مسیر مخصوص خودش نوشته می‌شه (نه کل سوال)، تا اگه هر دو
  // تقریباً هم‌زمان جواب بدن، جواب یکی جواب اون یکی رو پاک نکنه.
  const submitDeepAnswer = async () => {
    const q = gameData.deepQuestion;
    const text = deepAnswerInput.trim();
    if (!q || !text) return;
    setDeepAnswerInput('');
    setGameData(prev => {
      if (!prev.deepQuestion || prev.deepQuestion.id !== q.id) return prev;
      const next = { ...prev, deepQuestion: { ...prev.deepQuestion, answers: { ...prev.deepQuestion.answers, [currentUser]: text } } };
      persistLocal(next);
      return next;
    });
    await writeToServer(`${WORKER_URL}/${MOMENTS_PATH}/deepQuestion/answers/${currentUser}.json`, 'PUT', text);
  };

  const finishDeepRound = () => {
    const q = gameData.deepQuestion;
    const bothDone = !!(q?.answers.amin && q?.answers.niyayesh);
    setDeepAnswerInput('');
    syncState({
      deepQuestion: null,
      ...(bothDone ? { deepAnsweredCount: gameData.deepAnsweredCount + 1 } : {})
    });
  };

  const deepQ = gameData.deepQuestion;
  const myDeepAnswer = deepQ?.answers[currentUser];
  const partnerDeepAnswer = deepQ?.answers[partnerKey];
  const deepBothDone = !!(myDeepAnswer && partnerDeepAnswer);

  // خبر دادن وقتی طرف مقابل جواب می‌ده (فقط برای تغییر زنده، نه بارگذاری اولیه)
  const seenPartnerAnswerRef = useRef<string | null>(null);
  const deepWatcherReadyRef = useRef(false);
  useEffect(() => {
    const key = deepQ && partnerDeepAnswer ? deepQ.id : null;
    if (!deepWatcherReadyRef.current) {
      deepWatcherReadyRef.current = true;
      seenPartnerAnswerRef.current = key;
      return;
    }
    if (key && key !== seenPartnerAnswerRef.current) {
      showToast(myDeepAnswer ? `${partnerName} هم جواب داد — جواب‌ها باز شد` : `${partnerName} جواب داد، نوبت توئه`);
    }
    seenPartnerAnswerRef.current = key;
  }, [deepQ?.id, partnerDeepAnswer, myDeepAnswer, partnerName, showToast]);

  // ---- Truth / Dare ----
  const lastSeenTsRef = useRef<number>(0);
  const pickTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(() => () => { if (pickTimerRef.current) clearTimeout(pickTimerRef.current); }, []);

  const drawChallenge = async (forcedKind?: 'truth' | 'dare') => {
    if (isPicking) return;
    setIsPicking(true);
    setSelectedDare(null);
    const kind: 'truth' | 'dare' = forcedKind || (Math.random() > 0.5 ? 'truth' : 'dare');
    const [text] = await Promise.all([
      generateTruthOrDare(kind),
      new Promise<void>(resolve => setTimeout(resolve, 700))
    ]);
    const result = { type: kind, text, timestamp: Date.now(), spinnerId: currentUser };
    lastSeenTsRef.current = result.timestamp;
    syncState({ lastBottleResult: result });
    setIsPicking(false);
    setSelectedDare({ type: kind, text });
  };

  // روی گوشی طرف مقابل هم نشون بده؛ و اگه صفحه بسته و دوباره باز شد، آخرین چالش برگرده.
  useEffect(() => {
    const result = gameData.lastBottleResult;
    if (!result || result.timestamp === lastSeenTsRef.current) return;
    const isRestore = lastSeenTsRef.current === 0;
    lastSeenTsRef.current = result.timestamp;
    if (isRestore) { setSelectedDare({ type: result.type, text: result.text }); return; }
    if (result.spinnerId === currentUser) return;
    setIsPicking(true);
    setSelectedDare(null);
    pickTimerRef.current = setTimeout(() => {
      setIsPicking(false);
      setSelectedDare({ type: result.type, text: result.text });
    }, 900);
  }, [gameData.lastBottleResult, currentUser]);

  // چالش همیشه برای طرف مقابلِ کسیه که اون رو کشیده
  const answererKey: Who | undefined = gameData.lastBottleResult
    ? (gameData.lastBottleResult.spinnerId === 'amin' ? 'niyayesh' : 'amin')
    : undefined;
  const isAnswerer = answererKey === currentUser;
  const dareDone = !!gameData.lastBottleResult?.answeredAt;

  const markDareDone = () => {
    if (!gameData.lastBottleResult || dareDone) return;
    syncState({
      lastBottleResult: { ...gameData.lastBottleResult, answeredAt: Date.now() },
      completedDareCount: gameData.completedDareCount + 1
    });
  };

  const seenAnsweredAtRef = useRef<number | undefined>(undefined);
  const ackWatcherReadyRef = useRef(false);
  useEffect(() => {
    const answeredAt = gameData.lastBottleResult?.answeredAt;
    if (!ackWatcherReadyRef.current) {
      ackWatcherReadyRef.current = true;
      seenAnsweredAtRef.current = answeredAt;
      return;
    }
    if (answeredAt && answeredAt !== seenAnsweredAtRef.current && gameData.lastBottleResult?.spinnerId === currentUser) {
      showToast(`${partnerName} به چالش جواب داد`);
    }
    seenAnsweredAtRef.current = answeredAt;
  }, [gameData.lastBottleResult?.answeredAt, gameData.lastBottleResult?.spinnerId, currentUser, partnerName, showToast]);

  const tabClass = (tab: MomentsTab) =>
    `flex-1 min-h-[44px] rounded-xl text-sm font-black flex items-center justify-center gap-2 cursor-pointer transition-colors ${
      activeTab === tab ? 'bg-stone-900 text-white shadow-sm' : 'text-stone-500 hover:text-stone-800'
    }`;

  return (
    <PageWrapper>
      <div className="space-y-4 max-w-2xl mx-auto px-2 sm:px-4 py-2" dir="rtl">

        <AnimatePresence>
          {toastMsg && (
            <motion.div
              role="status"
              aria-live="polite"
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="fixed top-4 left-1/2 -translate-x-1/2 z-50 bg-stone-900/95 text-white text-sm font-black px-5 py-3 rounded-2xl shadow-lg max-w-[90vw] text-center"
            >
              {toastMsg}
            </motion.div>
          )}
        </AnimatePresence>

        <section className="bg-white rounded-3xl p-5 shadow-[0_16px_50px_-12px_rgba(28,25,23,0.06)] text-center">
          <h1 className="text-2xl font-black text-stone-900 tracking-tight">گفتگوی دونفره</h1>
          <p className="text-xs text-stone-500 font-bold mt-1.5">
            سوال‌هایی که باعث می‌شن بیشتر همدیگه رو بشناسید
          </p>
        </section>

        <div className="bg-stone-100 rounded-2xl p-1 flex gap-1" role="tablist" aria-label="بخش‌ها">
          <button role="tab" aria-selected={activeTab === 'deep'} onClick={() => setActiveTab('deep')} className={tabClass('deep')}>
            <MessageCircleHeart className="w-4 h-4" />
            <span>سوال‌های عمیق</span>
          </button>
          <button role="tab" aria-selected={activeTab === 'truth'} onClick={() => setActiveTab('truth')} className={tabClass('truth')}>
            <Dices className="w-4 h-4" />
            <span>جرأت یا حقیقت</span>
          </button>
        </div>

        {/* ---------- Deep questions ---------- */}
        {activeTab === 'deep' && (
          <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} className="space-y-3">
            {gameData.deepAnsweredCount > 0 && (
              <p className="text-center text-[11px] font-bold text-stone-400">
                {gameData.deepAnsweredCount.toLocaleString('fa-IR')} سوال تا حالا با هم جواب دادید
              </p>
            )}

            {!deepQ ? (
              <div className="space-y-2.5">
                <p className="text-xs font-bold text-stone-500 text-center px-2">
                  سطح رو انتخاب کنید. هر دو جدا جواب می‌نویسید و بعد از جواب دادن هر دو، جواب‌ها هم‌زمان باز می‌شه.
                </p>
                {LEVELS.map(opt => (
                  <button
                    key={opt.level}
                    onClick={() => startDeepQuestion(opt.level)}
                    disabled={isGeneratingDeep}
                    className="w-full bg-white hover:bg-stone-50 disabled:opacity-60 rounded-2xl p-4 border border-stone-200 flex items-center justify-between gap-3 cursor-pointer transition-colors text-right"
                  >
                    <span>
                      <span className="text-sm font-black text-stone-900 block">{opt.title}</span>
                      <span className="text-[11px] font-bold text-stone-500">{opt.desc}</span>
                    </span>
                    {isGeneratingDeep && <Loader2 className="w-4 h-4 animate-spin text-stone-400 shrink-0" />}
                  </button>
                ))}
              </div>
            ) : (
              <div className="bg-white rounded-3xl p-5 border border-stone-200 space-y-4">
                <p className="text-[15px] font-black text-stone-900 leading-8 text-center">{deepQ.question}</p>

                {deepBothDone ? (
                  <div className="space-y-3">
                    {([['amin', 'امین'], ['niyayesh', 'نیایش']] as const).map(([key, name]) => (
                      <div key={key} className="bg-stone-50 rounded-2xl p-3.5 border border-stone-200">
                        <span className="text-[11px] font-black text-stone-500 block mb-1">{name}</span>
                        <p className="text-sm font-bold text-stone-800 leading-7 whitespace-pre-wrap">{deepQ.answers[key]}</p>
                      </div>
                    ))}
                    <button
                      onClick={finishDeepRound}
                      className="w-full min-h-[44px] bg-stone-900 hover:bg-stone-800 text-white text-sm font-black rounded-xl flex items-center justify-center gap-2 cursor-pointer transition-colors"
                    >
                      <RotateCcw className="w-4 h-4" />
                      <span>سوال بعدی</span>
                    </button>
                  </div>
                ) : myDeepAnswer ? (
                  <div className="flex items-center justify-center gap-2 text-sm font-bold text-stone-500 py-2">
                    <Clock className="w-4 h-4" />
                    <span>جوابت ثبت شد. منتظر {partnerName} هستیم</span>
                  </div>
                ) : (
                  <div className="space-y-2.5">
                    <textarea
                      value={deepAnswerInput}
                      onChange={(e) => setDeepAnswerInput(e.target.value)}
                      placeholder="صادقانه بنویس. تا وقتی هر دو جواب ندید، دیده نمی‌شه"
                      aria-label="جواب تو"
                      rows={4}
                      className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3.5 py-3 text-sm font-bold text-stone-900 placeholder:text-stone-400 placeholder:font-medium focus:outline-hidden focus:border-stone-400 resize-none leading-7"
                    />
                    <div className="flex gap-2">
                      <button
                        onClick={submitDeepAnswer}
                        disabled={!deepAnswerInput.trim()}
                        className="flex-1 min-h-[44px] bg-stone-900 hover:bg-stone-800 disabled:opacity-40 text-white text-sm font-black rounded-xl flex items-center justify-center gap-2 cursor-pointer transition-colors"
                      >
                        <Send className="w-4 h-4" />
                        <span>ثبت جواب</span>
                      </button>
                      {!partnerDeepAnswer && (
                        <button
                          onClick={() => startDeepQuestion(deepQ.level)}
                          disabled={isGeneratingDeep}
                          aria-label="یک سوال دیگه از همین سطح"
                          className="min-h-[44px] px-4 bg-stone-100 hover:bg-stone-200 disabled:opacity-50 text-stone-700 text-sm font-black rounded-xl flex items-center justify-center gap-2 cursor-pointer transition-colors"
                        >
                          {isGeneratingDeep ? <Loader2 className="w-4 h-4 animate-spin" /> : <Shuffle className="w-4 h-4" />}
                          <span>سوال دیگه</span>
                        </button>
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}
          </motion.div>
        )}

        {/* ---------- Truth or dare ---------- */}
        {activeTab === 'truth' && (
          <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} className="bg-white rounded-3xl p-5 border border-stone-200 space-y-4">
            <div className="flex items-start justify-between gap-3">
              <p className="text-xs font-bold text-stone-500 leading-6">
                چالش یا سوالی که می‌کشی، همیشه برای طرف مقابله
              </p>
              {gameData.completedDareCount > 0 && (
                <span className="shrink-0 text-[11px] font-black text-stone-400">
                  {gameData.completedDareCount.toLocaleString('fa-IR')} انجام‌شده
                </span>
              )}
            </div>

            <button
              onClick={() => drawChallenge()}
              disabled={isPicking}
              className="w-full min-h-[48px] bg-stone-900 hover:bg-stone-800 disabled:opacity-60 text-white text-sm font-black rounded-xl flex items-center justify-center gap-2 cursor-pointer transition-colors"
            >
              {isPicking ? <Loader2 className="w-4 h-4 animate-spin" /> : <Shuffle className="w-4 h-4" />}
              <span>{isPicking ? 'در حال انتخاب...' : 'یه چالش تصادفی'}</span>
            </button>

            <div className="grid grid-cols-2 gap-2.5">
              <button
                onClick={() => drawChallenge('truth')}
                disabled={isPicking}
                className="min-h-[44px] bg-sky-50 hover:bg-sky-100 text-sky-800 border border-sky-200 text-sm font-black rounded-xl cursor-pointer transition-colors disabled:opacity-50 flex items-center justify-center gap-1.5"
              >
                <HelpCircle className="w-4 h-4" />
                <span>حقیقت</span>
              </button>
              <button
                onClick={() => drawChallenge('dare')}
                disabled={isPicking}
                className="min-h-[44px] bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-200 text-sm font-black rounded-xl cursor-pointer transition-colors disabled:opacity-50 flex items-center justify-center gap-1.5"
              >
                <Flame className="w-4 h-4" />
                <span>جرأت</span>
              </button>
            </div>

            {selectedDare && (
              <motion.div
                initial={{ opacity: 0, scale: 0.97 }}
                animate={{ opacity: 1, scale: 1 }}
                className={`p-4 rounded-2xl border space-y-3 ${
                  selectedDare.type === 'truth' ? 'bg-sky-50 border-sky-200 text-sky-950' : 'bg-rose-50 border-rose-200 text-rose-950'
                }`}
              >
                <span className="text-[11px] font-black opacity-70 block text-center">
                  {selectedDare.type === 'truth' ? 'حقیقت' : 'جرأت'}
                </span>
                <p className="text-[15px] font-black leading-8 text-center">{selectedDare.text}</p>

                <div className="flex justify-center">
                  {isAnswerer ? (
                    dareDone ? (
                      <span className="inline-flex items-center gap-1.5 text-xs font-black bg-white/70 px-3 py-1.5 rounded-full">
                        <CheckCircle2 className="w-3.5 h-3.5" /> انجام شد
                      </span>
                    ) : (
                      <button
                        onClick={markDareDone}
                        className="min-h-[44px] px-6 rounded-xl bg-stone-900 hover:bg-stone-800 text-white text-sm font-black cursor-pointer transition-colors"
                      >
                        انجام دادم
                      </button>
                    )
                  ) : (
                    <span className="inline-flex items-center gap-1.5 text-xs font-black bg-white/70 px-3 py-1.5 rounded-full">
                      {dareDone
                        ? <><CheckCircle2 className="w-3.5 h-3.5" /> {partnerName} انجام داد</>
                        : <><Clock className="w-3.5 h-3.5" /> منتظر {partnerName}</>}
                    </span>
                  )}
                </div>
              </motion.div>
            )}
          </motion.div>
        )}

      </div>
    </PageWrapper>
  );
};
