# Loveniya — Final Engineering Release (98% target)

## Base preservation

This release starts from **Release V4** and keeps the V4 archive untouched.

V4 SHA-256:
`bdfa5c455b01d9062b6f97f34e5e2f06f8f3661b9505be70b457fd040ba24aac`

No changes from previous packaged releases were intentionally removed.

## New work in this final pass

### Data/sync reliability
- Prevented overlapping Store polling cycles.
- Added immediate foreground refresh when a hidden tab becomes visible again.
- Changed multi-resource sync to `Promise.allSettled`, so one failed collection no longer prevents successful collections from updating.
- Partial sync failure is now visible without discarding successful updates.
- AI delayed refresh timers are explicitly cleaned up on unmount.

### Server hardening
- Production CSP now restricts `connect-src` to the configured data/AI origins instead of every HTTPS origin.
- Added `Cross-Origin-Opener-Policy` and `Origin-Agent-Cluster` headers.
- Login body length is bounded before password verification.
- Generic data-gateway and AI error responses no longer echo arbitrary upstream bodies/details to the browser; details are logged server-side.
- AI stream upstream failures are now sanitized.

### UI/accessibility
- Added a consistent `:focus-visible` language across the application.
- Removed a duplicate CSS declaration.
- Added a lightweight scrollbar treatment for long content surfaces.
- Hidden HTML audio is explicitly hidden from assistive technology.
- Embedded video permissions were reduced to the minimum currently required by the player.
- Production error boundary no longer exposes internal exception text; technical details are development-only.

### Release/QA tooling
- Static QA now checks multi-line buttons, image `alt`, iframe `title`, `target=_blank` link safety, and retired code across the whole project.
- Added `release-structural-smoke.mjs` for security/architecture regression checks.
- Added `final-gate.mjs` for repeatable release verification.
- Added `SETUP_FINAL.md` with secure secret configuration instructions.

## Verified in this sandbox

- Static QA: **PASS**
- TypeScript syntax smoke: **PASS — 38 TS/TSX files**
- Release structural/security smoke: **PASS**
- Truth/Dare engine smoke: **PASS**
- Moments engine smoke: **PASS**
- Pure game-module compile: **PASS** using the global TypeScript compiler with an isolated empty type root
- package-lock graph dry-run from V4: **PASS** (dependency graph previously verified)
- No executable Tic-Tac-Toe / «دوز عاشقی» references remain in `src/` or `server.ts`
- No client-side APP_SECRET / worker upstream secret references remain
- `target="_blank"` links have `rel="noopener noreferrer"`
- images and iframes pass the static accessibility guards

## Intentionally not claimed as sandbox-verified

- A full clean `npm ci` followed by a production Vite build
- Full browser E2E on real desktop/mobile browsers
- Real two-device concurrency against the deployed Worker/AI services

The container available for this pass runs Node 22.16.0 and cannot complete the clean dependency install required by the pinned Node 24.21.0 target, so the release does not falsely label those steps as PASS.

## Current dependency security check

- Vite `6.4.3` is on the patched side of the 2026 `server.fs.deny` advisory; the advisory lists `6.4.3` as the first patched 6.x release. citeturn495548search6
- React `19.2.8` is the patched version listed for the July 2026 Server Functions advisory. This project does not use React Server Components, but the patched React release is retained. citeturn495548search8
- React Router `8.3.0` is the first patched release listed for the 2026 RSC CSRF advisory affecting the 8.x line. citeturn495548search0
- Express `4.22.2` is the current 4.x release shown in the official Express release list used for this audit. citeturn495548search1

## Final engineering position

This is the final code-quality/reliability release for the requested **98% engineering completeness target**.

The remaining validation is intentionally left for deployment and the user's own real-world testing: clean production build, browser/device E2E, and real multi-user network interaction.
