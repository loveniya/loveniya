import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const read = file => fs.readFileSync(path.join(root, file), 'utf8');
const failures = [];
const expect = (condition, message) => { if (!condition) failures.push(message); };

const server = read('server.ts');
const index = read('index.html');
const css = read('src/index.css');
const app = read('src/App.tsx');
const chat = read('src/pages/AIChat.tsx');
const moments = read('src/pages/Moments.tsx');
const packageJson = JSON.parse(read('package.json'));

expect(server.includes('x-loveniya-request'), 'CSRF guard missing');
expect(server.includes('APP_UNLOCK_PASSWORD_SHA256'), 'production password hash guard missing');
expect(server.includes('Content-Security-Policy'), 'CSP missing');
expect(server.includes('connect-src'), 'CSP connect-src missing');
expect(server.includes('Cross-Origin-Opener-Policy'), 'COOP header missing');
expect(server.includes('X-Content-Type-Options'), 'nosniff header missing');
expect(server.includes('Cache-Control", "no-store'), 'no-store API cache policy missing');
expect(server.includes("app.get(\"/api/health\""), 'health endpoint missing');
expect(server.includes('SIGTERM') && server.includes('server.close'), 'graceful shutdown missing');
expect(server.includes('هوش مصنوعی موقتاً در دسترس نیست'), 'generic AI failure response missing');
expect(!/status\(502\)\.json\(\{\s*error:\s*error\?\.message/.test(server), 'raw AI/server error message still exposed');
expect(!/return res\.status\(upstream\.status \|\| 502\)\.send\(text/.test(server), 'raw upstream stream error still exposed');

expect(/Vazirmatn/.test(index) && /font-family:\s*'Vazirmatn'/.test(css), 'single-font configuration missing');
expect(!/font-family:\s*[^;]*(?:Arial|Roboto|Inter|system-ui)/i.test(css), 'secondary global font family detected');
expect(!/Tic[-\s]?Tac[-\s]?Toe|tictactoe|دوز عاشقی/.test(app + moments + server), 'retired Tic-Tac-Toe remains in executable game code');
expect(!/workers\.dev|APP_SECRET|X-App-Secret/.test(read('src/lib/api.ts')), 'server-only worker secret leaked into api client');
expect(chat.includes('senderId: \'ai\''), 'AI sender id contract missing');
expect(chat.includes('aiRefreshTimerRef'), 'AI delayed refresh cleanup missing');
expect(server.includes('mergeMomentsPatch'), 'server-authoritative Moments engine missing');
expect(packageJson.engines?.node === '>=24.21.0 <25', 'Node engine target changed unexpectedly');
expect(packageJson.engines?.npm === '>=11 <12', 'npm engine target changed unexpectedly');

if (failures.length) {
  console.error('RELEASE_STRUCTURAL_SMOKE_FAILED');
  for (const failure of failures) console.error('- ' + failure);
  process.exit(1);
}
console.log('RELEASE_STRUCTURAL_SMOKE_PASS');
