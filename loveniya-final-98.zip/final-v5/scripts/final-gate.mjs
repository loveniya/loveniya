import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { execFileSync } from 'node:child_process';

const root = process.cwd();
const run = (cmd, args) => execFileSync(cmd, args, { cwd: root, stdio: 'inherit', env: process.env });

run(process.execPath, ['scripts/qa.mjs']);
run(process.execPath, ['scripts/syntax-smoke.mjs']);

for (const file of ['src/lib/truthOrDare.ts', 'src/lib/momentsEngine.ts']) {
  if (!fs.existsSync(path.join(root, file))) throw new Error(`Missing required game module: ${file}`);
}

const lock = fs.readFileSync(path.join(root, 'package-lock.json'), 'utf8');
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
if (!lock.includes('node_modules/vite')) throw new Error('package-lock.json does not contain vite');
if (pkg.engines?.node !== '>=24.21.0 <25') throw new Error('Unexpected Node engine target');
if (pkg.engines?.npm !== '>=11 <12') throw new Error('Unexpected npm engine target');

const report = {
  generatedAt: new Date().toISOString(),
  qa: 'PASS',
  syntax: 'PASS',
  gameModulesPresent: true,
  packageLockPresent: true,
  nodeTarget: pkg.engines.node,
  npmTarget: pkg.engines.npm,
  buildVerifiedInSandbox: false,
  note: 'Production build/E2E require the pinned Node 24 runtime and a complete dependency install.'
};
fs.writeFileSync(path.join(root, 'FINAL_GATE_RESULT.json'), JSON.stringify(report, null, 2) + '\n');
console.log('FINAL_GATE_PASS');
