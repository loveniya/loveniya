import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const srcRoot = path.join(root, 'src');
const files = [];

function walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(full);
    else if (/\.(ts|tsx|js|jsx|mjs|cjs)$/.test(entry.name)) files.push(full);
  }
}
walk(srcRoot);

const failures = [];
const text = files.map(file => ({ file, text: fs.readFileSync(file, 'utf8') }));
const allProjectFiles = [];
(function walkAll(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (['node_modules', 'dist', 'dist-test'].includes(entry.name)) continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) walkAll(full); else allProjectFiles.push(full);
  }
})(root);

const retiredGamePattern = /دوز عاشقی|Tic[-\s]?Tac[-\s]?Toe|tictactoe|getTicTacToeWinner|game-panel--tictactoe/;

for (const { file, text: source } of text) {
  const rel = path.relative(root, file);
  if (/dangerouslySetInnerHTML\s*=/.test(source) && !rel.endsWith('src/components/RomanticEffects.tsx')) {
    failures.push(`${rel}: unexpected dangerouslySetInnerHTML`);
  }
  if (/\beval\s*\(|\bnew\s+Function\s*\(/.test(source)) {
    failures.push(`${rel}: dynamic code execution detected`);
  }
  if (/X-App-Secret|APP_SECRET|CLOUDFLARE_AI_WORKER_URL|DATA_WORKER_URL/.test(source) && rel.startsWith('src/')) {
    failures.push(`${rel}: server-only secret/upstream token leaked into client source`);
  }
  if (/<button\b[\s\S]*?>/gi.test(source) && /<button\b(?:(?!>).)*?(?:\n|\r|\s)[\s\S]*?>/i.test(source)) {
    const buttonTags = source.match(/<button\b[\s\S]*?>/gi) || [];
    for (const tag of buttonTags) if (!/\btype\s*=\s*[\"']/i.test(tag)) failures.push(`${rel}: button without explicit type`);
  } else if (/<button(?![^>]*\btype=)[^>]*>/i.test(source)) {
    failures.push(`${rel}: button without explicit type`);
  }
  for (const tag of source.match(/<img\b[\s\S]*?>/gi) || []) {
    if (!/\balt\s*=/i.test(tag)) failures.push(`${rel}: img without alt`);
  }
  for (const tag of source.match(/<iframe\b[\s\S]*?>/gi) || []) {
    if (!/\btitle\s*=/i.test(tag)) failures.push(`${rel}: iframe without title`);
  }
  for (const tag of source.match(/<a\b[\s\S]*?>/gi) || []) {
    if (/\btarget\s*=\s*[\"']_blank[\"']/i.test(tag) && !/\brel\s*=\s*[\"'][^\"']*noopener/i.test(tag)) failures.push(`${rel}: target=_blank link missing noopener`);
  }
  if (retiredGamePattern.test(source)) {
    failures.push(`${rel}: retired Tic-Tac-Toe references detected`);
  }
}

const vite = fs.readFileSync(path.join(root, 'vite.config.ts'), 'utf8');
if (vite.includes('__dirname')) failures.push('vite.config.ts: __dirname is not ESM-safe');

const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
for (const forbidden of ['html2canvas', 'tailwind-merge']) {
  if (pkg.dependencies?.[forbidden] || pkg.devDependencies?.[forbidden]) {
    failures.push(`package.json: unused dependency still present: ${forbidden}`);
  }
}

const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
if (!/viewport-fit=cover/.test(html)) failures.push('index.html: viewport-fit=cover missing');

for (const file of allProjectFiles) {
  const rel = path.relative(root, file);
  if (/\.(?:tsx?|jsx?|mjs|cjs|json|css|html|md)$/.test(file)) {
    const source = fs.readFileSync(file, 'utf8');
    const historical = /(?:REPORT|README|CONTINUITY|REMOVAL_DUZE|FINAL_RELEASE)/i.test(rel) || rel === 'scripts/qa.mjs' || rel === 'scripts/release-structural-smoke.mjs';
    if (!historical && retiredGamePattern.test(source)) failures.push(`${rel}: retired Tic-Tac-Toe references detected`);
  }
}

if (failures.length) {
  console.error('QA FAILED');
  for (const failure of failures) console.error(`- ${failure}`);
  process.exit(1);
}

console.log(`QA PASS — ${files.length} source files scanned.`);
