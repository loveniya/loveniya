import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { Memory, Pledge, Dream, Music, Capsule, TrashItem, SyncStatus } from './types';
import { apiFetch, dataApi } from './api';

interface StoreContextType {
  memories: Memory[];
  pledges: Pledge[];
  dreams: Dream[];
  playlist: Music[];
  capsules: Capsule[];
  trashItems: TrashItem[];
  letterContent: string;
  syncStatus: SyncStatus;
  syncError: string | null;
  isInitialLoading: boolean;
  addMemory: (m: Memory) => void;
  updateMemory: (m: Memory) => void;
  removeMemory: (id: string) => void;
  addPledge: (p: Pledge) => void;
  updatePledge: (p: Pledge) => void;
  removePledge: (id: string) => void;
  addDream: (d: Dream) => void;
  updateDream: (d: Dream) => void;
  removeDream: (id: string) => void;
  addMusic: (m: Music) => void;
  updateMusic: (m: Music) => void;
  removeMusic: (id: string) => void;
  addCapsule: (c: Capsule) => void;
  updateCapsule: (c: Capsule) => void;
  removeCapsule: (id: string) => void;
  setLetterContent: (text: string) => void;
  moveToTrash: (type: TrashItem['type'], item: any) => void;
  emptyTrash: () => void;
  restoreFromTrash: (trashId: string) => void;
  permanentlyDeleteFromTrash: (trashId: string) => void;
}

const StoreContext = createContext<StoreContextType | null>(null);


type PendingWrite = {
  id: string;
  path: string;
  targetPath: string;
  localKey: string;
  method: 'PUT' | 'DELETE';
  itemId?: string;
  createdAt: number;
};

const OUTBOX_KEY = 'loveniya_sync_outbox_v2';
const MAX_PENDING_WRITES = 1000;
const inMemoryPendingWrites = new Map<string, PendingWrite>();
const inMemoryPendingBodies = new Map<string, unknown>();

function readPendingWrites(): PendingWrite[] {
  const merged = new Map<string, PendingWrite>();
  try {
    const raw = localStorage.getItem(OUTBOX_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        for (const item of parsed) {
          if (item && item.id && item.path && item.targetPath && item.localKey) merged.set(item.id, item);
        }
      }
    }
  } catch {}
  for (const [id, write] of inMemoryPendingWrites) merged.set(id, write);
  return [...merged.values()].sort((a, b) => a.createdAt - b.createdAt);
}

function writePendingWrites(items: PendingWrite[]) {
  try {
    localStorage.setItem(OUTBOX_KEY, JSON.stringify(items.slice(-MAX_PENDING_WRITES)));
  } catch {
    // Local storage may be unavailable or full; the in-memory write queue still protects the current session.
  }
}

function enqueuePendingWrite(write: Omit<PendingWrite, 'id' | 'createdAt'>): string {
  const id = `${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;
  const next: PendingWrite = { ...write, id, createdAt: Date.now() };
  for (const [queuedId, queued] of inMemoryPendingWrites) {
    if (queued.targetPath === write.targetPath) {
      inMemoryPendingWrites.delete(queuedId);
      inMemoryPendingBodies.delete(queuedId);
    }
  }
  inMemoryPendingWrites.set(id, next);
  const items = readPendingWrites().filter(item => item.targetPath !== write.targetPath && item.id !== id);
  items.push(next);
  writePendingWrites(items);
  return id;
}

function removePendingWrite(id: string) {
  inMemoryPendingWrites.delete(id);
  inMemoryPendingBodies.delete(id);
  writePendingWrites(readPendingWrites().filter(item => item.id !== id));
}

function readBodyForPendingWrite(write: PendingWrite): unknown {
  if (write.method === 'DELETE') return undefined;
  if (inMemoryPendingBodies.has(write.id)) return inMemoryPendingBodies.get(write.id);
  try {
    const raw = localStorage.getItem(write.localKey);
    if (raw == null) return undefined;
    const data = JSON.parse(raw);
    if (write.itemId !== undefined) {
      const arr = Array.isArray(data) ? data : Object.values(data || {});
      return arr.find((item: any) => item?.id === write.itemId || item?.trashId === write.itemId);
    }
    return Array.isArray(data)
      ? Object.fromEntries(data.filter(Boolean).map((item: any) => [item?.id ?? item?.trashId, item]).filter(([key]) => Boolean(key)))
      : data;
  } catch {
    return undefined;
  }
}

export const useStore = () => {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error('useStore must be used within StoreProvider');
  return ctx;
};

export const StoreProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const load = <T,>(key: string, def: T): T => {
    try {
      const stored = localStorage.getItem(key);
      return stored ? JSON.parse(stored) : def;
    } catch {
      return def;
    }
  };

  const [memories, setMemoriesState] = useState<Memory[]>(() => load('loveniya_mems', []));
  const [pledges, setPledgesState] = useState<Pledge[]>(() => load('loveniya_plg', []));
  const [dreams, setDreamsState] = useState<Dream[]>(() => load('loveniya_dreams', []));
  const [playlist, setPlaylistState] = useState<Music[]>(() => load('loveniya_msc', []));
  const [capsules, setCapsulesState] = useState<Capsule[]>(() => load('loveniya_capsules', []));
  const [trashItems, setTrashItemsState] = useState<TrashItem[]>(() => load('loveniya_trash', []));
  const [letterContent, setLetterContentState] = useState<string>(() => {
    return localStorage.getItem('loveniya_letter') || '';
  });

  // refهایی که همیشه آخرین state رو منعکس می‌کنن — چه از طریق setXXX پایین
  // تغییر کرده باشه چه از طریق fetchAllData/localStorage. بدون این‌ها
  // مجبور بودیم safeSet (یه درخواست شبکه واقعی) رو داخل تابع آپدیتِ
  // setState صدا بزنیم که در React StrictMode (توی dev) دوبار اجرا می‌شه —
  // یعنی هر افزودن/ویرایش/حذف، درخواست شبکه رو دوبار می‌فرستاد.
  const memoriesRef = React.useRef(memories);
  const pledgesRef = React.useRef(pledges);
  const dreamsRef = React.useRef(dreams);
  const playlistRef = React.useRef(playlist);
  const capsulesRef = React.useRef(capsules);
  const trashItemsRef = React.useRef(trashItems);
  useEffect(() => { memoriesRef.current = memories; }, [memories]);
  useEffect(() => { pledgesRef.current = pledges; }, [pledges]);
  useEffect(() => { dreamsRef.current = dreams; }, [dreams]);
  useEffect(() => { playlistRef.current = playlist; }, [playlist]);
  useEffect(() => { capsulesRef.current = capsules; }, [capsules]);
  useEffect(() => { trashItemsRef.current = trashItems; }, [trashItems]);

  const [syncStatus, setSyncStatus] = useState<SyncStatus>('syncing');
  const [syncError, setSyncError] = useState<string | null>(null);
  const [isInitialLoading, setIsInitialLoading] = useState<boolean>(true);

  // نگهداری زمان آخرین تغییر محلی برای هر کلید تا پاسخی از سرور نتواند تغییرات را موقتاً بازگرداند
  const mutatedAtRef = React.useRef<Record<string, number>>({});
  const consecutiveFailuresRef = React.useRef<number>(0);
  const writeQueueRef = React.useRef<Map<string, Promise<void>>>(new Map());
  const fetchInFlightRef = React.useRef<Promise<void> | null>(null);

  const sendPendingWrite = useCallback(async (write: PendingWrite) => {
    const bodyData = readBodyForPendingWrite(write);
    if (write.method === 'PUT' && bodyData === undefined) throw new Error('داده‌ی همگام‌سازی‌شده در دسترس نیست.');
    const res = await apiFetch(dataApi(write.targetPath), {
      method: write.method,
      body: bodyData === undefined ? undefined : JSON.stringify(bodyData),
    });
    if (res.status === 401) throw new Error('نشست ورود منقضی شده است؛ دوباره وارد شوید.');
    if (!res.ok) {
      const detail = await res.text().catch(() => '');
      throw new Error(detail || `خطای HTTP: ${res.status}`);
    }
  }, []);

  const flushOutbox = useCallback(async () => {
    const pending = readPendingWrites();
    for (const write of pending) {
      try {
        await sendPendingWrite(write);
        removePendingWrite(write.id);
      } catch (error) {
        throw error;
      }
    }
  }, [sendPendingWrite]);

  const safeSet = useCallback(async (path: string, localKey: string, data: any, itemId?: string, itemData?: any) => {
    mutatedAtRef.current[path] = Date.now();
    try {
      localStorage.setItem(localKey, typeof data === 'string' ? data : JSON.stringify(data));
    } catch {}

    let targetPath = path;
    let method: 'PUT' | 'DELETE' = 'PUT';
    if (itemId !== undefined) {
      targetPath = `${path}/${encodeURIComponent(itemId)}`;
      if (itemData === null) method = 'DELETE';
    }

    const writeId = enqueuePendingWrite({ path, targetPath, localKey, method, itemId });
    const bodyForQueue = method === 'PUT'
      ? (itemId !== undefined ? itemData : data)
      : undefined;
    if (method === 'PUT' && bodyForQueue !== undefined) inMemoryPendingBodies.set(writeId, bodyForQueue);
    const previous = writeQueueRef.current.get(path) || Promise.resolve();
    const current = previous.catch(() => undefined).then(async () => {
      setSyncStatus('syncing');
      await sendPendingWrite({ id: writeId, path, targetPath, localKey, method, itemId, createdAt: Date.now() });
      removePendingWrite(writeId);
    }).then(() => {
      consecutiveFailuresRef.current = 0;
      setSyncStatus('connected');
      setSyncError(null);
    }).catch((err: any) => {
      consecutiveFailuresRef.current += 1;
      setSyncStatus('error');
      setSyncError(err?.message || 'خطا در همگام‌سازی.');
    }).finally(() => {
      if (writeQueueRef.current.get(path) === current) writeQueueRef.current.delete(path);
    });
    writeQueueRef.current.set(path, current);
    await current;
  }, [sendPendingWrite]);

  // دریافت تمام اطلاعات از دیتابیس بدون نیاز به وب‌سوکت با ادغام هوشمند جهت عدم از دست رفتن داده‌ها
  const fetchAllData = useCallback(async () => {
    if (fetchInFlightRef.current) return fetchInFlightRef.current;

    const run = (async () => {
      const isRecentlyMutated = (key: string) => {
        if (readPendingWrites().some(write => write.path === key)) return true;
        const lastMutated = mutatedAtRef.current[key] || 0;
        return Date.now() - lastMutated < 15000;
      };

      try {
        const pendingPaths = new Set(readPendingWrites().map(write => write.path));
        if (pendingPaths.size > 0) {
          try {
            await flushOutbox();
          } catch (err: any) {
            consecutiveFailuresRef.current += 1;
            setSyncStatus('error');
            setSyncError(err?.message || 'برخی تغییرات هنوز همگام نشده‌اند.');
          }
        }

        const t = Date.now();
        const requests = [
          ['loveniya_mems', apiFetch(`${dataApi('loveniya_mems')}?_t=${t}`)],
          ['loveniya_plg', apiFetch(`${dataApi('loveniya_plg')}?_t=${t}`)],
          ['loveniya_dreams', apiFetch(`${dataApi('loveniya_dreams')}?_t=${t}`)],
          ['loveniya_msc', apiFetch(`${dataApi('loveniya_msc')}?_t=${t}`)],
          ['loveniya_capsules', apiFetch(`${dataApi('loveniya_capsules')}?_t=${t}`)],
          ['loveniya_trash', apiFetch(`${dataApi('loveniya_trash')}?_t=${t}`)],
          ['loveniya_letter', apiFetch(`${dataApi('loveniya_letter')}?_t=${t}`)],
        ] as const;
        const settled = await Promise.allSettled(requests.map(([, promise]) => promise));

        let successful = 0;
        let failed = 0;
        let unauthorized = false;

        for (let index = 0; index < settled.length; index++) {
          const [key] = requests[index];
          const result = settled[index];
          if (result.status === 'rejected') {
            failed += 1;
            continue;
          }
          const response = result.value;
          if (response.status === 401) unauthorized = true;
          if (!response.ok) {
            failed += 1;
            continue;
          }

          successful += 1;
          if (isRecentlyMutated(key)) continue;

          try {
            const data = await response.json();
            if (key === 'loveniya_mems') {
              const arr = data ? (Array.isArray(data) ? data : Object.values(data)) : [];
              setMemoriesState(arr as Memory[]);
              try { localStorage.setItem('loveniya_mems', JSON.stringify(arr)); } catch {}
            } else if (key === 'loveniya_plg') {
              const arr = data ? (Array.isArray(data) ? data : Object.values(data)) : [];
              setPledgesState(arr as Pledge[]);
              try { localStorage.setItem('loveniya_plg', JSON.stringify(arr)); } catch {}
            } else if (key === 'loveniya_dreams') {
              const arr = data ? (Array.isArray(data) ? data : Object.values(data)) : [];
              setDreamsState(arr as Dream[]);
              try { localStorage.setItem('loveniya_dreams', JSON.stringify(arr)); } catch {}
            } else if (key === 'loveniya_msc') {
              const arr = data ? (Array.isArray(data) ? data : Object.values(data)) : [];
              setPlaylistState(arr as Music[]);
              try { localStorage.setItem('loveniya_msc', JSON.stringify(arr)); } catch {}
            } else if (key === 'loveniya_capsules') {
              const arr = data ? (Array.isArray(data) ? data : Object.values(data)) : [];
              setCapsulesState(arr as Capsule[]);
              try { localStorage.setItem('loveniya_capsules', JSON.stringify(arr)); } catch {}
            } else if (key === 'loveniya_trash') {
              let arr = data ? (Array.isArray(data) ? data : Object.values(data)) : [];
              arr = arr.filter((x: any) => x && x.trashId);
              setTrashItemsState(arr as TrashItem[]);
              try { localStorage.setItem('loveniya_trash', JSON.stringify(arr)); } catch {}
            } else if (key === 'loveniya_letter') {
              const text = typeof data === 'string' && data.trim().length > 0 ? data : '';
              setLetterContentState(text);
              try { localStorage.setItem('loveniya_letter', text); } catch {}
            }
          } catch {
            failed += 1;
          }
        }

        if (unauthorized) throw new Error('نشست ورود منقضی شده است؛ دوباره وارد شوید.');
        if (successful === 0 && failed > 0) throw new Error('ارتباط با سرور برقرار نشد.');

        consecutiveFailuresRef.current = failed === settled.length ? consecutiveFailuresRef.current + 1 : 0;
        setSyncStatus(failed > 0 ? 'error' : 'connected');
        setSyncError(failed > 0 ? `${failed} بخش موقتاً همگام نشد؛ تلاش دوباره ادامه دارد.` : null);
      } catch (err: any) {
        consecutiveFailuresRef.current += 1;
        setSyncStatus('error');
        setSyncError(err?.message || 'خطا در ارتباط با سرور.');
      }
    })();

    fetchInFlightRef.current = run;
    try {
      await run;
    } finally {
      if (fetchInFlightRef.current === run) fetchInFlightRef.current = null;
    }
  }, [flushOutbox]);

  useEffect(() => {
    void fetchAllData().finally(() => setIsInitialLoading(false));

    let cancelled = false;
    let timeoutId: ReturnType<typeof setTimeout> | null = null;

    const scheduleNext = () => {
      if (cancelled) return;
      const delay = consecutiveFailuresRef.current >= 3 ? 20000 : 8000;
      timeoutId = setTimeout(async () => {
        if (cancelled) return;
        if (document.visibilityState === 'visible') await fetchAllData();
        scheduleNext();
      }, delay);
    };

    const handleVisibility = () => {
      if (document.visibilityState === 'visible') void fetchAllData();
    };
    document.addEventListener('visibilitychange', handleVisibility);
    scheduleNext();

    return () => {
      cancelled = true;
      if (timeoutId) clearTimeout(timeoutId);
      document.removeEventListener('visibilitychange', handleVisibility);
    };
  }, [fetchAllData]);

  const setMemories = (v: Memory[] | ((prev: Memory[]) => Memory[]), itemId?: string, itemData?: any) => {
    const next = typeof v === 'function' ? (v as (p: Memory[]) => Memory[])(memoriesRef.current) : v;
    memoriesRef.current = next;
    setMemoriesState(next);
    safeSet('loveniya_mems', 'loveniya_mems', next, itemId, itemData);
  };

  const setPledges = (v: Pledge[] | ((prev: Pledge[]) => Pledge[]), itemId?: string, itemData?: any) => {
    const next = typeof v === 'function' ? (v as (p: Pledge[]) => Pledge[])(pledgesRef.current) : v;
    pledgesRef.current = next;
    setPledgesState(next);
    safeSet('loveniya_plg', 'loveniya_plg', next, itemId, itemData);
  };

  const setDreams = (v: Dream[] | ((prev: Dream[]) => Dream[]), itemId?: string, itemData?: any) => {
    const next = typeof v === 'function' ? (v as (p: Dream[]) => Dream[])(dreamsRef.current) : v;
    dreamsRef.current = next;
    setDreamsState(next);
    safeSet('loveniya_dreams', 'loveniya_dreams', next, itemId, itemData);
  };

  const setPlaylist = (v: Music[] | ((prev: Music[]) => Music[]), itemId?: string, itemData?: any) => {
    const next = typeof v === 'function' ? (v as (p: Music[]) => Music[])(playlistRef.current) : v;
    playlistRef.current = next;
    setPlaylistState(next);
    safeSet('loveniya_msc', 'loveniya_msc', next, itemId, itemData);
  };

  const setCapsules = (v: Capsule[] | ((prev: Capsule[]) => Capsule[]), itemId?: string, itemData?: any) => {
    const next = typeof v === 'function' ? (v as (p: Capsule[]) => Capsule[])(capsulesRef.current) : v;
    capsulesRef.current = next;
    setCapsulesState(next);
    safeSet('loveniya_capsules', 'loveniya_capsules', next, itemId, itemData);
  };

  const setTrashItems = (v: TrashItem[] | ((prev: TrashItem[]) => TrashItem[]), itemId?: string, itemData?: any) => {
    const next = typeof v === 'function' ? (v as (p: TrashItem[]) => TrashItem[])(trashItemsRef.current) : v;
    trashItemsRef.current = next;
    setTrashItemsState(next);
    safeSet('loveniya_trash', 'loveniya_trash', next, itemId, itemData);
  };

  const handleSetLetterContent = (text: string) => {
    setLetterContentState(text);
    safeSet('loveniya_letter', 'loveniya_letter', text);
  };

  const moveToTrash = (type: TrashItem['type'], item: any) => {
    const trashObj: TrashItem = {
      trashId: 'trash_' + Date.now(),
      type,
      deletedAt: new Date().toLocaleDateString('fa-IR', { timeZone: 'Asia/Tehran' }),
      itemPayload: item
    };
    setTrashItems(prev => [trashObj, ...prev], trashObj.trashId, trashObj);
  };

  const restoreFromTrash = (trashId: string) => {
    const item = trashItems.find(t => t.trashId === trashId);
    if (!item) return;
    
    // Safely replace or append
    const safelyMerge = (arr: any[], newItem: any) => {
      const idx = arr.findIndex(x => x.id === newItem.id);
      if (idx !== -1) return arr.map(x => x.id === newItem.id ? newItem : x);
      return [...arr, newItem];
    };

    if (item.type === 'memory') setMemories(prev => safelyMerge(prev, item.itemPayload), item.itemPayload.id, item.itemPayload);
    if (item.type === 'pledge') setPledges(prev => safelyMerge(prev, item.itemPayload), item.itemPayload.id, item.itemPayload);
    if (item.type === 'dream') setDreams(prev => safelyMerge(prev, item.itemPayload), item.itemPayload.id, item.itemPayload);
    if (item.type === 'music') setPlaylist(prev => safelyMerge(prev, item.itemPayload), item.itemPayload.id, item.itemPayload);
    if (item.type === 'capsule') setCapsules(prev => safelyMerge(prev, item.itemPayload), item.itemPayload.id, item.itemPayload);
    
    setTrashItems(prev => prev.filter(t => t.trashId !== trashId), trashId, null);
  };

  const permanentlyDeleteFromTrash = (trashId: string) => {
    setTrashItems(prev => prev.filter(t => t.trashId !== trashId), trashId, null);
  };

  const emptyTrash = () => setTrashItems([]);

  const addMemory = (m: Memory) => setMemories(prev => [m, ...prev], m.id, m);
  const updateMemory = (m: Memory) => {
    setMemories(prev => prev.map(x => x.id === m.id ? m : x), m.id, m);
  };
  const removeMemory = (id: string) => {
    const item = memories.find(x => x.id === id);
    if (item) moveToTrash('memory', item);
    setMemories(prev => prev.filter(x => x.id !== id), id, null); // Scoped delete: only removes this item remotely, never overwrites the whole list
  };

  const addPledge = (p: Pledge) => setPledges(prev => [p, ...prev], p.id, p);
  const updatePledge = (p: Pledge) => {
    setPledges(prev => prev.map(x => x.id === p.id ? p : x), p.id, p);
  };
  const removePledge = (id: string) => {
    const item = pledges.find(x => x.id === id);
    if (item) moveToTrash('pledge', item);
    setPledges(prev => prev.filter(x => x.id !== id), id, null);
  };

  const addDream = (d: Dream) => setDreams(prev => [d, ...prev], d.id, d);
  const updateDream = (d: Dream) => {
    setDreams(prev => prev.map(x => x.id === d.id ? d : x), d.id, d);
  };
  const removeDream = (id: string) => {
    const item = dreams.find(x => x.id === id);
    if (item) moveToTrash('dream', item);
    setDreams(prev => prev.filter(x => x.id !== id), id, null);
  };

  const addMusic = (m: Music) => setPlaylist(prev => [m, ...prev], m.id, m);
  const updateMusic = (m: Music) => {
    setPlaylist(prev => prev.map(x => x.id === m.id ? m : x), m.id, m);
  };
  const removeMusic = (id: string) => {
    const item = playlist.find(x => x.id === id);
    if (item) moveToTrash('music', item);
    setPlaylist(prev => prev.filter(x => x.id !== id), id, null);
  };

  const addCapsule = (c: Capsule) => setCapsules(prev => [c, ...prev], c.id, c);
  const updateCapsule = (c: Capsule) => {
    setCapsules(prev => prev.map(x => x.id === c.id ? c : x), c.id, c);
  };
  const removeCapsule = (id: string) => {
    const item = capsules.find(x => x.id === id);
    if (item) moveToTrash('capsule', item);
    setCapsules(prev => prev.filter(x => x.id !== id), id, null);
  };

  return (
    <StoreContext.Provider value={{
      memories, pledges, dreams, playlist, capsules, trashItems, letterContent,
      syncStatus, syncError, isInitialLoading,
      addMemory, updateMemory, removeMemory,
      addPledge, updatePledge, removePledge,
      addDream, updateDream, removeDream,
      addMusic, updateMusic, removeMusic,
      addCapsule, updateCapsule, removeCapsule,
      setLetterContent: handleSetLetterContent,
      moveToTrash, emptyTrash, restoreFromTrash, permanentlyDeleteFromTrash
    }}>
      {children}
    </StoreContext.Provider>
  );
};