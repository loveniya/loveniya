import React, { useEffect, useRef, useState } from 'react';
import { Lock, Eye, EyeOff, AlertCircle, UserRound, Heart } from 'lucide-react';
import clsx from 'clsx';
import { unlock } from '../lib/api';

export const LockScreen: React.FC<{ onUnlock: () => void }> = ({ onUnlock }) => {
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState(false);
  const [selectedUser, setSelectedUser] = useState<'amin' | 'niyayesh' | null>(null);
  const [userError, setUserError] = useState(false);
  const [busy, setBusy] = useState(false);
  const passwordRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    passwordRef.current?.focus();
  }, []);

  const checkPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUser || busy) {
      setUserError(!selectedUser);
      return;
    }

    setBusy(true);
    setError(false);
    try {
      const user = await unlock(password, selectedUser);
      localStorage.setItem('loveniya_user', user);
      onUnlock();
    } catch {
      setError(true);
      setPassword('');
      passwordRef.current?.focus();
    } finally {
      setBusy(false);
    }
  };

  return (
    <div role="dialog" aria-modal="true" aria-labelledby="lock-title" className="fixed inset-0 z-[100] flex items-center justify-center px-5 py-8 bg-[#f7f2f8]" dir="rtl">
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute -top-20 -right-16 w-64 h-64 rounded-full bg-rose-200/35 blur-3xl" />
        <div className="absolute -bottom-24 -left-10 w-72 h-72 rounded-full bg-violet-200/35 blur-3xl" />
      </div>

      <div className="relative w-full max-w-[25rem] ui-surface px-5 py-6 sm:px-7 sm:py-8 text-center">
        <div className="mx-auto mb-4 w-14 h-14 rounded-2xl flex items-center justify-center text-white bg-gradient-to-br from-rose-500 to-violet-500 shadow-[0_14px_30px_rgba(189,66,111,0.22)]">
          <Lock className="w-6 h-6" />
        </div>

        <div className="flex items-center justify-center gap-1.5 text-[11px] font-black text-rose-600 mb-2">
          <Heart className="w-3.5 h-3.5 fill-current" />
          <span>ورود امن</span>
        </div>
        <h2 id="lock-title" className="text-xl sm:text-2xl font-black text-stone-900 tracking-tight">جهان ما</h2>
        <p className="mt-1.5 text-xs font-bold leading-relaxed text-stone-500">اول خودت را انتخاب کن، بعد رمز ورود را وارد کن.</p>

        <form onSubmit={checkPassword} className="mt-6 space-y-3.5">
          <div className="grid grid-cols-2 gap-2.5" aria-label="انتخاب کاربر">
            {([
              ['amin', 'امین'],
              ['niyayesh', 'نیایش'],
            ] as const).map(([id, label]) => {
              const active = selectedUser === id;
              return (
                <button
                  key={id}
                  type="button"
                  onClick={() => { setSelectedUser(id); setUserError(false); setError(false); }}
                  className={clsx(
                    'min-h-[3rem] rounded-xl border text-sm font-black transition-all flex items-center justify-center gap-2',
                    active
                      ? 'border-rose-300 bg-rose-50 text-rose-700 shadow-sm'
                      : 'border-stone-200 bg-white text-stone-500 hover:bg-stone-50'
                  )}
                  aria-pressed={active}
                >
                  <UserRound className="w-4 h-4" />
                  {label}
                </button>
              );
            })}
          </div>

          {userError && <p role="alert" className="text-[11px] font-bold text-rose-600">ابتدا یکی از دو کاربر را انتخاب کن.</p>}

          <div className="relative">
            <label htmlFor="lock-password" className="sr-only">رمز عبور</label>
            <input
              id="lock-password"
              ref={passwordRef}
              type={showPassword ? 'text' : 'password'}
              value={password}
              autoComplete="current-password"
              onChange={e => { setPassword(e.target.value); setError(false); }}
              placeholder="رمز عبور"
              className="w-full h-12 rounded-xl bg-white border border-stone-200 px-12 pr-4 text-center text-sm font-bold text-stone-800 placeholder:text-stone-400 focus:border-rose-300 focus:ring-2 focus:ring-rose-100 focus:outline-none"
            />
            <button
              type="button"
              onClick={() => setShowPassword(prev => !prev)}
              aria-label={showPassword ? 'مخفی کردن رمز' : 'نمایش رمز'}
              aria-pressed={showPassword}
              className="absolute left-2 top-2 w-8 h-8 rounded-lg text-stone-400 hover:text-rose-500 hover:bg-rose-50 flex items-center justify-center"
            >
              {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>

          {error && (
            <div role="alert" className="flex items-center justify-center gap-1.5 text-[11px] text-rose-600 font-bold">
              <AlertCircle className="w-3.5 h-3.5" />
              <span>رمز عبور درست نیست.</span>
            </div>
          )}

          <button
            type="submit"
            disabled={busy || !selectedUser || !password}
            aria-busy={busy}
            className="w-full h-12 rounded-xl bg-gradient-to-r from-rose-500 to-violet-500 text-white text-sm font-black shadow-[0_12px_24px_rgba(189,66,111,0.2)] disabled:opacity-45 disabled:cursor-not-allowed transition-all active:scale-[0.99]"
          >
            {busy ? 'در حال بررسی…' : 'ورود'}
          </button>
        </form>
      </div>
    </div>
  );
};
