import React, { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import { 
  Play, Pause, Volume2, VolumeX, Maximize, Minimize, 
  AlertCircle, Loader2, Gauge, RotateCcw, RotateCw, Tv, 
  ExternalLink
} from 'lucide-react';
import { sanitizeHttpUrl, isHost } from '../lib/urls';

interface BuiltInVideoPlayerProps {
  url: string;
  title?: string;
  className?: string;
}

interface ProcessedVideo {
  isEmbed: boolean;
  embedUrl: string;
  directUrl: string;
  hostName: string;
}

function processVideoUrl(rawUrl: string): ProcessedVideo {
  const safeUrl = sanitizeHttpUrl(rawUrl);
  if (!safeUrl) return { isEmbed: false, embedUrl: '', directUrl: '', hostName: '' };

  const parsed = new URL(safeUrl);
  const hostname = parsed.hostname.toLowerCase();

  // YouTube
  if (hostname === 'youtu.be' || isHost(parsed, ['youtube.com'])) {
    const id = hostname === 'youtu.be'
      ? parsed.pathname.split('/').filter(Boolean)[0]
      : parsed.searchParams.get('v') || parsed.pathname.match(/\/embed\/([^/]+)/)?.[1] || parsed.pathname.match(/\/shorts\/([^/]+)/)?.[1];
    if (id && /^[A-Za-z0-9_-]{11}$/.test(id)) {
      return { isEmbed: true, embedUrl: `https://www.youtube.com/embed/${id}?autoplay=0&rel=0&modestbranding=1`, directUrl: '', hostName: 'YouTube' };
    }
  }

  // Aparat
  if (isHost(parsed, ['aparat.com'])) {
    const id = parsed.pathname.match(/\/v\/([A-Za-z0-9]+)/)?.[1];
    if (id) return { isEmbed: true, embedUrl: `https://www.aparat.com/video/video/embed/videohash/${id}/vt/frame`, directUrl: '', hostName: 'آپارات' };
  }

  // 7Upload
  if (isHost(parsed, ['7upload.com'])) {
    let path = parsed.pathname;
    if (path.includes('/view/')) path = path.replace('/view/', '/uploads/');
    const direct = new URL(path + parsed.search + parsed.hash, parsed.origin).href.replace(/\/+$/, '');
    return { isEmbed: false, embedUrl: '', directUrl: direct, hostName: '7Upload' };
  }

  // Google Drive
  if (hostname === 'drive.google.com') {
    const id = parsed.pathname.match(/\/d\/([A-Za-z0-9_-]+)/)?.[1];
    if (id) return { isEmbed: false, embedUrl: '', directUrl: `https://drive.google.com/uc?export=download&id=${encodeURIComponent(id)}`, hostName: 'Google Drive' };
  }

  // Dropbox
  if (isHost(parsed, ['dropbox.com', 'dropboxusercontent.com'])) {
    if (hostname === 'www.dropbox.com') parsed.hostname = 'dl.dropboxusercontent.com';
    parsed.searchParams.set('raw', '1');
    parsed.searchParams.delete('dl');
    return { isEmbed: false, embedUrl: '', directUrl: parsed.href, hostName: 'Dropbox' };
  }

  return { isEmbed: false, embedUrl: '', directUrl: safeUrl, hostName: 'ویدیو' };
}


export const BuiltInVideoPlayer: React.FC<BuiltInVideoPlayerProps> = ({ url, title, className = '' }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const processed = useMemo(() => processVideoUrl(url), [url]);

  const [playing, setPlaying] = useState(false);
  const [volume, setVolume] = useState(0.9);
  const [muted, setMuted] = useState(false);
  const [played, setPlayed] = useState(0);
  const [duration, setDuration] = useState(0);
  const [seeking, setSeeking] = useState(false);
  const [playbackRate, setPlaybackRate] = useState(1);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const [isReady, setIsReady] = useState(false);
  const [hasError, setHasError] = useState(false);
  const [showSpeedMenu, setShowSpeedMenu] = useState(false);

  // Gesture indicators (-10s / +10s / Play-Pause Flash)
  const [seekFeedback, setSeekFeedback] = useState<'rewind' | 'forward' | 'play' | 'pause' | null>(null);
  const lastTapRef = useRef<{ time: number; x: number }>({ time: 0, x: 0 });
  const controlsTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const feedbackTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const tapTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Reset state on URL change
  useEffect(() => {
    setIsReady(false);
    setHasError(false);
    setPlayed(0);
    setPlaying(false);
  }, [url]);

  // Sync state with HTML5 video element
  useEffect(() => {
    const video = videoRef.current;
    if (!video || processed.isEmbed) return;

    if (playing) {
      video.play().catch((err) => {
        console.warn("Video play error:", err);
        setPlaying(false);
      });
    } else {
      video.pause();
    }
  }, [playing, processed.directUrl, processed.isEmbed]);

  useEffect(() => {
    if (videoRef.current && !processed.isEmbed) {
      videoRef.current.volume = volume;
      videoRef.current.muted = muted;
    }
  }, [volume, muted, processed.isEmbed]);

  useEffect(() => {
    if (videoRef.current && !processed.isEmbed) {
      videoRef.current.playbackRate = playbackRate;
    }
  }, [playbackRate, processed.isEmbed]);

  // Trigger temporary feedback animation overlay
  const triggerFeedback = (type: 'rewind' | 'forward' | 'play' | 'pause') => {
    setSeekFeedback(type);
    if (feedbackTimeoutRef.current) clearTimeout(feedbackTimeoutRef.current);
    feedbackTimeoutRef.current = setTimeout(() => {
      setSeekFeedback(null);
    }, 600);
  };

  // Auto-hide controls during playback
  const handleMouseMove = () => {
    setShowControls(true);
    if (controlsTimeoutRef.current) clearTimeout(controlsTimeoutRef.current);
    if (playing) {
      controlsTimeoutRef.current = setTimeout(() => {
        setShowControls(false);
        setShowSpeedMenu(false);
      }, 3000);
    }
  };

  useEffect(() => {
    return () => {
      if (controlsTimeoutRef.current) clearTimeout(controlsTimeoutRef.current);
      if (feedbackTimeoutRef.current) clearTimeout(feedbackTimeoutRef.current);
      if (tapTimeoutRef.current) clearTimeout(tapTimeoutRef.current);
    };
  }, []);

  const togglePlay = useCallback(() => {
    setPlaying((prev) => {
      const next = !prev;
      triggerFeedback(next ? 'play' : 'pause');
      return next;
    });
  }, []);

  // Jump seek +/- 10 seconds
  const jumpSeconds = useCallback((seconds: number) => {
    if (!videoRef.current) return;
    const newTime = Math.min(Math.max(0, videoRef.current.currentTime + seconds), duration);
    videoRef.current.currentTime = newTime;
    if (duration > 0) {
      setPlayed(newTime / duration);
    }
    triggerFeedback(seconds < 0 ? 'rewind' : 'forward');
  }, [duration]);

  // Handle double tap or click on video sides
  const handleCanvasClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const now = Date.now();
    const rect = e.currentTarget.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const width = rect.width;

    // Double click / tap detection (within 300ms)
    if (now - lastTapRef.current.time < 300) {
      if (clickX < width * 0.35) {
        jumpSeconds(-10);
      } else if (clickX > width * 0.65) {
        jumpSeconds(10);
      } else {
        togglePlay();
      }
      lastTapRef.current = { time: 0, x: 0 };
      return;
    }

    lastTapRef.current = { time: now, x: clickX };

    if (tapTimeoutRef.current) clearTimeout(tapTimeoutRef.current);
    tapTimeoutRef.current = setTimeout(() => {
      if (lastTapRef.current.time === now) togglePlay();
    }, 300);
  };

  const handleSeekChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setPlayed(val);
  };

  const handleSeekMouseDown = () => {
    setSeeking(true);
  };

  const handleSeekMouseUp = (e: React.SyntheticEvent<HTMLInputElement>) => {
    setSeeking(false);
    const target = e.currentTarget;
    const val = parseFloat(target.value);
    setPlayed(val);
    if (videoRef.current && duration > 0) {
      videoRef.current.currentTime = val * duration;
    }
  };

  const toggleMute = () => {
    setMuted(!muted);
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setVolume(val);
    setMuted(val === 0);
  };

  const toggleFullscreen = () => {
    if (!containerRef.current) return;

    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen().then(() => setIsFullscreen(true)).catch(err => {
        console.error("Fullscreen error:", err);
      });
    } else {
      document.exitFullscreen().then(() => setIsFullscreen(false)).catch(err => {
        console.error("Exit fullscreen error:", err);
      });
    }
  };

  const togglePictureInPicture = async () => {
    if (!videoRef.current) return;
    try {
      if (document.pictureInPictureElement) {
        await document.exitPictureInPicture();
      } else if (document.pictureInPictureEnabled) {
        await videoRef.current.requestPictureInPicture();
      }
    } catch (err) {
      console.warn("PiP Error:", err);
    }
  };

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  const formatTime = (seconds: number) => {
    if (isNaN(seconds) || seconds < 0) return '00:00';
    const date = new Date(seconds * 1000);
    const hh = date.getUTCHours();
    const mm = date.getUTCMinutes();
    const ss = date.getUTCSeconds().toString().padStart(2, '0');
    if (hh) {
      return `${hh}:${mm.toString().padStart(2, '0')}:${ss}`;
    }
    return `${mm.toString().padStart(2, '0')}:${ss}`;
  };

  const speedOptions = [0.5, 0.75, 1, 1.25, 1.5, 2];

  const currentTimeStr = formatTime(played * duration);
  const totalTimeStr = formatTime(duration);

  // If pure video embed (YouTube / Aparat)
  if (processed.isEmbed && processed.embedUrl) {
    return (
      <div 
        ref={containerRef}
        className={`relative bg-stone-950 rounded-3xl overflow-hidden shadow-2xl aspect-video border border-rose-900/30 group ${className}`}
        dir="ltr"
      >
        <iframe
          src={processed.embedUrl}
          title={title || "Video Player"}
          className="w-full h-full border-0"
          allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
        />
      </div>
    );
  }

  return (
    <div 
      ref={containerRef}
      onMouseMove={handleMouseMove}
      onTouchStart={handleMouseMove}
      className={`relative group bg-stone-950 rounded-3xl overflow-hidden shadow-2xl aspect-video flex items-center justify-center border border-stone-800 ${
        playing ? 'shadow-rose-900/20 shadow-2xl' : ''
      } ${className}`}
      dir="ltr"
    >
      {/* Background Subtle Gradient Glow */}
      <div className="absolute inset-0 bg-gradient-to-tr from-rose-950/20 via-transparent to-sky-950/20 pointer-events-none" />

      {!isReady && !hasError && (
        <div className="absolute inset-0 z-10 flex flex-col items-center justify-center bg-stone-900/95 text-white gap-3 pointer-events-none backdrop-blur-sm">
          <Loader2 className="w-9 h-9 animate-spin text-rose-500" />
          <span className="text-xs font-bold text-stone-300">درحال دریافت و پخش ویدیو...</span>
        </div>
      )}

      {hasError ? (
        <div className="absolute inset-0 z-10 flex flex-col items-center justify-center bg-stone-900/95 text-stone-300 p-6 text-center gap-3">
          <AlertCircle className="w-10 h-10 text-rose-500" />
          <div>
            <p className="text-sm font-black text-white mb-1">امکان پخش مستقیم این ویدیو در مرورگر وجود ندارد</p>
            <p className="text-xs text-stone-400 max-w-sm leading-relaxed">
              سرور فایل اجازه پخش درون‌برنامه‌ای را نمی‌دهد یا فرمت ویدیو نیازمند دانلود است.
            </p>
          </div>
          <div className="flex items-center gap-2 mt-2">
            <a 
              href={processed.directUrl || sanitizeHttpUrl(url)} 
              target="_blank" 
              rel="noopener noreferrer" 
              className="text-xs font-bold bg-rose-600 hover:bg-rose-500 text-white px-5 py-2.5 rounded-full transition-[color,background-color,border-color,box-shadow,transform] shadow-lg shadow-rose-600/30 flex items-center gap-1.5"
            >
              <ExternalLink className="w-4 h-4" />
              <span>باز کردن یا دانلود مستقیم</span>
            </a>
          </div>
        </div>
      ) : (
        <video
          ref={videoRef}
          src={processed.directUrl}
          playsInline
          preload="metadata"
          aria-label={title || 'ویدیو'}
          className="w-full h-full object-contain"
          onLoadedMetadata={(e) => {
            setIsReady(true);
            setDuration(e.currentTarget.duration || 0);
          }}
          onTimeUpdate={(e) => {
            if (!seeking && e.currentTarget.duration) {
              setPlayed(e.currentTarget.currentTime / e.currentTarget.duration);
            }
          }}
          onEnded={() => setPlaying(false)}
          onError={() => {
            console.warn("Video load error for direct URL:", processed.directUrl);
            setHasError(true);
          }}
        />
      )}

      {/* Touch / Click Interactive Canvas Layer */}
      {isReady && !hasError && (
        <div 
          onClick={handleCanvasClick}
          className="absolute inset-0 z-20 cursor-pointer flex items-center justify-center select-none"
        >
          {/* Center Play/Pause Floating Play Badge when paused or hovered */}
          {(!playing || showControls) && !seekFeedback && (
            <div className={`w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-rose-600/90 hover:bg-rose-600 text-white flex items-center justify-center shadow-2xl backdrop-blur-md transition-[color,background-color,border-color,box-shadow,transform] transform ${playing ? 'scale-90 opacity-75' : 'scale-100 opacity-100 hover:scale-105'}`}>
              {playing ? <Pause className="w-8 h-8 fill-white" /> : <Play className="w-8 h-8 fill-white ml-1" />}
            </div>
          )}

          {/* Gesture Feedback Animations (-10s / +10s / Play / Pause) */}
          {seekFeedback === 'rewind' && (
            <div className="absolute left-8 bg-black/80 text-white px-4 py-3 rounded-2xl flex items-center gap-2 backdrop-blur-md border border-white/20 animate-ping-once text-sm font-black shadow-2xl">
              <RotateCcw className="w-5 h-5 text-rose-400" />
              <span>۱۰ ثانیه قبل</span>
            </div>
          )}

          {seekFeedback === 'forward' && (
            <div className="absolute right-8 bg-black/80 text-white px-4 py-3 rounded-2xl flex items-center gap-2 backdrop-blur-md border border-white/20 animate-ping-once text-sm font-black shadow-2xl">
              <span>۱۰ ثانیه بعد</span>
              <RotateCw className="w-5 h-5 text-rose-400" />
            </div>
          )}
        </div>
      )}

      {/* Top Title Overlay Bar */}
      {title && showControls && isReady && !hasError && (
        <div className="absolute top-0 left-0 right-0 z-30 p-4 bg-gradient-to-b from-black/90 via-black/50 to-transparent text-white flex items-center justify-between transition-opacity duration-300 pointer-events-none">
          <div className="flex items-center gap-2" dir="rtl">
            
            <h4 className="text-xs sm:text-sm font-black truncate max-w-[80vw] text-stone-100">{title}</h4>
          </div>
        </div>
      )}

      {/* Bottom Custom Control Bar */}
      {showControls && isReady && !hasError && (
        <div 
          className="absolute bottom-0 left-0 right-0 z-30 p-3 sm:p-4 bg-gradient-to-t from-black/95 via-black/80 to-transparent text-white space-y-2 transition-opacity duration-300"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Timeline Slider with Hover Glow */}
          <div className="flex items-center gap-2 sm:gap-3">
            <span className="text-[11px] font-mono text-stone-300 w-11 text-right shrink-0">{currentTimeStr}</span>
            <div className="relative flex-1 flex items-center">
              <input
                type="range"
                min={0}
                max={0.999999}
                step="any"
                value={played}
                aria-label="موقعیت ویدیو"
                onChange={handleSeekChange}
                onMouseDown={handleSeekMouseDown}
                onMouseUp={handleSeekMouseUp}
                onTouchStart={handleSeekMouseDown}
                onTouchEnd={handleSeekMouseUp}
                className="w-full h-2 bg-white/20 rounded-lg appearance-none cursor-pointer accent-rose-500 hover:h-2.5 transition-[color,background-color,border-color,box-shadow,transform] shadow-inner"
              />
            </div>
            <span className="text-[11px] font-mono text-stone-400 w-11 text-left shrink-0">{totalTimeStr}</span>
          </div>

          {/* Control Buttons Row */}
          <div className="flex items-center justify-between pt-1">
            <div className="flex items-center gap-1.5 sm:gap-3">
              {/* Play / Pause Button */}
              <button type="button" 
                onClick={togglePlay}
                className="text-white hover:text-rose-400 transition-[color,background-color,border-color,box-shadow,transform] p-1.5 rounded-full hover:bg-white/10 active:scale-95"
                title={playing ? 'توقف' : 'پخش'}
              >
                {playing ? <Pause className="w-5 sm:w-6 h-5 sm:h-6 fill-current" /> : <Play className="w-5 sm:w-6 h-5 sm:h-6 fill-current" />}
              </button>

              {/* Jump -10s */}
              <button type="button"
                onClick={() => jumpSeconds(-10)}
                className="text-stone-300 hover:text-white transition-[color,background-color,border-color,box-shadow,transform] p-1.5 rounded-full hover:bg-white/10 active:scale-95 hidden sm:flex"
                title="۱۰ ثانیه قبل"
              >
                <RotateCcw className="w-4 h-4" />
              </button>

              {/* Jump +10s */}
              <button type="button"
                onClick={() => jumpSeconds(10)}
                className="text-stone-300 hover:text-white transition-[color,background-color,border-color,box-shadow,transform] p-1.5 rounded-full hover:bg-white/10 active:scale-95 hidden sm:flex"
                title="۱۰ ثانیه بعد"
              >
                <RotateCw className="w-4 h-4" />
              </button>

              {/* Volume & Mute */}
              <div className="flex items-center gap-1.5 group/vol ml-1 sm:ml-2">
                <button type="button" onClick={toggleMute} className="text-stone-300 hover:text-white transition-colors p-1 rounded-full hover:bg-white/10">
                  {muted || volume === 0 ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4" />}
                </button>
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.05}
                  value={muted ? 0 : volume}
                  aria-label="صدای ویدیو"
                  onChange={handleVolumeChange}
                  className="w-14 sm:w-20 h-1 bg-white/30 rounded-lg appearance-none cursor-pointer accent-rose-500 opacity-80 group-hover/vol:opacity-100 transition-opacity"
                />
              </div>
            </div>

            <div className="flex items-center gap-1.5 sm:gap-2">
              {/* Speed Selector */}
              <div className="relative">
                <button type="button" 
                  onClick={() => setShowSpeedMenu(!showSpeedMenu)}
                  className="text-stone-200 hover:text-white text-xs font-black px-2.5 py-1 rounded-xl bg-white/15 hover:bg-white/25 backdrop-blur-sm flex items-center gap-1 transition-[color,background-color,border-color,box-shadow,transform] border border-white/10"
                  title="سرعت پخش"
                >
                  <Gauge className="w-3.5 h-3.5 text-rose-400" />
                  <span>{playbackRate}x</span>
                </button>

                {showSpeedMenu && (
                  <div className="absolute bottom-full mb-2 right-0 bg-stone-900/95 border border-stone-700 rounded-2xl p-1.5 shadow-2xl flex flex-col gap-0.5 z-50 text-xs font-bold text-white min-w-[80px] backdrop-blur-xl">
                    {speedOptions.map((rate) => (
                      <button type="button"
                        key={rate}
                        onClick={() => {
                          setPlaybackRate(rate);
                          setShowSpeedMenu(false);
                        }}
                        className={`px-3 py-1.5 rounded-xl text-center hover:bg-rose-600 transition-colors ${playbackRate === rate ? 'bg-rose-600 font-black' : ''}`}
                      >
                        {rate}x
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Picture-in-Picture Button */}
              {document.pictureInPictureEnabled && (
                <button type="button"
                  onClick={togglePictureInPicture}
                  className="text-stone-300 hover:text-white transition-colors p-1.5 rounded-full hover:bg-white/10 hidden sm:flex"
                  title="تصویر در تصویر"
                >
                  <Tv className="w-4 h-4" />
                </button>
              )}

              {/* Fullscreen Button */}
              <button type="button" 
                onClick={toggleFullscreen}
                className="text-stone-300 hover:text-white transition-colors p-1.5 rounded-full hover:bg-white/10"
                title="تمام صفحه"
              >
                {isFullscreen ? <Minimize className="w-4.5 h-4.5" /> : <Maximize className="w-4.5 h-4.5" />}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
