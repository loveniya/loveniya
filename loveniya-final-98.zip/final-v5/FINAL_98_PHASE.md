# Loveniya — Final 98% Phase

Base: Release V4
Base archive SHA-256: bdfa5c455b01d9062b6f97f34e5e2f06f8f3661b9505be70b457fd040ba24aac

This phase contains only new, verified work beyond V4; prior releases remain preserved.

Key additions:
- Prevent overlapping Store sync cycles; refresh immediately when a hidden tab becomes visible.
- Treat partial endpoint failures as partial sync errors while still applying successful data.
- Fix AI chat delayed refresh cleanup and legacy sender-id normalization.
- Tighten production CSP to configured upstream origins instead of any HTTPS origin.
- Add stronger browser isolation headers and bound login input size.
- Redact raw upstream gateway error bodies from clients.
- Improve global keyboard focus styling and release CSS duplication.
- Strengthen static QA for images, iframes, new-tab links and retired code across the whole project.
