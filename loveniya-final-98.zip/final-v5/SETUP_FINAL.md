# راه‌اندازی نسخه نهایی Loveniya

## Runtime

پروژه برای Node.js 24.21.0 و npm 11.x تنظیم شده است.

```bash
nvm use
npm ci
npm run verify
npm start
```

## Secrets

مقادیر واقعی را هرگز داخل فایل‌های `src/` یا `VITE_*` قرار ندهید.

نمونه‌ی فایل:

```env
APP_SECRET=...
SESSION_SECRET=...
APP_UNLOCK_PASSWORD_SHA256=...
DATA_WORKER_URL=https://...
AI_WORKER_URL=https://...
PORT=3000
```

برای ساخت SHA-256 رمز بدون ذخیره‌کردن آن در shell history، از یک ورودی تعاملی Node استفاده کنید:

```bash
node -e "const crypto=require('crypto'), readline=require('readline'); const r=readline.createInterface({input:process.stdin,output:process.stdout}); r.question('Password: ', p=>{console.log(crypto.createHash('sha256').update(p,'utf8').digest('hex')); r.close();});"
```

در production فقط `APP_UNLOCK_PASSWORD_SHA256` استفاده می‌شود؛ `APP_UNLOCK_PASSWORD` برای توسعه‌ی محلی است.

## Verification

```bash
npm run verify
```

این دستور QA، syntax smoke، game smoke، type-check و production build را اجرا می‌کند.
