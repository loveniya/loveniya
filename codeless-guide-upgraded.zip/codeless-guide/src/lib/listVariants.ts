// انیمیشن ورود پلکانی کارت‌های لیست (خاطرات، عهدها، آرزوها، نامه‌ها).
// به‌جای دادن یک delay دستی به هر کارت (که وقتی کارت prop=layout هم داره
// درست دیده نمی‌شه)، از مکانیزم رسمی framer-motion برای پلکانی‌کردن
// (staggerChildren روی والد) استفاده می‌کنیم — راه مطمئن‌تر و مستندتر.

export const listContainerVariants = {
  hidden: {},
  show: {
    transition: {
      staggerChildren: 0.06,
      delayChildren: 0.02,
    },
  },
};

export const listItemVariants = {
  hidden: { opacity: 0, y: 14 },
  show: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.35, ease: 'easeOut' as const },
  },
};
