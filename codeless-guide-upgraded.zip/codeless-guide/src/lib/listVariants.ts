// انیمیشن ورود پلکانی کارت‌های لیست (خاطرات، عهدها، آرزوها، نامه‌ها).
// به‌جای دادن یک delay دستی به هر کارت (که وقتی کارت prop=layout هم داره
// درست دیده نمی‌شه)، از مکانیزم رسمی framer-motion برای پلکانی‌کردن
// (staggerChildren روی والد) استفاده می‌کنیم — راه مطمئن‌تر و مستندتر.
//
// خود جلوه‌ی ورود هم به درخواست امین عوض شد: به‌جای محوشدن+سرخوردن،
// هر کارت مثل یه برگه/کارت که از لبه‌ی بالاییش باز می‌شه وارد می‌شه
// (چرخش سه‌بعدی روی محور X). هر کارتی که این استایل رو استفاده می‌کنه
// باید روی خودش style={{ transformOrigin: 'top center', transformPerspective: 900 }}
// هم داشته باشه تا چرخش سه‌بعدی درست دیده بشه.

export const listContainerVariants = {
  hidden: {},
  show: {
    transition: {
      staggerChildren: 0.08,
      delayChildren: 0.02,
    },
  },
};

export const listItemVariants = {
  hidden: { opacity: 0, rotateX: -85 },
  show: {
    opacity: 1,
    rotateX: 0,
    transition: { duration: 0.55, ease: [0.22, 1, 0.36, 1] as const },
  },
};

// استایل ثابتی که باید روی همون motion.div کارت (کنار variants) قرار بگیره
export const cardUnfoldStyle = { transformOrigin: 'top center', transformPerspective: 900 } as const;
