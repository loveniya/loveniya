import React, { useState, useEffect, useMemo } from 'react';
import { 
  Heart, Calendar, Clock, 
  Activity, Flame, Infinity as InfinityIcon, Zap
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// Tehran Date utility
const getTehranDate = () => new Date(new Date().toLocaleString("en-US", { timeZone: "Asia/Tehran" }));

export const ModernLoveTimer: React.FC = () => {
  // Target start date: 20 Ordibehesht 1405 (May 10, 2026, 00:00:00)
  const startDate = useMemo(() => new Date(2026, 4, 10, 0, 0, 0), []);

  const [activeTab, setActiveTab] = useState<'detailed' | 'milestones'>('detailed');
  const [now, setNow] = useState(getTehranDate());
  const [isBeating, setIsBeating] = useState(false);
  const [showCelebration, setShowCelebration] = useState(false);

  // Exact time breakdown
  const calculateDetailedTime = (currentDate: Date) => {
    if (currentDate < startDate) {
      const diff = Math.max(0, startDate.getTime() - currentDate.getTime());
      const s = Math.floor((diff / 1000) % 60);
      const mi = Math.floor((diff / 1000 / 60) % 60);
      const h = Math.floor((diff / (1000 * 60 * 60)) % 24);
      const d = Math.floor(diff / (1000 * 60 * 60 * 24));
      return { years: 0, months: 0, days: d, hours: h, minutes: mi, seconds: s, isFuture: true };
    }

    let y = currentDate.getFullYear() - startDate.getFullYear();
    let mo = currentDate.getMonth() - startDate.getMonth();
    let d = currentDate.getDate() - startDate.getDate();
    let h = currentDate.getHours() - startDate.getHours();
    let mi = currentDate.getMinutes() - startDate.getMinutes();
    let s = currentDate.getSeconds() - startDate.getSeconds();

    if (s < 0) { s += 60; mi--; }
    if (mi < 0) { mi += 60; h--; }
    if (h < 0) { h += 24; d--; }
    if (d < 0) {
      const prevMonthDays = new Date(currentDate.getFullYear(), currentDate.getMonth(), 0).getDate();
      d += prevMonthDays;
      mo--;
    }
    if (mo < 0) { mo += 12; y--; }

    return { years: y, months: mo, days: d, hours: h, minutes: mi, seconds: s, isFuture: false };
  };

  const time = useMemo(() => calculateDetailedTime(now), [now, startDate]);

  // Synchronized 1-second pulse
  useEffect(() => {
    const interval = setInterval(() => {
      const tehranNow = getTehranDate();
      setNow(tehranNow);
      setIsBeating(true);
      setTimeout(() => setIsBeating(false), 380);
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  // Overall totals
  const diffMs = Math.abs(now.getTime() - startDate.getTime());
  const totalDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
  const totalHours = Math.floor(diffMs / (1000 * 60 * 60));
  const totalMinutes = Math.floor(diffMs / (1000 * 60));
  const totalSeconds = Math.floor(diffMs / 1000);
  const totalHeartbeats = Math.floor(totalSeconds * 1.2); // approx 72 bpm

  // Monthiversary calculation (20th of each month)
  const todayMidnight = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  let nextYear = now.getFullYear();
  let nextMonthIdx = now.getMonth();
  let maxDaysInMonth = new Date(nextYear, nextMonthIdx + 1, 0).getDate();
  let targetDate = Math.min(startDate.getDate(), maxDaysInMonth);
  let nextMonth = new Date(nextYear, nextMonthIdx, targetDate);

  if (todayMidnight.getTime() > nextMonth.getTime()) {
    nextMonthIdx += 1;
    if (nextMonthIdx > 11) {
      nextMonthIdx = 0;
      nextYear += 1;
    }
    maxDaysInMonth = new Date(nextYear, nextMonthIdx + 1, 0).getDate();
    targetDate = Math.min(startDate.getDate(), maxDaysInMonth);
    nextMonth = new Date(nextYear, nextMonthIdx, targetDate);
  }

  // Previous monthiversary to calculate progress percentage
  let prevMonthIdx = nextMonthIdx - 1;
  let prevYear = nextYear;
  if (prevMonthIdx < 0) {
    prevMonthIdx = 11;
    prevYear -= 1;
  }
  const prevMaxDays = new Date(prevYear, prevMonthIdx + 1, 0).getDate();
  const prevTargetDate = Math.min(startDate.getDate(), prevMaxDays);
  const prevMonth = new Date(prevYear, prevMonthIdx, prevTargetDate);

  const daysUntilNext = Math.round((nextMonth.getTime() - todayMidnight.getTime()) / (1000 * 3600 * 24));
  const totalCycleMs = nextMonth.getTime() - prevMonth.getTime();
  const elapsedCycleMs = Math.max(0, now.getTime() - prevMonth.getTime());
  const monthProgress = Math.min(100, Math.max(0, Math.round((elapsedCycleMs / totalCycleMs) * 100)));

  // یک‌بار در روز ماهگرد، یک جشن ذره‌ای کوتاه نشون بده (نه هر بار که صفحه باز میشه)
  useEffect(() => {
    if (daysUntilNext !== 0) return;
    const storageKey = 'loveniya_monthiversary_celebrated';
    const todayKey = getTehranDate().toLocaleDateString('en-CA', { timeZone: 'Asia/Tehran' });
    if (localStorage.getItem(storageKey) === todayKey) return;
    localStorage.setItem(storageKey, todayKey);
    setShowCelebration(true);
    const timer = setTimeout(() => setShowCelebration(false), 2600);
    return () => clearTimeout(timer);
  }, [daysUntilNext]);

  return (
    <motion.section 
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, ease: "easeOut" }}
      className="relative rounded-3xl overflow-hidden bg-white border border-stone-200/90 shadow-2xs p-4 sm:p-5 text-center transition-all"
      dir="rtl"
    >
      {/* Decorative subtle ambient backdrop glow */}
      <div className="absolute -top-16 -right-16 w-36 h-36 bg-rose-100/50 rounded-full blur-2xl pointer-events-none" />
      <div className="absolute -bottom-16 -left-16 w-36 h-36 bg-pink-100/40 rounded-full blur-2xl pointer-events-none" />

      {/* Celebration burst: only once per monthiversary day, self-cleans after ~2.6s */}
      <AnimatePresence>
        {showCelebration && (
          <div className="absolute inset-0 pointer-events-none overflow-hidden rounded-3xl z-20">
            {Array.from({ length: 14 }).map((_, i) => {
              const angle = (i / 14) * Math.PI * 2;
              const distance = 55 + (i % 3) * 18;
              return (
                <motion.span
                  key={i}
                  initial={{ opacity: 1, top: '50%', left: '50%', x: '-50%', y: '-50%', scale: 0.5 }}
                  animate={{
                    opacity: 0,
                    x: `calc(-50% + ${Math.cos(angle) * distance}px)`,
                    y: `calc(-50% + ${Math.sin(angle) * distance}px)`,
                    scale: 1,
                  }}
                  transition={{ duration: 1.1, ease: 'easeOut', delay: (i % 5) * 0.03 }}
                  className="absolute text-rose-500"
                  style={{ fontSize: 12 + (i % 4) * 4 }}
                >
                  ❤
                </motion.span>
              );
            })}
          </div>
        )}
      </AnimatePresence>

      {/* Top Header: Title & View Modes */}
      <div className="relative z-10 flex flex-col sm:flex-row items-center justify-between gap-3 mb-4 pb-3 border-b border-stone-100">
        
        {/* Romantic Title */}
        <div className="flex items-center gap-2.5 sm:gap-3 w-full sm:w-auto justify-center sm:justify-start">
          <div className="text-right">
            <div className="flex items-center gap-1.5">
              <h2 className="text-sm sm:text-base font-black text-stone-900 leading-tight">
                روزشمار عشق و دلدادگی
              </h2>
              <span className="inline-flex items-center gap-1 text-[11px] font-black text-amber-600">
                
                <span>پیوند ابدی</span>
              </span>
            </div>
            <p className="text-[11px] font-bold text-stone-400 mt-0.5 leading-none">
              از ۲۰ اردیبهشت ۱۴۰۵ • با عشق امین و نیایش
            </p>
          </div>
        </div>

        {/* Tab switcher */}
        <div className="flex items-center bg-stone-100/90 p-1 rounded-2xl w-full sm:w-auto justify-center">
          <button
            type="button"
            onClick={() => setActiveTab('detailed')}
            className={`flex-1 sm:flex-initial px-4 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              activeTab === 'detailed'
                ? 'bg-white text-rose-700 shadow-2xs font-black'
                : 'text-stone-500 hover:text-stone-800 font-medium'
            }`}
          >
            <Clock className="w-3.5 h-3.5 text-rose-500" />
            <span>زمان زنده</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('milestones')}
            className={`flex-1 sm:flex-initial px-4 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              activeTab === 'milestones'
                ? 'bg-white text-rose-700 shadow-2xs font-black'
                : 'text-stone-500 hover:text-stone-800 font-medium'
            }`}
          >
            <Activity className="w-3.5 h-3.5 text-indigo-500" />
            <span>آمار کل</span>
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="relative z-10">
        <AnimatePresence mode="wait">
          {activeTab === 'detailed' ? (
            <motion.div
              key="detailed"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              transition={{ duration: 0.2 }}
              className="space-y-3"
            >
              {/* 6 Responsive Digital Units (Logical RTL Order: سال to ثانیه) */}
              <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 sm:gap-2.5">
                {[
                  { label: 'سال', value: time.years, isSec: false },
                  { label: 'ماه', value: time.months, isSec: false },
                  { label: 'روز', value: time.days, isSec: false },
                  { label: 'ساعت', value: time.hours, isSec: false },
                  { label: 'دقیقه', value: time.minutes, isSec: false },
                  { label: 'ثانیه', value: time.seconds, isSec: true }
                ].map((unit, i) => (
                  <div 
                    key={i} 
                    className={`relative rounded-2xl p-2.5 sm:p-3 flex flex-col items-center justify-center transition-all duration-300 ${
                      unit.isSec
                        ? 'bg-rose-50/80 border border-rose-200/70 shadow-2xs'
                        : 'bg-stone-50/90 hover:bg-stone-100/90 border border-stone-200/50 shadow-2xs'
                    }`}
                  >
                    {/* Numeric Value — rolls to the new number instead of jump-cutting */}
                    <div className="flex items-center justify-center min-h-[30px] sm:min-h-[36px] overflow-hidden relative w-full">
                      <AnimatePresence mode="popLayout" initial={false}>
                        <motion.span 
                          key={unit.value}
                          initial={{ y: 14, opacity: 0 }}
                          animate={{ y: 0, opacity: 1, scale: unit.isSec && isBeating ? 1.1 : 1 }}
                          exit={{ y: -14, opacity: 0 }}
                          transition={{ duration: 0.25, ease: 'easeOut' }}
                          className={`text-2xl sm:text-3xl font-black tracking-tight tabular-nums leading-none ${
                            unit.isSec ? 'text-rose-600' : 'text-stone-900'
                          }`}
                        >
                          {unit.value.toString().padStart(2, '0')}
                        </motion.span>
                      </AnimatePresence>
                    </div>

                    {/* Label */}
                    <span className={`text-[11px] font-bold mt-1 ${
                      unit.isSec ? 'text-rose-600 font-black' : 'text-stone-500'
                    }`}>
                      {unit.label}
                    </span>
                  </div>
                ))}
              </div>

              {/* Shared Heartbeat Count */}
              <div className="flex items-center justify-center gap-1.5 px-2 pt-0.5 text-[11px] font-black text-rose-600">
                <Heart className="w-3.5 h-3.5 fill-rose-500 text-rose-500" />
                <span>{totalHeartbeats.toLocaleString('fa-IR')} تپش مشترک</span>
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="milestones"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              transition={{ duration: 0.2 }}
              className="grid grid-cols-2 sm:grid-cols-4 gap-2 sm:gap-2.5"
            >
              {/* Total Days */}
              <div className="bg-amber-50/90 border border-amber-200/70 rounded-2xl p-3 text-center flex flex-col items-center justify-center shadow-2xs">
                <div className="w-8 h-8 rounded-xl bg-white text-amber-500 flex items-center justify-center mb-1 shadow-2xs">
                  <Flame className="w-4 h-4 fill-amber-500 text-amber-500" />
                </div>
                <span className="text-xl sm:text-2xl font-black text-stone-900 tabular-nums leading-none mb-1">
                  {totalDays.toLocaleString('fa-IR')}
                </span>
                <span className="text-xs font-bold text-amber-800">روز در کنار هم</span>
              </div>

              {/* Total Hours */}
              <div className="bg-emerald-50/90 border border-emerald-200/70 rounded-2xl p-3 text-center flex flex-col items-center justify-center shadow-2xs">
                <div className="w-8 h-8 rounded-xl bg-white text-emerald-600 flex items-center justify-center mb-1 shadow-2xs">
                  <Clock className="w-4 h-4" />
                </div>
                <span className="text-xl sm:text-2xl font-black text-stone-900 tabular-nums leading-none mb-1">
                  {totalHours.toLocaleString('fa-IR')}
                </span>
                <span className="text-xs font-bold text-emerald-800">ساعت عاشقی</span>
              </div>

              {/* Total Minutes */}
              <div className="bg-rose-50/90 border border-rose-200/70 rounded-2xl p-3 text-center flex flex-col items-center justify-center shadow-2xs">
                <div className="w-8 h-8 rounded-xl bg-white text-rose-500 flex items-center justify-center mb-1 shadow-2xs">
                  <Heart className={`w-4 h-4 fill-rose-500 text-rose-500 transition-transform ${isBeating ? 'scale-125' : 'scale-100'}`} />
                </div>
                <span className="text-xl sm:text-2xl font-black text-rose-600 tabular-nums leading-none mb-1">
                  {(Math.round(totalHeartbeats / 1000)).toLocaleString('fa-IR')}k+
                </span>
                <span className="text-xs font-bold text-rose-800">تپش مشترک</span>
              </div>

              {/* Eternal Commitment */}
              <div className="bg-indigo-50/90 border border-indigo-200/70 rounded-2xl p-3 text-center flex flex-col items-center justify-center shadow-2xs">
                <div className="w-8 h-8 rounded-xl bg-white text-indigo-600 flex items-center justify-center mb-1 shadow-2xs">
                  <InfinityIcon className="w-4 h-4" />
                </div>
                <span className="text-xl sm:text-2xl font-black text-stone-900 leading-none mb-1">
                  بی‌نهایت
                </span>
                <span className="text-xs font-bold text-indigo-800">عشق و تعهد</span>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Monthiversary (ماهگرد) Banner & Progress */}
        <div className="mt-3 pt-3 border-t border-stone-100">
          <div className="flex flex-col gap-2 px-1">
            
            <div className="flex items-center justify-between text-xs font-black">
              <div className="flex items-center gap-1.5 text-stone-800">
                <Calendar className="w-3.5 h-3.5 text-rose-500 shrink-0" />
                <span>
                  {daysUntilNext === 0 
                    ? 'امروز روز ماهگردمونه! 🎉 مبارکمون باشه عشقم' 
                    : `ماهگرد بعدی: ۲۰ هر ماه`}
                </span>
              </div>

              <span className="text-[11px] font-black text-rose-600">
                {daysUntilNext === 0 
                  ? 'جشن ماهگرد' 
                  : `${daysUntilNext} روز مانده`}
              </span>
            </div>

            {/* Glowing progress line filled in RTL */}
            <div className="w-full bg-stone-100 rounded-full h-2 overflow-hidden p-0.5 flex justify-start" dir="rtl">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${daysUntilNext === 0 ? 100 : monthProgress}%` }}
                transition={{ duration: 0.6, ease: "easeOut" }}
                className="h-full rounded-full bg-gradient-to-l from-rose-500 via-pink-500 to-rose-600"
              />
            </div>

            <div className="text-center text-[10px] font-extrabold text-stone-500">
              {daysUntilNext === 0 ? '۱۰۰٪ کامل شد' : `${monthProgress}٪ از ماه سپری شده`}
            </div>
          </div>
        </div>
      </div>
    </motion.section>
  );
};
