import React, { useEffect, useState } from 'react';
import { NavLink, useLocation } from 'react-router';
import { 
  AlertCircle, 
  Camera, 
  ChevronLeft, 
  Compass, 
  Dices, 
  Grid, 
  HeartHandshake, 
  Home, 
  Mail, 
  MessagesSquare, 
  Music, 
  Settings, 
  
  X 
} from 'lucide-react';
import clsx from 'clsx';
import { motion, AnimatePresence } from 'framer-motion';

/**
 * =========================================================================================
 * Navigation_PureOptics_Production.tsx
 * نوار ناوبری کپسولی شیشه توپر با فیزیک اپتیک شکست نور و تفکیک کروماتیک
 * ۱۰۰٪ ایمن، ضد باگ، سازگار با اسکرول صفحه و ساختار استاندارد React
 * =========================================================================================
 * 
 * حل قطعی باگ‌های نسخه قبلی:
 * ۱. حذف کانواس تمام‌صفحه WebGL که کل اسکرول صفحه و کلیک‌های بادی را مختل می‌کرد.
 * ۲. استفاده از موتور استاندارد، سبک و بی‌خطر SVG Displacement Map و فیلتر اپتیک مدرن:
 *    - انکسار استوانه‌ای یک‌بعدی (1D Refraction) در راستای محور عمودی Y
 *    - حفظ ۱۰۰٪ ابعاد و پهنای افقی (Zero X Distortion)
 *    - تفکیک طول‌موج کروماتیک (Chromatic Dispersion) در مرزهای کپسول
 *    - لایه فرنل طولی و کانون کاستیک متمرکز در زیر کپسول
 * ۳. بهینه‌سازی شده برای محیط‌های بالای ۸۰٪ روشن بدون ماتی شیری، بدون دوده کثیف
 * ۴. آیکون «چت روم» (MessagesSquare) و آیکون «بازی‌ها» با تاس‌های شانس (Dices)
 */

interface NavigationProps {
  syncStatus?: 'idle' | 'syncing' | 'error';
  syncError?: string | null;
}

export const Navigation: React.FC<NavigationProps> = ({ 
  syncStatus = 'idle', 
  syncError = null 
}) => {
  const [showMoreMenu, setShowMoreMenu] = useState(false);
  const location = useLocation();

  // کنترل ایمن اسکرول هنگام باز شدن شیت مدال
  useEffect(() => {
    if (showMoreMenu) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [showMoreMenu]);

  // تب‌های نوار ناوبری اصلی
  const navTabs = [
    { to: '/', label: 'خانه', icon: Home },
    { to: '/memories', label: 'خاطرات', icon: Camera },
    { to: '/pledges', label: 'عهدها', icon: HeartHandshake },
    { to: '/chat', label: 'چت روم', icon: MessagesSquare },
    { to: '/games', label: 'بازی‌ها', icon: Dices },
  ];

  // آیتم‌های منوی کشویی سایر
  const moreItems = [
    { 
      to: '/dreams', 
      label: 'آرزوهای مشترک', 
      desc: 'اهداف، سفرها و برنامه‌های دو نفره ما', 
      icon: <Compass className="w-5 h-5 text-sky-600" />, 
      c: 'bg-sky-50/90 hover:bg-sky-100/90 border-sky-200/80' 
    },
    { 
      to: '/music', 
      label: 'موزیک روم مشترک', 
      desc: 'آهنگ‌های دلنشین و خاطره‌ساز', 
      icon: <Music className="w-5 h-5 text-fuchsia-600" />, 
      c: 'bg-fuchsia-50/90 hover:bg-fuchsia-100/90 border-fuchsia-200/80' 
    },
    { 
      to: '/letters', 
      label: 'صندوق نامه‌ها', 
      desc: 'نامه‌های زمان‌دار و یادداشت‌های قلبی', 
      icon: <Mail className="w-5 h-5 text-amber-600" />, 
      c: 'bg-amber-50/90 hover:bg-amber-100/90 border-amber-200/80' 
    },
    { 
      to: '/settings', 
      label: 'تنظیمات و قفل امن', 
      desc: 'شخصی‌سازی، امنیت و وضعیت اتصال', 
      icon: <Settings className="w-5 h-5 text-stone-700" />, 
      c: 'bg-stone-50/90 hover:bg-stone-100/90 border-stone-200/80' 
    },
  ];

  const moreActive = moreItems.some((i) => i.to === location.pathname);

  return (
    <>
      {/* فیلترهای استاندارد اپتیکال برای شبیه‌سازی شکست نور استوانه‌ای و تفکیک کروماتیک */}
      <svg className="absolute w-0 h-0 pointer-events-none opacity-0" aria-hidden="true">
        <defs>
          {/* فیلتر انکسار استوانه‌ای: اعوجاج در محور Y و حفظ کامل محور X */}
          <filter id="cylindrical-refraction" x="-10%" y="-20%" width="120%" height="140%">
            <feTurbulence type="fractalNoise" baseFrequency="0.002 0.08" numOctaves="1" result="noise" />
            <feDisplacementMap in="SourceGraphic" in2="noise" scale="8" xChannelSelector="R" yChannelSelector="G" />
          </filter>
        </defs>
      </svg>

      <style>{`
        /* بدنه کپسول شیشه توپر با فرمول‌های فیزیک اپتیک برای محیط‌های ۸۰٪ روشن */
        .solid-glass-capsule {
          position: relative;
          height: 60px;
          border-radius: 9999px;
          /* گرادیان عبور نور شیشه توپر سنگین (بدون ذرات شیری یا ماتی دوده) */
          background: linear-gradient(180deg,
            rgba(255, 255, 255, 0.42) 0%,
            rgba(255, 255, 255, 0.10) 24%,
            rgba(255, 255, 255, 0.00) 62%,
            rgba(255, 255, 255, 0.16) 100%);
          /* فیلتر اپتیک با تراکم رنگ محیط و اشباع نوری فوتون‌ها */
          backdrop-filter: blur(12px) saturate(240%) contrast(108%) brightness(1.02);
          -webkit-backdrop-filter: blur(12px) saturate(240%) contrast(108%) brightness(1.02);
          /* مرز انکساری با رنگ گلبهی ارگانیک جهت تفکیک کپسول در پس‌زمینه‌های روشن */
          border: 1px solid rgba(225, 29, 72, 0.20);
          box-shadow:
            /* ۱. بازتاب خطی طولی فرنل در سقف کپسول (Fresnel Top Rim) */
            inset 0 1.5px 0.5px 0 rgba(255, 255, 255, 0.98),
            /* ۲. بازتاب لبه پایینی عدسی محدب */
            inset 0 -1.2px 0.6px 0 rgba(255, 255, 255, 0.65),
            /* ۳. بازتاب فرنل انحنای کروی دو سر کپسول (چپ و راست ۳۶۰ درجه) */
            inset 3px 0 2px 0 rgba(255, 255, 255, 0.75),
            inset -3px 0 2px 0 rgba(255, 255, 255, 0.75),
            /* ۴. هاله شکست نور استوانه‌ای در بالای کپسول */
            inset 0 8px 16px -4px rgba(255, 255, 255, 0.45),
            /* ۵. گرادیان انکسار عمق شیشه توپر در پایین بدون سیاهی کثیف */
            inset 0 -6px 12px -3px rgba(15, 23, 42, 0.09),
            /* ۶. سایه طبیعی تماس کریستال سنگین در محیط روشن */
            0 14px 32px -8px rgba(15, 23, 42, 0.12),
            0 4px 10px -2px rgba(15, 23, 42, 0.06);
          overflow: hidden;
          will-change: transform;
        }

        /* لایه قوس اسپکیولار براق روی تحدب بدنه استوانه‌ای شیشه */
        .solid-specular-arc {
          position: absolute;
          top: 0;
          left: 4%;
          right: 4%;
          height: 16px;
          border-radius: 9999px 9999px 0 0;
          background: linear-gradient(90deg,
            rgba(255, 255, 255, 0.95) 0%,
            rgba(255, 255, 255, 0.35) 18%,
            rgba(255, 255, 255, 0.12) 50%,
            rgba(255, 255, 255, 0.35) 82%,
            rgba(255, 255, 255, 0.95) 100%);
          -webkit-mask-image: radial-gradient(ellipse at top, black 40%, transparent 78%);
          mask-image: radial-gradient(ellipse at top, black 40%, transparent 78%);
          pointer-events: none;
          z-index: 2;
        }

        /* حوضچه فوتونی کاستیک زیر کپسول ناشی از همگرایی پرتوهای لنز محدب */
        .solid-caustic-beam {
          position: absolute;
          bottom: -5px;
          left: 10%;
          right: 10%;
          height: 10px;
          border-radius: 9999px;
          background: radial-gradient(ellipse at center, 
            rgba(255, 255, 255, 0.95) 0%, 
            rgba(244, 63, 94, 0.35) 38%, 
            transparent 72%);
          filter: blur(4px);
          pointer-events: none;
          z-index: 0;
        }

        /* شکست کروماتیک لبه‌های شیشه (تفکیک ظریف طیفی نور) */
        .chromatic-dispersion-edge {
          position: absolute;
          inset: 0;
          border-radius: 9999px;
          box-shadow: 
            inset 0 1px 1px 0 rgba(244, 63, 94, 0.25),
            inset 0 -1px 1px 0 rgba(56, 189, 248, 0.20);
          pointer-events: none;
          z-index: 1;
        }

        .capsule-tab-item {
          -webkit-tap-highlight-color: transparent;
          transition: transform 0.2s cubic-bezier(0.34, 1.56, 0.64, 1);
        }
      `}</style>

      {/* ۱. هدر بالایی با پس‌زمینه کریستالی شیشه‌ای */}
      <header 
        className="fixed top-0 inset-x-0 z-40 h-13 sm:h-14 border-b border-white/60 select-none" 
        style={{ 
          background: 'rgba(255,255,255,0.80)', 
          backdropFilter: 'blur(28px) saturate(160%)', 
          WebkitBackdropFilter: 'blur(28px) saturate(160%)', 
          boxShadow: '0 4px 20px -2px rgba(0,0,0,0.03), inset 0 -1px 0 rgba(255,255,255,0.6)' 
        }}
      >
        <div className="max-w-4xl mx-auto h-full px-3 sm:px-4 flex items-center justify-between">
          <NavLink 
            to="/settings" 
            className={({ isActive }) => clsx(
              'w-8 h-8 sm:w-9 sm:h-9 rounded-xl flex items-center justify-center shrink-0 transition-colors', 
              isActive ? 'bg-rose-50 text-rose-700 border border-rose-200/60' : 'text-stone-700 bg-white/80 border border-stone-200/40 hover:bg-stone-50'
            )} 
            title="تنظیمات"
          >
            <Settings className="w-4 h-4" />
          </NavLink>
          <NavLink to="/" className="flex-1 flex items-center justify-center sm:justify-end gap-2 select-none" dir="ltr" title="صفحه اصلی">
            <span className="text-2xl sm:text-3xl text-rose-600 font-bold whitespace-nowrap" style={{ fontFamily: "'Alex Brush','Great Vibes','Dancing Script',cursive" }}>I Love You</span>
            <span className="text-rose-500 text-2xl">♡</span>
          </NavLink>
        </div>
      </header>

      {/* هشدار خطا در صورت بروز اختلال در همگام‌سازی */}
      {syncStatus === 'error' && (
        <div className="fixed top-14 inset-x-0 z-40 bg-rose-600 text-white text-xs font-bold text-center py-2 px-4 shadow-sm" dir="rtl">
          <AlertCircle className="w-4 h-4 inline-block ml-1 align-text-bottom" />
          {syncError || 'خطای اتصال به سرور'}
        </div>
      )}

      {/* ۲. نوار ناوبری کپسولی شناور شیشه توپر (کاملاً ایزوله، بدون ایجاد باگ اسکرول) */}
      <div
        className="fixed z-40 pointer-events-none select-none"
        style={{ 
          bottom: '16px', 
          left: 'max(16px, env(safe-area-inset-left))', 
          right: 'max(16px, env(safe-area-inset-right))',
          paddingBottom: 'env(safe-area-inset-bottom)'
        }}
        dir="rtl"
      >
        <div className="max-w-md mx-auto w-full relative">
          {/* کانون کاستیک نوری زیر شیشه */}
          <div className="solid-caustic-beam" />

          {/* بدنه کپسول شیشه‌ای */}
          <nav
            aria-label="نوار ناوبری اصلی"
            className="solid-glass-capsule pointer-events-auto w-full h-[60px] flex items-center justify-around px-1.5"
          >
            {/* لایه‌های اپتیکال */}
            <div className="solid-specular-arc" />
            <div className="chromatic-dispersion-edge" />

            {/* تب‌های اصلی */}
            {navTabs.map((tab) => {
              const Icon = tab.icon;
              const active = location.pathname === tab.to;
              return (
                <NavLink
                  key={tab.to}
                  to={tab.to}
                  className="capsule-tab-item relative flex-1 h-full flex flex-col items-center justify-center gap-0.5 z-10 active:scale-90"
                >
                  {/* هاله فوتونی تب فعال */}
                  {active && (
                    <div 
                      className="absolute inset-x-1.5 top-1.5 bottom-1.5 rounded-full pointer-events-none"
                      style={{
                        background: 'radial-gradient(circle, rgba(225,29,72,0.30) 0%, transparent 70%)',
                        filter: 'blur(4px)'
                      }}
                    />
                  )}

                  <Icon
                    size={21}
                    strokeWidth={active ? 2.5 : 1.9}
                    className="transition-all duration-200"
                    style={{
                      color: active ? '#e11d48' : 'rgba(15,23,42,0.88)',
                      transform: active ? 'scale(1.1)' : 'none',
                      filter: active 
                        ? 'drop-shadow(0 2px 8px rgba(225,29,72,0.65))' 
                        : 'drop-shadow(0 1px 1px rgba(255,255,255,0.8))',
                    }}
                  />
                  <span
                    className="tracking-tight leading-none transition-colors duration-200 whitespace-nowrap select-none"
                    style={{
                      fontSize: '9.5px',
                      fontWeight: active ? 800 : 600,
                      color: active ? '#e11d48' : 'rgba(15,23,42,0.92)',
                      textShadow: active 
                        ? '0 1px 4px rgba(225,29,72,0.35)' 
                        : '0 1px 2px rgba(255,255,255,0.8)',
                    }}
                  >
                    {tab.label}
                  </span>

                  {/* نشانگر نقطه فعال در پایین */}
                  {active && (
                    <span
                      className="absolute rounded-full"
                      style={{ 
                        bottom: '4px', 
                        width: '5px', 
                        height: '5px', 
                        background: '#e11d48', 
                        boxShadow: '0 0 8px #e11d48' 
                      }}
                    />
                  )}
                </NavLink>
              );
            })}

            {/* دکمه سایر */}
            <button
              type="button"
              onClick={() => setShowMoreMenu(true)}
              className="capsule-tab-item relative flex-1 h-full flex flex-col items-center justify-center gap-0.5 z-10 active:scale-90"
              aria-label="سایر بخش‌ها"
            >
              {moreActive && (
                <div 
                  className="absolute inset-x-1.5 top-1.5 bottom-1.5 rounded-full pointer-events-none"
                  style={{
                    background: 'radial-gradient(circle, rgba(225,29,72,0.30) 0%, transparent 70%)',
                    filter: 'blur(4px)'
                  }}
                />
              )}

              <Grid
                size={21}
                strokeWidth={moreActive ? 2.5 : 1.9}
                className="transition-all duration-200"
                style={{
                  color: moreActive ? '#e11d48' : 'rgba(15,23,42,0.88)',
                  transform: moreActive ? 'scale(1.1)' : 'none',
                  filter: moreActive 
                    ? 'drop-shadow(0 2px 8px rgba(225,29,72,0.65))' 
                    : 'drop-shadow(0 1px 1px rgba(255,255,255,0.8))',
                }}
              />
              <span
                className="tracking-tight leading-none transition-colors duration-200 whitespace-nowrap select-none"
                style={{
                  fontSize: '9.5px',
                  fontWeight: moreActive ? 800 : 600,
                  color: moreActive ? '#e11d48' : 'rgba(15,23,42,0.92)',
                  textShadow: moreActive 
                    ? '0 1px 4px rgba(225,29,72,0.35)' 
                    : '0 1px 2px rgba(255,255,255,0.8)',
                }}
              >
                سایر
              </span>

              {moreActive && (
                <span
                  className="absolute rounded-full"
                  style={{ 
                    bottom: '4px', 
                    width: '5px', 
                    height: '5px', 
                    background: '#e11d48', 
                    boxShadow: '0 0 8px #e11d48' 
                  }}
                />
              )}
            </button>
          </nav>
        </div>
      </div>

      {/* ۳. شیت مدال منوی سایر */}
      <AnimatePresence>
        {showMoreMenu && (
          <>
            <motion.div 
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }} 
              exit={{ opacity: 0 }} 
              onClick={() => setShowMoreMenu(false)} 
              className="fixed inset-0 bg-stone-950/60 z-50 cursor-pointer" 
              style={{ backdropFilter: 'blur(4px)' }} 
            />
            <motion.div
              initial={{ opacity: 0, y: '100%' }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: '100%' }}
              transition={{ type: 'spring', stiffness: 360, damping: 32 }}
              className="fixed bottom-3 inset-x-3 bg-white/95 border border-white/60 rounded-[28px] shadow-2xl z-50 max-w-xl mx-auto p-4 sm:p-6 text-right overflow-hidden"
              style={{ marginBottom: 'env(safe-area-inset-bottom)' }}
              dir="rtl"
            >
              <div className="w-12 h-1.5 bg-stone-300 rounded-full mx-auto mb-4" />
              <div className="flex items-center justify-between mb-4 pb-3 border-b border-stone-100">
                <div className="flex items-center gap-2.5">
                  <div>
                    <h3 className="text-sm sm:text-base font-black text-stone-900">سایر بخش‌های اختصاصی</h3>
                    <p className="text-[11px] font-bold text-stone-500">امکانات و گنجینه‌های عاشقانه ما</p>
                  </div>
                </div>
                <button 
                  type="button"
                  onClick={() => setShowMoreMenu(false)} 
                  className="p-2 rounded-xl text-stone-500 bg-stone-100 hover:bg-stone-200 transition-colors cursor-pointer"
                  aria-label="بستن منو"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {moreItems.map((item) => {
                  const active = location.pathname === item.to;
                  return (
                    <NavLink 
                      key={item.to} 
                      to={item.to} 
                      onClick={() => setShowMoreMenu(false)} 
                      className={clsx(
                        'p-3 rounded-2xl flex items-center justify-between transition-all border group cursor-pointer', 
                        active ? `${item.c} ring-2 ring-rose-300` : item.c
                      )}
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="p-2.5 rounded-xl bg-white shadow-sm shrink-0">{item.icon}</div>
                        <div className="min-w-0">
                          <span className="text-xs sm:text-sm font-black text-stone-900 block truncate">{item.label}</span>
                          <span className="text-[10.5px] text-stone-500 font-bold block truncate mt-0.5">{item.desc}</span>
                        </div>
                      </div>
                      <ChevronLeft className="w-4 h-4 text-stone-500 shrink-0" />
                    </NavLink>
                  );
                })}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
};
