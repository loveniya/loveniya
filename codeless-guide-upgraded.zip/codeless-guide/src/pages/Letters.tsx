import { PageWrapper } from "../components/PageWrapper";
import React, { useState, useEffect } from 'react';
import { Mail, Plus, Lock, Unlock, Clock, Star, Trash2, Edit3, Heart, X } from 'lucide-react';
import { useStore } from '../lib/store';
import { Capsule } from '../lib/types';
import { KebabMenu, KebabMenuItem } from '../components/KebabMenu';
import { motion, AnimatePresence } from 'motion/react';
import { SkeletonList } from '../components/Skeleton';
import { useLetterDraft } from '../lib/draftStore';
import { dedupById } from '../lib/dedup';
import { PersianDateTimePicker } from '../components/PersianDateTimePicker';
import { formatJalaliReadable } from '../lib/jalali';

export const Letters: React.FC = () => {
  const { capsules, addCapsule, updateCapsule, removeCapsule, isInitialLoading } = useStore();
  const { draft, setDraft, resetDraft } = useLetterDraft();
  const [isSaving, setIsSaving] = useState(false);
  
  const showForm = draft.showForm;
  const editingId = draft.editingId;
  const title = draft.title;
  const text = draft.text;
  const openDate = draft.openDate;
  const sender = draft.sender;
  const recipient = draft.recipient;
  const confirmSave = draft.confirmSave;

  const formRef = React.useRef<HTMLDivElement>(null);
  const [activeLetter, setActiveLetter] = useState<Capsule | null>(null);

  // Keep activeLetter in sync with any updates or removals
  useEffect(() => {
    if (activeLetter) {
      const fresh = capsules.find(c => c.id === activeLetter.id);
      if (fresh) {
        setActiveLetter(fresh);
      } else {
        setActiveLetter(null);
      }
    }
  }, [capsules]);

  // Force re-render to keep countdowns fresh. The lock countdown only shows
  // day/hour precision (updates fine once a minute), but the 30s post-creation
  // "time left to edit" countdown genuinely needs per-second accuracy — so we
  // check every second, but only actually re-render when one of those is due,
  // instead of re-rendering the whole page every second unconditionally.
  const [, setTick] = useState(0);
  const lastSlowTickRef = React.useRef(Date.now());
  useEffect(() => {
    const timer = setInterval(() => {
      const hasActiveEditWindow = capsules.some(c => Date.now() - (c.createdAt || 0) < 30000);
      if (hasActiveEditWindow || Date.now() - lastSlowTickRef.current >= 60000) {
        lastSlowTickRef.current = Date.now();
        setTick(t => t + 1);
      }
    }, 1000);
    return () => clearInterval(timer);
  }, [capsules]);

  const resetForm = () => {
    resetDraft();
  };

  const handleEdit = (c: Capsule) => {
    setActiveLetter(null);
    setDraft({
      editingId: c.id,
      title: c.title,
      text: c.text,
      openDate: c.openDate,
      sender: c.sender || '',
      recipient: c.recipient || '',
      showForm: true,
      confirmSave: false
    });
    setTimeout(() => {
      formRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 120);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!confirmSave) {
      setDraft({ confirmSave: true });
      return;
    }
    if (isSaving) return;

    setIsSaving(true);
    try {
      if (editingId) {
        const existing = capsules.find(c => c.id === editingId);
        if (existing) {
          updateCapsule({
            ...existing,
            title,
            text,
            openDate,
            sender,
            recipient,
            createdAt: existing.createdAt || Date.now()
          });
        }
      } else {
        addCapsule({
          id: `capsule_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
          title,
          text,
          openDate,
          sender,
          recipient,
          isOpened: false,
          pinned: false,
          createdAt: Date.now()
        });
      }
      resetForm();
    } finally {
      setIsSaving(false);
    }
  };

  const checkLocked = (dateStr: string) => {
    if (!dateStr) return false;
    return new Date(dateStr) > new Date();
  };

  const calculateTimeLeft = (dateStr: string) => {
    if (!dateStr) return '';
    const diff = new Date(dateStr).getTime() - new Date().getTime();
    if (diff <= 0) return 'همین الان قابل خوندنه!';
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
    if (days > 0) return `${days} روز و ${hours} ساعت دیگه`;
    return `${hours} ساعت دیگه باز میشه`;
  };

  const openLetter = (letter: Capsule) => {
    if (checkLocked(letter.openDate)) return;
    if (!letter.isOpened) {
      updateCapsule({ ...letter, isOpened: true });
    }
    setActiveLetter(letter);
  };

  const [showCount, setShowCount] = useState(4);

  // Deduplicate and sort capsules: pinned ones first
  const uniqueCapsules = React.useMemo(() => dedupById(capsules), [capsules]);
  const sortedCapsules = React.useMemo(() => {
    return [...uniqueCapsules].sort((a, b) => {
      if (a.pinned && !b.pinned) return -1;
      if (!a.pinned && b.pinned) return 1;
      return 0;
    });
  }, [uniqueCapsules]);

  const displayedCapsules = sortedCapsules.slice(0, showCount);
  const hasMore = showCount < sortedCapsules.length;
  const hasLess = showCount > 4;

  if (activeLetter) {
    return (
      <PageWrapper>
        <div className="space-y-6" dir="rtl">
          <motion.div 
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            className="glass-card rounded-3xl p-4 sm:p-6 md:p-10 envelope-bg relative overflow-hidden shadow-2xl"
          >
            <div className="flex justify-between items-start mb-6 border-b border-rose-200/50 pb-4 sm:pb-6">
              <div>
                <h2 className="text-xl md:text-2xl font-black text-rose-600 flex items-center gap-2 mb-1.5">
                  <Heart className="w-5 h-5 sm:w-6 sm:h-6 fill-rose-500 shrink-0" /> {activeLetter.title}
                </h2>
                <p className="text-xs text-rose-400 font-bold flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5" /> تاریخ بازگشایی: {formatJalaliReadable(activeLetter.openDate)}
                </p>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <button 
                  onClick={() => handleEdit(activeLetter)}
                  className="text-rose-700 hover:text-rose-900 bg-white/70 hover:bg-white px-3 py-1.5 rounded-xl font-bold text-xs transition-colors flex items-center gap-1.5 shadow-xs"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>ویرایش</span>
                </button>
                <button onClick={() => setActiveLetter(null)} className="text-slate-400 hover:text-rose-500 bg-white/50 p-2 rounded-full transition-colors shrink-0">
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="min-h-[220px] sm:min-h-[300px] whitespace-pre-wrap text-base font-bold text-stone-800 leading-relaxed sm:leading-[2.5]"
            >
              {activeLetter.text}
            </motion.div>

            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.8 }}
              className="mt-8 sm:mt-12 text-left text-rose-500 font-black text-base sm:text-lg flex flex-col items-end justify-end gap-1.5"
            >
              <div className="flex items-center gap-2">
                از طرف {activeLetter.sender || 'ناشناس'} 
              </div>
              {activeLetter.recipient && (
                <div className="text-base sm:text-lg text-rose-400">
                  تقدیم به: {activeLetter.recipient}
                </div>
              )}
            </motion.div>
          </motion.div>
        </div>
      </PageWrapper>
    );
  }

  return (
    <PageWrapper>
      <div className="space-y-6" dir="rtl">
        {/* Layer 2: Independent Header Banner */}
        <div className="bg-white rounded-3xl p-5 sm:p-6 relative overflow-hidden shadow-xl shadow-amber-900/5">
          <div className="absolute inset-0 overflow-hidden rounded-3xl pointer-events-none">
            <div className="absolute -right-20 -top-20 w-48 h-48 bg-amber-100/30 rounded-full blur-3xl"></div>
            <div className="absolute -left-20 -bottom-20 w-48 h-48 bg-orange-100/20 rounded-full blur-3xl"></div>
          </div>

        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 relative z-10">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-500 text-white flex items-center justify-center shadow-md shadow-amber-500/20 shrink-0">
              <Mail className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black text-slate-800 flex items-center gap-2">
                <span>نامه‌های زمان‌دار</span>
              </h2>
              <p className="text-xs text-slate-500 font-bold mt-0.5">
                کپسول‌های زمان و نامه‌هایی که در تاریخی مشخص باز می‌شوند
              </p>
            </div>
          </div>
          <button 
            onClick={() => {
              if (showForm) resetForm();
              else setDraft({ showForm: true });
            }} 
            className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white text-xs font-bold px-4 py-2 rounded-xl flex items-center gap-1.5 transition-all active:scale-95 shadow-md shadow-amber-500/20 shrink-0 justify-center"
          >
            <Plus className={`w-3.5 h-3.5 text-white transition-transform duration-300 ${showForm ? 'rotate-45' : ''}`} />
            <span>{showForm ? 'انصراف' : 'نوشتن نامه جدید'}</span>
          </button>
        </div>

        {/* Add/Edit Form */}
        <AnimatePresence>
          {showForm && (
            <motion.div 
              ref={formRef}
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="mt-6 overflow-hidden relative z-10 pt-4 border-t border-rose-100"
            >
              <form onSubmit={handleSave} className="space-y-4">
                {editingId && (
                  <div className="text-amber-600 text-xs font-black flex items-center gap-2 pb-1">
                    <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
                    <Edit3 className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                    <span>در حال ویرایش نامه: {title || 'بدون عنوان'}</span>
                  </div>
                )}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-extrabold text-slate-700 mb-1">از طرف (فرستنده):</label>
                    <input 
                      type="text" 
                      placeholder="مثلا: امین" 
                      required 
                      value={sender} 
                      onChange={e => setDraft({ sender: e.target.value, confirmSave: false })}
                      className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm focus:border-rose-400 focus:outline-none" 
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-extrabold text-slate-700 mb-1">برای (گیرنده):</label>
                    <input 
                      type="text" 
                      placeholder="مثلا: نیایش" 
                      required 
                      value={recipient} 
                      onChange={e => setDraft({ recipient: e.target.value, confirmSave: false })}
                      className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm focus:border-rose-400 focus:outline-none" 
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-extrabold text-slate-700 mb-1">عنوان نامه:</label>
                  <input 
                    type="text" 
                    placeholder="مثلا: برای تولد سال بعدت..." 
                    required 
                    value={title} 
                    onChange={e => setDraft({ title: e.target.value, confirmSave: false })}
                    className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm focus:border-rose-400 focus:outline-none font-bold text-slate-800" 
                  />
                </div>
                <div>
                  <label className="block text-xs font-extrabold text-slate-700 mb-1.5">تاریخ و زمان باز شدن نامه (شمسی):</label>
                  <PersianDateTimePicker 
                    value={openDate} 
                    onChange={(iso) => setDraft({ openDate: iso, confirmSave: false })} 
                  />
                </div>
                <div>
                  <label className="block text-xs font-extrabold text-slate-700 mb-1">متن کامل نامه:</label>
                  <textarea 
                    rows={6} 
                    placeholder="حرف‌های دلت رو بنویس..." 
                    required 
                    value={text} 
                    onChange={e => setDraft({ text: e.target.value, confirmSave: false })}
                    className="w-full bg-white border border-slate-200 rounded-xl p-3 text-sm focus:border-rose-400 focus:outline-none leading-[2]"
                  ></textarea>
                </div>
                <div className="flex justify-end gap-2 pt-2">
                  <button 
                    type="button" 
                    onClick={resetForm} 
                    className="flex items-center justify-center bg-slate-100 text-slate-600 text-xs px-3.5 py-2 rounded-xl font-bold hover:bg-slate-200 transition-colors"
                  >
                    انصراف
                  </button>
                  <button 
                    type="submit" 
                    className={`flex items-center justify-center text-white text-xs font-bold px-4 py-2 rounded-xl transition-all ${
                      confirmSave 
                        ? 'bg-amber-500 hover:bg-amber-600 shadow-md shadow-amber-500/20' 
                        : 'bg-gradient-to-r from-rose-500 to-pink-500 hover:from-rose-600 hover:to-pink-600 shadow-md shadow-rose-500/20'
                    }`}
                  >
                    {confirmSave ? 'مطمئنم، ذخیره کن (غیرقابل ویرایش)' : (editingId ? 'ذخیره تغییرات' : 'مُهر و موم کردن نامه')}
                  </button>
                </div>
              </form>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Layer 2: Letter Cards Grid directly on page */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {sortedCapsules.length === 0 ? (
          isInitialLoading ? (
            <div className="col-span-full">
              <SkeletonList count={4} />
            </div>
          ) : (
            <div className="col-span-full glass-card rounded-3xl p-10 text-center text-slate-500 text-xs flex flex-col items-center justify-center gap-3 border border-dashed border-rose-200">
              <div className="w-12 h-12 rounded-full bg-rose-50 flex items-center justify-center text-rose-500">
                <Mail className="w-6 h-6" />
              </div>
              <p className="font-extrabold text-slate-700 text-base">هنوز نامه‌ای نوشته نشده...</p>
              <p className="text-xs text-slate-400">با زدن دکمه «نوشتن نامه جدید» یک کپسول زمان عاشقانه بساز.</p>
            </div>
          )
        ) : (
          displayedCapsules.map((capsule, idx) => {
            const locked = checkLocked(capsule.openDate);
            const isEditable = (Date.now() - (capsule.createdAt || 0) <= 30000);
            const editTimeLeft = Math.max(0, Math.floor((30000 - (Date.now() - (capsule.createdAt || 0))) / 1000));
            
            return (
              <motion.div 
                layout
                key={capsule.id} 
                initial={{ opacity: 0, y: 14 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.35, delay: Math.min(idx * 0.05, 0.3), ease: 'easeOut' }}
                className={`relative p-4 sm:p-5 rounded-3xl transition-all duration-300 shadow-md hover:shadow-lg hover:-translate-y-1 ${
                  capsule.pinned 
                    ? 'bg-[#fffafb] border-2 border-rose-200/90' 
                    : 'bg-white border border-stone-200/80'
                }${
                  locked 
                    ? ' opacity-90' 
                    : ' cursor-pointer'
                }`}
                onClick={() => !locked && openLetter(capsule)}
              >
                {/* Card Top Header */}
                <div className="flex justify-between items-center gap-2 mb-3">
                  <div className="flex items-center gap-2 min-w-0 flex-wrap">
                    <div className={`p-2 rounded-xl shrink-0 ${
                      capsule.pinned
                        ? 'bg-rose-100 text-rose-600'
                        : (locked ? 'bg-stone-200 text-stone-500' : 'bg-rose-100 text-rose-600')
                    }`}>
                      {locked ? <Lock className="w-4 h-4" /> : <Unlock className="w-4 h-4" />}
                    </div>
                    {capsule.pinned && (
                      <span className="inline-flex items-center gap-1 bg-rose-50 border border-rose-200 text-rose-700 text-[10px] font-black px-2 py-0.5 rounded-full shadow-2xs shrink-0">
                        <Star className="w-2.5 h-2.5 fill-rose-500 text-rose-500" />
                        <span>نامه برگزیده</span>
                      </span>
                    )}
                    <h3 className={`font-black text-sm sm:text-base truncate ${
                      capsule.pinned ? 'text-rose-950 font-bold' : 'text-stone-900'
                    }`}>
                      {capsule.title}
                    </h3>
                  </div>
                  
                  {/* Only prevent click propagation for Kebab Menu */}
                  <div className="flex items-center gap-1 shrink-0" onClick={e => e.stopPropagation()}>
                    {!locked && !capsule.isOpened && (
                      <span className="text-[10px] font-black bg-rose-500 text-white px-2 py-0.5 rounded-full animate-pulse shadow-xs">جدید!</span>
                    )}
                    <KebabMenu>
                      <KebabMenuItem 
                        icon={<Star className={`w-4 h-4 ${capsule.pinned ? 'text-rose-500 fill-rose-500' : 'text-slate-400'}`} />} 
                        label={capsule.pinned ? 'برداشتن نشان برتر' : 'نشان کردن به عنوان برتر'} 
                        onClick={() => updateCapsule({ ...capsule, pinned: !capsule.pinned })} 
                      />
                      {isEditable ? (
                        <KebabMenuItem 
                          icon={<Edit3 className="w-4 h-4 text-slate-500" />} 
                          label="ویرایش" 
                          onClick={() => handleEdit(capsule)} 
                        />
                      ) : null}
                      {isEditable ? (
                        <KebabMenuItem 
                          icon={<Trash2 className="w-4 h-4 text-rose-500" />} 
                          label="حذف" 
                          danger 
                          onClick={() => removeCapsule(capsule.id)} 
                        />
                      ) : null}
                    </KebabMenu>
                  </div>
                </div>

                <div className="mt-3 flex flex-col gap-2">
                  <div className="flex items-center gap-2 text-[11px] font-bold">
                    {locked ? (
                      <span className={`flex items-center gap-1.5 px-3 py-2 rounded-xl w-full border ${
                        capsule.pinned 
                          ? 'text-rose-800 bg-rose-50 border-rose-200 font-bold' 
                          : 'text-stone-700 bg-stone-100 border-stone-200 font-bold'
                      }`}>
                        <Clock className="w-3.5 h-3.5" /> 
                        <span>قفل تا: {formatJalaliReadable(capsule.openDate)} ({calculateTimeLeft(capsule.openDate)})</span>
                      </span>
                    ) : (
                      <span className={`flex items-center gap-1.5 px-3 py-2 rounded-xl w-full border ${
                        capsule.pinned
                          ? 'text-rose-900 bg-rose-50 border-rose-200 font-black'
                          : 'text-rose-700 bg-rose-50 border-rose-200 font-black'
                      }`}>
                        <Mail className="w-3.5 h-3.5 text-rose-600" /> 
                        {capsule.isOpened ? 'خوانده شده (برای مرور دوباره لمس کنید)' : 'آماده‌ی باز شدن - این نامه خاص را لمس کن!'}
                      </span>
                    )}
                  </div>
                  {editTimeLeft > 0 && (
                    <div className="text-[10px] text-amber-800 font-black bg-amber-50 px-3 py-1.5 rounded-xl w-full border border-amber-300">
                      زمان باقی‌مانده برای ویرایش: {editTimeLeft} ثانیه
                    </div>
                  )}
                </div>
              </motion.div>
            );
          })
        )}
      </div>

      {sortedCapsules.length > 4 && (
        <div className="flex justify-center gap-3 mt-6 relative z-10 pb-4">
          {hasMore && (
            <button onClick={() => setShowCount(c => c + 4)} className="bg-white/95 backdrop-blur-sm border border-rose-100 hover:bg-rose-50 text-rose-500 transition-all px-6 py-2.5 rounded-full font-bold text-xs flex items-center gap-2 shadow-sm active:scale-95">
              <Heart className="w-4 h-4 fill-rose-500" />
              نمایش بیشتر ({sortedCapsules.length - showCount})
            </button>
          )}
          {hasLess && (
            <button onClick={() => setShowCount(4)} className="bg-white/95 backdrop-blur-sm border border-slate-100 hover:bg-slate-50 text-slate-500 transition-all px-6 py-2.5 rounded-full font-bold text-xs flex items-center gap-2 shadow-sm active:scale-95">
              نمایش کمتر
            </button>
          )}
        </div>
      )}
    </div>
    </PageWrapper>
  );
};
