import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { 
  Heart, Trophy, 
  Dices, Zap, Shuffle, Gamepad2,
  Award, HelpCircle, Flame,
  RotateCcw, Loader2, Lock
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useSearchParams } from 'react-router';
import { PageWrapper } from '../components/PageWrapper';
import { generateTelepathyQuestion, generateTruthOrDare, AiTelepathyQuestion } from '../lib/gameAi';
import { APP_SECRET } from '../lib/appSecret';

const WORKER_URL = "https://niya.am-b-asdfghjkl20112011.workers.dev";

export type MomentsTab = 'bottle' | 'tictactoe' | 'telepathy';

// --- DATASETS FOR VIRTUAL LDR COUPLE ---

// یک سوال پیش‌فرض یکسان که فقط برای یک لحظه‌ی کوتاه، تا قبل از رسیدن اولین
// سوال از هوش مصنوعی، روی هر دو گوشی یکسان نمایش داده می‌شه (بدون سینک هم یکیه).
const FALLBACK_FIRST_QUESTION = {
  q: 'برای شب‌های خستگی کدوم رو ترجیح میدی؟',
  a: 'ویس‌کال شبانه تا وقتی خوابمون ببره 🌙',
  b: 'تماشای همزمان فیلم با واچ‌پارتی 🎬'
};

// State Structure
type MomentsData = {
  // Tic-Tac-Toe
  board: (string | null)[];
  turn: 'amin' | 'niyayesh';
  scores: { amin: number; niyayesh: number; draws: number };
  winner: string | null;
  // Telepathy
  telepathyChoices: { [qId: string]: { amin?: string; niyayesh?: string } };
  currentTelepathyQuestion?: AiTelepathyQuestion & { id: string };
  // Bottle
  lastBottleResult?: { type: 'truth' | 'dare'; text: string; timestamp: number; spinnerId: 'amin' | 'niyayesh'; answeredAt?: number };
};

const INITIAL_DATA: MomentsData = {
  board: Array(9).fill(null),
  turn: 'amin',
  scores: { amin: 0, niyayesh: 0, draws: 0 },
  winner: null,
  telepathyChoices: {},
  currentTelepathyQuestion: undefined,
  lastBottleResult: undefined
};

function sanitizeMomentsData(data: any): MomentsData {
  if (!data || typeof data !== 'object') return INITIAL_DATA;
  return {
    board: Array.isArray(data.board) && data.board.length === 9 ? data.board : Array(9).fill(null),
    turn: data.turn === 'niyayesh' ? 'niyayesh' : 'amin',
    scores: {
      amin: Number(data.scores?.amin) || 0,
      niyayesh: Number(data.scores?.niyayesh) || 0,
      draws: Number(data.scores?.draws) || 0
    },
    winner: typeof data.winner === 'string' ? data.winner : null,
    telepathyChoices: (data.telepathyChoices && typeof data.telepathyChoices === 'object') ? data.telepathyChoices : {},
    currentTelepathyQuestion: (data.currentTelepathyQuestion && typeof data.currentTelepathyQuestion === 'object' && data.currentTelepathyQuestion.id)
      ? data.currentTelepathyQuestion : undefined,
    lastBottleResult: data.lastBottleResult && typeof data.lastBottleResult === 'object' ? data.lastBottleResult : undefined
  };
}

export const Moments: React.FC = () => {
  const [searchParams] = useSearchParams();
  const requestedTab = searchParams.get('tab') as MomentsTab;
  const initialTab: MomentsTab = (requestedTab && ['bottle', 'tictactoe', 'telepathy'].includes(requestedTab))
    ? requestedTab
    : 'bottle';

  // Read identity
  const currentUser = (localStorage.getItem('loveniya_user') as 'amin' | 'niyayesh') || 'amin';
  const partnerName = currentUser === 'amin' ? 'نیایش' : 'امین';
  const partnerKey: 'amin' | 'niyayesh' = currentUser === 'amin' ? 'niyayesh' : 'amin';

  const [activeTab, setActiveTab] = useState<MomentsTab>(initialTab);
  const [gameData, setGameData] = useState<MomentsData>(INITIAL_DATA);
  const mutatedAtRef = useRef<number>(0);

  // Telepathy — question itself now lives in synced gameData.currentTelepathyQuestion
  const [isGeneratingQuestion, setIsGeneratingQuestion] = useState(false);

  // Bottle Spinner & Truth/Dare
  const [isBottleSpinning, setIsBottleSpinning] = useState(false);
  const [bottleAngle, setBottleAngle] = useState(0);
  const [selectedDare, setSelectedDare] = useState<{ type: 'truth' | 'dare'; text: string } | null>(null);

  // Toast
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 3000);
  };

  // Sync with Cloudflare Worker — sends only the changed fields (PATCH/merge),
  // never the whole local snapshot, so two people interacting with different
  // games at nearly the same time can never silently overwrite each other.
  const syncState = useCallback(async (patch: Partial<MomentsData>) => {
    mutatedAtRef.current = Date.now();
    setGameData(prev => {
      const merged = sanitizeMomentsData({ ...prev, ...patch });
      try { localStorage.setItem('loveniya_moments_v2', JSON.stringify(merged)); } catch(e) {}
      return merged;
    });

    try {
      await fetch(`${WORKER_URL}/loveniya_moments_v2.json`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json', 'X-App-Secret': APP_SECRET },
        body: JSON.stringify(patch)
      });
    } catch {
      // offline fallback
    }
  }, []);

  const fetchData = useCallback(async () => {
    if (Date.now() - mutatedAtRef.current < 8000) return;

    try {
      const res = await fetch(`${WORKER_URL}/loveniya_moments_v2.json?_t=${Date.now()}`, { cache: 'no-store', headers: { 'X-App-Secret': APP_SECRET } });
      if (res.ok) {
        const data = await res.json();
        const clean = sanitizeMomentsData(data);
        setGameData(clean);
        try { localStorage.setItem('loveniya_moments_v2', JSON.stringify(clean)); } catch(e) {}
      }
    } catch {
      const saved = localStorage.getItem('loveniya_moments_v2');
      if (saved) {
        try { setGameData(sanitizeMomentsData(JSON.parse(saved))); } catch(e) {}
      }
    }
  }, []);

  useEffect(() => {
    const saved = localStorage.getItem('loveniya_moments_v2');
    if (saved) {
      try { setGameData(sanitizeMomentsData(JSON.parse(saved))); } catch(e) {}
    }
    fetchData();
    const interval = setInterval(() => {
      if (typeof document !== 'undefined' && document.visibilityState !== 'visible') return;
      fetchData();
    }, 6000);
    return () => clearInterval(interval);
  }, [fetchData]);

  // --- 1. TIC-TAC-TOE LOGIC ---
  const checkWinner = (squares: (string | null)[]) => {
    const lines = [
      [0, 1, 2], [3, 4, 5], [6, 7, 8], // rows
      [0, 3, 6], [1, 4, 7], [2, 5, 8], // cols
      [0, 4, 8], [2, 4, 6]             // diags
    ];
    for (let i = 0; i < lines.length; i++) {
      const [a, b, c] = lines[i];
      if (squares[a] && squares[a] === squares[b] && squares[a] === squares[c]) {
        return squares[a];
      }
    }
    if (squares.every(s => s !== null)) return 'draw';
    return null;
  };

  const handleSquareClick = (index: number) => {
    const currentBoard = gameData.board || Array(9).fill(null);
    if (currentBoard[index] || gameData.winner) return;
    if (gameData.turn !== currentUser) return; // نوبت طرف مقابله؛ اجازه حرکت نده

    // Symbol: X for Amin, O for Niyayesh
    const symbol = currentUser === 'amin' ? 'X' : 'O';
    const newBoard = [...currentBoard];
    newBoard[index] = symbol;

    const winnerResult = checkWinner(newBoard);
    let newScores = { ...(gameData.scores || { amin: 0, niyayesh: 0, draws: 0 }) };

    if (winnerResult === 'X') {
      newScores.amin += 1;
    } else if (winnerResult === 'O') {
      newScores.niyayesh += 1;
    } else if (winnerResult === 'draw') {
      newScores.draws += 1;
    }

    const nextTurn = gameData.turn === 'amin' ? 'niyayesh' : 'amin';

    syncState({
      board: newBoard,
      turn: nextTurn,
      winner: winnerResult,
      scores: newScores
    });
  };

  const handleResetBoard = () => {
    syncState({
      board: Array(9).fill(null),
      winner: null,
      turn: 'amin'
    });
    showToast('✨ زمین بازی ریست شد');
  };

  // اعلام برد/تساوی — روی هر دو گوشی یکسان، چه کسی که حرکت آخر رو زده باشه
  // چه کسی که فقط داره نتیجه رو از طریق سینک می‌بینه. اولین رندر (بارگذاری
  // صفحه با یک نتیجه‌ی قدیمی از قبل) نادیده گرفته می‌شه تا نتیجه‌ی بازی
  // قبلی دوباره اعلام نشه.
  const winnerWatcherMounted = useRef(false);
  const lastSeenWinnerRef = useRef<string | null>(null);
  useEffect(() => {
    const w = gameData.winner;
    if (!winnerWatcherMounted.current) {
      winnerWatcherMounted.current = true;
      lastSeenWinnerRef.current = w;
      return;
    }
    if (w === lastSeenWinnerRef.current) return;
    lastSeenWinnerRef.current = w;
    if (w === 'X') showToast('🎉 امین برنده این دست شد!');
    else if (w === 'O') showToast('🎉 نیایش برنده این دست شد!');
    else if (w === 'draw') showToast('🤝 این دست مساوی شد!');
  }, [gameData.winner]);

  // --- 2. TELEPATHY (THIS OR THAT) LOGIC — fully AI-generated & synced ---
  const currentQ = gameData.currentTelepathyQuestion || { id: 'default', ...FALLBACK_FIRST_QUESTION };
  const allChoices = gameData.telepathyChoices || {};
  const qChoices = allChoices[currentQ.id] || {};
  const myChoice = qChoices[currentUser];
  const partnerChoice = qChoices[partnerKey];
  const bothAnswered = !!myChoice && !!partnerChoice;
  const isMatch = bothAnswered && myChoice === partnerChoice;

  const handleSelectTelepathy = (choiceKey: 'A' | 'B') => {
    const updatedChoices = {
      ...(gameData.telepathyChoices || {}),
      [currentQ.id]: {
        ...qChoices,
        [currentUser]: choiceKey
      }
    };
    syncState({ telepathyChoices: updatedChoices });
    showToast('✨ انتخاب شما با ۱ کلیک ثبت شد!');
  };

  // درخواست یک سوال تازه از هوش مصنوعی — چون امین و نیایش وقت نوشتن سوال ندارن،
  // این تنها راه گرفتن سوال بعدیه (گزینه دستی وجود نداره).
  const handleNextAiQuestion = async () => {
    if (isGeneratingQuestion) return;
    setIsGeneratingQuestion(true);
    try {
      const generated = await generateTelepathyQuestion();
      syncState({
        currentTelepathyQuestion: { id: `ai-${Date.now()}`, ...generated }
      });
    } finally {
      setIsGeneratingQuestion(false);
    }
  };

  // اولین بار که صفحه باز می‌شه و هنوز هیچ سوالی سینک نشده، یک سوال تازه بساز.
  useEffect(() => {
    if (!gameData.currentTelepathyQuestion && !isGeneratingQuestion) {
      handleNextAiQuestion();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [gameData.currentTelepathyQuestion]);

  // Telepathy Match Rate — روی همه سوالاتی که واقعاً پاسخ داده شدن حساب می‌شه
  // (نه فقط بانک ثابت قدیمی)، چون سوالات حالا به‌صورت نامحدود از AI میان.
  const matchRate = useMemo(() => {
    let total = 0;
    let matches = 0;
    const choices: { [qId: string]: { amin?: string; niyayesh?: string } } = gameData.telepathyChoices || {};
    Object.values(choices).forEach(c => {
      if (c && c.amin && c.niyayesh) {
        total++;
        if (c.amin === c.niyayesh) matches++;
      }
    });
    return total > 0 ? Math.round((matches / total) * 100) : 100;
  }, [gameData.telepathyChoices]);

  // وقتی طرف مقابل به سوال فعلی جواب می‌ده و من هنوز جواب ندادم، خبر بده —
  // این‌جوری منتظر نمی‌مونم تا خودم بیام چک کنم. اگه هر دومون جواب داده
  // باشیم، بنر تطابق همین الان توی کارت دیده می‌شه و نیازی به toast اضافه نیست.
  const telepathyWatcherMounted = useRef(false);
  const lastSeenPartnerChoiceRef = useRef<string | undefined>(undefined);
  useEffect(() => {
    if (!telepathyWatcherMounted.current) {
      telepathyWatcherMounted.current = true;
      lastSeenPartnerChoiceRef.current = partnerChoice;
      return;
    }
    if (partnerChoice && partnerChoice !== lastSeenPartnerChoiceRef.current && !myChoice) {
      showToast(`💭 ${partnerName} به این سوال جواب داد، نوبت توئه!`);
    }
    lastSeenPartnerChoiceRef.current = partnerChoice;
  }, [partnerChoice, myChoice, partnerName]);


  // --- 3. BOTTLE SPINNER & TRUTH/DARE ---
  const handleSpinBottle = async (forcedKind?: 'truth' | 'dare') => {
    if (isBottleSpinning) return;
    setIsBottleSpinning(true);
    setSelectedDare(null);

    const randomRotations = 1440 + Math.floor(Math.random() * 720);
    setBottleAngle(prev => prev + randomRotations);

    const kind: 'truth' | 'dare' = forcedKind || (Math.random() > 0.5 ? 'truth' : 'dare');

    // هم‌زمان: هوش مصنوعی متن رو تولید می‌کنه و انیمیشن چرخش حداقل ۲ ثانیه ادامه پیدا می‌کنه
    const [text] = await Promise.all([
      generateTruthOrDare(kind),
      new Promise<void>(resolve => setTimeout(resolve, 2000))
    ]);

    const result = { type: kind, text, timestamp: Date.now(), spinnerId: currentUser };
    lastSeenBottleTs.current = result.timestamp; // this device already reveals locally below; don't re-trigger from the watcher
    syncState({ lastBottleResult: result });

    setIsBottleSpinning(false);
    setSelectedDare({ type: result.type, text: result.text });
  };

  // Shows the bottle result on the *other* device too, with its own short
  // suspense animation, instead of it only ever appearing for whoever spun it.
  // همین watcher مسئول بازیابیه: اگه صفحه رو ببندی و بعداً برگردی (خیلی محتمله
  // چون رابطه مجاردوره)، آخرین چالش رو بلافاصله نشون می‌ده، بدون انیمیشن
  // ساختگیِ چرخش — چون این یه رویداد زنده نیست، بازیابی یه چیز قدیمیه.
  const lastSeenBottleTs = useRef<number>(0);
  useEffect(() => {
    const result = gameData.lastBottleResult;
    if (!result || result.timestamp === lastSeenBottleTs.current) return;
    const isRestoreOnLoad = lastSeenBottleTs.current === 0;
    lastSeenBottleTs.current = result.timestamp;

    if (isRestoreOnLoad) {
      setSelectedDare({ type: result.type, text: result.text });
      return;
    }

    if (result.spinnerId === currentUser) return; // this device triggered it live, already animating

    setIsBottleSpinning(true);
    setSelectedDare(null);
    setBottleAngle(prev => prev + 1440 + Math.floor(Math.random() * 720));
    setTimeout(() => {
      setIsBottleSpinning(false);
      setSelectedDare({ type: result.type, text: result.text });
    }, 1800);
  }, [gameData.lastBottleResult, currentUser]);

  // چالش/سوال همیشه برای طرف مقابل کسیه که بطری رو چرخونده — نه برای خود
  // چرخوننده. این‌جوری هر دو گوشی دقیقاً می‌دونن نوبت جواب دادن با کیه.
  const bottleAnswererKey: 'amin' | 'niyayesh' | undefined = gameData.lastBottleResult
    ? (gameData.lastBottleResult.spinnerId === 'amin' ? 'niyayesh' : 'amin')
    : undefined;
  const isBottleAnswerer = bottleAnswererKey === currentUser;
  const bottleAnswered = !!gameData.lastBottleResult?.answeredAt;

  const handleAcknowledgeDare = () => {
    if (!gameData.lastBottleResult) return;
    syncState({ lastBottleResult: { ...gameData.lastBottleResult, answeredAt: Date.now() } });
    showToast('عالی بود! جوابت برای طرف مقابل فرستاده شد 💌');
  };

  // به چرخوننده‌ی بطری خبر بده که طرف مقابل به چالش جواب داد.
  const bottleAckWatcherMounted = useRef(false);
  const lastSeenAnsweredAtRef = useRef<number | undefined>(undefined);
  useEffect(() => {
    const answeredAt = gameData.lastBottleResult?.answeredAt;
    if (!bottleAckWatcherMounted.current) {
      bottleAckWatcherMounted.current = true;
      lastSeenAnsweredAtRef.current = answeredAt;
      return;
    }
    if (answeredAt === lastSeenAnsweredAtRef.current) return;
    lastSeenAnsweredAtRef.current = answeredAt;
    if (answeredAt && gameData.lastBottleResult?.spinnerId === currentUser) {
      showToast(`🎉 ${partnerName} به چالش جواب داد!`);
    }
  }, [gameData.lastBottleResult?.answeredAt, gameData.lastBottleResult?.spinnerId, currentUser, partnerName]);

  return (
    <PageWrapper>
      <div className="space-y-4 max-w-2xl mx-auto px-2 sm:px-4 py-2" dir="rtl">
        
        {/* Floating Toast Notification */}
        <AnimatePresence>
          {toastMsg && (
            <motion.div 
              initial={{ opacity: 0, y: -10 }} 
              animate={{ opacity: 1, y: 0 }} 
              exit={{ opacity: 0, y: -10 }}
              className="fixed top-4 left-1/2 -translate-x-1/2 z-50 bg-stone-900/90 text-white text-sm font-black px-5 py-3 rounded-2xl shadow-lg border border-stone-700 flex items-center gap-2"
            >
              
              <span>{toastMsg}</span>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Header Title in a solid card */}
        <section className="text-center space-y-1.5 pt-1 pb-1">
          <div className="bg-white/95 rounded-3xl p-5 sm:p-6 shadow-[0_16px_50px_-12px_rgba(28,25,23,0.06)] mb-2 relative overflow-hidden">
            <div className="inline-flex items-center justify-center gap-2 text-emerald-700 text-xs font-black tracking-wide flex-wrap mb-2">
              <Gamepad2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>بازی‌ها و سرگرمی‌های آنلاین امین و نیایش</span>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-stone-500 font-bold flex items-center gap-1">شما: {currentUser === 'amin' ? <><span className="text-sky-600">امین</span><Award className="w-3.5 h-3.5 text-sky-500" /></> : <><span className="text-fuchsia-600">نیایش</span><Award className="w-3.5 h-3.5 text-fuchsia-500" /></>}</span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-black text-stone-900 tracking-tight">
              کل‌کل و تفریحات دونفره
            </h1>
            <p className="text-xs text-stone-500 font-bold max-w-md mx-auto mt-2">
              بازی‌های آماده، سریع و بدون نیاز به طراحی سوال — مخصوص روزهای شلوغ و رابطه مجازی
            </p>
          </div>
        </section>

        {/* 3-Tab Navigation Bar — فقط بازی‌های واقعی و دونفره، بدون شلوغی اضافه */}
        <div className="grid grid-cols-3 gap-1.5">
          <button
            onClick={() => setActiveTab('bottle')}
            className={`py-2 px-1 rounded-2xl text-xs sm:text-sm font-black transition-[color,background-color,border-color,box-shadow,transform] flex flex-col items-center justify-center gap-1 cursor-pointer border ${
              activeTab === 'bottle'
                ? 'bg-amber-50 text-amber-700 border-amber-200 shadow-sm'
                : 'bg-white border-stone-200 text-stone-600 hover:text-stone-900 hover:border-stone-300'
            }`}
          >
            <Dices className={`w-3.5 h-3.5 ${activeTab === 'bottle' ? 'text-amber-500' : 'text-stone-400'}`} />
            <span>جرأت یا حقیقت</span>
          </button>

          <button
            onClick={() => setActiveTab('tictactoe')}
            className={`py-2 px-1 rounded-2xl text-xs sm:text-sm font-black transition-[color,background-color,border-color,box-shadow,transform] flex flex-col items-center justify-center gap-1 cursor-pointer border ${
              activeTab === 'tictactoe'
                ? 'bg-emerald-50 text-emerald-700 border-emerald-200 shadow-sm'
                : 'bg-white border-stone-200 text-stone-600 hover:text-stone-900 hover:border-stone-300'
            }`}
          >
            <Gamepad2 className={`w-3.5 h-3.5 ${activeTab === 'tictactoe' ? 'text-emerald-600' : 'text-stone-400'}`} />
            <span>دوز عاشقی</span>
          </button>

          <button
            onClick={() => setActiveTab('telepathy')}
            className={`py-2 px-1 rounded-2xl text-xs sm:text-sm font-black transition-[color,background-color,border-color,box-shadow,transform] flex flex-col items-center justify-center gap-1 cursor-pointer border ${
              activeTab === 'telepathy'
                ? 'bg-indigo-50 text-indigo-700 border-indigo-200 shadow-sm'
                : 'bg-white border-stone-200 text-stone-600 hover:text-stone-900 hover:border-stone-300'
            }`}
          >
            <Zap className={`w-3.5 h-3.5 ${activeTab === 'telepathy' ? 'text-indigo-500' : 'text-stone-400'}`} />
            <span>تله‌پاتی آماده</span>
          </button>
        </div>

        {/* TAB 1: TIC-TAC-TOE GAME */}
        {activeTab === 'tictactoe' && (
          <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
            
            {/* Scoreboard */}
            <div className="bg-white rounded-3xl p-4 border border-rose-200 shadow-2xs flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-amber-50 border border-amber-200 flex items-center justify-center text-sm font-black text-amber-800">
                  X
                </div>
                <div>
                  <span className="text-xs font-black text-stone-900 block">امین</span>
                  <span className="text-[11px] font-bold text-stone-500">{gameData.scores?.amin || 0} برد</span>
                </div>
              </div>

              <div className="text-center">
                <span className="text-[10px] font-bold text-stone-400 block">مساوی</span>
                <span className="text-xs font-black text-stone-700">{gameData.scores?.draws || 0}</span>
              </div>

              <div className="flex items-center gap-2 text-left">
                <div>
                  <span className="text-xs font-black text-stone-900 block">نیایش</span>
                  <span className="text-[11px] font-bold text-stone-500">{gameData.scores?.niyayesh || 0} برد</span>
                </div>
                <div className="w-8 h-8 rounded-xl bg-rose-50 border border-rose-200 flex items-center justify-center text-sm font-black text-rose-800">
                  O
                </div>
              </div>
            </div>

            {/* 3x3 Grid Board */}
            <div className="bg-white rounded-3xl p-6 border border-stone-200 shadow-xs max-w-sm mx-auto text-center space-y-4">
              
              {/* Turn Banner */}
              <div className="flex justify-center">
                {gameData.winner ? (
                  <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-2xl text-xs font-black shadow-sm ${
                    gameData.winner === 'draw' 
                      ? 'bg-amber-100 text-amber-800 border border-amber-200'
                      : 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                  }`}>
                    {gameData.winner === 'draw' ? (
                      <>
                        <Heart className="w-4 h-4 text-amber-600" />
                        <span>بازی مساوی شد!</span>
                      </>
                    ) : (
                      <>
                        <Trophy className="w-4 h-4 text-emerald-600" />
                        <span>برنده این دست: {gameData.winner === 'X' ? 'امین' : 'نیایش'}</span>
                      </>
                    )}
                  </div>
                ) : (
                  <div className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-xs font-black ${
                    gameData.turn === currentUser
                      ? 'bg-rose-50 text-rose-700 border-rose-200'
                      : 'bg-stone-100 text-stone-500 border-stone-200'
                  }`}>
                    {gameData.turn !== currentUser && <Lock className="w-3 h-3" />}
                    <span>
                      {gameData.turn === currentUser
                        ? `نوبت توئه (${currentUser === 'amin' ? 'X' : 'O'})`
                        : `منتظر حرکت ${partnerName}...`}
                    </span>
                  </div>
                )}
              </div>

              {/* Grid */}
              <div className="grid grid-cols-3 gap-2.5 max-w-[260px] mx-auto aspect-square">
                {(gameData.board || Array(9).fill(null)).map((cell, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleSquareClick(idx)}
                    disabled={!!cell || !!gameData.winner || gameData.turn !== currentUser}
                    className={`rounded-2xl border flex items-center justify-center text-3xl font-black transition-[color,background-color,border-color,box-shadow,transform] select-none ${
                      cell 
                        ? 'bg-rose-50/60 border-rose-200 shadow-2xs cursor-not-allowed' 
                        : gameData.turn !== currentUser
                          ? 'bg-stone-50 border-stone-200/90 cursor-not-allowed opacity-60'
                          : 'bg-stone-50 hover:bg-rose-50/40 border-stone-200/90 hover:border-rose-300 cursor-pointer'
                    }`}
                  >
                    {cell}
                  </button>
                ))}
              </div>

              {/* Reset Game Action */}
              <div className="pt-2">
                <button
                  onClick={handleResetBoard}
                  className="inline-flex items-center gap-1.5 min-h-[44px] px-4 py-2 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-xs font-black transition-[color,background-color,border-color,box-shadow,transform] cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>دست جدید / بازی مجدد</span>
                </button>
              </div>

            </div>

          </motion.div>
        )}

        {/* TAB 2: READY TELEPATHY QUESTIONS */}
        {activeTab === 'telepathy' && (
          <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
            
            {/* Header Banner */}
            <div className="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-3xl p-5 text-white shadow-sm flex items-center justify-between">
              <div>
                <span className="text-[10px] font-bold bg-white/20 px-2.5 py-0.5 rounded-full inline-block mb-1">
                  تله‌پاتی و هماهنگی فکری
                </span>
                <h3 className="text-xl font-black flex items-center gap-1.5">
                  <Zap className="w-5 h-5 text-amber-300" />
                  <span>تطابق ذهنی: {matchRate}٪</span>
                </h3>
              </div>

              <button
                onClick={handleNextAiQuestion}
                disabled={isGeneratingQuestion}
                className={`bg-white/20 hover:bg-white/30 disabled:opacity-60 text-white text-xs font-black px-3 py-2 rounded-xl transition-[color,background-color,border-color,box-shadow,transform] flex items-center gap-1.5 cursor-pointer shrink-0 ${
                  bothAnswered ? 'ring-2 ring-amber-300 animate-pulse' : ''
                }`}
              >
                {isGeneratingQuestion ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Shuffle className="w-3.5 h-3.5" />}
                <span>{isGeneratingQuestion ? 'در حال ساخت سوال...' : 'سوال بعدی'}</span>
              </button>
            </div>

            {/* Question Card */}
            <div className="bg-white rounded-3xl p-5 sm:p-7 border border-indigo-200 shadow-xs text-center space-y-4">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-200 text-xs font-black text-indigo-800">
                
                <span>سوال تازه، ساخته‌شده توسط هوش مصنوعی</span>
              </span>

              <h3 className="text-sm sm:text-base font-black text-stone-900">
                {currentQ.q}
              </h3>

              {/* 2 Big Choice Buttons */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                <button
                  onClick={() => handleSelectTelepathy('A')}
                  className={`p-4 rounded-2xl border text-right transition-[color,background-color,border-color,box-shadow,transform] cursor-pointer flex flex-col justify-between gap-3 ${
                    myChoice === 'A'
                      ? 'bg-indigo-600 text-white border-indigo-700 shadow-xs'
                      : 'bg-stone-50 hover:bg-indigo-50/50 border-stone-200 text-stone-800'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-lg">گزینه اول</span>
                    {myChoice === 'A' && <span className="text-[10px] bg-white/20 px-2 py-0.5 rounded-md font-bold">انتخاب شما ✓</span>}
                  </div>
                  <p className="text-xs sm:text-sm font-bold leading-relaxed">{currentQ.a}</p>
                </button>

                <button
                  onClick={() => handleSelectTelepathy('B')}
                  className={`p-4 rounded-2xl border text-right transition-[color,background-color,border-color,box-shadow,transform] cursor-pointer flex flex-col justify-between gap-3 ${
                    myChoice === 'B'
                      ? 'bg-indigo-600 text-white border-indigo-700 shadow-xs'
                      : 'bg-stone-50 hover:bg-indigo-50/50 border-stone-200 text-stone-800'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-lg">گزینه دوم</span>
                    {myChoice === 'B' && <span className="text-[10px] bg-white/20 px-2 py-0.5 rounded-md font-bold">انتخاب شما ✓</span>}
                  </div>
                  <p className="text-xs sm:text-sm font-bold leading-relaxed">{currentQ.b}</p>
                </button>
              </div>

              {/* Partner Status */}
              <div className="bg-stone-50 rounded-2xl p-3 border border-stone-200 text-xs font-bold text-stone-700 flex items-center justify-between">
                <span>وضعیت {partnerName}: {partnerChoice ? 'پاسخ داده ✓' : 'منتظر انتخاب...'}</span>
                {bothAnswered && (
                  <span className={`px-2.5 py-0.5 rounded-lg text-[11px] font-black ${isMatch ? 'bg-emerald-100 text-emerald-800' : 'bg-stone-200 text-stone-700'}`}>
                    {isMatch ? '🎉 تطابق ۱۰۰٪ تله‌پاتی!' : '❤️ سلایق مکمل'}
                  </span>
                )}
              </div>
            </div>

          </motion.div>
        )}

        {/* TAB 3: TRUTH OR DARE — بازی اصلی امین و نیایش */}
        {activeTab === 'bottle' && (
          <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
            
            <div className="bg-white rounded-3xl p-6 sm:p-8 text-center border border-amber-200 shadow-xs space-y-5">
              <div>
                <h3 className="text-base font-black text-stone-900">
                  جرأت یا حقیقت
                </h3>
                <p className="text-xs text-stone-500 font-medium mt-0.5">
                  بطری رو بچرخون یا خودت مستقیم انتخاب کن — سوال همیشه برای طرف مقابلته
                </p>
              </div>

              {/* Rotating Bottle Animation */}
              <div className="relative w-36 h-36 mx-auto flex items-center justify-center">
                <div className="absolute inset-0 rounded-full border-2 border-dashed border-amber-200/80 animate-spin-slow" />
                <div 
                  className="text-5xl select-none transition-transform duration-[2000ms] ease-out cursor-pointer"
                  style={{ transform: `rotate(${bottleAngle}deg)` }}
                  onClick={() => handleSpinBottle()}
                >
                  🍾
                </div>
              </div>

              <button
                onClick={() => handleSpinBottle()}
                disabled={isBottleSpinning}
                className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white text-sm font-black px-6 py-3 rounded-xl transition-[color,background-color,border-color,box-shadow,transform] shadow-xs cursor-pointer active:scale-95 disabled:opacity-50 flex items-center justify-center gap-2 mx-auto"
              >
                <Dices className="w-4 h-4" />
                <span>{isBottleSpinning ? 'در حال چرخیدن...' : 'چرخاندن بطری (شانسی)'}</span>
              </button>

              {/* Direct choice — برای وقتی که می‌خوای خودت انتخاب کنی، نه شانسی */}
              <div className="grid grid-cols-2 gap-2.5 max-w-xs mx-auto">
                <button
                  onClick={() => handleSpinBottle('truth')}
                  disabled={isBottleSpinning}
                  className="bg-sky-50 hover:bg-sky-100 text-sky-800 border border-sky-200 text-xs font-black py-2.5 rounded-xl transition-[color,background-color,border-color,box-shadow,transform] cursor-pointer active:scale-95 disabled:opacity-50 flex items-center justify-center gap-1.5"
                >
                  <HelpCircle className="w-3.5 h-3.5" />
                  <span>فقط حقیقت</span>
                </button>
                <button
                  onClick={() => handleSpinBottle('dare')}
                  disabled={isBottleSpinning}
                  className="bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-200 text-xs font-black py-2.5 rounded-xl transition-[color,background-color,border-color,box-shadow,transform] cursor-pointer active:scale-95 disabled:opacity-50 flex items-center justify-center gap-1.5"
                >
                  <Flame className="w-3.5 h-3.5" />
                  <span>فقط شجاعت</span>
                </button>
              </div>

              {/* Dare / Truth Result */}
              {selectedDare && (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className={`p-4 rounded-2xl border text-center space-y-2.5 ${
                    selectedDare.type === 'truth'
                      ? 'bg-sky-50 border-sky-200 text-sky-950'
                      : 'bg-rose-50 border-rose-200 text-rose-950'
                  }`}
                >
                  <span className="text-xs font-black px-3 py-1 rounded-full bg-white shadow-2xs inline-flex items-center gap-1.5">
                    {selectedDare.type === 'truth' ? <><HelpCircle className="w-3.5 h-3.5 text-sky-500" /><span>سوال حقیقت</span></> : <><Flame className="w-3.5 h-3.5 text-rose-500" /><span>چالش شجاعت</span></>}
                  </span>
                  <p className="text-xs sm:text-sm font-bold leading-relaxed">
                    {selectedDare.text}
                  </p>

                  {/* مشخص می‌کنه دقیقاً نوبت جواب دادن با کیه */}
                  <div className="pt-1">
                    {isBottleAnswerer ? (
                      bottleAnswered ? (
                        <span className="inline-flex items-center gap-1.5 text-[11px] font-black bg-white/70 px-3 py-1.5 rounded-full">
                          ✅ جوابت ثبت شد
                        </span>
                      ) : (
                        <button
                          onClick={handleAcknowledgeDare}
                          className="min-h-[40px] px-5 py-2 rounded-xl bg-stone-900 hover:bg-stone-800 text-white text-xs font-black transition-[color,background-color,border-color,box-shadow,transform] cursor-pointer active:scale-95"
                        >
                          نوبت توئه — جواب دادم ✅
                        </button>
                      )
                    ) : (
                      <span className="inline-flex items-center gap-1.5 text-[11px] font-black bg-white/70 px-3 py-1.5 rounded-full">
                        {bottleAnswered ? `✅ ${partnerName} جواب داد` : `⏳ منتظر جواب ${partnerName}...`}
                      </span>
                    )}
                  </div>
                </motion.div>
              )}
            </div>

          </motion.div>
        )}

      </div>
    </PageWrapper>
  );
};
