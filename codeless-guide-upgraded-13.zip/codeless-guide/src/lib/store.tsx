import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { Memory, Pledge, Dream, Music, Capsule, TrashItem, SyncStatus } from './types';
import { APP_SECRET } from './appSecret';
import { bumpRev, fetchRevs } from './rev';

// آدرس پُل اختصاصی شما در کلودفلر
const WORKER_URL = "https://niya.am-b-asdfghjkl20112011.workers.dev";

interface StoreContextType {
  memories: Memory[];
  pledges: Pledge[];
  dreams: Dream[];
  playlist: Music[];
  capsules: Capsule[];
  trashItems: TrashItem[];
  letterContent: string;
  syncStatus: SyncStatus;
  syncError: string | null;
  isInitialLoading: boolean;
  addMemory: (m: Memory) => void;
  updateMemory: (m: Memory) => void;
  removeMemory: (id: string) => void;
  addPledge: (p: Pledge) => void;
  updatePledge: (p: Pledge) => void;
  removePledge: (id: string) => void;
  addDream: (d: Dream) => void;
  updateDream: (d: Dream) => void;
  removeDream: (id: string) => void;
  addMusic: (m: Music) => void;
  updateMusic: (m: Music) => void;
  removeMusic: (id: string) => void;
  addCapsule: (c: Capsule) => void;
  updateCapsule: (c: Capsule) => void;
  removeCapsule: (id: string) => void;
  setLetterContent: (text: string) => void;
  moveToTrash: (type: TrashItem['type'], item: any) => void;
  emptyTrash: () => void;
  restoreFromTrash: (trashId: string) => void;
  permanentlyDeleteFromTrash: (trashId: string) => void;
}

const StoreContext = createContext<StoreContextType | null>(null);

// زمان ساخت هر آیتم داخل idش هست (mem_<timestamp>_<random> و ...). RTDB آیتم‌ها رو
// به ترتیب کلید برمی‌گردونه (یعنی قدیمی‌ترین اول)، در حالی که add* آیتم تازه رو
// اول لیست می‌ذاره؛ بدون این مرتب‌سازی، خاطره‌ی تازه بعد از اولین همگام‌سازی
// می‌پرید ته لیست. مرتب‌سازی پایدار و جدیدترین-اول، هر دو رفتار رو یکی می‌کنه.
const tsFromId = (x: any): number => {
  const raw = x && (x.id ?? x.trashId);
  if (typeof raw !== 'string') return 0;
  const n = Number(raw.split('_')[1]);
  return Number.isFinite(n) ? n : 0;
};
const sortNewestFirst = <T,>(arr: T[]): T[] => [...arr].sort((a, b) => tsFromId(b) - tsFromId(a));

// پیام خطا فقط وقتی به کاربر نشون داده می‌شه که فارسی باشه؛ پیام‌های فنی
// مرورگر (مثل «Failed to fetch») برای کاربر بی‌معنیه.
const toFriendlyError = (msg?: string) =>
  msg && /[\u0600-\u06FF]/.test(msg) ? msg : 'ارتباط با سرور برقرار نیست؛ تغییرات بعد از وصل شدن اینترنت دوباره ارسال می‌شن.';

export const useStore = () => {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error('useStore must be used within StoreProvider');
  return ctx;
};

export const StoreProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const load = <T,>(key: string, def: T): T => {
    try {
      const stored = localStorage.getItem(key);
      return stored ? JSON.parse(stored) : def;
    } catch {
      return def;
    }
  };

  const [memories, setMemoriesState] = useState<Memory[]>(() => load('loveniya_mems', []));
  const [pledges, setPledgesState] = useState<Pledge[]>(() => load('loveniya_plg', []));
  const [dreams, setDreamsState] = useState<Dream[]>(() => load('loveniya_dreams', []));
  const [playlist, setPlaylistState] = useState<Music[]>(() => load('loveniya_msc', []));
  const [capsules, setCapsulesState] = useState<Capsule[]>(() => load('loveniya_capsules', []));
  const [trashItems, setTrashItemsState] = useState<TrashItem[]>(() => load('loveniya_trash', []));
  const [letterContent, setLetterContentState] = useState<string>(() => {
    return localStorage.getItem('loveniya_letter') || '';
  });

  // refهایی که همیشه آخرین state رو منعکس می‌کنن — چه از طریق setXXX پایین
  // تغییر کرده باشه چه از طریق fetchAllData/localStorage. بدون این‌ها
  // مجبور بودیم safeSet (یه درخواست شبکه واقعی) رو داخل تابع آپدیتِ
  // setState صدا بزنیم که در React StrictMode (توی dev) دوبار اجرا می‌شه —
  // یعنی هر افزودن/ویرایش/حذف، درخواست شبکه رو دوبار می‌فرستاد.
  const memoriesRef = React.useRef(memories);
  const pledgesRef = React.useRef(pledges);
  const dreamsRef = React.useRef(dreams);
  const playlistRef = React.useRef(playlist);
  const capsulesRef = React.useRef(capsules);
  const trashItemsRef = React.useRef(trashItems);
  useEffect(() => { memoriesRef.current = memories; }, [memories]);
  useEffect(() => { pledgesRef.current = pledges; }, [pledges]);
  useEffect(() => { dreamsRef.current = dreams; }, [dreams]);
  useEffect(() => { playlistRef.current = playlist; }, [playlist]);
  useEffect(() => { capsulesRef.current = capsules; }, [capsules]);
  useEffect(() => { trashItemsRef.current = trashItems; }, [trashItems]);

  const [syncStatus, setSyncStatus] = useState<SyncStatus>('connected');
  const [syncError, setSyncError] = useState<string | null>(null);
  const [isInitialLoading, setIsInitialLoading] = useState<boolean>(true);

  // نگهداری زمان آخرین تغییر محلی برای هر کلید تا پاسخی از سرور نتواند تغییرات را موقتاً بازگرداند
  const mutatedAtRef = React.useRef<Record<string, number>>({});
  const consecutiveFailuresRef = React.useRef<number>(0);

  // بهینه‌سازی همگام‌سازی: آخرین متن خام پاسخ هر مجموعه، آخرین نسخه‌ی دیده‌شده،
  // زمان آخرین همگام‌سازی کامل، و شمارنده‌ی «پاسخ خالیِ پشت‌سرهم» (محافظ پاک‌شدن ناگهانی).
  const rawCacheRef = React.useRef<Record<string, string>>({});
  const lastRevRef = React.useRef<Record<string, number>>({});
  const lastFullFetchRef = React.useRef<number>(0);
  const emptyStreakRef = React.useRef<Record<string, number>>({});
  const firstSyncDoneRef = React.useRef<boolean>(false);

  // صف نوشتن‌های ناموفق: اگه نوشتن روی سرور بعد از چند تلاش شکست بخوره (مثلاً
  // اینترنت قطع باشه)، قبلاً همگام‌سازی بعدی نسخه‌ی سرور رو روی نسخه‌ی محلی
  // می‌نوشت و خاطره/عهد/آرزوی تازه‌ای که ذخیره نشده بود بی‌صدا ناپدید می‌شد.
  // حالا تا وقتی نوشتن موفق نشده، دوباره تلاش می‌شه و نسخه‌ی سرور جاش رو نمی‌گیره.
  const pendingWritesRef = React.useRef<Record<string, { method: string; body?: string }>>(load('loveniya_pending_writes', {}));
  const persistPending = () => {
    try { localStorage.setItem('loveniya_pending_writes', JSON.stringify(pendingWritesRef.current)); } catch (e) {}
  };
  const hasPendingFor = (path: string) =>
    Object.keys(pendingWritesRef.current).some(url => url.startsWith(`${WORKER_URL}/${path}`));

  // تابع ارسال مستقیم اطلاعات به فایربیس از طریق کلودفلر و ذخیره همزمان در حافظه گوشی
  const safeSet = useCallback(async (path: string, localKey: string, data: any, itemId?: string, itemData?: any) => {
    mutatedAtRef.current[path] = Date.now();
    delete rawCacheRef.current[path]; // تا همگام‌سازی بعدی، نسخه‌ی سرور حتماً دوباره بررسی بشه
    try {
      localStorage.setItem(localKey, typeof data === 'string' ? data : JSON.stringify(data));
    } catch (e) {}

    let targetUrl = `${WORKER_URL}/${path}.json`;
    let method = 'PUT';
    let bodyData = data;

    if (itemId !== undefined) {
      targetUrl = `${WORKER_URL}/${path}/${itemId}.json`;
      if (itemData === null) {
        method = 'DELETE';
        bodyData = undefined;
      } else {
        method = 'PUT';
        bodyData = itemData;
      }
    } else if (Array.isArray(data) && data.length > 0) {
      // Fallback for full sync, convert to object
      bodyData = {};
      data.forEach(item => {
        if (item.id) bodyData[item.id] = item;
        else if (item.trashId) bodyData[item.trashId] = item;
      });
    } else if (Array.isArray(data) && data.length === 0) {
      bodyData = {};
    }

    const serialized = bodyData === undefined ? undefined : JSON.stringify(bodyData);

    const attemptWrite = async () => {
      setSyncStatus('syncing');
      const res = await fetch(targetUrl, {
        method,
        headers: { 'Content-Type': 'application/json', 'X-App-Secret': APP_SECRET },
        body: serialized,
      });
      if (res.status === 401) {
        throw new Error('عدم دسترسی به دیتابیس (رمز اپ با رمز تنظیم‌شده روی ورکر همخوانی ندارد)');
      }
      if (!res.ok) throw new Error(`خطای HTTP: ${res.status}`);
    };

    try {
      let lastErr: any = null;
      for (let attempt = 0; attempt < 3; attempt++) {
        try {
          await attemptWrite();
          lastErr = null;
          break;
        } catch (err: any) {
          lastErr = err;
          if (err?.message?.includes('عدم دسترسی')) break; // تلاش دوباره کمکی نمی‌کنه
          if (attempt < 2) await new Promise(resolve => setTimeout(resolve, 1000 * (attempt + 1)));
        }
      }
      if (lastErr) throw lastErr;

      delete pendingWritesRef.current[targetUrl];
      persistPending();
      mutatedAtRef.current[path] = Date.now(); // پنجره‌ی محافظتی رو تا پایان تلاش (و تلاش‌های مجدد) تمدید کن
      consecutiveFailuresRef.current = 0;
      setSyncStatus('connected');
      setSyncError(null);
      bumpRev(path); // به دستگاه مقابل خبر بده که این مجموعه تغییر کرده
    } catch (err: any) {
      if (!String(err?.message).includes('عدم دسترسی')) {
        pendingWritesRef.current[targetUrl] = { method, body: serialized };
        persistPending();
      }
      consecutiveFailuresRef.current += 1;
      if (consecutiveFailuresRef.current >= 3 || String(err?.message).includes('عدم دسترسی')) {
        setSyncStatus('error');
        setSyncError(toFriendlyError(err?.message));
      } else {
        setSyncStatus('connected');
      }
    }
  }, []);

  // دریافت تمام اطلاعات از دیتابیس بدون نیاز به وب‌سوکت با ادغام هوشمند جهت عدم از دست رفتن داده‌ها
  const fetchAllData = useCallback(async () => {
    const isRecentlyMutated = (key: string) => {
      const lastMutated = mutatedAtRef.current[key] || 0;
      return Date.now() - lastMutated < 15000 || hasPendingFor(key);
    };

    // اول نوشتن‌های عقب‌مونده رو دوباره بفرست؛ اولین شکست یعنی هنوز آفلاینیم
    for (const url of Object.keys(pendingWritesRef.current)) {
      const w = pendingWritesRef.current[url];
      try {
        const res = await fetch(url, {
          method: w.method,
          headers: { 'Content-Type': 'application/json', 'X-App-Secret': APP_SECRET },
          body: w.body,
        });
        if (res.ok) {
          delete pendingWritesRef.current[url];
          persistPending();
          const replayedPath = url.slice(WORKER_URL.length + 1).split('/')[0].replace('.json', '');
          if (replayedPath) bumpRev(replayedPath);
        }
      } catch { break; }
    }

    try {
      const t = Date.now();
      const authHeaders = { headers: { 'X-App-Secret': APP_SECRET }, cache: 'no-store' as RequestCache };

      type Coll = {
        key: string;
        kind: 'list' | 'trash' | 'letter';
        ref?: React.MutableRefObject<any[]>;
        apply: (value: any) => void;
      };
      const collections: Coll[] = [
        { key: 'loveniya_mems', kind: 'list', ref: memoriesRef, apply: v => setMemoriesState(v) },
        { key: 'loveniya_plg', kind: 'list', ref: pledgesRef, apply: v => setPledgesState(v) },
        { key: 'loveniya_dreams', kind: 'list', ref: dreamsRef, apply: v => setDreamsState(v) },
        { key: 'loveniya_msc', kind: 'list', ref: playlistRef, apply: v => setPlaylistState(v) },
        { key: 'loveniya_capsules', kind: 'list', ref: capsulesRef, apply: v => setCapsulesState(v) },
        { key: 'loveniya_trash', kind: 'trash', ref: trashItemsRef, apply: v => setTrashItemsState(v) },
        { key: 'loveniya_letter', kind: 'letter', apply: v => setLetterContentState(v) },
      ];

      // اول فقط شیء کوچک نسخه‌ها؛ اگه در دسترس نبود یا هر ۳۰ ثانیه، همگام‌سازی کامل مثل قبل
      const revs = await fetchRevs();
      const fullSync = !firstSyncDoneRef.current || !revs || t - lastFullFetchRef.current > 30000;
      if (fullSync) lastFullFetchRef.current = t;

      const targets = collections.filter(c => {
        if (isRecentlyMutated(c.key)) return false;
        if (fullSync) return true;
        const r = revs?.[c.key];
        return r !== undefined && r !== lastRevRef.current[c.key];
      });

      const responses = await Promise.all(
        targets.map(async c => ({ c, res: await fetch(`${WORKER_URL}/${c.key}.json?_t=${t}`, authHeaders) }))
      );

      if (responses.some(r => r.res.status === 401)) {
        throw new Error('عدم دسترسی به دیتابیس (رمز اپ اشتباهه یا قوانین امنیتی فایربیس منقضی شده)');
      }

      for (const { c, res } of responses) {
        if (!res.ok) continue;
        const txt = await res.text();
        // اگه بعد از شروع این درخواست، کاربر همین مجموعه رو تغییر داده، نتیجه‌ی قدیمی رو دور بریز
        if (isRecentlyMutated(c.key)) continue;

        const markSeen = () => {
          rawCacheRef.current[c.key] = txt;
          if (revs && revs[c.key] !== undefined) lastRevRef.current[c.key] = revs[c.key];
        };
        if (txt === rawCacheRef.current[c.key]) { markSeen(); continue; } // هیچ چیزی عوض نشده

        let data: any;
        try { data = JSON.parse(txt); } catch { continue; }

        if (c.kind === 'letter') {
          const text = (typeof data === 'string' && data.trim().length > 0) ? data : '';
          c.apply(text);
          try { localStorage.setItem(c.key, text); } catch (e) {}
          markSeen();
          continue;
        }

        let arr: any[] = data ? (Array.isArray(data) ? data : Object.values(data)) : [];
        if (c.kind === 'trash') arr = arr.filter((x: any) => x && x.trashId);
        arr = sortNewestFirst(arr);

        // محافظ: اگه یهو پاسخ خالی اومد ولی چند آیتم محلی داریم، اولین‌بار قبول نکن
        // (خطای گذرای سرور/ورکر نباید کل خاطره‌های روی گوشی رو پاک کنه). اگه دوباره
        // هم خالی بود، یعنی واقعاً پاک شده و قبول می‌شه.
        const localCount = c.ref ? c.ref.current.length : 0;
        if (arr.length === 0 && localCount > 2) {
          emptyStreakRef.current[c.key] = (emptyStreakRef.current[c.key] || 0) + 1;
          if (emptyStreakRef.current[c.key] < 2) continue;
        }
        emptyStreakRef.current[c.key] = 0;

        if (c.ref) c.ref.current = arr;
        c.apply(arr);
        try { localStorage.setItem(c.key, JSON.stringify(arr)); } catch (e) {}
        markSeen();
      }
      firstSyncDoneRef.current = true;

      consecutiveFailuresRef.current = 0;
      setSyncStatus('connected');
      setSyncError(null);
    } catch (err: any) {
      consecutiveFailuresRef.current += 1;
      if (consecutiveFailuresRef.current >= 3 || String(err?.message).includes('عدم دسترسی')) {
        setSyncStatus('error');
        setSyncError(toFriendlyError(err?.message));
      }
    }
  }, []);

  useEffect(() => {
    fetchAllData().finally(() => setIsInitialLoading(false));

    // Silent background sync — every 5s normally, but backs off to every 20s
    // after repeated failures, and pauses entirely while the tab is hidden
    // (avoids draining battery/data and avoids a jarring resync the instant
    // the tab regains focus).
    let cancelled = false;
    let timeoutId: ReturnType<typeof setTimeout>;

    const scheduleNext = () => {
      const delay = consecutiveFailuresRef.current >= 3 ? 20000 : 5000;
      timeoutId = setTimeout(async () => {
        if (cancelled) return;
        if (typeof document === 'undefined' || document.visibilityState === 'visible') {
          await fetchAllData();
        }
        scheduleNext();
      }, delay);
    };
    scheduleNext();

    return () => {
      cancelled = true;
      clearTimeout(timeoutId);
    };
  }, [fetchAllData]);

  const setMemories = (v: Memory[] | ((prev: Memory[]) => Memory[]), itemId?: string, itemData?: any) => {
    const next = typeof v === 'function' ? (v as (p: Memory[]) => Memory[])(memoriesRef.current) : v;
    memoriesRef.current = next;
    setMemoriesState(next);
    safeSet('loveniya_mems', 'loveniya_mems', next, itemId, itemData);
  };

  const setPledges = (v: Pledge[] | ((prev: Pledge[]) => Pledge[]), itemId?: string, itemData?: any) => {
    const next = typeof v === 'function' ? (v as (p: Pledge[]) => Pledge[])(pledgesRef.current) : v;
    pledgesRef.current = next;
    setPledgesState(next);
    safeSet('loveniya_plg', 'loveniya_plg', next, itemId, itemData);
  };

  const setDreams = (v: Dream[] | ((prev: Dream[]) => Dream[]), itemId?: string, itemData?: any) => {
    const next = typeof v === 'function' ? (v as (p: Dream[]) => Dream[])(dreamsRef.current) : v;
    dreamsRef.current = next;
    setDreamsState(next);
    safeSet('loveniya_dreams', 'loveniya_dreams', next, itemId, itemData);
  };

  const setPlaylist = (v: Music[] | ((prev: Music[]) => Music[]), itemId?: string, itemData?: any) => {
    const next = typeof v === 'function' ? (v as (p: Music[]) => Music[])(playlistRef.current) : v;
    playlistRef.current = next;
    setPlaylistState(next);
    safeSet('loveniya_msc', 'loveniya_msc', next, itemId, itemData);
  };

  const setCapsules = (v: Capsule[] | ((prev: Capsule[]) => Capsule[]), itemId?: string, itemData?: any) => {
    const next = typeof v === 'function' ? (v as (p: Capsule[]) => Capsule[])(capsulesRef.current) : v;
    capsulesRef.current = next;
    setCapsulesState(next);
    safeSet('loveniya_capsules', 'loveniya_capsules', next, itemId, itemData);
  };

  const setTrashItems = (v: TrashItem[] | ((prev: TrashItem[]) => TrashItem[]), itemId?: string, itemData?: any) => {
    const next = typeof v === 'function' ? (v as (p: TrashItem[]) => TrashItem[])(trashItemsRef.current) : v;
    trashItemsRef.current = next;
    setTrashItemsState(next);
    safeSet('loveniya_trash', 'loveniya_trash', next, itemId, itemData);
  };

  const handleSetLetterContent = (text: string) => {
    setLetterContentState(text);
    safeSet('loveniya_letter', 'loveniya_letter', text);
  };

  const moveToTrash = (type: TrashItem['type'], item: any) => {
    const trashObj: TrashItem = {
      trashId: `trash_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      type,
      deletedAt: new Date().toLocaleDateString('fa-IR', { timeZone: 'Asia/Tehran' }),
      itemPayload: item
    };
    setTrashItems(prev => [trashObj, ...prev], trashObj.trashId, trashObj);
  };

  const restoreFromTrash = (trashId: string) => {
    const item = trashItemsRef.current.find(t => t.trashId === trashId);
    if (!item) return;
    
    // Safely replace or append
    const safelyMerge = (arr: any[], newItem: any) => {
      const idx = arr.findIndex(x => x.id === newItem.id);
      if (idx !== -1) return arr.map(x => x.id === newItem.id ? newItem : x);
      return [...arr, newItem];
    };

    if (item.type === 'memory') setMemories(prev => safelyMerge(prev, item.itemPayload), item.itemPayload.id, item.itemPayload);
    if (item.type === 'pledge') setPledges(prev => safelyMerge(prev, item.itemPayload), item.itemPayload.id, item.itemPayload);
    if (item.type === 'dream') setDreams(prev => safelyMerge(prev, item.itemPayload), item.itemPayload.id, item.itemPayload);
    if (item.type === 'music') setPlaylist(prev => safelyMerge(prev, item.itemPayload), item.itemPayload.id, item.itemPayload);
    if (item.type === 'capsule') setCapsules(prev => safelyMerge(prev, item.itemPayload), item.itemPayload.id, item.itemPayload);
    
    setTrashItems(prev => prev.filter(t => t.trashId !== trashId), trashId, null);
  };

  const permanentlyDeleteFromTrash = (trashId: string) => {
    setTrashItems(prev => prev.filter(t => t.trashId !== trashId), trashId, null);
  };

  const emptyTrash = () => setTrashItems([]);

  const addMemory = (m: Memory) => setMemories(prev => [m, ...prev], m.id, m);
  const updateMemory = (m: Memory) => {
    setMemories(prev => prev.map(x => x.id === m.id ? m : x), m.id, m);
  };
  const removeMemory = (id: string) => {
    const item = memoriesRef.current.find(x => x.id === id);
    if (item) moveToTrash('memory', item);
    setMemories(prev => prev.filter(x => x.id !== id), id, null); // Scoped delete: only removes this item remotely, never overwrites the whole list
  };

  const addPledge = (p: Pledge) => setPledges(prev => [p, ...prev], p.id, p);
  const updatePledge = (p: Pledge) => {
    setPledges(prev => prev.map(x => x.id === p.id ? p : x), p.id, p);
  };
  const removePledge = (id: string) => {
    const item = pledgesRef.current.find(x => x.id === id);
    if (item) moveToTrash('pledge', item);
    setPledges(prev => prev.filter(x => x.id !== id), id, null);
  };

  const addDream = (d: Dream) => setDreams(prev => [d, ...prev], d.id, d);
  const updateDream = (d: Dream) => {
    setDreams(prev => prev.map(x => x.id === d.id ? d : x), d.id, d);
  };
  const removeDream = (id: string) => {
    const item = dreamsRef.current.find(x => x.id === id);
    if (item) moveToTrash('dream', item);
    setDreams(prev => prev.filter(x => x.id !== id), id, null);
  };

  const addMusic = (m: Music) => setPlaylist(prev => [m, ...prev], m.id, m);
  const updateMusic = (m: Music) => {
    setPlaylist(prev => prev.map(x => x.id === m.id ? m : x), m.id, m);
  };
  const removeMusic = (id: string) => {
    const item = playlistRef.current.find(x => x.id === id);
    if (item) moveToTrash('music', item);
    setPlaylist(prev => prev.filter(x => x.id !== id), id, null);
  };

  const addCapsule = (c: Capsule) => setCapsules(prev => [c, ...prev], c.id, c);
  const updateCapsule = (c: Capsule) => {
    setCapsules(prev => prev.map(x => x.id === c.id ? c : x), c.id, c);
  };
  const removeCapsule = (id: string) => {
    const item = capsulesRef.current.find(x => x.id === id);
    if (item) moveToTrash('capsule', item);
    setCapsules(prev => prev.filter(x => x.id !== id), id, null);
  };

  return (
    <StoreContext.Provider value={{
      memories, pledges, dreams, playlist, capsules, trashItems, letterContent,
      syncStatus, syncError, isInitialLoading,
      addMemory, updateMemory, removeMemory,
      addPledge, updatePledge, removePledge,
      addDream, updateDream, removeDream,
      addMusic, updateMusic, removeMusic,
      addCapsule, updateCapsule, removeCapsule,
      setLetterContent: handleSetLetterContent,
      moveToTrash, emptyTrash, restoreFromTrash, permanentlyDeleteFromTrash
    }}>
      {children}
    </StoreContext.Provider>
  );
};