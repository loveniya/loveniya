/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { RefreshCw } from 'lucide-react';
import { motion } from 'motion/react';

export default function App() {
  return (
    <main
      id="update-screen"
      className="min-h-screen bg-slate-50 text-slate-800 flex items-center justify-center p-6 select-none"
    >
      <motion.div
        id="message-card"
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.4, ease: 'easeOut' }}
        className="w-full max-w-lg rounded-2xl bg-white border border-slate-200/80 p-8 sm:p-10 text-center shadow-xl shadow-slate-200/50 flex flex-col items-center"
      >
        <div
          id="icon-wrapper"
          className="w-14 h-14 rounded-2xl bg-indigo-50 border border-indigo-100 text-indigo-600 flex items-center justify-center mb-6 shadow-sm"
        >
          <RefreshCw className="w-6 h-6 animate-spin [animation-duration:3s]" />
        </div>

        <h1
          id="update-title"
          className="text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight mb-4"
        >
          این سایت در حال آپدیت می‌باشد
        </h1>

        <p
          id="update-message"
          className="text-base sm:text-lg text-slate-600 leading-relaxed max-w-md"
        >
          تا اتمام آپدیت امکان مشاهده وجود ندارد، لطفاً بعداً سر بزنید.
        </p>
      </motion.div>
    </main>
  );
}
