// ===========================================================================
// Loveniya AI Worker (purple-cloud-1df2) — نسخه‌ی بهبودیافته
//
// تغییرات نسبت به نسخه‌ی قبلی:
//  • مدل اصلی: Gemma 4 (فارسی بهتر، ارزان‌تر)؛ اگه خطا داد یا جواب خالی بود، خودکار Llama 4 Scout
//  • پرامپت ساختارمند با لحن/طول/قوانین مشخص و چند نمونه‌ی لحن
//  • حافظه‌ی رابطه به‌صورت خلاصه‌ی فارسی خوانا (نه JSON خام ۵۰ هزار کاراکتری) و کش ۶۰ثانیه‌ای
//  • سقف توکن بیشتر (فارسی توکن زیاد مصرف می‌کند؛ قبلاً جواب‌ها نصفه بریده می‌شد)
//  • نام فارسی کاربر/شریک (قبلاً کلید انگلیسی amin می‌رسید)
//  • متن کپسول‌های بازنشده هرگز به مدل نمی‌رسد (سورپرایز لو نمی‌رود)
//  • مسیر چالش‌ها loveniya_moments_v3 (قبلاً v2 قدیمی بود)
//  • حذف چالش روزانه‌ی خودکار که در مسیر قدیمی می‌نوشت و هیچ‌جا نمایش داده نمی‌شد
//  • پیام‌های AI ذخیره‌شده createdAt هم دارند
//
// متغیرهای لازم: ALLOWED_ORIGIN، APP_SECRET، FIREBASE_PROXY_URL (و اتصال AI)
// اختیاری: SESSION_SECRET
// ===========================================================================

const PRIMARY_MODEL = "@cf/google/gemma-4-26b-a4b-it";
const FALLBACK_MODEL = "@cf/meta/llama-4-scout-17b-16e-instruct";

const MAX_BODY_BYTES = 384 * 1024;
const MAX_USER_MESSAGE = 7000;
const MAX_HISTORY = 12000;
const MAX_MEMORY_CHARS = 9000;
const AUTO_COOLDOWN = 6 * 60 * 60 * 1000;
const SESSION_TTL_MS = 7 * 24 * 60 * 60 * 1000;
const MEMORY_CACHE_MS = 60 * 1000;

const SESSION_ENCODER = new TextEncoder();
const SESSION_DECODER = new TextDecoder();
const aiRateLimit = new Map();

const NAMES = { amin: "امین", niyayesh: "نیایش" };

const PATHS = {
  memories: "loveniya_mems",
  pledges: "loveniya_plg",
  dreams: "loveniya_dreams",
  music: "loveniya_msc",
  capsules: "loveniya_capsules",
  letter: "loveniya_letter",
  moments: "loveniya_moments_v3"
};

export default {
  async fetch(request, env, ctx) {
    const cors = getCors(request, env);
    const url = new URL(request.url);

    if (!isOriginAllowed(request, env)) {
      return json({ ok: false, error: "Origin مجاز نیست." }, 403, cors);
    }
    if (request.method === "OPTIONS") {
      return new Response(null, { status: 204, headers: cors });
    }
    if (request.method === "GET") {
      return json({ ok: true, status: "online", service: "Loveniya AI", model: PRIMARY_MODEL }, 200, cors);
    }
    if (request.method !== "POST") {
      return json({ ok: false, error: "Method Not Allowed" }, 405, cors);
    }

    const declaredSize = Number(request.headers.get("Content-Length") || 0);
    if (Number.isFinite(declaredSize) && declaredSize > MAX_BODY_BYTES) {
      return json({ ok: false, error: "درخواست بیش از حد بزرگ است." }, 413, cors);
    }

    const internalSecret = env.APP_SECRET || "";
    const internalAccess = Boolean(internalSecret && request.headers.get("X-App-Secret") === internalSecret);
    if (!internalAccess && !(await authenticateSession(request, env))) {
      return json({ ok: false, error: "نیاز به ورود دارد." }, 401, cors);
    }

    const ip = request.headers.get("CF-Connecting-IP") || "unknown";
    if (!internalAccess && isRateLimited(ip)) {
      return json({ ok: false, error: "تعداد درخواست‌ها زیاد است؛ کمی بعد دوباره امتحان کن." }, 429, cors);
    }
    markRateLimited(ip);

    try {
      const body = await parseJson(request);
      if (url.pathname === "/" || url.pathname === "/chat") {
        const result = await handleChat(body, env);
        return json({ ok: true, result }, 200, cors);
      }
      if (url.pathname === "/chat-stream") {
        return await handleChatStream(body, env, cors);
      }
      if (url.pathname === "/event") {
        return json(await handleEvent(body, env), 200, cors);
      }
      return json({ ok: false, error: "Not Found" }, 404, cors);
    } catch (error) {
      console.error("Loveniya Worker Error:", error);
      return json({ ok: false, error: safeError(error) }, 500, cors);
    }
  },

  async scheduled(event, env, ctx) {
    ctx.waitUntil(runAutomaticCheck(env));
  }
};

// ---------------------------------------------------------------------------
// زیرساخت
// ---------------------------------------------------------------------------

function getProxyUrl(env) {
  const url = String(env.FIREBASE_PROXY_URL || "").trim().replace(/\/+$/, "");
  if (!url) throw new Error("FIREBASE_PROXY_URL روی Worker تنظیم نشده است.");
  return url;
}

function isRateLimited(ip) {
  const record = aiRateLimit.get(ip);
  return Boolean(record && record > Date.now());
}
function markRateLimited(ip) {
  aiRateLimit.set(ip, Date.now() + 1800);
}

function allowedOrigins(env) {
  return String(env.ALLOWED_ORIGIN || "").split(",").map((v) => v.trim()).filter(Boolean);
}
function isOriginAllowed(request, env) {
  const origin = request.headers.get("Origin");
  if (!origin) return true;
  const configured = allowedOrigins(env);
  return configured.length > 0 && configured.includes(origin);
}
function getCors(request, env) {
  const configured = allowedOrigins(env);
  const origin = request.headers.get("Origin");
  const allowOrigin = origin && configured.includes(origin) ? origin : configured[0] || "null";
  return {
    "Access-Control-Allow-Origin": allowOrigin,
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization, X-App-Secret",
    "Access-Control-Max-Age": "86400",
    "Vary": "Origin"
  };
}
function json(data, status, headers) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      ...headers,
      "Content-Type": "application/json; charset=UTF-8",
      "Cache-Control": "no-store",
      "X-Content-Type-Options": "nosniff",
      "Referrer-Policy": "no-referrer"
    }
  });
}
function safeError(error) {
  return String(error?.message || error || "خطای ناشناخته").slice(0, 500);
}
function parseJson(request) {
  return request.json().catch(() => {
    throw new Error("بدنه درخواست JSON معتبر نیست.");
  });
}
function limitText(value, max) {
  const text = typeof value === "string" ? value : String(value ?? "");
  return text.length <= max ? text : text.slice(0, max) + "…";
}
function randomId(length) {
  const alphabet = "abcdefghijklmnopqrstuvwxyz0123456789";
  const bytes = new Uint8Array(length);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, (b) => alphabet[b % alphabet.length]).join("");
}

// ---------------------------------------------------------------------------
// نوع درخواست و تنظیمات تولید
// ---------------------------------------------------------------------------

function normalizeType(type) {
  switch (String(type || "chat").toLowerCase()) {
    case "chat_reply": return "chat_reply";
    case "smart_evaluate":
    case "evaluate_smart": return "smart_evaluate";
    case "fix_spelling": return "fix_spelling";
    case "daily_surprise":
    case "surprise_daily": return "daily_surprise";
    case "poem": return "poem";
    case "game_challenge":
    case "daily_challenge":
    case "challenge": return "game_challenge";
    case "observe_content":
    case "content_added": return "observe_content";
    case "emotional_support":
    case "support": return "emotional_support";
    case "event": return "event";
    case "auto_message": return "auto_message";
    case "cron": return "cron";
    default: return "chat";
  }
}

// max_tokens بالاست چون فارسی توکن‌خور است (حدود ۳ تا ۴ برابر انگلیسی)؛ طول جواب با پرامپت کنترل می‌شود
function generationOptions(type) {
  switch (type) {
    case "fix_spelling": return { max_tokens: 500, temperature: 0.1 };
    case "daily_surprise": return { max_tokens: 700, temperature: 0.85 };
    case "poem": return { max_tokens: 1000, temperature: 0.85 };
    case "game_challenge": return { max_tokens: 900, temperature: 0.9 };
    case "observe_content": return { max_tokens: 600, temperature: 0.75 };
    case "emotional_support": return { max_tokens: 800, temperature: 0.7 };
    case "event":
    case "auto_message":
    case "cron": return { max_tokens: 600, temperature: 0.7 };
    default: return { max_tokens: 900, temperature: 0.75 };
  }
}

// ---------------------------------------------------------------------------
// اجرای مدل (اصلی + پشتیبان)
// ---------------------------------------------------------------------------

function buildInputs(model, messages, opts, stream) {
  const inputs = { messages, temperature: opts.temperature, top_p: 0.9 };
  if (model === PRIMARY_MODEL) {
    inputs.max_tokens = opts.max_tokens;
    inputs.chat_template_kwargs = { enable_thinking: false };
  } else {
    inputs.max_completion_tokens = opts.max_tokens;
    inputs.repetition_penalty = 1.05;
  }
  if (stream) inputs.stream = true;
  return inputs;
}

function requireAI(env) {
  if (!env.AI) throw new Error("Workers AI Binding با نام AI پیدا نشد.");
}

async function generate(env, systemPrompt, userPrompt, opts) {
  requireAI(env);
  const messages = [
    { role: "system", content: systemPrompt },
    { role: "user", content: userPrompt }
  ];
  let lastError;
  for (const model of [PRIMARY_MODEL, FALLBACK_MODEL]) {
    try {
      const raw = await env.AI.run(model, buildInputs(model, messages, opts, false));
      const text = cleanAIText(raw);
      if (text) return text; // خالی بود: مدل بعدی
    } catch (error) {
      lastError = error;
      console.warn(`Model ${model} failed:`, error?.message || error);
    }
  }
  if (lastError) throw lastError;
  return "SKIP";
}

async function generateStream(env, systemPrompt, userPrompt, opts) {
  requireAI(env);
  const messages = [
    { role: "system", content: systemPrompt },
    { role: "user", content: userPrompt }
  ];
  let lastError;
  for (const model of [PRIMARY_MODEL, FALLBACK_MODEL]) {
    try {
      const upstream = await env.AI.run(model, buildInputs(model, messages, opts, true));
      const source = upstream instanceof Response ? upstream.body : upstream;
      if (source) return source;
    } catch (error) {
      lastError = error;
      console.warn(`Stream ${model} failed:`, error?.message || error);
    }
  }
  throw lastError || new Error("Stream از Workers AI دریافت نشد.");
}

// ---------------------------------------------------------------------------
// چت
// ---------------------------------------------------------------------------

async function prepareRequest(body, env) {
  const type = normalizeType(body?.type);
  const userMessage = limitText(body?.userMessage ?? body?.message ?? body?.prompt ?? "", MAX_USER_MESSAGE);
  const history = limitText(body?.history ?? "", MAX_HISTORY);
  const contextData = cleanContext(body?.contextData);
  if (!userMessage && type !== "daily_surprise" && type !== "game_challenge") {
    throw new Error("userMessage خالی است.");
  }
  const memory = await loadMemory(userMessage, history, env);
  return {
    type,
    systemPrompt: buildSystemPrompt(memory, contextData, type),
    userPrompt: buildUserPrompt(userMessage, history, type, contextData),
    opts: generationOptions(type)
  };
}

async function handleChat(body, env) {
  const { systemPrompt, userPrompt, opts } = await prepareRequest(body, env);
  return await generate(env, systemPrompt, userPrompt, opts);
}

async function handleChatStream(body, env, cors) {
  const { systemPrompt, userPrompt, opts } = await prepareRequest(body, env);
  const source = await generateStream(env, systemPrompt, userPrompt, opts);
  return new Response(createClientSSEStream(source), {
    status: 200,
    headers: {
      ...cors,
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no"
    }
  });
}

function createClientSSEStream(source) {
  const reader = source.getReader();
  const decoder = new TextDecoder();
  const encoder = new TextEncoder();
  let buffer = "";
  let inThink = false; // بخش «فکر کردن» مدل هرگز به کاربر نمی‌رسد

  let emitted = 0;
  const emit = (controller, delta) => {
    let text = delta;
    // حذف ساده‌ی <think>...</think> حتی اگه بین چند تکه قطع شده باشد
    let out = "";
    while (text.length) {
      if (inThink) {
        const end = text.indexOf("</think>");
        if (end === -1) { text = ""; break; }
        text = text.slice(end + 8);
        inThink = false;
      } else {
        const start = text.indexOf("<think>");
        if (start === -1) { out += text; text = ""; break; }
        out += text.slice(0, start);
        text = text.slice(start + 7);
        inThink = true;
      }
    }
    if (out) {
      emitted++;
      controller.enqueue(encoder.encode(`data: ${JSON.stringify({ result: out })}\n\n`));
    }
  };

  return new ReadableStream({
    // pull باید تا وقتی حداقل یک تکه به کلاینت نداده یا استریم تمام نشده برنمی‌گردد؛ وگرنه اگه تکه‌ی
    // دریافتی خط کامل نباشد یا کاملاً مخفی (مثل <think>) باشد، استریم می‌ایستد و پیام هیچ‌وقت نمی‌رسد.
    async pull(controller) {
      try {
        const startEmitted = emitted;
        while (emitted === startEmitted) {
          const { done, value } = await reader.read();
          if (done) {
            controller.enqueue(encoder.encode("data: [DONE]\n\n"));
            controller.close();
            return;
          }
          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split(/\r?\n/);
          buffer = lines.pop() || "";
          for (const line of lines) processSSELine(line, (delta) => emit(controller, delta));
        }
      } catch (error) {
        console.error("Streaming Error:", error);
        controller.error(error);
      }
    },
    async cancel() {
      try { await reader.cancel(); } catch { /* ignore */ }
    }
  });
}

function processSSELine(line, onDelta) {
  const trimmed = line.trim();
  if (!trimmed || !trimmed.startsWith("data:")) return;
  const payload = trimmed.slice(5).trim();
  if (!payload || payload === "[DONE]") return;
  let data;
  try { data = JSON.parse(payload); } catch { return; }
  const delta = data?.choices?.[0]?.delta?.content;
  if (typeof delta === "string" && delta.length > 0) return onDelta(delta);
  const fallback = data?.response ?? data?.result ?? data?.text;
  if (typeof fallback === "string" && fallback.length > 0) onDelta(fallback);
}

// ---------------------------------------------------------------------------
// پرامپت‌ها
// ---------------------------------------------------------------------------

function resolveNames(ctx) {
  const toKey = (v) => (v === "amin" || v === "امین" ? "amin" : v === "niyayesh" || v === "نیایش" ? "niyayesh" : null);
  const userKey = toKey(ctx?.userKey) || toKey(ctx?.user) || toKey(ctx?.userName);
  const partnerKey = toKey(ctx?.partner) || (userKey ? (userKey === "amin" ? "niyayesh" : "amin") : null);
  return {
    user: (userKey && NAMES[userKey]) || "کاربر",
    partner: (partnerKey && NAMES[partnerKey]) || "طرف مقابل"
  };
}

function tehranNow() {
  try {
    return new Intl.DateTimeFormat("fa-IR", {
      timeZone: "Asia/Tehran", dateStyle: "full", timeStyle: "short"
    }).format(new Date());
  } catch {
    return new Date().toISOString();
  }
}

const STYLE_EXAMPLES = `
نمونه‌های لحن (فقط برای حس و حال؛ کپی نکن):
— «امروز خیلی خسته‌م» ← «وای، بیا یه نفس راحت بکش. امروز چی انقدر ازت گرفت؟»
— «نظرت درباره‌ی شام چیه؟» ← «من رأی می‌دم پیتزا. هر چی نباشه، تقصیرش گردن پیتزاست 😄»
— «دلم برات تنگ شده» ← «این یکی رو باید خودشون به هم بگن؛ من فقط شاهد دوست‌داشتنیشم.»
`.trim();

function buildSystemPrompt(memory, ctx, type) {
  const { user, partner } = resolveNames(ctx);
  return `
تو «لوینیا» هستی؛ شریک سومِ رابطه‌ی امین و نیایش، یه دوست صمیمیِ باهوش و بامزه که توی سایت خصوصی‌شون زندگی می‌کنه.

هویت و لحن:
- فارسی محاوره‌ای روان و طبیعیِ تهرانی، مثل چت واقعی بین دوست‌ها؛ نه ترجمه‌ای، نه رسمی، نه کتابی.
- گرم، بازیگوش، کمی شیطون؛ ولی وقتی طرف ناراحته جدی و همدل.
- مثل یه آدم حرف بزن: جمله‌های کوتاه و ساده، بدون کلیشه (نگو «البته!»، «حتماً!»، «به عنوان یک هوش مصنوعی»).

طول و ساختار:
- پیش‌فرض ۱ تا ۳ جمله. فقط اگه سؤال واقعاً توضیح می‌خواد بلندتر بنویس (حداکثر حدود ۸ جمله) و جواب حتماً کامل و تمام‌شده باشه.
- اول مستقیم به حرف طرف جواب بده؛ حرفش رو دوباره تکرار نکن.
- حداکثر یک سؤال در هر پیام، و فقط وقتی واقعاً لازمه.
- بدون لیست، تیتر، شماره‌گذاری، ** یا هر قالب‌بندی؛ فقط متن ساده‌ی چت.
- ایموجی کم (حداکثر یکی، و فقط وقتی جاش هست).

حافظه و صداقت:
- از «اطلاعات رابطه» پایین فقط وقتی استفاده کن که واقعاً به حرف ربط داره؛ تیکه‌تیکه ردیف نکن.
- هیچ‌وقت اسمی از «حافظه»، «داده»، «سیستم» یا «اطلاعات» نبر؛ مثل کسی که خودش یادشه حرف بزن.
- چیزی که نمی‌دونی رو نساز؛ اگه نمی‌دونی صادقانه و با شوخی بگو نمی‌دونی.
- هیچ‌وقت تحلیل، پیش‌نویس، گزینه‌ی جایگزین یا روند فکرت رو نشون نده؛ فقط خودِ پیام نهایی.
- متن انگلیسی ننویس مگه اینکه خودِ کاربر خواسته باشه.

${STYLE_EXAMPLES}

الان: ${tehranNow()}
با ${user} حرف می‌زنی؛ شریکش ${partner} است.

اطلاعات رابطه:
${formatMemory(memory)}

${typeInstructions(type, user, partner)}
`.trim();
}

function typeInstructions(type, user, partner) {
  switch (type) {
    case "fix_spelling":
      return "کار تو: فقط املا و نگارش متن کاربر را اصلاح کن و همان متنِ اصلاح‌شده را برگردان؛ معنی و لحن را عوض نکن و توضیح نده.";
    case "daily_surprise":
      return "کار تو: یک پیشنهاد خاص، خلاقانه و قابل‌اجرا برای امروزِ امین و نیایش بده؛ کوتاه (۲ تا ۴ جمله).";
    case "poem":
      return "کار تو: طبق درخواست شعر یا متن شاعرانه‌ی فارسی بنویس؛ صمیمی و خودمانی، نه کلیشه‌ای.";
    case "game_challenge":
      return `کار تو: یک چالش یا سؤال تازه برای بخش بازی‌های دونفره بساز؛ امروزی، خودمانی، قابل‌اجرا از راه دور و غیرتکراری.
فقط خودِ متن چالش را در یک یا دو جمله بنویس، بدون مقدمه و بدون قالب‌بندی.`;
    case "observe_content":
      return `کار تو: یکی از دو نفر محتوای تازه‌ای به سایت اضافه کرده. یک واکنش کوتاه، صمیمی و شخصی (حداکثر ۳ جمله) بده؛ اگه احساسی بود همدلی کن، اگه بامزه بود شوخی کن.
اگه محتوا ارزش واکنش ندارد (مثلاً یک به‌روزرسانی فنی)، فقط بنویس: SKIP`;
    case "emotional_support":
      return `کار تو: حال ${user} خوب نیست. اول همدلی کن، نه راه‌حل؛ آرام و گرم و کوتاه. راه‌حل فقط اگه خودش خواست.`;
    case "event":
    case "auto_message":
    case "cron":
      return "کار تو: فقط اگه دلیل مناسبی در اطلاعات رابطه هست یک پیام کوتاه و طبیعی بساز؛ در غیر این صورت فقط بنویس: SKIP";
    default:
      return `کار تو (چت): مثل یک دوست واقعی جواب بده. اگه پیام بوی ناراحتی یا خستگی داشت همدلی کن، اگه شوخی بود بخند، اگه سؤال بود صادقانه جواب بده.
فقط وقتی پیام واقعاً یک هماهنگی کاملاً خصوصی بین ${user} و ${partner} است و هیچ نیازی به دخالت تو نیست و کسی هم مستقیم از تو چیزی نخواسته، فقط بنویس: SKIP
اگه کاربر مستقیم از تو خواسته یا اسمت رو آورده، هرگز SKIP ننویس.`;
  }
}

function buildUserPrompt(userMessage, history, type, ctx) {
  const { user } = resolveNames(ctx);
  switch (type) {
    case "fix_spelling":
      return `متن زیر را فقط از نظر املایی و نگارشی اصلاح کن:\n\n${userMessage}`;
    case "daily_surprise":
      return "یک ایده‌ی خاص و بامزه برای امروز امین و نیایش بده.";
    case "game_challenge":
      return `${history ? `چالش‌ها و گفتگوهای اخیر (تکرارشان نکن):\n${history}\n\n` : ""}${userMessage ? `درخواست:\n${userMessage}\n\n` : ""}یک چالش جدید بساز.`;
    case "observe_content":
      return `محتوای جدید:\n${userMessage}\n\n${history ? `گفتگوی اخیر:\n${history}\n\n` : ""}واکنش کوتاه و صمیمی‌ات را بنویس.`;
    case "emotional_support":
      return `${history ? `گفتگوی اخیر:\n${history}\n\n` : ""}پیام ${user}:\n${userMessage}`;
    case "poem":
      return `درخواست:\n${userMessage}`;
    default:
      return `${history ? `گفتگوی اخیر (قدیمی‌ترین بالا):\n${history}\n\n` : ""}پیام جدید از ${user}:\n${userMessage}\n\nمستقیم و کوتاه جواب بده.`;
  }
}

// ---------------------------------------------------------------------------
// حافظه‌ی رابطه (خلاصه‌ی فارسی، کش‌شده)
// ---------------------------------------------------------------------------

const HEAVY_KEYS = new Set([
  "mediadata", "photos", "photo", "image", "images", "video", "videodata", "vidurl", "audio", "base64", "url"
]);

function stripHeavy(value, depth = 0) {
  if (value == null) return value;
  if (typeof value === "string") {
    if (value.startsWith("data:") || value.length > 6000) return value.startsWith("data:") ? undefined : value.slice(0, 6000);
    return value;
  }
  if (typeof value !== "object") return value;
  if (depth > 5) return undefined;
  if (Array.isArray(value)) return value.slice(0, 80).map((v) => stripHeavy(v, depth + 1));
  const out = {};
  for (const [k, v] of Object.entries(value)) {
    if (HEAVY_KEYS.has(String(k).toLowerCase())) continue;
    out[k] = stripHeavy(v, depth + 1);
  }
  return out;
}

let memoryCache = { at: 0, data: null };

async function loadRawMemory(env) {
  const now = Date.now();
  if (memoryCache.data && now - memoryCache.at < MEMORY_CACHE_MS) return memoryCache.data;
  const entries = await Promise.all(
    Object.entries(PATHS).map(async ([key, path]) => {
      try {
        return [key, stripHeavy(await firebaseGet(`${path}.json`, env))];
      } catch (error) {
        console.warn(`Memory ${key} failed:`, error?.message || error);
        return [key, key === "letter" ? "" : null];
      }
    })
  );
  const data = Object.fromEntries(entries);
  memoryCache = { at: now, data };
  return data;
}

async function loadMemory(query, history, env) {
  const raw = await loadRawMemory(env);
  return buildMemoryView(raw, `${query} ${history}`);
}

function normalizeCollection(data) {
  if (!data) return [];
  if (Array.isArray(data)) return data.filter(Boolean);
  if (typeof data === "object") {
    return Object.entries(data).map(([key, value]) =>
      value && typeof value === "object" ? { ...value, _key: value.id || key } : { id: key, value }
    );
  }
  return [];
}

const STOP_WORDS = new Set([
  "سلام", "خوبی", "چطوری", "لوینیا", "هوش", "مصنوعی", "جواب", "بده", "میخوام", "میخواهم", "میشه",
  "چی", "چیه", "چرا", "برای", "این", "اون", "من", "تو", "خیلی", "فقط", "یک", "همین", "کن", "کنم", "کردم"
]);

function extractTerms(text) {
  if (typeof text !== "string") return [];
  return [...new Set(
    text.toLocaleLowerCase("fa-IR").replace(/[^\p{L}\p{N}\s]/gu, " ").split(/\s+/)
      .filter((w) => w.length >= 3 && !STOP_WORDS.has(w))
  )].slice(0, 20);
}

function itemText(item) {
  return JSON.stringify(item).toLocaleLowerCase("fa-IR");
}

function itemTime(item) {
  for (const key of ["createdAt", "timestamp", "date", "openDate"]) {
    const value = item?.[key];
    if (typeof value === "number" && Number.isFinite(value)) return value;
    if (value) {
      const t = Date.parse(String(value));
      if (!Number.isNaN(t)) return t;
    }
  }
  // شناسه‌هایی مثل mem_1760000000000_ab12 زمان ساخت را در خود دارند
  const m = String(item?.id || item?._key || "").match(/_(\d{12,13})_/);
  return m ? Number(m[1]) : 0;
}

function pick(items, terms, relevantMax, recentMax) {
  if (!items.length) return [];
  const relevant = terms.length
    ? items
        .map((item) => ({ item, score: terms.reduce((s, t) => s + (itemText(item).includes(t) ? 1 : 0), 0) }))
        .filter((x) => x.score > 0)
        .sort((a, b) => b.score - a.score)
        .slice(0, relevantMax)
        .map((x) => x.item)
    : [];
  const recent = items.slice().sort((a, b) => itemTime(b) - itemTime(a)).slice(0, recentMax);
  const seen = new Set();
  const out = [];
  for (const item of [...relevant, ...recent]) {
    const id = item.id || item._key || JSON.stringify(item);
    if (seen.has(id)) continue;
    seen.add(id);
    out.push(item);
  }
  return out;
}

const clip = (v, n) => limitText(String(v ?? "").replace(/\s+/g, " ").trim(), n);

function buildMemoryView(raw, query) {
  const terms = extractTerms(query);
  const lines = [];

  const memories = pick(normalizeCollection(raw.memories), terms, 6, 8);
  if (memories.length) {
    lines.push("خاطره‌ها:");
    for (const m of memories) lines.push(`- ${m.date ? `[${clip(m.date, 20)}] ` : ""}${clip(m.title, 80)}${m.desc ? `: ${clip(m.desc, 260)}` : ""}`);
  }

  const pledges = pick(normalizeCollection(raw.pledges), terms, 4, 6);
  if (pledges.length) {
    lines.push("عهدها:");
    for (const p of pledges) lines.push(`- ${clip(p.text, 200)}`);
  }

  const dreams = pick(normalizeCollection(raw.dreams), terms, 4, 6);
  if (dreams.length) {
    lines.push("آرزوها:");
    for (const d of dreams) lines.push(`- ${clip(d.text, 200)}`);
  }

  const music = pick(normalizeCollection(raw.music), terms, 3, 4);
  if (music.length) {
    lines.push("آهنگ‌ها:");
    for (const m of music) lines.push(`- ${clip(m.title, 80)}${m.artist ? ` — ${clip(m.artist, 60)}` : ""}`);
  }

  const capsules = pick(normalizeCollection(raw.capsules), terms, 3, 5);
  if (capsules.length) {
    lines.push("کپسول‌های زمانی:");
    for (const c of capsules) {
      // متن کپسولِ بازنشده محرمانه است و هرگز به مدل داده نمی‌شود
      if (c.isOpened === true) lines.push(`- «${clip(c.title, 60)}» (بازشده): ${clip(c.text, 220)}`);
      else lines.push(`- «${clip(c.title, 60)}» (هنوز بسته، تاریخ بازشدن: ${clip(c.openDate, 25)}؛ محتوایش را نمی‌دانی)`);
    }
  }

  if (typeof raw.letter === "string" && raw.letter.trim()) {
    lines.push(`نامه‌ی مشترک: ${clip(raw.letter, 500)}`);
  }

  const challenges = pick(normalizeCollection(raw.moments?.challenges), terms, 2, 5);
  if (challenges.length) {
    lines.push("چالش‌های اخیر بخش دونفره:");
    for (const c of challenges) {
      const answers = c.answers && typeof c.answers === "object"
        ? Object.entries(c.answers).map(([who, a]) => `${NAMES[who] || who}: ${clip(a, 140)}`).join(" | ")
        : "";
      lines.push(`- ${clip(c.text, 160)}${answers ? ` ← ${answers}` : ""}`);
    }
  }

  const text = lines.join("\n");
  return text.length > MAX_MEMORY_CHARS ? text.slice(0, MAX_MEMORY_CHARS) + "…" : text;
}

function formatMemory(memory) {
  return memory && String(memory).trim() ? String(memory) : "(هنوز چیز زیادی ثبت نشده)";
}

function cleanContext(value) {
  if (!value || typeof value !== "object") return {};
  const out = {};
  for (const [k, v] of Object.entries(value)) {
    if (typeof v === "string") out[k] = limitText(v, 400);
    else if (typeof v === "number" || typeof v === "boolean") out[k] = v;
    else if (v && typeof v === "object") out[k] = stripHeavy(v, 3);
  }
  return out;
}

// ---------------------------------------------------------------------------
// خروجی مدل
// ---------------------------------------------------------------------------

function extractText(value) {
  if (typeof value === "string") return value;
  if (typeof value?.response === "string") return value.response;
  if (typeof value?.result === "string") return value.result;
  if (typeof value?.choices?.[0]?.message?.content === "string") return value.choices[0].message.content;
  if (typeof value?.choices?.[0]?.text === "string") return value.choices[0].text;
  return "";
}

function cleanAIText(value) {
  let text = String(extractText(value) || "");
  // بخش «فکر کردن» (بسته یا نیمه‌باز) هرگز نمایش داده نمی‌شود
  text = text.replace(/<think>[\s\S]*?<\/think>/gi, "").replace(/<think>[\s\S]*$/i, "");
  text = text.replace(/^```(?:text|json)?\s*/i, "").replace(/\s*```$/i, "").trim();
  if (/^SKIP\b[.!؟\s]*$/i.test(text)) return "SKIP";
  // برچسب گوینده یا قالب‌بندی که مدل از تاریخچه کپی می‌کند
  text = text.replace(/^\[[^\]]{0,200}\]\s*/, "");
  text = text.replace(/^(?:-+>\s*)?(?:لوینیا|امین|نیایش)\s*[:：]\s*/, "");
  text = text.replace(/\*\*(.+?)\*\*/g, "$1").replace(/^#{1,6}\s+/gm, "");
  text = text.trim();
  // جواب نصفه (سقف توکن): تا آخرین جمله‌ی کامل
  if (text.length >= 200 && !/[.!?؟…»"')\]]$/.test(text) && !/\p{Extended_Pictographic}$/u.test(text)) {
    const cut = Math.max(text.lastIndexOf("."), text.lastIndexOf("!"), text.lastIndexOf("؟"), text.lastIndexOf("?"), text.lastIndexOf("…"), text.lastIndexOf("\n"));
    if (cut >= text.length * 0.6) text = text.slice(0, cut + 1).trim();
  }
  return text;
}

// ---------------------------------------------------------------------------
// رویداد محتوای تازه
// ---------------------------------------------------------------------------

async function handleEvent(body, env) {
  const eventType = limitText(body?.eventType || body?.type || "site_event", 100);
  const eventData = cleanContext(body?.data);
  const contentEvents = ["memory_added", "moment_added", "pledge_added", "dream_added", "capsule_added", "music_added", "letter_updated"];
  const taskType = contentEvents.includes(eventType) ? "observe_content" : "event";

  // متن کپسول محرمانه است؛ حتی اگه کلاینت فرستاده باشد حذف می‌شود
  if (eventType === "capsule_added") {
    delete eventData.text; delete eventData.content; delete eventData.message;
  }

  const labels = {
    memory_added: "یک خاطره‌ی تازه ثبت شد", pledge_added: "یک عهد تازه ثبت شد", dream_added: "یک آرزوی تازه ثبت شد",
    music_added: "یک آهنگ تازه اضافه شد", capsule_added: "یک کپسول زمانی تازه ساخته شد (محتوایش محرمانه است)",
    moment_added: "یک لحظه‌ی تازه ثبت شد", letter_updated: "نامه‌ی مشترک به‌روز شد"
  };
  const memory = await loadMemory(JSON.stringify(eventData), "", env);
  const userPrompt = `${labels[eventType] || `اتفاق تازه: ${eventType}`}:\n${JSON.stringify(eventData, null, 0).slice(0, 2500)}\n\nاگه واقعاً ارزش یک واکنش کوتاه و صمیمی دارد بنویس؛ وگرنه فقط: SKIP`;
  const text = await generate(env, buildSystemPrompt(memory, {}, taskType), userPrompt, generationOptions(taskType));

  if (!text || text === "SKIP") return { ok: true, result: "SKIP", sent: false };
  const sent = await saveAiMessage(text, `event:${eventType}`, env);
  return { ok: true, result: text, sent };
}

// ---------------------------------------------------------------------------
// بررسی خودکار (Cron)
// ---------------------------------------------------------------------------

async function runAutomaticCheck(env) {
  const state = await firebaseGet("loveniya_ai_state.json", env).catch(() => null);
  const now = Date.now();
  if (now - Number(state?.lastAutoMessageAt || 0) < AUTO_COOLDOWN) return;

  memoryCache = { at: 0, data: null };
  const raw = await loadRawMemory(env);
  const signals = findTodaySignals(raw, now);
  if (signals.length === 0) return;

  const memory = buildMemoryView(raw, JSON.stringify(signals));
  const prompt = `امروز برای امین و نیایش این موارد مرتبط پیدا شده:\n\n${JSON.stringify(signals, null, 0)}\n\nفقط اگه واقعاً ارزش یک پیام مستقل و طبیعی از طرف لوینیا دارند یک پیام کوتاه (۱ تا ۳ جمله) بنویس؛ تکراری، تبلیغاتی یا بیش‌ازحد شیرین نباشد. وگرنه فقط: SKIP`;
  const text = await generate(env, buildSystemPrompt(memory, {}, "cron"), prompt, generationOptions("cron"));
  if (!text || text === "SKIP") return;

  if (await saveAiMessage(text, "scheduled", env)) {
    await firebasePut("loveniya_ai_state.json", { lastAutoMessageAt: now, lastTrigger: signals[0]?.kind || "scheduled" }, env);
  }
}

function dateOnly(item, keys = ["date", "createdAt", "timestamp"]) {
  for (const key of keys) {
    const value = item?.[key];
    if (typeof value === "number") {
      const d = new Date(value);
      if (!Number.isNaN(d.getTime())) return d.toISOString().slice(0, 10);
    }
    if (value) {
      const m = String(value).match(/\d{4}[-/]\d{1,2}[-/]\d{1,2}/);
      if (m) return m[0].replaceAll("/", "-");
    }
  }
  return "";
}

function findTodaySignals(raw, now) {
  const today = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Tehran" }).format(new Date(now));
  const [, month, day] = today.split("-");
  const same = (d) => {
    const m = String(d).match(/^\d{4}-(\d{2})-(\d{2})$/);
    return Boolean(m) && m[1] === month && m[2] === day;
  };
  const result = [];
  for (const item of normalizeCollection(raw.memories)) {
    if (same(dateOnly(item))) result.push({ kind: "memory_anniversary", title: item.title || "خاطره" });
  }
  for (const item of normalizeCollection(raw.pledges)) {
    if (same(dateOnly(item))) result.push({ kind: "pledge_anniversary", text: item.text || "عهد" });
  }
  for (const item of normalizeCollection(raw.capsules)) {
    if (dateOnly(item, ["openDate"]) === today && item.isOpened !== true) {
      result.push({ kind: "capsule_due", title: item.title || "کپسول" });
    }
  }
  return result.slice(0, 8);
}

async function saveAiMessage(text, trigger, env) {
  const now = Date.now();
  const id = `ai_${now}_${randomId(7)}`;
  const clean = String(text).trim();
  const message = {
    id,
    senderId: "ai",
    senderName: "لوینیا",
    sender: "Loveniya AI",
    role: "ai",
    text: clean,
    content: clean,
    timestamp: now,
    createdAt: now,
    aiMetadata: { emotion: "caring", actionTrigger: trigger }
  };
  try {
    await firebasePut(`loveniya_chat/${encodeURIComponent(id)}.json`, message, env);
    return true;
  } catch (error) {
    console.error("Save AI message failed:", error);
    return false;
  }
}

// ---------------------------------------------------------------------------
// Firebase (از طریق ورکر داده‌ها)
// ---------------------------------------------------------------------------

async function firebaseGet(path, env) {
  const base = getProxyUrl(env);
  const response = await fetch(`${base}/${path}${path.includes("?") ? "&" : "?"}_ai=${Date.now()}`, {
    method: "GET",
    headers: { Accept: "application/json", "X-App-Secret": env.APP_SECRET },
    redirect: "follow"
  });
  if (!response.ok) throw new Error(`Firebase GET ${response.status}`);
  return await response.json();
}

async function firebasePut(path, data, env) {
  const base = getProxyUrl(env);
  const response = await fetch(`${base}/${path}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json", Accept: "application/json", "X-App-Secret": env.APP_SECRET },
    body: JSON.stringify(data),
    redirect: "follow"
  });
  if (!response.ok) {
    const text = await response.text().catch(() => "");
    throw new Error(`Firebase PUT ${response.status}: ${text.slice(0, 300)}`);
  }
  return true;
}

// ---------------------------------------------------------------------------
// نشست (اختیاری)
// ---------------------------------------------------------------------------

async function authenticateSession(request, env) {
  const header = request.headers.get("Authorization") || "";
  const match = /^Bearer\s+(.+)$/i.exec(header.trim());
  if (!match || !env.SESSION_SECRET) return false;
  const [payload, signature] = match[1].split(".");
  if (!payload || !signature) return false;
  const expected = encodeBase64Url(await hmacSign(env.SESSION_SECRET, payload));
  if (!safeEqual(signature, expected)) return false;
  try {
    const data = JSON.parse(decodeBase64Url(payload));
    return (
      (data?.user === "amin" || data?.user === "niyayesh") &&
      typeof data?.exp === "number" && data.exp > Date.now() &&
      Date.now() - Number(data.iat || 0) < SESSION_TTL_MS + 5 * 60000
    );
  } catch {
    return false;
  }
}

async function hmacSign(secret, value) {
  const key = await crypto.subtle.importKey("raw", SESSION_ENCODER.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return await crypto.subtle.sign("HMAC", key, SESSION_ENCODER.encode(value));
}
function safeEqual(a, b) {
  const l = String(a), r = String(b);
  if (l.length !== r.length) return false;
  let diff = 0;
  for (let i = 0; i < l.length; i++) diff |= l.charCodeAt(i) ^ r.charCodeAt(i);
  return diff === 0;
}
function encodeBase64Url(value) {
  const bytes = typeof value === "string" ? SESSION_ENCODER.encode(value) : new Uint8Array(value);
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}
function decodeBase64Url(value) {
  const raw = String(value);
  const padded = raw.replace(/-/g, "+").replace(/_/g, "/") + "===".slice((raw.length + 3) % 4);
  const binary = atob(padded);
  return SESSION_DECODER.decode(Uint8Array.from(binary, (c) => c.charCodeAt(0)));
}
