import React, { useEffect, useMemo, useState } from 'react';
import {
  Shuffle, HelpCircle, Flame, MessageCircleHeart, Loader2, Send,
  CheckCircle2, Clock, ChevronDown, Sparkles, BellRing, Lock
} from 'lucide-react';
import { motion } from 'motion/react';
import { PageWrapper } from '../components/PageWrapper';
import { useGames } from '../lib/gameStore';
import {
  Challenge, ChallengeKind, Who, canNudge, isDone, needsMe, nameOf, timeAgoFa, toFa
} from '../lib/challenges';

// منطق همگام‌سازی، صف ارسال و اعلان‌ها در lib/gameStore.tsx زندگی می‌کنه (تا اعلان‌ها روی همه‌ی
// صفحه‌های سایت کار کنن)؛ این صفحه فقط نمایش و ورودی کاربره.

const KIND_META: Record<ChallengeKind, { label: string; icon: typeof HelpCircle; badge: string }> = {
  truth: { label: 'حقیقت', icon: HelpCircle, badge: 'bg-sky-50 text-sky-700 border-sky-200' },
  dare: { label: 'جرأت', icon: Flame, badge: 'bg-rose-50 text-rose-700 border-rose-200' },
  deep: { label: 'سوال عمیق', icon: MessageCircleHeart, badge: 'bg-emerald-50 text-emerald-700 border-emerald-200' }
};

const HISTORY_PREVIEW = 3;

export const Moments: React.FC = () => {
  const {
    me, partnerName, challenges, loaded, isDrawing, drawBlock, unseenResultIds,
    createChallenge, submitAnswer, markDareDone, nudge, markSeen
  } = useGames();

  const [drafts, setDrafts] = useState<Record<string, string>>({});
  const [showHistory, setShowHistory] = useState(false);

  // نتیجه‌های خونده‌نشده: تو همین بازدید با برچسب «جدید» بالا می‌مونن، ولی بعد از یک مکث کوتاه
  // «دیده‌شده» ثبت می‌شن تا زنگ هدر خاموش بشه.
  const [freshIds, setFreshIds] = useState<Set<string>>(() => new Set());
  useEffect(() => {
    if (!loaded || unseenResultIds.length === 0) return;
    setFreshIds(prev => {
      const next = new Set(prev);
      unseenResultIds.forEach(id => next.add(id));
      return next;
    });
    const t = setTimeout(() => {
      if (document.visibilityState === 'visible') markSeen(unseenResultIds);
    }, 1500);
    return () => clearTimeout(t);
  }, [loaded, unseenResultIds, markSeen]);

  const { pendingForMe, pendingForPartner, fresh, history } = useMemo(() => {
    const done = challenges.filter(isDone);
    return {
      pendingForMe: challenges.filter(c => needsMe(c, me)),
      pendingForPartner: challenges.filter(c => !isDone(c) && !needsMe(c, me)),
      fresh: done.filter(c => freshIds.has(c.id)),
      history: done.filter(c => !freshIds.has(c.id))
    };
  }, [challenges, me, freshIds]);

  const visibleHistory = showHistory ? history : history.slice(0, HISTORY_PREVIEW);

  const cardProps = (c: Challenge) => ({
    c, me, partnerName,
    draft: drafts[c.id] || '',
    onDraftChange: (v: string) => setDrafts(prev => ({ ...prev, [c.id]: v })),
    onSubmitAnswer: () => {
      const text = (drafts[c.id] || '').trim();
      if (!text) return;
      setDrafts(prev => ({ ...prev, [c.id]: '' }));
      void submitAnswer(c.id, text);
    },
    onMarkDone: () => void markDareDone(c.id),
    onNudge: () => void nudge(c.id)
  });

  const blockedHint =
    drawBlock === 'mine'
      ? 'اول به چالش‌هایی که منتظر توئن جواب بده؛ بعد می‌تونی چالش تازه بسازی'
      : drawBlock === 'waiting'
        ? `چند چالش هنوز بی‌جواب مونده؛ وقتی ${partnerName} جواب داد، چالش تازه می‌سازی`
        : null;

  return (
    <PageWrapper>
      <div className="space-y-4 max-w-2xl mx-auto px-2 sm:px-4 py-2" dir="rtl">

        <section className="bg-white rounded-3xl p-5 shadow-[0_16px_50px_-12px_rgba(28,25,23,0.06)] text-center space-y-3">
          <div>
            <h1 className="text-2xl font-black text-stone-900 tracking-tight">گفتگوی دونفره</h1>
            <p className="text-xs text-stone-500 font-bold mt-1.5">
              هر بار یه چیز متفاوت — گاهی سبک، گاهی شیطنت‌آمیز، گاهی واقعاً عمیق
            </p>
          </div>
          <button
            onClick={() => void createChallenge()}
            disabled={isDrawing || drawBlock !== null}
            className="w-full min-h-[48px] bg-stone-900 hover:bg-stone-800 disabled:opacity-50 disabled:cursor-not-allowed text-white text-sm font-black rounded-xl flex items-center justify-center gap-2 cursor-pointer transition-colors"
          >
            {isDrawing
              ? <Loader2 className="w-4 h-4 animate-spin" />
              : drawBlock
                ? <Lock className="w-4 h-4" />
                : <Shuffle className="w-4 h-4" />}
            <span>{isDrawing ? 'در حال ساختن...' : 'یه چالش تازه بساز'}</span>
          </button>
          {blockedHint && !isDrawing && (
            <p className="text-[11px] font-bold text-stone-500 leading-5">{blockedHint}</p>
          )}
        </section>

        {fresh.length > 0 && (
          <section className="space-y-2.5">
            <h2 className="text-xs font-black text-rose-600 px-1">جواب‌های تازه ({toFa(fresh.length)})</h2>
            {fresh.map(c => <ChallengeCard key={c.id} {...cardProps(c)} isNew />)}
          </section>
        )}

        {pendingForMe.length > 0 && (
          <section className="space-y-2.5">
            <h2 className="text-xs font-black text-stone-500 px-1">برای تو ({toFa(pendingForMe.length)})</h2>
            {pendingForMe.map(c => <ChallengeCard key={c.id} {...cardProps(c)} />)}
          </section>
        )}

        {pendingForPartner.length > 0 && (
          <section className="space-y-2.5">
            <h2 className="text-xs font-black text-stone-500 px-1">منتظر {partnerName} ({toFa(pendingForPartner.length)})</h2>
            {pendingForPartner.map(c => <ChallengeCard key={c.id} {...cardProps(c)} />)}
          </section>
        )}

        {history.length > 0 && (
          <section className="space-y-2.5">
            <h2 className="text-xs font-black text-stone-500 px-1">تاریخچه ({toFa(history.length)})</h2>
            {visibleHistory.map(c => <ChallengeCard key={c.id} {...cardProps(c)} />)}
            {history.length > HISTORY_PREVIEW && (
              <button
                onClick={() => setShowHistory(v => !v)}
                className="w-full min-h-[36px] flex items-center justify-center gap-1.5 text-xs font-black text-stone-500 hover:text-stone-800 cursor-pointer"
              >
                <span>{showHistory ? 'نمایش کمتر' : `نمایش ${toFa(history.length - HISTORY_PREVIEW)} مورد قبلی`}</span>
                <ChevronDown className={`w-3.5 h-3.5 transition-transform ${showHistory ? 'rotate-180' : ''}`} />
              </button>
            )}
          </section>
        )}

        {challenges.length === 0 && (
          <div className="bg-white rounded-3xl p-8 text-center border border-dashed border-stone-200">
            <Sparkles className="w-6 h-6 text-stone-300 mx-auto mb-2" />
            <p className="text-xs font-bold text-stone-400">
              {loaded ? 'هنوز چیزی نساختید — دکمه‌ی بالا رو بزن' : 'در حال دریافت...'}
            </p>
          </div>
        )}

      </div>
    </PageWrapper>
  );
};

type CardProps = {
  c: Challenge;
  me: Who;
  partnerName: string;
  isNew?: boolean;
  draft: string;
  onDraftChange: (v: string) => void;
  onSubmitAnswer: () => void;
  onMarkDone: () => void;
  onNudge: () => void;
};

const AnswerBox: React.FC<{
  draft: string; rows: number; placeholder: string;
  onDraftChange: (v: string) => void; onSubmit: () => void;
}> = ({ draft, rows, placeholder, onDraftChange, onSubmit }) => (
  <div className="space-y-2">
    <textarea
      value={draft}
      onChange={(e) => onDraftChange(e.target.value)}
      placeholder={placeholder}
      rows={rows}
      className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3 py-2.5 text-xs font-bold text-stone-900 placeholder:text-stone-400 placeholder:font-medium focus:outline-hidden focus:border-stone-400 resize-none leading-6"
    />
    <button
      onClick={onSubmit}
      disabled={!draft.trim()}
      className="w-full min-h-[40px] bg-stone-900 hover:bg-stone-800 disabled:opacity-40 text-white text-xs font-black rounded-xl flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
    >
      <Send className="w-3.5 h-3.5" />
      <span>ثبت جواب</span>
    </button>
  </div>
);

const AnswerView: React.FC<{ label: string; text?: string }> = ({ label, text }) => (
  <div className="bg-stone-50 rounded-xl p-3 border border-stone-200">
    <span className="text-[10px] font-black text-stone-500 block mb-1">{label}</span>
    <p className="text-xs font-bold text-stone-800 leading-6 whitespace-pre-wrap">{text}</p>
  </div>
);

const ChallengeCard: React.FC<CardProps> = ({
  c, me, partnerName, isNew, draft, onDraftChange, onSubmitAnswer, onMarkDone, onNudge
}) => {
  const meta = KIND_META[c.kind];
  const Icon = meta.icon;
  const finished = isDone(c);
  const mine = needsMe(c, me);
  const nudgeable = canNudge(c, me);
  const waitingLabel = c.kind === 'dare' ? `منتظر ${partnerName}` : `منتظر جواب ${partnerName}`;

  const waiting = (
    <div className="flex items-center justify-between gap-2">
      <span className="inline-flex items-center gap-1.5 text-[11px] font-black text-stone-400">
        <Clock className="w-3.5 h-3.5" /> {waitingLabel}
      </span>
      {nudgeable && (
        <button
          onClick={onNudge}
          className="inline-flex items-center gap-1 min-h-[32px] text-[11px] font-black text-rose-600 hover:text-rose-700 cursor-pointer"
        >
          <BellRing className="w-3.5 h-3.5" /> یادآوری
        </button>
      )}
    </div>
  );

  let body: React.ReactNode;
  if (c.kind === 'deep') {
    if (finished) {
      body = (
        <div className="space-y-2">
          {(['amin', 'niyayesh'] as const).map(k => <AnswerView key={k} label={nameOf(k)} text={c.answers[k]} />)}
        </div>
      );
    } else if (mine) {
      body = (
        <AnswerBox draft={draft} rows={3} onDraftChange={onDraftChange} onSubmit={onSubmitAnswer}
          placeholder="صادقانه بنویس، تا هر دو جواب ندید دیده نمی‌شه" />
      );
    } else {
      body = (
        <div className="space-y-2">
          <AnswerView label="جواب تو" text={c.answers[me]} />
          {waiting}
        </div>
      );
    }
  } else if (c.kind === 'truth') {
    if (finished) body = <AnswerView label={`جواب ${nameOf(c.targetUser!)}`} text={c.answers[c.targetUser!]} />;
    else if (mine) body = <AnswerBox draft={draft} rows={2} onDraftChange={onDraftChange} onSubmit={onSubmitAnswer} placeholder="جوابت..." />;
    else body = waiting;
  } else if (finished) {
    body = (
      <span className="inline-flex items-center gap-1.5 text-[11px] font-black text-emerald-600">
        <CheckCircle2 className="w-3.5 h-3.5" /> انجام شد
      </span>
    );
  } else if (mine) {
    body = (
      <button
        onClick={onMarkDone}
        className="w-full min-h-[40px] bg-stone-900 hover:bg-stone-800 text-white text-xs font-black rounded-xl cursor-pointer transition-colors"
      >
        انجام دادم
      </button>
    );
  } else {
    body = waiting;
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      className={`bg-white rounded-2xl p-4 border space-y-3 ${isNew ? 'border-rose-300' : finished ? 'border-stone-200' : mine ? 'border-stone-900/15' : 'border-stone-200'}`}
    >
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0">
          <span className={`inline-flex items-center gap-1.5 text-[11px] font-black px-2.5 py-1 rounded-full border ${meta.badge}`}>
            <Icon className="w-3.5 h-3.5" />
            <span>{meta.label}</span>
          </span>
          {c.tone === 'flirty' && (
            <span className="inline-flex items-center gap-1 text-[10px] font-black text-fuchsia-500">
              <Sparkles className="w-3 h-3" /> شیطنت‌آمیز
            </span>
          )}
          {isNew && <span className="text-[10px] font-black text-rose-500">جدید</span>}
        </div>
        <span className="text-[10px] font-bold text-stone-400 shrink-0">{timeAgoFa(c.createdAt)}</span>
      </div>

      <p className="text-sm font-black text-stone-900 leading-7">{c.text}</p>

      {body}
    </motion.div>
  );
};
