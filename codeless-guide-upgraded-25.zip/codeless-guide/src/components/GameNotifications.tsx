import React from 'react';
import { NavLink, useLocation, useNavigate } from 'react-router';
import { AlertCircle, Bell, MessageCircleHeart, X } from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { useGames } from '../lib/gameStore';
import { toFa } from '../lib/challenges';

/**
 * اعلان درون‌سایتی بخش «دونفره»: روی هر صفحه‌ای که باشی (به‌جز چت تمام‌صفحه) خبر تازه رو می‌بینی.
 * با لمس، به همون بخش می‌ره. زیر هدر نشسته تا نوار پایین دست‌نخورده بمونه.
 */
export const GameToaster: React.FC = () => {
  const { toast, dismissToast } = useGames();
  const navigate = useNavigate();
  const location = useLocation();

  const open = () => {
    if (!toast) return;
    const to = toast.to;
    dismissToast();
    if (to && location.pathname !== to) navigate(to);
  };

  const isError = toast?.tone === 'error';
  const Icon = isError ? AlertCircle : MessageCircleHeart;

  return (
    <div
      className="fixed inset-x-0 z-50 flex justify-center px-3 pointer-events-none"
      style={{ top: 'calc(env(safe-area-inset-top) + 3.75rem)' }}
      dir="rtl"
    >
      <AnimatePresence mode="wait">
        {toast && (
          <motion.div
            key={toast.id}
            role={isError ? 'alert' : 'status'}
            aria-live={isError ? 'assertive' : 'polite'}
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
            className={`pointer-events-auto max-w-[92vw] flex items-center gap-2 rounded-2xl shadow-lg pl-1.5 pr-3 py-1.5 text-white ${isError ? 'bg-rose-600/95' : 'bg-stone-900/95'}`}
          >
            <button
              type="button"
              onClick={open}
              className="flex items-center gap-2 min-h-[40px] text-sm font-black text-right cursor-pointer"
            >
              <Icon className="w-4 h-4 shrink-0" aria-hidden="true" />
              <span>{toast.text}</span>
            </button>
            <button
              type="button"
              onClick={dismissToast}
              aria-label="بستن اعلان"
              className="w-8 h-8 shrink-0 rounded-xl flex items-center justify-center text-white/70 hover:text-white hover:bg-white/10 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

/**
 * زنگ هدر: فقط وقتی خبری در «دونفره» منتظره دیده می‌شه؛ در غیر این‌صورت جای خالی همون
 * دکمه‌ی تنظیمات رو نگه می‌داره تا لوگو دقیقاً وسط هدر بمونه (طراحی قبلی بدون تغییر).
 */
export const GameBell: React.FC = () => {
  const { attention, todoCount } = useGames();

  if (attention <= 0) return <span aria-hidden="true" className="w-9 shrink-0" />;

  const label = todoCount > 0
    ? `${toFa(todoCount)} مورد در دونفره منتظر جواب توئه`
    : 'جواب تازه در دونفره';

  return (
    <NavLink
      to="/games"
      aria-label={label}
      title={label}
      className="relative w-9 h-9 rounded-xl flex items-center justify-center shrink-0 text-rose-600 bg-rose-50 border border-rose-200/60 hover:bg-rose-100 transition-colors"
    >
      <Bell className="w-4 h-4" />
      <span
        aria-hidden="true"
        className="absolute -top-1.5 -left-1.5 min-w-[18px] h-[18px] px-1 rounded-full bg-rose-500 text-white text-[10px] font-black leading-[18px] text-center"
      >
        {toFa(attention)}
      </span>
    </NavLink>
  );
};
