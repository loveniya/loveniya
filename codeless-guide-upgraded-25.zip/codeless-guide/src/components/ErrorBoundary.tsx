import React from 'react';
import { RefreshCcw } from 'lucide-react';

type Props = {
  children: React.ReactNode;
  /** با تغییر این مقدار (مثلاً مسیر صفحه) خطا پاک می‌شه و دوباره رندر امتحان می‌شه. */
  resetKey?: string;
};
type State = { error: Error | null };

/**
 * قبلاً هیچ ErrorBoundary‌ای وجود نداشت؛ یعنی هر خطای رندر، یا شکست در دانلود صفحه‌ی سنگینی مثل
 * چت (روی اینترنت ضعیف) کل برنامه رو به یک صفحه‌ی سفید تبدیل می‌کرد. حالا فقط همون بخش
 * خراب می‌شه و دکمه‌ی تلاش دوباره دیده می‌شه.
 */
export class ErrorBoundary extends React.Component<Props, State> {
  state: State = { error: null };

  static getDerivedStateFromError(error: Error): State {
    return { error };
  }

  componentDidCatch(error: Error, info: React.ErrorInfo) {
    console.error('ErrorBoundary:', error, info.componentStack);
  }

  componentDidUpdate(prev: Props) {
    if (this.state.error && prev.resetKey !== this.props.resetKey) this.setState({ error: null });
  }

  private retry = () => {
    // اگه خطا از دانلود بخشی از برنامه بود (chunk)، فقط رندر مجدد کافی نیست
    const msg = String(this.state.error?.message || '');
    if (/Failed to fetch dynamically imported module|Importing a module script failed|error loading dynamically imported module|Loading chunk/i.test(msg)) {
      window.location.reload();
      return;
    }
    this.setState({ error: null });
  };

  render() {
    if (!this.state.error) return this.props.children;
    return (
      <div role="alert" className="flex flex-col items-center justify-center gap-3 py-20 px-6 text-center" dir="rtl">
        <p className="text-sm font-black text-stone-800">این بخش درست باز نشد</p>
        <p className="text-xs font-bold text-stone-500 max-w-xs leading-6">
          احتمالاً اینترنت یک لحظه قطع شده. دوباره امتحان کن؛ اطلاعاتت از بین نرفته.
        </p>
        <button
          type="button"
          onClick={this.retry}
          className="min-h-[44px] px-5 rounded-xl bg-stone-900 hover:bg-stone-800 text-white text-xs font-black flex items-center gap-2 cursor-pointer transition-colors"
        >
          <RefreshCcw className="w-4 h-4" />
          <span>تلاش دوباره</span>
        </button>
      </div>
    );
  }
}
