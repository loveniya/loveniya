/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { HashRouter, Routes, Route, Navigate, useLocation } from 'react-router';
import { useState, useEffect, Suspense } from 'react';
import { motion, MotionConfig } from 'motion/react';
import { StoreProvider } from './lib/store';
import { Navigation } from './components/Navigation';
import { LockScreen } from './components/LockScreen';
import { Home } from './pages/Home';
import { RomanticEffects } from './components/RomanticEffects';
import { MediaPlayer } from './components/MediaPlayer';
import { useGlobalPresenceTracker } from './lib/presence';
import { GameProvider } from './lib/gameStore';
import { GameToaster } from './components/GameNotifications';
import { ErrorBoundary } from './components/ErrorBoundary';
import { lazyRetry } from './lib/lazyRetry';

// فقط خانه همراه بسته‌ی اصلی می‌آد (اولین چیزی که دیده می‌شه). بقیه‌ی صفحه‌ها جدا لود می‌شن تا
// موقع باز کردن سایت، جاوااسکریپتِ کمتری دانلود و اجرا بشه (روی گوشی‌های ضعیف و اینترنت کند فرق محسوسیه).
// لودرها اینجا تعریف می‌شن تا بعد از رندر اول بشه در پس‌زمینه پیش‌دانلودشون کرد (پایین‌تر).
const pageLoaders = {
  memories: () => import('./pages/Memories').then(m => ({ default: m.Memories })),
  pledges: () => import('./pages/Pledges').then(m => ({ default: m.Pledges })),
  dreams: () => import('./pages/Dreams').then(m => ({ default: m.Dreams })),
  music: () => import('./pages/Music').then(m => ({ default: m.Music })),
  letters: () => import('./pages/Letters').then(m => ({ default: m.Letters })),
  settings: () => import('./pages/Settings').then(m => ({ default: m.Settings })),
  moments: () => import('./pages/Moments').then(m => ({ default: m.Moments })),
  chat: () => import('./pages/AIChat').then(m => ({ default: m.AIChat })),
};
const AIChat = lazyRetry(pageLoaders.chat);
const Moments = lazyRetry(pageLoaders.moments);
const Memories = lazyRetry(pageLoaders.memories);
const Pledges = lazyRetry(pageLoaders.pledges);
const Dreams = lazyRetry(pageLoaders.dreams);
const Music = lazyRetry(pageLoaders.music);
const Letters = lazyRetry(pageLoaders.letters);
const Settings = lazyRetry(pageLoaders.settings);

/**
 * بعد از اینکه صفحه‌ی اول نشون داده شد و مرورگر بیکار شد، بقیه‌ی صفحه‌ها رو یکی‌یکی و آروم دانلود می‌کنه:
 * هم رفتن بین صفحه‌ها فوری می‌شه، هم اگه اینترنت وسط کار قطع شد صفحه‌ها از قبل دم‌دستن (سایت سرویس‌ورکر نداره).
 * اگه کاربر «صرفه‌جویی در داده» رو روشن کرده یا اتصالش خیلی کنده، هیچ چیزی پیش‌دانلود نمی‌شه.
 */
function usePrefetchPages() {
  useEffect(() => {
    const conn = (navigator as any).connection;
    if (conn && (conn.saveData || /(^|-)2g$/.test(conn.effectiveType || ''))) return;
    let cancelled = false;
    const queue = Object.values(pageLoaders);
    // سافاری requestIdleCallback ندارد؛ برایش با تایمر کوتاه جایگزین می‌شود
    const ric = (window as any).requestIdleCallback as undefined | ((cb: () => void, o?: { timeout: number }) => number);
    const idle = (cb: () => void) => (typeof ric === 'function' ? ric(cb, { timeout: 4000 }) : window.setTimeout(cb, 1500));
    const next = () => {
      if (cancelled) return;
      const load = queue.shift();
      if (!load) return;
      load().catch(() => { /* شکست پیش‌دانلود مهم نیست؛ موقع رفتن به صفحه دوباره تلاش می‌شه */ }).finally(() => idle(next));
    };
    const start = window.setTimeout(() => idle(next), 2500);
    return () => { cancelled = true; window.clearTimeout(start); };
  }, []);
}

const RouteLoadingFallback = () => (
  <div className="flex items-center justify-center py-24" dir="rtl">
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="flex flex-col items-center gap-3 text-rose-400"
    >
      <div className="w-8 h-8 border-2 border-rose-200 border-t-rose-500 rounded-full animate-spin" />
      <span className="text-xs font-bold text-stone-400">در حال آماده‌سازی...</span>
    </motion.div>
  </div>
);

function AppContent({ handleLock }: { handleLock: () => void }) {
  useGlobalPresenceTracker();
  usePrefetchPages();

  return (
    <HashRouter basename="/">
      {/* موتور «دونفره» و اعلان‌هاش باید داخل router باشن و روی همه‌ی صفحه‌ها فعال بمونن */}
      <GameProvider>
        <AppLayout handleLock={handleLock} />
      </GameProvider>
    </HashRouter>
  );
}

function AppLayout({ handleLock }: { handleLock: () => void }) {
  const location = useLocation();
  const isChatPage = location.pathname === '/magic' || location.pathname === '/chat';

  if (isChatPage) {
    return (
      <div className="fixed inset-0 z-50 bg-[#fff0f5] overflow-hidden overscroll-none">
        <ErrorBoundary resetKey={location.pathname}>
          <Suspense fallback={<RouteLoadingFallback />}>
            <AIChat />
          </Suspense>
        </ErrorBoundary>
      </div>
    );
  }

  return (
    <>
      <Navigation />
      <GameToaster />
      <MediaPlayer />
      <main className="max-w-4xl mx-auto px-4 md:px-6 pt-16 sm:pt-18 pb-28 relative z-10">
        <ErrorBoundary resetKey={location.pathname}>
        <Suspense fallback={<RouteLoadingFallback />}>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/memories" element={<Memories />} />
            <Route path="/pledges" element={<Pledges />} />
            <Route path="/dreams" element={<Dreams />} />
            <Route path="/music" element={<Music />} />
            <Route path="/letters" element={<Letters />} />
            <Route path="/moments" element={<Moments />} />
            <Route path="/games" element={<Moments />} />
            <Route path="/settings" element={<Settings onLock={handleLock} />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </Suspense>
        </ErrorBoundary>
      </main>
    </>
  );
}

export default function App() {
  // مقدار اولیه مستقیم از localStorage خونده می‌شه؛ قبلاً با useEffect بعد از اولین رندر
  // تنظیم می‌شد و صفحه‌ی قفل در هر بار باز شدن سایت یک لحظه فلش می‌زد.
  const [isUnlocked, setIsUnlocked] = useState(
    () => localStorage.getItem('loveniya_unlocked') === 'true' && !!localStorage.getItem('loveniya_user')
  );

  const handleUnlock = () => setIsUnlocked(true);
  const handleLock = () => {
    // هر دو کلید قفل باید با هم پاک بشن؛ اگه فقط یکی پاک بشه (باگ قبلی)،
    // دفعه بعد که سایت باز میشه بازم از LockScreen رد میشه چون شرط
    // بازشدن قفل توی useEffect بالا هر دو کلید رو با هم چک می‌کنه —
    // ولی چون خود کاربر و هویتش (loveniya_user) پاک نمی‌شد، قفل کردن
    // واقعی و کامل حساب رخ نمی‌داد.
    localStorage.removeItem('loveniya_unlocked');
    localStorage.removeItem('loveniya_user');
    setIsUnlocked(false);
  };

  if (!isUnlocked) {
    return <LockScreen onUnlock={handleUnlock} />;
  }

  return (
    <MotionConfig reducedMotion="user">
      <ErrorBoundary>
        <StoreProvider>
          <RomanticEffects />
          <AppContent handleLock={handleLock} />
        </StoreProvider>
      </ErrorBoundary>
    </MotionConfig>
  );
}

