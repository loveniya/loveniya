// باید اولین import باشه: قبل از هر کدی که localStorage می‌خونه، ذخیره‌سازیِ خراب رو محافظت می‌کنه.
import './lib/storageFallback';
import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
// فونت وزیرمتن روی خود سایت (بدون وابستگی به CDN خارجی)
import '@fontsource-variable/vazirmatn';
// فونت اسکریپت لوگوی هدر (I Love You)
import '@fontsource/alex-brush';
import App from './App.tsx';
import './index.css';

// بازیابی خودکار اسکرول مرورگر با HashRouter + انیمیشن‌های ورود با هم تداخل می‌کنن و صفحه رو وسط محتوا باز می‌کنن؛
// اسکرول رو خودمون مدیریت می‌کنیم (PageWrapper بالا، useDetailScroll جای قبلی).
if ('scrollRestoration' in history) history.scrollRestoration = 'manual';

// قفل زوم: متای viewport در اندروید کافیه و دابل‌تپ-زوم با touch-action: manipulation در index.css بسته شده.
// فقط pinch-zoom خود iOS Safari (که متا رو نادیده می‌گیره) با رویدادهای gesture* مسدود می‌شه.
// نکته: قبلاً یک listener غیرفعال روی touchmove بود که با touches.length > 1 جلوی رویداد رو می‌گرفت؛
// اگه حین اسکرول یک انگشت دوم (شست/کف دست) روی صفحه می‌موند، کل اسکرول می‌مرد و هر touchmove هم کند می‌شد. حذف شد.
const blockZoom = (e: Event) => e.preventDefault();
document.addEventListener('gesturestart', blockZoom);
document.addEventListener('gesturechange', blockZoom);
document.addEventListener('gestureend', blockZoom);

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
