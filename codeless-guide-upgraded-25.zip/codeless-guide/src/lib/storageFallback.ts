/**
 * محافظ ذخیره‌سازی: اگه مرورگر localStorage رو مسدود کرده باشه (بعضی حالت‌های خصوصی، وب‌ویوی برخی اپ‌ها،
 * تنظیمات «مسدود کردن همه‌ی کوکی‌ها/داده‌ها»)، فقط دسترسی به `window.localStorage` هم خطای SecurityError
 * پرتاب می‌کنه و کل سایت (از جمله App و قفل‌صفحه) با صفحه‌ی سفید می‌میره. پر شدن حافظه (QuotaExceededError)
 * هم نوشتن رو می‌شکنه.
 *
 * این ماژول باید «اولین import» در main.tsx باشه. فقط وقتی ذخیره‌سازی واقعی خراب باشه فعال می‌شه؛ در حالت
 * عادی هیچ تغییری روی رفتار سایت نداره. در حالت خراب، خوندن از ذخیره‌سازی واقعی (اگه خوندنی بود) ادامه
 * پیدا می‌کنه و نوشتنی که شکست بخوره در حافظه‌ی همین نشست نگه داشته می‌شه (با بستن تب از بین می‌ره).
 */
function probe(): boolean {
  try {
    const k = '__loveniya_probe__';
    window.localStorage.setItem(k, '1');
    window.localStorage.removeItem(k);
    return true;
  } catch {
    return false;
  }
}

if (typeof window !== 'undefined' && !probe()) {
  let real: Storage | null = null;
  try { real = window.localStorage; } catch { real = null; }
  const mem = new Map<string, string>();
  const removed = new Set<string>();

  const shim = {
    getItem(k: string): string | null {
      if (removed.has(k)) return null;
      if (mem.has(k)) return mem.get(k)!;
      try { return real ? real.getItem(k) : null; } catch { return null; }
    },
    setItem(k: string, v: string): void {
      const val = String(v);
      removed.delete(k);
      try {
        if (real) { real.setItem(k, val); mem.delete(k); return; }
      } catch { /* حافظه پر یا مسدود: می‌ریم سراغ حافظه‌ی نشست */ }
      mem.set(k, val);
    },
    removeItem(k: string): void {
      mem.delete(k);
      removed.add(k);
      try { real?.removeItem(k); } catch { /* نادیده */ }
    },
    clear(): void {
      mem.clear();
      try { real?.clear(); } catch { /* نادیده */ }
    },
    key(i: number): string | null {
      return [...mem.keys()][i] ?? null;
    },
    get length(): number {
      return mem.size;
    },
  };

  try {
    Object.defineProperty(window, 'localStorage', { value: shim, configurable: true });
  } catch { /* اگه مرورگر اجازه‌ی جایگزینی نداد، چاره‌ای نیست؛ ErrorBoundary بالاتر وضعیت رو مدیریت می‌کنه */ }
}

export {};
