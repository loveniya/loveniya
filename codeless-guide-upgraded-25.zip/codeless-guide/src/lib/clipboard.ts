/**
 * کپی متن در کلیپ‌بورد. navigator.clipboard فقط در زمینه‌ی امن (HTTPS) و در مرورگرهای نسبتاً جدید هست و
 * در بعضی وب‌ویوها یا بعد از سپری شدن «حرکت کاربر» رد می‌شه؛ در این حالت‌ها به روش قدیمی execCommand برمی‌گردیم.
 * خروجی: true اگه کپی انجام شد.
 */
export async function copyText(text: string): Promise<boolean> {
  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch { /* می‌ریم سراغ روش جایگزین */ }

  try {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.setAttribute('readonly', '');
    // خارج از دید ولی قابل انتخاب؛ فونت ۱۶ پیکسل تا iOS موقع انتخاب زوم نکنه
    ta.style.cssText = 'position:fixed;top:0;left:-9999px;opacity:0;font-size:16px;user-select:text;-webkit-user-select:text';
    document.body.appendChild(ta);
    ta.focus({ preventScroll: true });
    ta.select();
    ta.setSelectionRange(0, text.length);
    const ok = document.execCommand('copy');
    document.body.removeChild(ta);
    return ok;
  } catch {
    return false;
  }
}
