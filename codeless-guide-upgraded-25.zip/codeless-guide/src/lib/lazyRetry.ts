import { lazy } from 'react';
import type { ComponentType } from 'react';

/**
 * مثل React.lazy، ولی اگه دانلود صفحه با یک قطعیِ لحظه‌ای شکست خورد چند بار با تأخیر دوباره
 * امتحان می‌کنه (اینترنت ضعیف). فقط بعد از چند شکست پشت‌سرهم خطا به ErrorBoundary می‌رسه.
 */
export function lazyRetry<T extends ComponentType<any>>(
  factory: () => Promise<{ default: T }>,
  retries = 3
) {
  return lazy(async () => {
    let lastError: unknown;
    for (let attempt = 0; attempt <= retries; attempt++) {
      try {
        return await factory();
      } catch (err) {
        lastError = err;
        if (attempt < retries) await new Promise(r => setTimeout(r, 700 * (attempt + 1)));
      }
    }
    throw lastError;
  });
}
