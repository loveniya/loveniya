import { APP_SECRET } from './appSecret';
import { fetchT } from './net';
import { WORKER_URL, bumpRev } from './rev';
import type { ChatMessage } from './types';

/**
 * صف ارسال چت.
 *
 * مشکل قبلی: ارسال پیام (و جواب هوش مصنوعی) یک fetch خام بدون سقف زمانی، بدون تلاش مجدد و
 * بدون بررسی نتیجه بود. روی اینترنت کند یا قطع‌ووصل: (۱) اگه درخواست دیر می‌رسید، همگام‌سازی
 * بعدی لیست سرور (که هنوز پیام رو نداشت) جای لیست محلی رو می‌گرفت و پیام از صفحه‌ی خودِ فرستنده
 * می‌پرید؛ (۲) اگه درخواست شکست می‌خورد، پیام برای همیشه گم می‌شد و شریک هیچ‌وقت نمی‌دیدش.
 *
 * حالا هر نوشتن/حذف اول اینجا (و توی localStorage) ثبت می‌شه، با سقف زمانی و چند تلاش فرستاده
 * می‌شه، و تا وقتی به سرور نرسیده روی هر لیست دریافتی دوباره اعمال می‌شه.
 */

const KEY = 'chat_outbox_v1';
const MAX_ENTRIES = 200;

type Entry = { op: 'put'; msg: ChatMessage } | { op: 'del'; id: string };

function load(): Map<string, Entry> {
  try {
    const raw = JSON.parse(localStorage.getItem(KEY) || '[]');
    if (!Array.isArray(raw)) return new Map();
    const m = new Map<string, Entry>();
    for (const [id, e] of raw as [string, Entry][]) {
      if (typeof id === 'string' && e && (e.op === 'put' || e.op === 'del')) m.set(id, e);
    }
    return m;
  } catch {
    return new Map();
  }
}

let entries: Map<string, Entry> = load();
const listeners = new Set<() => void>();
let flushing = false;
let lastSuccessAt = 0;

function persist() {
  try {
    const arr = [...entries.entries()].slice(-MAX_ENTRIES);
    localStorage.setItem(KEY, JSON.stringify(arr));
  } catch { /* حافظه پر/خصوصی */ }
  listeners.forEach(fn => fn());
}

export function subscribeOutbox(fn: () => void): () => void {
  listeners.add(fn);
  return () => { listeners.delete(fn); };
}

export const hasPending = () => entries.size > 0;
/** زمان آخرین ارسال موفق؛ دریافتِ شروع‌شده قبل از اون، قدیمیه و باید دور ریخته بشه. */
export const getLastSuccessAt = () => lastSuccessAt;

/** شناسه‌ی پیام‌هایی که هنوز به سرور نرسیدن (برای نشون‌دادن ساعت به‌جای تیک). */
export function pendingPutIds(): Set<string> {
  const s = new Set<string>();
  for (const [id, e] of entries) if (e.op === 'put') s.add(id);
  return s;
}

export function queuePut(msg: ChatMessage) {
  entries.delete(msg.id);
  entries.set(msg.id, { op: 'put', msg });
  persist();
}

export function queueDelete(id: string) {
  entries.delete(id);
  entries.set(id, { op: 'del', id });
  persist();
}

export function clearOutbox() {
  entries = new Map();
  persist();
}

/** نوشتن‌ها/حذف‌های ارسال‌نشده رو روی لیستِ دریافتی از سرور اعمال می‌کنه. */
export function applyPending(list: ChatMessage[]): ChatMessage[] {
  if (entries.size === 0) return list;
  const deleted = new Set<string>();
  const added: ChatMessage[] = [];
  const have = new Set(list.map(m => m.id));
  for (const [id, e] of entries) {
    if (e.op === 'del') deleted.add(id);
    else if (!have.has(id)) added.push(e.msg);
  }
  const out = (deleted.size ? list.filter(m => !deleted.has(m.id)) : list.slice()).concat(
    added.filter(m => !deleted.has(m.id))
  );
  return added.length ? out.sort((a, b) => (a.createdAt || 0) - (b.createdAt || 0)) : out;
}

const sleep = (ms: number) => new Promise<void>(r => setTimeout(r, ms));

export type FlushResult = { sent: number; dropped: number };

/** صف رو به ترتیب می‌فرسته. همزمان فقط یک اجرا؛ اگه وسط کار چیزی اضافه شد، دوباره اجرا می‌شه. */
export async function flushOutbox(): Promise<FlushResult> {
  const result: FlushResult = { sent: 0, dropped: 0 };
  if (flushing || entries.size === 0) return result;
  flushing = true;
  // فقط کلیدهایی که «حین ارسال» اضافه شدن باعث اجرای دوباره می‌شن؛ اگه به‌خاطر آفلاین‌بودن وسط
  // کار ایستادیم، بقیه‌ی صف همچنان معطله و نباید بی‌نهایت دوباره امتحان بشه.
  const snapshot = new Set(entries.keys());
  let stoppedOffline = false;
  try {
    for (const [id, entry] of [...entries.entries()]) {
      const url = `${WORKER_URL}/loveniya_chat/${id}.json`;
      let status: 'ok' | 'drop' | 'retry' = 'retry';
      for (let attempt = 0; attempt < 3 && status === 'retry'; attempt++) {
        try {
          const res = await fetchT(url, entry.op === 'put'
            ? {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json', 'X-App-Secret': APP_SECRET },
                body: JSON.stringify(entry.msg)
              }
            : { method: 'DELETE', headers: { 'X-App-Secret': APP_SECRET } },
            15000);
          if (res.ok) status = 'ok';
          else if (res.status >= 400 && res.status < 500 && res.status !== 429) status = 'drop';
        } catch { /* شبکه / سقف زمانی */ }
        if (status === 'retry' && attempt < 2) await sleep(800 * (attempt + 1));
      }
      if (status === 'retry') { stoppedOffline = true; break; } // ترتیب حفظ می‌شه و بعداً ادامه می‌دیم
      // اگه حین ارسال همین پیام عوض شده (مثلاً حذف شده)، اون نسخه‌ی تازه رو دست نزن
      if (entries.get(id) === entry) entries.delete(id);
      if (status === 'ok') { result.sent++; lastSuccessAt = Date.now(); } else result.dropped++;
      persist();
    }
  } finally {
    flushing = false;
  }
  if (result.sent > 0) void bumpRev('loveniya_chat'); // به دستگاه مقابل خبر بده
  if (!stoppedOffline && [...entries.keys()].some(k => !snapshot.has(k))) {
    const more = await flushOutbox();
    result.sent += more.sent;
    result.dropped += more.dropped;
  }
  return result;
}
