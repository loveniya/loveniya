import { APP_SECRET } from './appSecret';

export const AI_WORKER_URL = "https://purple-cloud-1df2.am-b-asdfghjkl20112011.workers.dev";

// ورکر هوش مصنوعی هر درخواست POST را احراز هویت می‌کند (هدر X-App-Secret، همان رمزِ ورکر داده‌ها)؛
// قبلاً این هدر اصلاً فرستاده نمی‌شد، پس در عمل هر درخواست ۴۰۱ می‌گرفت.
const AI_HEADERS = { 'Content-Type': 'application/json', 'X-App-Secret': APP_SECRET };

export type AiDiagnosis = {
  ok: boolean;
  stage: 'offline' | 'blocked' | 'origin' | 'auth' | 'server' | 'ok';
  message: string;
};

/**
 * وقتی fetch با TypeError شکست می‌خوره (که برای «اینترنت قطعه»، «دامنه فیلتره» و «CORS رد شده» یکسانه)،
 * با یک پروب بدون‌CORS علت واقعی را جدا می‌کنیم تا به کاربر نگیم «اینترنتت رو چک کن» وقتی اینترنت وصله.
 */
export async function diagnoseAiConnection(): Promise<AiDiagnosis> {
  if (typeof navigator !== 'undefined' && navigator.onLine === false) {
    return { ok: false, stage: 'offline', message: 'گوشی به اینترنت وصل نیست.' };
  }
  try {
    const res = await fetchWithTimeout(`${AI_WORKER_URL}/`, { method: 'GET', cache: 'no-store' }, 10000);
    if (!res.ok) {
      return { ok: false, stage: 'server', message: `سرور هوش مصنوعی پاسخ ${res.status} داد.` };
    }
  } catch {
    // GET ساده شکست خورد: یا CORS رد شده یا اصلاً به سرور نمی‌رسیم
    try {
      await fetchWithTimeout(`${AI_WORKER_URL}/`, { method: 'GET', mode: 'no-cors', cache: 'no-store' }, 10000);
      return {
        ok: false,
        stage: 'origin',
        message: `به ورکر هوش مصنوعی می‌رسیم ولی ورکر درخواست‌های این سایت را رد می‌کند. این آدرس را عیناً در متغیر ALLOWED_ORIGIN ورکر purple-cloud بگذار: ${typeof location !== 'undefined' ? location.origin : ''}`
      };
    } catch {
      return {
        ok: false,
        stage: 'blocked',
        message: 'اینترنت وصله ولی به آدرس ورکر هوش مصنوعی نمی‌رسیم؛ احتمالاً روی این اینترنت مسدود یا بسیار کند است (VPN را امتحان کن).'
      };
    }
  }
  try {
    const res = await fetchWithTimeout(`${AI_WORKER_URL}/chat`, {
      method: 'POST',
      headers: AI_HEADERS,
      body: JSON.stringify({ type: 'fix_spelling', userMessage: 'سلام' })
    }, 20000);
    if (res.status === 401 || res.status === 403) {
      return { ok: false, stage: 'auth', message: 'ورکر هوش مصنوعی رمز برنامه را نپذیرفت؛ APP_SECRET ورکر purple-cloud باید با رمز برنامه یکی باشد.' };
    }
    if (!res.ok) return { ok: false, stage: 'server', message: `ورکر هوش مصنوعی خطای ${res.status} داد.` };
  } catch {
    return { ok: false, stage: 'blocked', message: 'درخواست آزمایشی به ورکر هوش مصنوعی ارسال نشد.' };
  }
  return { ok: true, stage: 'ok', message: 'اتصال به هوش مصنوعی سالم است.' };
}

async function networkFailureMessage(): Promise<string> {
  const d = await diagnoseAiConnection();
  if (d.stage === 'ok') return 'ارتباط با هوش مصنوعی لحظه‌ای قطع شد؛ دوباره امتحان کن.';
  return d.message;
}

// هر درخواست یک سقف زمانی دارد؛ بدون این، اگر ورکر گیر کند، چت برای همیشه در حالت
// «درحال پردازش» می‌ماند و جعبه‌ی تایپ قفل می‌شد.
const REQUEST_TIMEOUT_MS = 25000;
const STREAM_IDLE_TIMEOUT_MS = 20000;
// وقتی استریم جواب نداد، درخواست معمولیِ پشتیبان سقف کوتاه‌تری دارد: قبلاً بدترین حالت
// (۲۰ ثانیه استریم + ۳ تلاش ۲۵ثانیه‌ای) بیش از ۱۰۰ ثانیه چت را روی «در حال نوشتن» نگه می‌داشت.
const STREAM_FALLBACK = { retries: 2, timeoutMs: 18000 };

async function fetchWithTimeout(url: string, options: RequestInit, timeoutMs: number): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...options, signal: controller.signal });
  } catch (err: any) {
    if (err?.name === 'AbortError') throw new Error('پاسخ هوش مصنوعی خیلی طول کشید؛ دوباره امتحان کن.');
    throw err;
  } finally {
    clearTimeout(timer);
  }
}

// فقط خطاهای گذرا (شبکه، ۵xx و ۴۲۹) دوباره تلاش می‌شن؛ خطای ۴xx با تکرار درست نمی‌شه.
async function fetchWithRetry(url: string, options: RequestInit, retries = 3, backoff = 1000, timeoutMs = REQUEST_TIMEOUT_MS): Promise<Response> {
  let lastRes: Response | null = null;
  for (let i = 0; i < retries; i++) {
    try {
      const res = await fetchWithTimeout(url, options, timeoutMs);
      if (res.ok) return res;
      lastRes = res;
      if (res.status < 500 && res.status !== 429) return res;
    } catch (err: any) {
      if (typeof err?.message === 'string' && err.message.includes('خیلی طول کشید')) throw err;
      // network error → retry
    }
    if (i < retries - 1) {
      await new Promise(resolve => setTimeout(resolve, backoff * Math.pow(2, i)));
    }
  }
  if (lastRes) return lastRes;
  // دلیلِ واقعی را می‌گوییم، نه اینکه همیشه اینترنت کاربر را مقصر بدانیم
  throw new Error(await networkFailureMessage());
}

/**
 * Extracts AI text from various response structures of Cloudflare Workers AI
 */
function extractAIResponseText(data: any): string | null {
  if (!data) return null;
  
  if (typeof data === 'string') {
    const trimmed = data.trim();
    if (trimmed === 'SKIP') return 'SKIP';
    return trimmed.length > 0 ? trimmed : 'SKIP';
  }
  
  if (typeof data.response === 'string') {
    if (data.response.trim() === 'SKIP') return 'SKIP';
    return data.response.trim() || 'SKIP';
  }

  if (data.result !== undefined) {
    if (typeof data.result === 'string') {
      if (data.result.trim() === 'SKIP') return 'SKIP';
      return data.result.trim() || 'SKIP';
    }
    if (typeof data.result.response === 'string') {
      if (data.result.response.trim() === 'SKIP') return 'SKIP';
      return data.result.response.trim() || 'SKIP';
    }
    if (typeof data.result.text === 'string') {
      if (data.result.text.trim() === 'SKIP') return 'SKIP';
      return data.result.text.trim() || 'SKIP';
    }
    if (typeof data.result.reply === 'string') {
      if (data.result.reply.trim() === 'SKIP') return 'SKIP';
      return data.result.reply.trim() || 'SKIP';
    }
  }

  if (typeof data.reply === 'string') {
    if (data.reply.trim() === 'SKIP') return 'SKIP';
    return data.reply.trim() || 'SKIP';
  }
  if (typeof data.text === 'string') {
    if (data.text.trim() === 'SKIP') return 'SKIP';
    return data.text.trim() || 'SKIP';
  }
  if (typeof data.message === 'string') {
    if (data.message.trim() === 'SKIP') return 'SKIP';
    return data.message.trim() || 'SKIP';
  }
  if (Array.isArray(data.choices) && data.choices[0]?.message) {
    let raw = data.choices[0].message.content || data.choices[0].message.reasoning_content || data.choices[0].message.reasoning;
    if (typeof raw === 'string') {
        const content = raw.trim();
        if (content === 'SKIP') return 'SKIP';
        return content;
    }
  }

  return null;
}

/**
 * Universal Cloudflare AI Caller:
 * 1. Direct Cloudflare Worker AI with exact exact payload
 * 2. Backend Server proxy (/api/loveai)
 * 3. Heartfelt contextual Persian response generator
 */
export async function fetchLoveAI(payload: {
  type?: string;
  message?: string;
  prompt?: string;
  userMessage?: string;
  history?: string;
  contextData?: any;
}, opts: { retries?: number; timeoutMs?: number } = {}) {
  const textPrompt = payload.message || payload.prompt || payload.userMessage || '';
  const promptType = payload.type || 'chat';

  const exactPayload = {
    type: promptType,
    userMessage: textPrompt,
    contextData: payload.contextData || {},
    history: payload.history || ''
  };

  // Strategy 1: Direct Cloudflare AI Worker
  try {
    const res = await fetchWithRetry(`${AI_WORKER_URL}/chat`, {
      method: 'POST',
      headers: AI_HEADERS,
      body: JSON.stringify(exactPayload)
    }, opts.retries ?? 3, 1000, opts.timeoutMs ?? REQUEST_TIMEOUT_MS);

    if (res.ok) {
      const rawText = await res.text();
      try {
        const parsed = JSON.parse(rawText);
        const result = extractAIResponseText(parsed);
        if (result !== null) return result;
        throw new Error(`پاسخ خالی یا نامعتبر: ${rawText.substring(0, 100)}`);
      } catch (e: any) {
        if (e.message.startsWith('پاسخ خالی')) throw e;
        const result = extractAIResponseText(rawText);
        if (result !== null) return result;
        throw new Error(`متن نامشخص: ${rawText.substring(0, 100)}`);
      }
    } else {
      // پیام خطا همیشه فارسی و قابل‌فهمه؛ قبلاً اگه ورکر به‌جای JSON یک صفحه‌ی HTML برمی‌گردوند،
      // خطای انگلیسیِ «Unexpected token <» مستقیم به کاربر نشون داده می‌شد.
      let serverMsg = '';
      try {
        const errJson = JSON.parse(await res.text());
        serverMsg = String(errJson?.message || errJson?.error || '');
      } catch { /* بدنه JSON نبود */ }
      if (/[\u0600-\u06FF]/.test(serverMsg)) throw new Error(serverMsg);
      if (res.status === 401 || res.status === 403) throw new Error('هوش مصنوعی رمز یا دامنه‌ی برنامه را نپذیرفت (ورکر purple-cloud).');
      if (res.status === 429) throw new Error('درخواست‌های هوش مصنوعی زیاد بود؛ کمی بعد دوباره امتحان کن.');
      if (res.status >= 500) throw new Error('سرور هوش مصنوعی الان در دسترس نیست؛ کمی بعد دوباره امتحان کن.');
      throw new Error(`خطای ${res.status} در ارتباط با هوش مصنوعی`);
    }
  } catch (err: any) {
    throw err; // Let the UI handle network/HTTP errors via Toast
  }

  // Fallback shouldn't be reached unless fetch fails completely, 
  // but if we are here, we just throw error to let UI know
  throw new Error('عدم دریافت پاسخ معتبر از سرور');
}

// فقط متن «پاسخ» برداشته می‌شه. بخش reasoning/تفکر مدل قبلاً به متن پیام اضافه می‌شد و
// افکار داخلی مدل داخل چت نمایش داده می‌شد.
function extractStreamChunk(data: any): string {
  const delta = data?.choices?.[0]?.delta;
  if (typeof delta?.content === 'string') return delta.content;
  if (delta) return '';
  if (typeof data?.result === 'string') return data.result;
  if (typeof data?.text === 'string') return data.text;
  if (typeof data?.response === 'string') return data.response;
  return '';
}

export async function streamLoveAI(
  payload: {
    type?: string;
    message?: string;
    prompt?: string;
    userMessage?: string;
    history?: string;
    contextData?: any;
  },
  onChunk: (text: string) => void
): Promise<string> {
  const textPrompt = payload.message || payload.prompt || payload.userMessage || '';
  const promptType = payload.type || 'chat';

  const exactPayload = {
    type: promptType,
    userMessage: textPrompt,
    contextData: payload.contextData || {},
    history: payload.history || ''
  };

  const controller = new AbortController();
  let idleTimer: ReturnType<typeof setTimeout> | undefined;
  const armIdle = () => {
    if (idleTimer) clearTimeout(idleTimer);
    idleTimer = setTimeout(() => controller.abort(), STREAM_IDLE_TIMEOUT_MS);
  };

  let fullText = '';
  const handleLine = (rawLine: string) => {
    const line = rawLine.trim();
    if (!line) return;
    const payloadStr = line.startsWith('data:') ? line.slice(5).trim() : line;
    if (!payloadStr || payloadStr === '[DONE]' || payloadStr === 'SKIP') return;
    try {
      const chunk = extractStreamChunk(JSON.parse(payloadStr));
      if (chunk && chunk !== 'SKIP') {
        fullText += chunk;
        onChunk(fullText);
      }
    } catch {
      // خط غیر JSON: فقط وقتی متن ساده باشد (نه تکه‌ای از JSON) به پاسخ اضافه می‌شود
      if (!payloadStr.startsWith('{') && !payloadStr.startsWith('}') && !payloadStr.startsWith('[')) {
        fullText += payloadStr;
        onChunk(fullText);
      }
    }
  };

  try {
    armIdle();
    const res = await fetch(`${AI_WORKER_URL}/chat-stream`, {
      method: 'POST',
      headers: AI_HEADERS,
      body: JSON.stringify(exactPayload),
      signal: controller.signal
    });

    if (res.ok && res.body) {
      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        armIdle();
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';
        lines.forEach(handleLine);
      }
      buffer += decoder.decode();
      if (buffer.trim()) handleLine(buffer);

      const finalText = fullText.trim();
      if (finalText === 'SKIP') return 'SKIP';
      if (finalText) return fullText;
      // استریم چیزی (جز تفکر مدل) نداد؛ یک‌بار با درخواست معمولی امتحان می‌کنیم
      return await fetchLoveAI(payload, STREAM_FALLBACK);
    }
    return await fetchLoveAI(payload, STREAM_FALLBACK);
  } catch (err) {
    console.error("Stream failed, falling back to /chat", err);
    // اگه قبل از قطع‌شدن متن قابل‌قبولی رسیده بود، همون رو نگه می‌داریم (درخواست دوم هزینه و تأخیر داره)
    if (fullText.trim().length > 20) return fullText;
    return await fetchLoveAI(payload, STREAM_FALLBACK);
  } finally {
    if (idleTimer) clearTimeout(idleTimer);
  }
}


// ---------------------------------------------------------------------------
// واکنش لوینیا به محتوای تازه (ورکر مسیر /event را برای همین ساخته: خاطره، عهد، آرزو، آهنگ، کپسول).
// قبلاً هیچ‌جای برنامه این مسیر را صدا نمی‌زد، پس لوینیا هیچ‌وقت به محتوای تازه واکنش نشان نمی‌داد.
// ---------------------------------------------------------------------------

export type AiContentEvent =
  | 'memory_added'
  | 'pledge_added'
  | 'dream_added'
  | 'music_added'
  | 'capsule_added';

// حجم‌دارها حذف می‌شن؛ ورکر اصلاً نیازی به عکس/ویدیو ندارد و بدنه‌اش سقف ۳۸۴ کیلوبایت دارد.
const EVENT_DROP_KEYS = new Set(['photos', 'photo', 'mediadata', 'videodata', 'vidurl', 'url', 'audio', 'image', 'images', 'base64']);
// متن کپسول محرمانه‌ست تا روز بازشدن؛ به AI داده نمی‌شه که چیزی لو نره.
const EVENT_SECRET_KEYS: Partial<Record<AiContentEvent, string[]>> = { capsule_added: ['text', 'content', 'message'] };

function slimEventData(event: AiContentEvent, data: Record<string, unknown>): Record<string, unknown> {
  const secret = new Set((EVENT_SECRET_KEYS[event] || []).map(k => k.toLowerCase()));
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(data || {})) {
    const key = k.toLowerCase();
    if (EVENT_DROP_KEYS.has(key) || secret.has(key)) continue;
    if (typeof v === 'string') out[k] = v.length > 600 ? v.slice(0, 600) + '…' : v;
    else if (typeof v === 'number' || typeof v === 'boolean') out[k] = v;
  }
  return out;
}

let lastAiEventAt = 0;
const AI_EVENT_MIN_GAP_MS = 20000;

/** بی‌صدا و بدون تلاش مجدد: واکنش AI یک «اضافه»ست و نباید هیچ‌وقت کار اصلی (ذخیره) را مختل کند. */
export function notifyAiEvent(event: AiContentEvent, data: Record<string, unknown>): void {
  const now = Date.now();
  if (now - lastAiEventAt < AI_EVENT_MIN_GAP_MS) return;
  if (typeof navigator !== 'undefined' && navigator.onLine === false) return;
  lastAiEventAt = now;
  void fetchWithTimeout(`${AI_WORKER_URL}/event`, {
    method: 'POST',
    headers: AI_HEADERS,
    body: JSON.stringify({ eventType: event, data: slimEventData(event, data) })
  }, 30000).catch(() => { /* مهم نیست */ });
}
