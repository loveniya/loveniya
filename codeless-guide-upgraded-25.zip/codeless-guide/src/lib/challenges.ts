import type { ChallengeKind, ChallengeTone } from './gameAi';

// منطق خالص (بدون React و شبکه) بخش «دونفره»: شکل داده، وضعیت چالش‌ها و تشخیص رویدادهای
// تازه برای اعلان‌ها. هم صفحه‌ی Moments و هم اعلان‌های سراسری هدر از همین‌جا می‌خونن.

export type { ChallengeKind, ChallengeTone };
export type Who = 'amin' | 'niyayesh';

export const MOMENTS_PATH = 'loveniya_moments_v3';

export type Challenge = {
  id: string;
  kind: ChallengeKind;
  tone: ChallengeTone;
  text: string;
  createdBy: Who;
  // truth/dare: طرف مقابلِ کسی که ساختتش، یعنی همیشه یک نفر مشخص باید جواب بده/انجام بده.
  // deep: تعریف‌نشده، چون هر دو نفر باید جدا جواب بدن.
  targetUser?: Who;
  answers: { amin?: string; niyayesh?: string };
  doneAt?: number;   // فقط برای dare: لحظه‌ی «انجام دادم»
  nudgedAt?: number; // آخرین «یادآوری» (برای کسی که جواب نداده)
  createdAt: number;
};

export const KIND_LABEL: Record<ChallengeKind, string> = {
  truth: 'حقیقت',
  dare: 'جرأت',
  deep: 'سوال عمیق'
};

export const otherOf = (w: Who): Who => (w === 'amin' ? 'niyayesh' : 'amin');
export const nameOf = (w: Who): string => (w === 'amin' ? 'امین' : 'نیایش');

export function currentUserKey(): Who {
  return localStorage.getItem('loveniya_user') === 'niyayesh' ? 'niyayesh' : 'amin';
}

export function isDone(c: Challenge): boolean {
  if (c.kind === 'dare') return !!c.doneAt;
  if (c.kind === 'truth') return !!(c.targetUser && c.answers[c.targetUser]);
  return !!(c.answers.amin && c.answers.niyayesh); // deep
}

/** این چالش الان منتظر اقدام «من»ـه؟ */
export function needsMe(c: Challenge, me: Who): boolean {
  if (isDone(c)) return false;
  if (c.kind === 'deep') return !c.answers[me];
  return c.targetUser === me;
}

const NUDGE_MIN_AGE_MS = 60 * 60 * 1000;      // حداقل یک ساعت از ساخته‌شدن
const NUDGE_COOLDOWN_MS = 6 * 60 * 60 * 1000; // بین دو یادآوری حداقل ۶ ساعت

/** آیا می‌شه به طرف مقابل برای این چالش یادآوری فرستاد؟ */
export function canNudge(c: Challenge, me: Who, now = Date.now()): boolean {
  if (isDone(c) || needsMe(c, me)) return false;
  if (now - c.createdAt < NUDGE_MIN_AGE_MS) return false;
  return now - (c.nudgedAt || 0) >= NUDGE_COOLDOWN_MS;
}

export function sanitizeChallenge(id: string, raw: any): Challenge | null {
  if (!raw || typeof raw !== 'object' || typeof raw.text !== 'string' || !raw.text.trim()) return null;
  const kind: ChallengeKind = raw.kind === 'dare' || raw.kind === 'deep' ? raw.kind : 'truth';
  const rawAnswers = raw.answers && typeof raw.answers === 'object' ? raw.answers : {};
  const answers: Challenge['answers'] = {};
  if (typeof rawAnswers.amin === 'string' && rawAnswers.amin.trim()) answers.amin = rawAnswers.amin;
  if (typeof rawAnswers.niyayesh === 'string' && rawAnswers.niyayesh.trim()) answers.niyayesh = rawAnswers.niyayesh;
  return {
    id,
    kind,
    tone: raw.tone === 'flirty' || raw.tone === 'deep' ? raw.tone : 'light',
    text: raw.text,
    createdBy: raw.createdBy === 'niyayesh' ? 'niyayesh' : 'amin',
    targetUser: raw.targetUser === 'amin' || raw.targetUser === 'niyayesh' ? raw.targetUser : undefined,
    answers,
    doneAt: typeof raw.doneAt === 'number' ? raw.doneAt : undefined,
    nudgedAt: typeof raw.nudgedAt === 'number' ? raw.nudgedAt : undefined,
    createdAt: typeof raw.createdAt === 'number' ? raw.createdAt : 0
  };
}

export function sanitizeList(raw: unknown): Challenge[] {
  if (!raw || typeof raw !== 'object') return [];
  const entries: [string, unknown][] = Array.isArray(raw)
    ? raw.map((v, i) => [String((v as any)?.id ?? i), v] as [string, unknown])
    : Object.entries(raw as Record<string, unknown>);
  return entries
    .map(([id, v]) => sanitizeChallenge(id, v))
    .filter((c): c is Challenge => !!c)
    .sort((a, b) => b.createdAt - a.createdAt);
}

/**
 * نوشتن‌هایی که هنوز به سرور نرسیدن (صف ارسال) روی نسخه‌ی سرور اعمال می‌شن.
 * کلیدها مسیر نسبی زیر MOMENTS_PATH هستن:
 *   challenges/<id>                 ← خود چالش (ساخت)
 *   challenges/<id>/answers/<who>   ← جواب
 *   challenges/<id>/doneAt | nudgedAt
 */
export function applyOutbox(base: Challenge[], outbox: Record<string, unknown>): Challenge[] {
  const out = base.slice();
  for (const [p, body] of Object.entries(outbox)) {
    const parts = p.split('/');
    if (parts[0] !== 'challenges' || !parts[1]) continue;
    const id = parts[1];
    const i = out.findIndex(c => c.id === id);
    if (parts.length === 2) {
      if (i < 0) {
        const c = sanitizeChallenge(id, body);
        if (c) out.push(c);
      }
      continue;
    }
    if (i < 0) continue;
    if (parts[2] === 'answers' && (parts[3] === 'amin' || parts[3] === 'niyayesh') && typeof body === 'string') {
      out[i] = { ...out[i], answers: { ...out[i].answers, [parts[3]]: body } };
    } else if (parts[2] === 'doneAt' && typeof body === 'number') {
      out[i] = { ...out[i], doneAt: body };
    } else if (parts[2] === 'nudgedAt' && typeof body === 'number') {
      out[i] = { ...out[i], nudgedAt: body };
    }
  }
  return out.sort((a, b) => b.createdAt - a.createdAt);
}

export type GameEvent =
  | { type: 'incoming'; c: Challenge }  // چالش تازه از طرف مقابل که منتظر منه
  | { type: 'finished'; c: Challenge }  // طرف مقابل جواب داد/انجام داد و نتیجه آماده‌ست
  | { type: 'nudge'; c: Challenge };    // طرف مقابل یادآوری فرستاد

/** تفاوت دو نسخه‌ی پشت‌سرهم رو به رویدادهایی تبدیل می‌کنه که برای من قابل‌اطلاعن. */
export function detectEvents(prev: Challenge[], next: Challenge[], me: Who): GameEvent[] {
  const prevMap = new Map(prev.map(c => [c.id, c]));
  const events: GameEvent[] = [];
  for (const c of next) {
    const p = prevMap.get(c.id);
    if (!p) {
      if (c.createdBy !== me && needsMe(c, me)) events.push({ type: 'incoming', c });
      continue;
    }
    if (!isDone(p) && isDone(c)) {
      // truth/dare رو فقط وقتی من ساخته‌م طرف مقابل کامل می‌کنه؛ deep وقتی من قبلاً جواب داده بودم
      const byPartner = c.kind === 'deep' ? !!p.answers[me] : c.createdBy === me;
      if (byPartner) events.push({ type: 'finished', c });
      continue;
    }
    if ((c.nudgedAt || 0) > (p.nudgedAt || 0) && needsMe(c, me)) events.push({ type: 'nudge', c });
  }
  return events;
}

/** نتیجه‌هایی که برای من «خونده‌نشده»ـن: چالشِ تمام‌شده‌ای که من ساختم یا از نوع deep. */
export function unseenResults(list: Challenge[], me: Who, seen: ReadonlySet<string>): string[] {
  return list
    .filter(c => isDone(c) && (c.createdBy === me || c.kind === 'deep') && !seen.has(c.id))
    .map(c => c.id);
}

export function toFa(n: number): string {
  return n.toLocaleString('fa-IR');
}

/** «۲ ساعت پیش» — متن ساده‌ی نسبی، بدون کادر جدا (مطابق سلیقه‌ی طراحی). */
export function timeAgoFa(ts: number, now = Date.now()): string {
  if (!ts) return '';
  const diff = Math.max(0, now - ts);
  const min = Math.floor(diff / 60000);
  if (min < 1) return 'همین الان';
  if (min < 60) return `${toFa(min)} دقیقه پیش`;
  const hr = Math.floor(min / 60);
  if (hr < 24) return `${toFa(hr)} ساعت پیش`;
  const day = Math.floor(hr / 24);
  if (day < 30) return `${toFa(day)} روز پیش`;
  return `${toFa(Math.floor(day / 30))} ماه پیش`;
}
