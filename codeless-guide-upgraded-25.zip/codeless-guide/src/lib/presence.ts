import { useEffect, useCallback } from 'react';
import { APP_SECRET } from './appSecret';
import { fetchT, fetchGetAuth } from './net';

const WORKER_URL = "https://niya.am-b-asdfghjkl20112011.workers.dev";

export interface PresenceData {
  user: 'amin' | 'niyayesh';
  lastSeen: number;
  lastVisit: number;
  isOnline: boolean;
  isTyping?: boolean;
  page?: string;
  updatedAt?: number;
}

// وضعیت «در حال نوشتن» فقط اینجا نگه داشته می‌شه تا ضربان عمومیِ ۱۵ ثانیه‌ای
// (که فقط آنلاین‌بودن رو خبر می‌ده) وضعیت تایپِ صفحه‌ی چت رو با false بازنویسی نکنه.
let localTyping = false;
export const setLocalTyping = (v: boolean) => { localTyping = v; };

// «در حال نوشتن» فقط وقتی معتبره که تازه باشه؛ اگه کسی وسط نوشتن سایت رو بسته
// باشه، این مقدار توی دیتابیس می‌مونه و بدون این بررسی برای همیشه نمایش داده می‌شد.
export const TYPING_FRESH_MS = 12000;
export function isPresenceTyping(p: PresenceData | null | undefined): boolean {
  if (!p || !p.isTyping) return false;
  const stamp = p.updatedAt || p.lastSeen || 0;
  return Date.now() - stamp < TYPING_FRESH_MS;
}

/**
 * Updates the user's presence / last visit timestamp on Cloudflare
 */
type PresenceOptions = { isTyping?: boolean; isOnline?: boolean; page?: string; keepalive?: boolean };

// روی اینترنت کند هر درخواست چند ثانیه طول می‌کشه ولی ضربان‌ها هر ۵ و ۱۵ ثانیه می‌رسن؛ بدون این
// قفل، درخواست‌های حضور روی هم انباشته می‌شدن و پهنای باند و اتصال رو از پیام‌های چت می‌گرفتن.
// تا وقتی یکی در جریانه، فقط «آخرین» درخواست نگه داشته و بعدش فرستاده می‌شه.
let presenceInFlight = false;
let presenceQueued: { user?: 'amin' | 'niyayesh'; options?: PresenceOptions } | null = null;

export async function updateUserPresence(
  user?: 'amin' | 'niyayesh',
  options?: PresenceOptions
): Promise<void> {
  // keepalive (بستن تب) نباید معطل بمونه
  if (presenceInFlight && !options?.keepalive) {
    presenceQueued = { user, options };
    return;
  }
  presenceInFlight = true;
  try {
    const activeUser = user || (localStorage.getItem('loveniya_user') as 'amin' | 'niyayesh') || 'amin';
    const now = Date.now();
    
    const payload: PresenceData = {
      user: activeUser,
      lastSeen: now,
      lastVisit: now,
      isOnline: options?.isOnline !== false,
      isTyping: Boolean(options?.isTyping ?? localTyping),
      page: options?.page || (typeof window !== 'undefined' ? window.location.pathname : '/'),
      updatedAt: now
    };

    if (typeof localStorage !== 'undefined') {
      try {
        localStorage.setItem(`loveniya_presence_${activeUser}`, JSON.stringify(payload));
      } catch (e) {
        // ignore storage quota
      }
    }

    await fetchT(`${WORKER_URL}/loveniya_presence_${activeUser}.json`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', 'X-App-Secret': APP_SECRET },
      body: JSON.stringify(payload),
      // موقع بستن تب، درخواست معمولی لغو می‌شه؛ keepalive اجازه می‌ده تا تحویل ادامه پیدا کنه
      keepalive: Boolean(options?.keepalive)
    });
  } catch (e) {
    // Offline or network error handled gracefully
  } finally {
    presenceInFlight = false;
    if (presenceQueued) {
      const next = presenceQueued;
      presenceQueued = null;
      void updateUserPresence(next.user, next.options);
    }
  }
}

/**
 * Fetches the partner's latest presence data from Cloudflare
 */
const partnerInFlight: Record<string, Promise<PresenceData | null> | undefined> = {};

export function fetchPartnerPresenceData(partnerId: 'amin' | 'niyayesh'): Promise<PresenceData | null> {
  // خواندنِ در جریان با درخواست جدید یکی می‌شه (به‌جای انباشته‌شدن چند درخواست روی شبکه‌ی کند)
  const existing = partnerInFlight[partnerId];
  if (existing) return existing;
  const p = loadPartnerPresence(partnerId).finally(() => { partnerInFlight[partnerId] = undefined; });
  partnerInFlight[partnerId] = p;
  return p;
}

async function loadPartnerPresence(partnerId: 'amin' | 'niyayesh'): Promise<PresenceData | null> {
  try {
    const res = await fetchGetAuth(`${WORKER_URL}/loveniya_presence_${partnerId}.json?_t=${Date.now()}`, 8000);
    if (res.ok) {
      const data = await res.json();
      if (data && typeof data === 'object') {
        return {
          user: partnerId,
          lastSeen: Number(data.lastSeen || data.lastVisit || data.updatedAt) || 0,
          lastVisit: Number(data.lastVisit || data.lastSeen || data.updatedAt) || 0,
          isOnline: Boolean(data.isOnline),
          isTyping: Boolean(data.isTyping),
          page: data.page,
          updatedAt: Number(data.updatedAt || data.lastSeen) || 0
        };
      }
    }
  } catch (e) {
    // ignore
  }

  // Fallback to local cache if present
  if (typeof localStorage !== 'undefined') {
    try {
      const saved = localStorage.getItem(`loveniya_presence_${partnerId}`);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {}
  }

  return null;
}

/**
 * Formats the last seen / online timestamp strictly in Iran Standard Time (Asia/Tehran)
 */
export function formatIranLastSeen(
  presence: PresenceData | null | undefined,
  currentTypingState?: boolean
): string {
  if (!presence) {
    return 'آفلاین (اطلاعاتی ثبت نشده)';
  }

  if (currentTypingState || isPresenceTyping(presence)) {
    return 'در حال نوشتن...';
  }

  const timestamp = presence.lastSeen || presence.lastVisit || presence.updatedAt;
  if (!timestamp || isNaN(timestamp) || timestamp <= 0) {
    return 'آفلاین';
  }

  const now = Date.now();
  const diffMs = Math.max(0, now - timestamp);

  // If active within 35 seconds, consider online
  if (diffMs < 35000) {
    return 'آنلاین';
  }

  // Within 90 seconds
  if (diffMs < 90000) {
    return 'آخرین بازدید چند لحظه پیش';
  }

  const targetDate = new Date(timestamp);
  const nowDate = new Date(now);

  // Iran timezone date strings (YYYY-MM-DD format in Asia/Tehran)
  const tehranNow = nowDate.toLocaleDateString('en-CA', { timeZone: 'Asia/Tehran' });
  const tehranTarget = targetDate.toLocaleDateString('en-CA', { timeZone: 'Asia/Tehran' });

  // Exact time in Iran (24-hour Persian numerals, e.g. "۱۶:۱۱")
  const iranTimeStr = targetDate.toLocaleTimeString('fa-IR', {
    timeZone: 'Asia/Tehran',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false
  });

  // Visited today
  if (tehranNow === tehranTarget) {
    return `آخرین بازدید امروز ساعت ${iranTimeStr}`;
  }

  // Check yesterday in Iran
  const yesterday = new Date(now - 24 * 60 * 60 * 1000);
  const tehranYesterday = yesterday.toLocaleDateString('en-CA', { timeZone: 'Asia/Tehran' });

  if (tehranTarget === tehranYesterday) {
    return `آخرین بازدید دیروز ساعت ${iranTimeStr}`;
  }

  // Persian month and day in Iran timezone
  const iranDateStr = targetDate.toLocaleDateString('fa-IR', {
    timeZone: 'Asia/Tehran',
    month: 'long',
    day: 'numeric'
  });

  return `آخرین بازدید ${iranDateStr} ساعت ${iranTimeStr}`;
}

/**
 * Global React hook to automatically track presence whenever the user opens, browses, or returns to the site
 */
export function useGlobalPresenceTracker() {
  const syncPresence = useCallback((online = true, leaving = false) => {
    const user = (localStorage.getItem('loveniya_user') as 'amin' | 'niyayesh') || 'amin';
    if (leaving) setLocalTyping(false);
    updateUserPresence(user, {
      isOnline: online,
      ...(leaving ? { isTyping: false, keepalive: true } : {})
    });
  }, []);

  useEffect(() => {
    // Initial visit track
    syncPresence(true);

    // Heartbeat every 15 seconds to keep "Online" status fresh while browsing
    const interval = setInterval(() => {
      if (typeof document !== 'undefined' && document.visibilityState === 'visible') {
        syncPresence(true);
      }
    }, 15000);

    const handleVisibility = () => {
      if (document.visibilityState === 'visible') {
        syncPresence(true);
      } else {
        syncPresence(false, true);
      }
    };

    const handleFocus = () => syncPresence(true);
    const handleLeave = () => {
      // Record exit timestamp (pagehide روی موبایل قابل‌اعتمادتر از beforeunload ـه)
      syncPresence(false, true);
    };

    document.addEventListener('visibilitychange', handleVisibility);
    window.addEventListener('focus', handleFocus);
    window.addEventListener('beforeunload', handleLeave);
    window.addEventListener('pagehide', handleLeave);

    return () => {
      clearInterval(interval);
      document.removeEventListener('visibilitychange', handleVisibility);
      window.removeEventListener('focus', handleFocus);
      window.removeEventListener('beforeunload', handleLeave);
      window.removeEventListener('pagehide', handleLeave);
    };
  }, [syncPresence]);
}
