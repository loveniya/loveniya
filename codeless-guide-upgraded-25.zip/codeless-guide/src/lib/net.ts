import { APP_SECRET } from './appSecret';

/**
 * fetch با سقف زمانی. بدون این، اگه یک درخواست روی شبکه‌ی ضعیف بی‌پاسخ می‌موند، چرخه‌ی
 * همگام‌سازی (که منتظر همون درخواست بود) برای همیشه می‌ایستاد: چت روی «در حال همگام‌سازی»
 * می‌موند و پیام‌ها دیگه به‌روز نمی‌شدن تا کاربر صفحه رو رفرش کنه.
 */
export async function fetchT(url: string, init: RequestInit = {}, timeoutMs = 10000): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...init, signal: controller.signal });
  } catch (err: any) {
    if (err?.name === 'AbortError') throw new Error('زمان پاسخ‌دهی سرور تمام شد');
    throw err;
  } finally {
    clearTimeout(timer);
  }
}

/**
 * GET احراز هویت‌شده «بدون preflight».
 *
 * هدر سفارشی X-App-Secret باعث می‌شد مرورگر قبل از هر GET یک درخواست OPTIONS جدا بفرسته
 * (دو رفت‌وبرگشت به‌جای یکی). اینجا رمز به‌صورت پارامتر k در آدرس فرستاده می‌شه و درخواست
 * «ساده» حساب می‌شه و preflight نداره. اگه ورکر هنوز نسخه‌ی قدیمی بود (۴۰۱ داد)، یک‌بار با
 * هدر دوباره تلاش می‌کنه و تا آخر نشست همون روش رو ادامه می‌ده؛ پس ترتیب انتشار ورکر و سایت مهم نیست.
 */
let queryAuthSupported = true;

export async function fetchGetAuth(url: string, timeoutMs = 10000): Promise<Response> {
  if (queryAuthSupported) {
    const withKey = `${url}${url.includes('?') ? '&' : '?'}k=${encodeURIComponent(APP_SECRET)}`;
    const res = await fetchT(withKey, { cache: 'no-store' }, timeoutMs);
    if (res.status !== 401) return res;
    queryAuthSupported = false;
  }
  return fetchT(url, { cache: 'no-store', headers: { 'X-App-Secret': APP_SECRET } }, timeoutMs);
}
