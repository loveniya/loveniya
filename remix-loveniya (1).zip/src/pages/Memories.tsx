import React, { useState, useRef } from 'react';
import { Camera, Plus, Star, Trash2, Edit3, Image as ImageIcon, X, Heart } from 'lucide-react';
import { useStore } from '../lib/store';
import { Memory } from '../lib/types';
import { KebabMenu, KebabMenuItem } from '../components/KebabMenu';
import { motion, AnimatePresence } from 'motion/react';
import ReactPlayer from 'react-player';

export const Memories: React.FC = () => {
  const { memories, addMemory, updateMemory, removeMemory } = useStore();
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [activeMemory, setActiveMemory] = useState<Memory | null>(null);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [title, setTitle] = useState('');
  const [desc, setDesc] = useState('');
  const [vidUrl, setVidUrl] = useState('');
  const [photos, setPhotos] = useState<string[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const handleEdit = (mem: Memory) => {
    setEditingId(mem.id);
    setTitle(mem.title);
    setDesc(mem.desc);
    setVidUrl(mem.vidUrl || '');
    setPhotos(mem.photos || []);
    setShowForm(true);
  };

  const resizeImage = (file: File): Promise<string> => {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          let width = img.width;
          let height = img.height;
          const MAX_SIZE = 800;

          if (width > height) {
            if (width > MAX_SIZE) {
              height *= MAX_SIZE / width;
              width = MAX_SIZE;
            }
          } else {
            if (height > MAX_SIZE) {
              width *= MAX_SIZE / height;
              height = MAX_SIZE;
            }
          }

          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          ctx?.drawImage(img, 0, 0, width, height);
          resolve(canvas.toDataURL('image/jpeg', 0.7));
        };
        img.src = e.target?.result as string;
      };
      reader.readAsDataURL(file);
    });
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const newPhotos = [];
      for (let i = 0; i < e.target.files.length; i++) {
        const base64 = await resizeImage(e.target.files[i]);
        newPhotos.push(base64);
      }
      setPhotos(prev => [...prev, ...newPhotos]);
    }
  };

  const removePhoto = (index: number) => {
    setPhotos(photos.filter((_, i) => i !== index));
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingId) {
      const existing = memories.find(m => m.id === editingId);
      if (existing) {
        updateMemory({
          ...existing,
          title,
          desc,
          vidUrl,
          photos
        });
      }
    } else {
      const newMemory: Memory = {
        id: Date.now().toString(),
        title,
        desc,
        vidUrl,
        photos,
        date: new Date().toLocaleDateString('fa-IR'),
        pinned: false
      };
      addMemory(newMemory);
    }
    resetForm();
  };

  const resetForm = () => {
    setTitle('');
    setDesc('');
    setVidUrl('');
    setPhotos([]);
    setEditingId(null);
    setShowForm(false);
  };

  const [showCount, setShowCount] = useState(4);

  // Sort memories: pinned ones first
  const sortedMemories = [...memories].sort((a, b) => {
    if (a.pinned && !b.pinned) return -1;
    if (!a.pinned && b.pinned) return 1;
    return 0;
  });

  const displayedMemories = sortedMemories.slice(0, showCount);
  const hasMore = showCount < sortedMemories.length;
  const hasLess = showCount > 4;

  return (
    <>
      <AnimatePresence mode="wait">
      {activeMemory ? (
        <motion.div 
          key="detail"
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: -20 }}
          transition={{ type: "spring", stiffness: 300, damping: 30 }}
          className="space-y-6 pb-6 w-full" dir="rtl"
        >
          <div className="glass-card rounded-3xl p-6 md:p-10 relative overflow-hidden shadow-2xl bg-white/95">
            <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-rose-400 via-pink-400 to-sky-400"></div>
            
            <div className="flex justify-between items-start mb-8 border-b border-rose-100 pb-6">
              <div>
                <h2 className="text-2xl md:text-3xl font-black text-rose-600 flex items-center gap-2 mb-2">
                  <Camera className="w-7 h-7 fill-rose-500/20 text-rose-500" /> {activeMemory.title}
                </h2>
                <p className="text-xs md:text-sm text-slate-500 font-bold flex items-center gap-1">
                   ثبت شده در: {activeMemory.date}
                   {activeMemory.pinned && (
                     <span className="inline-flex items-center gap-1 bg-amber-100 text-amber-600 px-2 py-0.5 rounded-full mr-3 text-[10px]">
                       <Star className="w-3 h-3 fill-amber-500" /> خاطره برتر
                     </span>
                   )}
                </p>
              </div>
              <button onClick={() => setActiveMemory(null)} className="text-slate-400 hover:text-rose-500 bg-slate-50 p-2 rounded-full transition-colors shrink-0">
                <X className="w-5 h-5" />
              </button>
            </div>

            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="whitespace-pre-wrap text-sm md:text-base font-medium text-slate-700 leading-loose mb-10"
            >
              {activeMemory.desc}
            </motion.div>

            {activeMemory.photos && activeMemory.photos.length > 0 && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.4 }}
                className="space-y-3 mt-8"
              >
                <h3 className="text-sm font-black text-slate-800 flex items-center gap-2 mb-4">
                  <ImageIcon className="w-4 h-4 text-rose-400" /> گالری این خاطره
                </h3>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                  {activeMemory.photos.map((photo, idx) => (
                    <div key={idx} onClick={() => setSelectedImage(photo)} className="aspect-square rounded-2xl overflow-hidden border-2 border-white shadow-lg group cursor-pointer relative">
                      <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors z-10"></div>
                      <img src={photo} alt="" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300" />
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {activeMemory.vidUrl && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.5 }}
                className="mt-8 pt-6 border-t border-slate-100 space-y-4"
              >
                <h3 className="text-sm font-black text-slate-800 flex items-center gap-2 mb-4">
                  ویدیو پیوست شده
                </h3>
                <div className="rounded-2xl overflow-hidden border-2 border-white shadow-lg bg-slate-100 aspect-video relative flex items-center justify-center">
                  <ReactPlayer 
                    src={activeMemory.vidUrl} 
                    controls={true} 
                    width="100%" 
                    height="100%" 
                    className="absolute top-0 left-0"
                    fallback={<div className="text-slate-500 text-xs font-bold">درحال بارگذاری ویدیو...</div>}
                  />
                </div>
                <a href={activeMemory.vidUrl} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 text-sm font-bold bg-sky-50 text-sky-600 px-5 py-2.5 rounded-full hover:bg-sky-100 transition-colors shadow-sm">
                  لینک اصلی ویدیو
                </a>
              </motion.div>
            )}
          </div>
        </motion.div>
      ) : (
        <motion.div 
          key="list"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          transition={{ type: "spring", stiffness: 300, damping: 30 }}
          className="space-y-6 w-full" dir="rtl"
        >
          <div className="glass-card rounded-3xl p-6 md:p-8 relative">
        <div className="absolute inset-0 overflow-hidden rounded-3xl pointer-events-none">
          <div className="absolute top-0 right-0 w-64 h-64 bg-rose-300/20 rounded-full blur-3xl mix-blend-multiply"></div>
          <div className="absolute bottom-0 left-0 w-64 h-64 bg-sky-300/20 rounded-full blur-3xl mix-blend-multiply"></div>
        </div>

        <div className="flex flex-wrap justify-between items-center gap-3 mb-6 relative z-10">
          <div>
            <h2 className="text-2xl font-black text-slate-800 flex items-center gap-2">
              <Camera className="w-6 h-6 text-rose-500" /> قاب خاطرات
            </h2>
            <p className="text-xs text-slate-500 font-medium mt-1">ثبت عکس‌ها، ویدیوها و لحظات رویایی ما</p>
          </div>
          <button 
            onClick={() => {
              if (showForm) {
                resetForm();
              } else {
                setShowForm(true);
              }
            }} 
            className="bg-gradient-to-r from-rose-500 to-pink-500 text-white hover:opacity-90 px-5 py-2.5 rounded-full text-xs font-bold transition-all flex items-center gap-1.5 shadow-lg shadow-rose-200 active:scale-95"
          >
            <Plus className="w-4 h-4" /> {showForm ? 'بستن فرم' : 'ثبت خاطره جدید'}
          </button>
        </div>

        <AnimatePresence>
          {showForm && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="mb-8 relative z-10"
            >
              <div className="bg-white/90 backdrop-blur-md rounded-2xl p-6 border border-rose-200 shadow-xl">
                <form onSubmit={handleSave} className="space-y-5">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1.5">عنوان خاطره:</label>
                    <input type="text" placeholder="مثلا: اولین غروب آفتاب کنار دریا..." required value={title} onChange={e => setTitle(e.target.value)}
                           className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-xs focus:border-rose-400 focus:ring-2 focus:ring-rose-100 focus:outline-none font-bold text-slate-800 transition-all" />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1.5">عکس‌های خاطره:</label>
                    <div className="flex flex-wrap gap-3">
                      {photos.map((photo, i) => (
                        <div key={i} className="relative w-20 h-20 rounded-xl overflow-hidden shadow-sm group">
                          <img src={photo} alt="" className="w-full h-full object-cover" />
                          <button 
                            type="button" 
                            onClick={() => removePhoto(i)}
                            className="absolute top-1 right-1 bg-white/80 p-1 rounded-full text-rose-500 opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        </div>
                      ))}
                      <button 
                        type="button"
                        onClick={() => fileInputRef.current?.click()}
                        className="w-20 h-20 rounded-xl border-2 border-dashed border-slate-300 flex flex-col items-center justify-center text-slate-400 hover:text-rose-500 hover:border-rose-400 transition-colors bg-slate-50"
                      >
                        <ImageIcon className="w-6 h-6 mb-1" />
                        <span className="text-[9px] font-bold">افزودن</span>
                      </button>
                      <input 
                        type="file" 
                        ref={fileInputRef} 
                        onChange={handleFileChange} 
                        multiple 
                        accept="image/*" 
                        className="hidden" 
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1.5">لینک ویدیو/فایل خارجی (اختیاری):</label>
                    <input type="url" placeholder="https://..." value={vidUrl} onChange={e => setVidUrl(e.target.value)}
                           className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-xs focus:border-rose-400 focus:ring-2 focus:ring-rose-100 focus:outline-none transition-all" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1.5">شرح احساسی خاطره:</label>
                    <textarea rows={4} placeholder="احساسات اون لحظه‌ت رو بنویس..." required value={desc} onChange={e => setDesc(e.target.value)}
                              className="w-full bg-slate-50 border border-slate-200 rounded-xl p-4 text-xs focus:border-rose-400 focus:ring-2 focus:ring-rose-100 focus:outline-none leading-relaxed transition-all"></textarea>
                  </div>
                  <div className="flex justify-end gap-3 pt-2">
                    <button type="button" onClick={resetForm} className="bg-slate-200 text-slate-700 text-xs px-6 py-2.5 rounded-full font-bold hover:bg-slate-300 transition-colors">انصراف</button>
                    <button type="submit" className="bg-gradient-to-r from-rose-500 to-pink-500 text-white text-xs font-bold px-8 py-2.5 rounded-full hover:shadow-lg shadow-rose-200 transition-all">
                      {editingId ? 'ذخیره تغییرات' : 'ثبت خاطره'}
                    </button>
                  </div>
                </form>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="space-y-4 relative z-10">
          {sortedMemories.length === 0 ? (
            <div className="text-center text-slate-500/60 text-xs py-16 flex flex-col items-center gap-3">
              <Camera className="w-12 h-12 opacity-40" />
              <span className="font-semibold">هنوز خاطره‌ای ثبت نشده...</span>
            </div>
          ) : (
            displayedMemories.map(mem => (
              <motion.div layout key={mem.id} onClick={() => setActiveMemory(mem)} className={`cursor-pointer bg-white/90 backdrop-blur-sm p-5 rounded-3xl border transition-all relative group ${mem.pinned ? 'border-amber-300 shadow-[0_0_20px_rgba(252,211,77,0.3)] ring-1 ring-amber-300/50' : 'border-rose-100 shadow-sm hover:shadow-md'}`}>
                {mem.pinned && (
                  <div className="absolute -top-3 -right-3 bg-gradient-to-br from-amber-400 to-orange-500 text-white text-[10px] font-black px-3 py-1 rounded-full shadow-lg flex items-center gap-1 z-20 border-2 border-white">
                    <Star className="w-3 h-3 fill-white" /> انتخاب برتر
                  </div>
                )}
                
                <div className="flex justify-between items-start mb-3">
                  <h3 className="font-black text-slate-800 text-base flex items-center gap-2">
                    {mem.title}
                  </h3>
                  <div className="flex gap-2 relative z-20" onClick={e => e.stopPropagation()}>
                    <KebabMenu>
                      <KebabMenuItem 
                        icon={<Star className="w-4 h-4" />} 
                        label={mem.pinned ? 'برداشتن نشان برتر' : 'نشان کردن به عنوان برتر'} 
                        onClick={() => updateMemory({ ...mem, pinned: !mem.pinned })} 
                      />
                      <KebabMenuItem 
                        icon={<Edit3 className="w-4 h-4" />} 
                        label="ویرایش" 
                        onClick={() => handleEdit(mem)} 
                      />
                      <KebabMenuItem 
                        icon={<Trash2 className="w-4 h-4" />} 
                        label="حذف" 
                        danger 
                        onClick={() => removeMemory(mem.id)} 
                      />
                    </KebabMenu>
                  </div>
                </div>
                
                <p className="text-sm text-slate-600 mb-4 whitespace-pre-wrap leading-loose">{mem.desc}</p>
                
                {mem.photos && mem.photos.length > 0 && (
                  <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 mb-4">
                    {mem.photos.map((photo, idx) => (
                      <div key={idx} className="aspect-square rounded-2xl overflow-hidden border border-rose-100/50 shadow-sm">
                        <img src={photo} alt="" className="w-full h-full object-cover hover:scale-105 transition-transform duration-300" />
                      </div>
                    ))}
                  </div>
                )}

                <div className="flex justify-between items-center mt-2 border-t border-slate-100 pt-3">
                  <div className="text-[10px] font-bold text-slate-400 bg-slate-50 px-3 py-1 rounded-full">{mem.date}</div>
                  {mem.vidUrl && (
                    <a href={mem.vidUrl} target="_blank" rel="noreferrer" onClick={(e) => e.stopPropagation()} className="text-[10px] font-bold bg-sky-50 text-sky-600 px-3 py-1 rounded-full hover:bg-sky-100 transition-colors">
                      مشاهده لینک پیوست
                    </a>
                  )}
                </div>
              </motion.div>
            ))
          )}
        </div>

        {sortedMemories.length > 4 && (
          <div className="flex justify-center gap-3 mt-8 relative z-10">
            {hasMore && (
              <button onClick={() => setShowCount(c => c + 4)} className="bg-white/80 backdrop-blur-sm border border-rose-100 hover:bg-rose-50 text-rose-500 transition-colors px-6 py-2.5 rounded-full font-bold text-xs flex items-center gap-2 shadow-sm active:scale-95">
                <Heart className="w-4 h-4 fill-rose-500" />
                نمایش بیشتر ({sortedMemories.length - showCount})
              </button>
            )}
            {hasLess && (
              <button onClick={() => setShowCount(4)} className="bg-white/80 backdrop-blur-sm border border-slate-100 hover:bg-slate-50 text-slate-500 transition-colors px-6 py-2.5 rounded-full font-bold text-xs flex items-center gap-2 shadow-sm active:scale-95">
                نمایش کمتر
              </button>
            )}
          </div>
        )}

      </div>
        </motion.div>
      )}
    </AnimatePresence>
      
      <AnimatePresence>
        {selectedImage && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/90 backdrop-blur-sm p-4"
            onClick={() => setSelectedImage(null)}
          >
            <button 
              className="absolute top-6 right-6 text-white/70 hover:text-white bg-black/20 hover:bg-black/40 p-3 rounded-full transition-colors z-[110]"
              onClick={(e) => {
                e.stopPropagation();
                setSelectedImage(null);
              }}
            >
              <X className="w-6 h-6" />
            </button>
            <motion.img 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ type: "spring", stiffness: 300, damping: 30 }}
              src={selectedImage} 
              alt="بزرگنمایی" 
              className="max-w-full max-h-full object-contain rounded-xl shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};
