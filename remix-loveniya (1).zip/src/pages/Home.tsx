import React, { useState, useEffect } from 'react';
import { Sparkles, Star, Heart, ArrowLeft, RefreshCw } from 'lucide-react';
import { useStore } from '../lib/store';
import { NavLink } from 'react-router';

export const Home: React.FC = () => {
  const { memories } = useStore();
  
  // Timer state
  const startDate = new Date(2026, 4, 10, 0, 0, 0); // 20 Ordibehesht 1405

  const calculateTime = () => {
    const now = new Date();
    if (now < startDate) return { years: 0, months: 0, days: 0, hours: 0, minutes: 0, seconds: 0 };
    
    let y = now.getFullYear() - startDate.getFullYear();
    let mo = now.getMonth() - startDate.getMonth();
    let d = now.getDate() - startDate.getDate();
    let h = now.getHours() - startDate.getHours();
    let mi = now.getMinutes() - startDate.getMinutes();
    let s = now.getSeconds() - startDate.getSeconds();

    if (s < 0) { s += 60; mi--; }
    if (mi < 0) { mi += 60; h--; }
    if (h < 0) { h += 24; d--; }
    if (d < 0) {
      const prevMonthDays = new Date(now.getFullYear(), now.getMonth(), 0).getDate();
      d += prevMonthDays;
      mo--;
    }
    if (mo < 0) { mo += 12; y--; }

    return { years: y, months: mo, days: d, hours: h, minutes: mi, seconds: s };
  };

  const [time, setTime] = useState(calculateTime());
  const [today, setToday] = useState(new Date());

  useEffect(() => {
    const interval = setInterval(() => {
      setTime(calculateTime());
      setToday(new Date());
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const todayMidnight = new Date(today.getFullYear(), today.getMonth(), today.getDate());
  
  let nextYear = today.getFullYear();
  let nextMonthIdx = today.getMonth();
  let maxDaysInMonth = new Date(nextYear, nextMonthIdx + 1, 0).getDate();
  let targetDate = Math.min(startDate.getDate(), maxDaysInMonth);
  
  let nextMonth = new Date(nextYear, nextMonthIdx, targetDate);

  if (todayMidnight.getTime() > nextMonth.getTime()) {
    nextMonthIdx += 1;
    if (nextMonthIdx > 11) {
      nextMonthIdx = 0;
      nextYear += 1;
    }
    maxDaysInMonth = new Date(nextYear, nextMonthIdx + 1, 0).getDate();
    targetDate = Math.min(startDate.getDate(), maxDaysInMonth);
    nextMonth = new Date(nextYear, nextMonthIdx, targetDate);
  }

  const daysUntilNext = Math.round((nextMonth.getTime() - todayMidnight.getTime()) / (1000 * 3600 * 24));

  // Spotlight
  const topMemories = memories.filter(m => m.pinned);
  const randomTopMemory = topMemories.length > 0 
    ? topMemories[Math.floor(Math.random() * topMemories.length)]
    : memories.length > 0 ? memories[Math.floor(Math.random() * memories.length)] : null;

  // Reason Generator
  const reasons = [
    "چون با یه لبخندت کل روزم ساخته میشه.",
    "چون امن‌ترین پناهگاه دنیا بغل توئه.",
    "چون هر روز بیشتر از دیروز دلم برات ضعف میره.",
    "چون وقتی صدام می‌کنی، قشنگ‌ترین اسم دنیا رو دارم.",
    "چون تو تنها کسی هستی که دیوونه‌بازیامو درک میکنی.",
    "چون خنده‌هات قشنگ‌ترین موسیقی دنیاست.",
    "چون با تو، ساده‌ترین لحظه‌ها هم رویاییه.",
    "چون تو دقیقاً همونی هستی که همیشه آرزوشو داشتم."
  ];
  const [reason, setReason] = useState("دکمه رو بزن تا یه دلیل قشنگ ببینی... 💕");

  const showReason = () => {
    let newReason = reason;
    while (newReason === reason) {
      newReason = reasons[Math.floor(Math.random() * reasons.length)];
    }
    setReason(newReason);
  };

  return (
    <div className="space-y-10">
      {/* Hero Header */}
      <section className="text-center space-y-3 pt-2">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/60 border border-white/80 text-rose-500 text-xs font-black shadow-sm">
          <Sparkles className="w-3.5 h-3.5" /> تقدیم به فرشته‌ی زندگی من
        </div>
        <h1 className="text-3xl md:text-5xl font-black text-slate-800 leading-tight tracking-tight">
          تقدیم به <span className="bg-gradient-to-r from-rose-500 via-pink-500 to-purple-500 bg-clip-text text-transparent drop-shadow-sm">نیایش</span><br/>
          بهانه‌ی تمام عاشقانه‌هایم
        </h1>
        <p className="text-xs md:text-sm text-slate-500 max-w-md mx-auto font-medium">
          جهان مشترک امین و نیایش؛ جایی برای ماندگار کردن تمام لحظه‌ها، خنده‌ها و خاطرات شیرین‌مان.
        </p>
      </section>

      {/* Memory Spotlight */}
      {randomTopMemory && (
        <section className="glass-card rounded-3xl p-6 text-center relative overflow-hidden">
          <div className="absolute -right-10 -top-10 w-28 h-28 bg-rose-300/20 rounded-full blur-xl"></div>
          <h2 className="text-xs uppercase tracking-widest text-rose-500 font-black mb-2 flex items-center justify-center gap-2">
            <Star className="w-4 h-4 text-amber-400 fill-amber-400" /> امروز یادم افتاد از...
          </h2>
          <p className="text-lg font-black text-slate-800 mb-1">{randomTopMemory.title}</p>
          <p className="text-xs text-slate-500 mb-4 font-bold">{randomTopMemory.date}</p>
          <NavLink to="/memories" className="bg-gradient-to-r from-rose-400 to-pink-400 text-white hover:opacity-90 px-5 py-2.5 rounded-full text-xs font-bold transition-all inline-flex items-center gap-2 shadow-sm active:scale-95">
            <span>دوباره مرورش کن</span>
            <ArrowLeft className="w-3.5 h-3.5" />
          </NavLink>
        </section>
      )}

      {/* Love Counter / Timer */}
      <section className="glass-card rounded-3xl p-6 md:p-10 text-center relative overflow-hidden">
        <div className="absolute -left-12 -bottom-12 w-36 h-36 bg-sky-200/30 rounded-full blur-2xl"></div>
        <h2 className="text-xs uppercase tracking-widest text-rose-500 font-black mb-6 flex items-center justify-center gap-2">
          <Heart className="w-4 h-4 fill-rose-500 text-rose-500" /> تپش‌های قلبم از ۲۰ اردیبهشت ۱۴۰۵ <Heart className="w-4 h-4 fill-rose-500 text-rose-500" />
        </h2>
        <div className="flex flex-wrap justify-center gap-3 md:gap-6 dir-rtl" style={{ direction: 'rtl' }}>
          {[
            { label: 'ثانیه', value: time.seconds },
            { label: 'دقیقه', value: time.minutes },
            { label: 'ساعت', value: time.hours },
            { label: 'روز', value: time.days },
            { label: 'ماه', value: time.months },
            { label: 'سال', value: time.years }
          ].map((unit, i) => (
            <div key={i} className="text-center flex-1 min-w-[55px] bg-white/50 rounded-2xl p-3 border border-white/60">
              <span className="block text-2xl md:text-3xl font-black text-slate-700 mb-0.5">
                {unit.value.toString().padStart(2, '0')}
              </span>
              <span className="text-[10px] font-bold text-slate-500">{unit.label}</span>
            </div>
          ))}
        </div>
        <div className="mt-5 text-center">
          <p className="text-xs font-black text-rose-500/90 drop-shadow-sm">
            {daysUntilNext === 0 
              ? 'امروز ماهگردمونه! ✨' 
              : `${daysUntilNext} روز تا ماهگرد بعدی...`}
          </p>
        </div>
      </section>

      {/* Reason Generator */}
      <section className="glass-card rounded-3xl p-6 md:p-8 text-center relative overflow-hidden">
        <h2 className="text-base font-black text-slate-800 mb-1 flex items-center gap-2 justify-center">
          <Sparkles className="w-5 h-5 text-rose-500" /> چرا عاشقتم نیایش؟
        </h2>
        <p className="text-[11px] text-slate-500 font-medium mb-4">هر کلیک یه دلیل واقعی از ته قلب امین...</p>

        <div className="bg-white/70 rounded-2xl p-6 border border-white/80 my-4 shadow-inner">
          <p className="text-sm md:text-base text-rose-600 font-black min-h-[50px] flex items-center justify-center leading-relaxed">
            {reason}
          </p>
        </div>

        <button onClick={showReason} className="bg-gradient-to-r from-rose-500 to-pink-500 text-white text-xs font-bold px-7 py-3 rounded-full hover:opacity-95 shadow-md inline-flex items-center gap-2 active:scale-95 transition-all">
          <RefreshCw className="w-4 h-4" />
          <span>یه دلیل دیگه بگو</span>
        </button>
      </section>
    </div>
  );
};

