import React, { useState, useEffect } from 'react';
import { Mail, Plus, Lock, Unlock, Clock, Star, Trash2, Edit3, Heart, Sparkles, X } from 'lucide-react';
import { useStore } from '../lib/store';
import { Capsule } from '../lib/types';
import { KebabMenu, KebabMenuItem } from '../components/KebabMenu';
import { motion, AnimatePresence } from 'motion/react';

export const Letters: React.FC = () => {
  const { capsules, addCapsule, updateCapsule, removeCapsule } = useStore();
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  
  const [title, setTitle] = useState('');
  const [text, setText] = useState('');
  const [openDate, setOpenDate] = useState('');
  const [sender, setSender] = useState('');
  const [recipient, setRecipient] = useState('');
  const [confirmSave, setConfirmSave] = useState(false);

  const [activeLetter, setActiveLetter] = useState<Capsule | null>(null);

  // Force re-render to update locks and 30s timers
  const [, setTick] = useState(0);
  useEffect(() => {
    const timer = setInterval(() => setTick(t => t + 1), 1000);
    return () => clearInterval(timer);
  }, []);

  const resetForm = () => {
    setTitle('');
    setText('');
    setOpenDate('');
    setSender('');
    setRecipient('');
    setEditingId(null);
    setShowForm(false);
    setConfirmSave(false);
  };

  const handleEdit = (c: Capsule) => {
    setEditingId(c.id);
    setTitle(c.title);
    setText(c.text);
    setOpenDate(c.openDate);
    setSender(c.sender || '');
    setRecipient(c.recipient || '');
    setShowForm(true);
    setConfirmSave(false);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!confirmSave) {
      setConfirmSave(true);
      return;
    }
    if (editingId) {
      const existing = capsules.find(c => c.id === editingId);
      if (existing) {
        updateCapsule({
          ...existing,
          title,
          text,
          openDate,
          sender,
          recipient,
          createdAt: Date.now()
        });
      }
    } else {
      addCapsule({
        id: Date.now().toString(),
        title,
        text,
        openDate,
        sender,
        recipient,
        isOpened: false,
        pinned: false,
        createdAt: Date.now()
      });
    }
    resetForm();
  };

  const checkLocked = (dateStr: string) => {
    if (!dateStr) return false;
    return new Date(dateStr) > new Date();
  };

  const calculateTimeLeft = (dateStr: string) => {
    if (!dateStr) return '';
    const diff = new Date(dateStr).getTime() - new Date().getTime();
    if (diff <= 0) return 'همین الان قابل خوندنه!';
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
    if (days > 0) return `${days} روز و ${hours} ساعت دیگه`;
    return `${hours} ساعت دیگه باز میشه`;
  };

  const openLetter = (letter: Capsule) => {
    if (checkLocked(letter.openDate)) return;
    if (!letter.isOpened) {
      updateCapsule({ ...letter, isOpened: true });
    }
    setActiveLetter(letter);
  };

  const [showCount, setShowCount] = useState(4);

  const sortedCapsules = [...capsules].sort((a, b) => {
    if (a.pinned && !b.pinned) return -1;
    if (!a.pinned && b.pinned) return 1;
    return 0;
  });

  const displayedCapsules = sortedCapsules.slice(0, showCount);
  const hasMore = showCount < sortedCapsules.length;
  const hasLess = showCount > 4;

  if (activeLetter) {
    return (
      <div className="space-y-6" dir="rtl">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ type: "spring", stiffness: 300, damping: 30 }}
          className="glass-card rounded-3xl p-6 md:p-10 envelope-bg relative overflow-hidden shadow-2xl"
        >
          <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-rose-400 via-pink-400 to-sky-400"></div>
          
          <div className="flex justify-between items-start mb-8 border-b border-rose-200/50 pb-6">
            <div>
              <h2 className="text-2xl font-black text-rose-600 flex items-center gap-2 mb-2">
                <Heart className="w-6 h-6 fill-rose-500" /> {activeLetter.title}
              </h2>
              <p className="text-xs text-rose-400 font-bold flex items-center gap-1">
                <Clock className="w-3.5 h-3.5" /> تاریخ بازگشایی: {new Date(activeLetter.openDate).toLocaleDateString('fa-IR')}
              </p>
            </div>
            <button onClick={() => setActiveLetter(null)} className="text-slate-400 hover:text-rose-500 bg-white/50 p-2 rounded-full transition-colors">
              <X className="w-5 h-5" />
            </button>
          </div>

          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="min-h-[300px] whitespace-pre-wrap text-sm md:text-base font-medium text-slate-700 leading-[2.5]"
          >
            {activeLetter.text}
          </motion.div>

          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8 }}
            className="mt-12 text-left text-rose-500 font-black text-lg flex flex-col items-end justify-end gap-2"
          >
            <div className="flex items-center gap-2">
              از طرف {activeLetter.sender || 'ناشناس'} <Sparkles className="w-5 h-5 text-rose-400" />
            </div>
            {activeLetter.recipient && (
              <div className="text-sm text-rose-400">
                تقدیم به: {activeLetter.recipient}
              </div>
            )}
          </motion.div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="space-y-6" dir="rtl">
      <div className="glass-card rounded-3xl p-6 md:p-8 relative">
        <div className="absolute inset-0 overflow-hidden rounded-3xl pointer-events-none">
          <div className="absolute -right-20 -top-20 w-48 h-48 bg-rose-200/40 rounded-full blur-3xl"></div>
          <div className="absolute -left-20 -bottom-20 w-48 h-48 bg-sky-200/40 rounded-full blur-3xl"></div>
        </div>

        <div className="flex flex-wrap justify-between items-center gap-3 mb-8 relative z-10">
          <div>
            <h2 className="text-xl font-black text-slate-800 flex items-center gap-2">
              <Mail className="w-5 h-5 text-rose-500" /> نامه‌های زمان‌دار
            </h2>
            <p className="text-[11px] text-slate-500 font-medium mt-1">نامه‌هایی که تو زمان مشخصی باز میشن...</p>
          </div>
          <button 
            onClick={() => {
              if (showForm) resetForm();
              else setShowForm(true);
            }} 
            className="bg-gradient-to-r from-rose-400 to-pink-400 text-white hover:opacity-90 px-4 py-2.5 rounded-full text-xs font-bold transition-all flex items-center gap-1.5 shadow-sm active:scale-95"
          >
            <Plus className="w-4 h-4" /> {showForm ? 'بستن فرم' : 'نوشتن نامه جدید'}
          </button>
        </div>

        <AnimatePresence>
          {showForm && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="mb-8 overflow-hidden relative z-10"
            >
              <div className="bg-white/80 rounded-2xl p-5 border border-rose-200 shadow-sm">
                <form onSubmit={handleSave} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">از طرف (فرستنده):</label>
                      <input type="text" placeholder="مثلا: امین" required value={sender} onChange={e => {setSender(e.target.value); setConfirmSave(false);}}
                             className="w-full bg-white/90 border border-slate-200 rounded-xl px-3 py-2.5 text-xs focus:border-rose-400 focus:outline-none" />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">برای (گیرنده):</label>
                      <input type="text" placeholder="مثلا: نیایش" required value={recipient} onChange={e => {setRecipient(e.target.value); setConfirmSave(false);}}
                             className="w-full bg-white/90 border border-slate-200 rounded-xl px-3 py-2.5 text-xs focus:border-rose-400 focus:outline-none" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">عنوان نامه:</label>
                    <input type="text" placeholder="مثلا: برای تولد سال بعدت..." required value={title} onChange={e => {setTitle(e.target.value); setConfirmSave(false);}}
                           className="w-full bg-white/90 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs focus:border-rose-400 focus:outline-none font-bold text-slate-800" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">تاریخ باز شدن نامه:</label>
                    <input type="datetime-local" required value={openDate} onChange={e => {setOpenDate(e.target.value); setConfirmSave(false);}}
                           className="w-full bg-white/90 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:border-rose-400 focus:outline-none font-sans" dir="ltr" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">متن کامل نامه:</label>
                    <textarea rows={6} placeholder="حرف‌های دلت رو بنویس..." required value={text} onChange={e => {setText(e.target.value); setConfirmSave(false);}}
                              className="w-full bg-white/90 border border-slate-200 rounded-xl p-4 text-xs focus:border-rose-400 focus:outline-none leading-[2]"></textarea>
                  </div>
                  <div className="flex justify-end gap-2 pt-2">
                    <button type="button" onClick={resetForm} className="bg-slate-200 text-slate-700 text-xs px-5 py-2.5 rounded-full font-bold hover:bg-slate-300 transition-colors">انصراف</button>
                    <button type="submit" className={`text-white text-xs font-bold px-7 py-2.5 rounded-full shadow-md transition-colors ${confirmSave ? 'bg-amber-500 hover:bg-amber-600' : 'bg-rose-500 hover:bg-rose-600'}`}>
                      {confirmSave ? 'مطمئنم، ذخیره کن (غیرقابل ویرایش)' : (editingId ? 'ذخیره تغییرات' : 'مُهر و موم کردن نامه')}
                    </button>
                  </div>
                </form>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 relative z-10">
          {sortedCapsules.length === 0 ? (
            <div className="col-span-full text-center py-16 text-slate-500/60 flex flex-col items-center gap-3">
              <Mail className="w-12 h-12 opacity-40" />
              <p className="text-xs font-semibold">هنوز نامه‌ای نوشته نشده...</p>
            </div>
          ) : (
            displayedCapsules.map(capsule => {
              const locked = checkLocked(capsule.openDate);
              const isEditable = (Date.now() - (capsule.createdAt || 0) <= 30000);
              const editTimeLeft = Math.max(0, Math.floor((30000 - (Date.now() - (capsule.createdAt || 0))) / 1000));
              
              return (
                <motion.div 
                  layout
                  key={capsule.id} 
                  className={`relative p-5 rounded-3xl border transition-all ${capsule.pinned ? 'shadow-[0_0_20px_rgba(252,211,77,0.3)] ring-1 ring-amber-300/50 ' : ''}${
                    locked 
                      ? 'bg-slate-50/90 border-slate-200' 
                      : capsule.isOpened
                        ? 'bg-white/90 border-rose-100 hover:border-rose-300 cursor-pointer shadow-sm hover:shadow-md'
                        : 'envelope-bg border-rose-300 cursor-pointer shadow-md unseal-glow'
                  } ${capsule.pinned && !locked ? 'border-amber-300' : ''}`}
                  onClick={() => !locked && openLetter(capsule)}
                >
                  {capsule.pinned && (
                    <div className="absolute -top-3 -right-3 bg-gradient-to-br from-amber-400 to-orange-500 text-white text-[10px] font-black px-3 py-1 rounded-full shadow-lg flex items-center gap-1 z-20 border-2 border-white">
                      <Star className="w-3 h-3 fill-white" /> نامه برتر
                    </div>
                  )}
                  <div className="flex justify-between items-start mb-3">
                    <div className="flex items-center gap-2">
                      <div className={`p-2 rounded-xl ${locked ? 'bg-slate-200 text-slate-400' : 'bg-rose-100 text-rose-500'}`}>
                        {locked ? <Lock className="w-4 h-4" /> : <Unlock className="w-4 h-4" />}
                      </div>
                      <div>
                        <h3 className="font-black text-slate-800 text-sm flex items-center gap-1">
                          {capsule.title}
                        </h3>
                        {!locked && !capsule.isOpened && (
                          <span className="text-[9px] font-black bg-rose-500 text-white px-2 py-0.5 rounded-full absolute -top-2 -right-2 animate-pulse">جدید!</span>
                        )}
                      </div>
                    </div>
                    
                    {/* Only prevent click propagation for Kebab Menu */}
                    <div onClick={e => e.stopPropagation()}>
                      <KebabMenu>
                        <KebabMenuItem 
                          icon={<Star className="w-4 h-4" />} 
                          label={capsule.pinned ? 'برداشتن نشان برتر' : 'نشان کردن به عنوان برتر'} 
                          onClick={() => updateCapsule({ ...capsule, pinned: !capsule.pinned })} 
                        />
                        {isEditable ? (
                          <KebabMenuItem 
                            icon={<Edit3 className="w-4 h-4" />} 
                            label="ویرایش" 
                            onClick={() => handleEdit(capsule)} 
                          />
                        ) : null}
                        {isEditable ? (
                          <KebabMenuItem 
                            icon={<Trash2 className="w-4 h-4" />} 
                            label="حذف" 
                            danger 
                            onClick={() => removeCapsule(capsule.id)} 
                          />
                        ) : null}
                      </KebabMenu>
                    </div>
                  </div>

                  <div className="mt-4 flex flex-col gap-2">
                    <div className="flex items-center gap-2 text-[11px] font-bold">
                      {locked ? (
                        <span className="text-slate-500 flex items-center gap-1.5 bg-slate-200/50 px-3 py-1.5 rounded-lg w-full">
                          <Clock className="w-3.5 h-3.5" /> قفل تا: {calculateTimeLeft(capsule.openDate)}
                        </span>
                      ) : (
                        <span className="text-rose-500 flex items-center gap-1.5 bg-rose-50 px-3 py-1.5 rounded-lg w-full">
                          <Mail className="w-3.5 h-3.5" /> 
                          {capsule.isOpened ? 'خوانده شده' : 'آماده‌ی خواندن - بازش کن!'}
                        </span>
                      )}
                    </div>
                    {editTimeLeft > 0 && (
                      <div className="text-[10px] text-amber-500 font-bold bg-amber-50 px-3 py-1.5 rounded-lg w-full">
                        زمان باقی‌مانده برای ویرایش: {editTimeLeft} ثانیه
                      </div>
                    )}
                  </div>
                </motion.div>
              );
            })
          )}
        </div>

        {sortedCapsules.length > 4 && (
          <div className="flex justify-center gap-3 mt-8 relative z-10">
            {hasMore && (
              <button onClick={() => setShowCount(c => c + 4)} className="bg-white/80 backdrop-blur-sm border border-rose-100 hover:bg-rose-50 text-rose-500 transition-colors px-6 py-2.5 rounded-full font-bold text-xs flex items-center gap-2 shadow-sm active:scale-95">
                <Heart className="w-4 h-4 fill-rose-500" />
                نمایش بیشتر ({sortedCapsules.length - showCount})
              </button>
            )}
            {hasLess && (
              <button onClick={() => setShowCount(4)} className="bg-white/80 backdrop-blur-sm border border-slate-100 hover:bg-slate-50 text-slate-500 transition-colors px-6 py-2.5 rounded-full font-bold text-xs flex items-center gap-2 shadow-sm active:scale-95">
                نمایش کمتر
              </button>
            )}
          </div>
        )}

      </div>
    </div>
  );
};
