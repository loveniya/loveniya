import React from 'react';
import { NavLink } from 'react-router';
import { Heart, Clock, Camera, HeartHandshake, Compass, Music, Mail, Settings, Wifi, WifiOff, AlertCircle } from 'lucide-react';
import clsx from 'clsx';
import { useStore } from '../lib/store';

export const Navigation: React.FC = () => {
  const { syncStatus, syncError } = useStore();

  return (
    <>
      {/* Top Header */}
      <nav className="fixed top-0 w-full bg-white/50 backdrop-blur-xl z-40 border-b border-white/60 shadow-sm">
        <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between gap-3">
          <NavLink to="/" className="flex items-center gap-2 cursor-pointer group">
            <div className="w-9 h-9 rounded-full bg-gradient-to-br from-rose-400 via-pink-400 to-rose-300 text-white flex items-center justify-center shadow-md relative">
              <div className="absolute inset-0 rounded-full bg-white/20 group-hover:bg-white/0 transition-colors duration-300"></div>
              <Heart className="w-5 h-5 fill-white text-white drop-shadow-sm group-hover:scale-110 transition-transform duration-500 ease-out" />
              {syncStatus === 'connected' && (
                <div className="absolute -bottom-1 -right-1 w-3.5 h-3.5 bg-green-500 rounded-full border-2 border-white shadow-sm" title="Connected"></div>
              )}
              {syncStatus === 'disconnected' && (
                <div className="absolute -bottom-1 -right-1 w-3.5 h-3.5 bg-slate-400 rounded-full border-2 border-white shadow-sm" title="Offline"></div>
              )}
              {syncStatus === 'error' && (
                <div className="absolute -bottom-1 -right-1 w-3.5 h-3.5 bg-red-500 rounded-full border-2 border-white shadow-sm animate-pulse" title="Sync Error"></div>
              )}
            </div>
            <span className="font-black text-lg tracking-tight bg-gradient-to-r from-rose-500 via-pink-500 to-purple-500 bg-clip-text text-transparent drop-shadow-sm group-hover:opacity-80 transition-opacity">
              Loveniya
            </span>
          </NavLink>

          <div className="flex items-center gap-4 text-xs font-bold text-slate-600">
            {syncStatus === 'error' && (
               <div className="hidden md:flex items-center gap-1.5 text-[10px] bg-red-50 text-red-600 px-2 py-1 rounded-full border border-red-100 font-bold">
                 <AlertCircle className="w-3.5 h-3.5" />
                 {syncError || 'Error syncing'}
               </div>
            )}
            <NavLink to="/settings" className={({ isActive }) => clsx("hover:text-rose-500 transition-colors flex items-center gap-1 p-2 rounded-full hover:bg-rose-50", isActive && "text-rose-500 bg-rose-50")}>
              <Settings className="w-5 h-5" />
            </NavLink>
          </div>
        </div>
      </nav>

      {syncStatus === 'error' && (
        <div className="fixed top-14 w-full z-40 bg-red-500 text-white text-xs font-bold text-center py-2 px-4 shadow-sm md:hidden">
          <AlertCircle className="w-4 h-4 inline-block mr-1" />
          {syncError || 'Error syncing'}
        </div>
      )}

      {/* Bottom Navigation for smaller screens and desktop consistency */}
      <nav className="fixed bottom-0 w-full bg-white/90 backdrop-blur-xl z-40 border-t border-rose-100 shadow-[0_-10px_40px_rgba(244,114,182,0.1)] pb-safe">
        <div className="max-w-md mx-auto px-2 py-2 flex items-center justify-between gap-1 overflow-x-auto custom-scroll">
          <NavItem to="/" icon={<Clock className="w-5 h-5" />} label="زمان" />
          <NavItem to="/memories" icon={<Camera className="w-5 h-5" />} label="خاطرات" />
          <NavItem to="/pledges" icon={<HeartHandshake className="w-5 h-5" />} label="عهدها" />
          <NavItem to="/dreams" icon={<Compass className="w-5 h-5" />} label="آرزوها" />
          <NavItem to="/music" icon={<Music className="w-5 h-5" />} label="موزیک" />
          <NavItem to="/letters" icon={<Mail className="w-5 h-5" />} label="نامه" />
        </div>
      </nav>
    </>
  );
};

const NavItem = ({ to, icon, label }: { to: string; icon: React.ReactNode; label: string }) => {
  return (
    <NavLink 
      to={to} 
      className={({ isActive }) => clsx(
        "flex flex-col items-center justify-center w-14 h-14 rounded-2xl transition-all flex-shrink-0",
        isActive ? "bg-rose-100 text-rose-600" : "text-slate-400 hover:text-rose-500 hover:bg-rose-50"
      )}
    >
      {icon}
      <span className="text-[10px] font-bold mt-1">{label}</span>
    </NavLink>
  );
};
