import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { Memory, Pledge, Dream, Music, Capsule, TrashItem, SyncStatus } from './types';

// آدرس پُل اختصاصی شما در کلودفلر
const WORKER_URL = "https://niya.am-b-asdfghjkl20112011.workers.dev";

interface StoreContextType {
  memories: Memory[];
  pledges: Pledge[];
  dreams: Dream[];
  playlist: Music[];
  capsules: Capsule[];
  trashItems: TrashItem[];
  letterContent: string;
  syncStatus: SyncStatus;
  syncError: string | null;
  addMemory: (m: Memory) => void;
  updateMemory: (m: Memory) => void;
  removeMemory: (id: string) => void;
  addPledge: (p: Pledge) => void;
  updatePledge: (p: Pledge) => void;
  removePledge: (id: string) => void;
  addDream: (d: Dream) => void;
  updateDream: (d: Dream) => void;
  removeDream: (id: string) => void;
  addMusic: (m: Music) => void;
  updateMusic: (m: Music) => void;
  removeMusic: (id: string) => void;
  addCapsule: (c: Capsule) => void;
  updateCapsule: (c: Capsule) => void;
  removeCapsule: (id: string) => void;
  setLetterContent: (text: string) => void;
  moveToTrash: (type: TrashItem['type'], item: any) => void;
  emptyTrash: () => void;
  restoreFromTrash: (trashId: string) => void;
  permanentlyDeleteFromTrash: (trashId: string) => void;
}

const StoreContext = createContext<StoreContextType | null>(null);

export const useStore = () => {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error('useStore must be used within StoreProvider');
  return ctx;
};

export const StoreProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const load = <T,>(key: string, def: T): T => {
    try {
      const stored = localStorage.getItem(key);
      return stored ? JSON.parse(stored) : def;
    } catch {
      return def;
    }
  };

  const [memories, setMemoriesState] = useState<Memory[]>(() => load('loveniya_mems', []));
  const [pledges, setPledgesState] = useState<Pledge[]>(() => load('loveniya_plg', []));
  const [dreams, setDreamsState] = useState<Dream[]>(() => load('loveniya_dreams', []));
  const [playlist, setPlaylistState] = useState<Music[]>(() => load('loveniya_msc', []));
  const [capsules, setCapsulesState] = useState<Capsule[]>(() => load('loveniya_capsules', []));
  const [trashItems, setTrashItemsState] = useState<TrashItem[]>(() => load('loveniya_trash', []));
  const [letterContent, setLetterContentState] = useState<string>(() => {
    return localStorage.getItem('loveniya_letter') || '';
  });

  const [syncStatus, setSyncStatus] = useState<SyncStatus>('disconnected');
  const [syncError, setSyncError] = useState<string | null>(null);

  // تابع ارسال مستقیم اطلاعات به فایربیس از طریق کلودفلر و ذخیره همزمان در حافظه گوشی
  const safeSet = useCallback(async (path: string, localKey: string, data: any) => {
    try {
      localStorage.setItem(localKey, typeof data === 'string' ? data : JSON.stringify(data));
    } catch (e) {}

    try {
      setSyncStatus('syncing');
      const res = await fetch(`${WORKER_URL}/${path}.json`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });

      if (!res.ok) throw new Error(`خطای HTTP: ${res.status}`);
      
      setSyncStatus('connected');
      setSyncError(null);
    } catch (err: any) {
      setSyncStatus('error');
      setSyncError(err.message || 'خطا در ذخیره‌سازی سرور.');
    }
  }, []);

  // دریافت تمام اطلاعات از دیتابیس بدون نیاز به وب‌سوکت
  const fetchAllData = useCallback(async () => {
    try {
      const [mRes, pRes, dRes, msRes, cRes, tRes, lRes] = await Promise.all([
        fetch(`${WORKER_URL}/loveniya_mems.json`),
        fetch(`${WORKER_URL}/loveniya_plg.json`),
        fetch(`${WORKER_URL}/loveniya_dreams.json`),
        fetch(`${WORKER_URL}/loveniya_msc.json`),
        fetch(`${WORKER_URL}/loveniya_capsules.json`),
        fetch(`${WORKER_URL}/loveniya_trash.json`),
        fetch(`${WORKER_URL}/loveniya_letter.json`),
      ]);

      if (mRes.ok) {
        const data = await mRes.json();
        if (data !== null) {
          const arr = Array.isArray(data) ? data : Object.values(data);
          setMemoriesState(arr as Memory[]);
          localStorage.setItem('loveniya_mems', JSON.stringify(arr));
        }
      }

      if (pRes.ok) {
        const data = await pRes.json();
        if (data !== null) {
          const arr = Array.isArray(data) ? data : Object.values(data);
          setPledgesState(arr as Pledge[]);
          localStorage.setItem('loveniya_plg', JSON.stringify(arr));
        }
      }

      if (dRes.ok) {
        const data = await dRes.json();
        if (data !== null) {
          const arr = Array.isArray(data) ? data : Object.values(data);
          setDreamsState(arr as Dream[]);
          localStorage.setItem('loveniya_dreams', JSON.stringify(arr));
        }
      }

      if (msRes.ok) {
        const data = await msRes.json();
        if (data !== null) {
          const arr = Array.isArray(data) ? data : Object.values(data);
          setPlaylistState(arr as Music[]);
          localStorage.setItem('loveniya_msc', JSON.stringify(arr));
        }
      }

      if (cRes.ok) {
        const data = await cRes.json();
        if (data !== null) {
          const arr = Array.isArray(data) ? data : Object.values(data);
          setCapsulesState(arr as Capsule[]);
          localStorage.setItem('loveniya_capsules', JSON.stringify(arr));
        }
      }

      if (tRes.ok) {
        const data = await tRes.json();
        if (data !== null) {
          const arr = Array.isArray(data) ? data : Object.values(data);
          setTrashItemsState(arr as TrashItem[]);
          localStorage.setItem('loveniya_trash', JSON.stringify(arr));
        }
      }

      if (lRes.ok) {
        const data = await lRes.json();
        if (data !== null && typeof data === 'string') {
          setLetterContentState(data);
          localStorage.setItem('loveniya_letter', data);
        }
      }

      setSyncStatus('connected');
      setSyncError(null);
    } catch (err: any) {
      setSyncStatus('disconnected');
    }
  }, []);

  useEffect(() => {
    fetchAllData();
    // همگام‌سازی دوره‌ای هر ۵ ثانیه برای دریافت تغییرات جدید
    const interval = setInterval(fetchAllData, 5000);
    return () => clearInterval(interval);
  }, [fetchAllData]);

  const setMemories = (v: Memory[]) => {
    setMemoriesState(v);
    safeSet('loveniya_mems', 'loveniya_mems', v);
  };

  const setPledges = (v: Pledge[]) => {
    setPledgesState(v);
    safeSet('loveniya_plg', 'loveniya_plg', v);
  };

  const setDreams = (v: Dream[]) => {
    setDreamsState(v);
    safeSet('loveniya_dreams', 'loveniya_dreams', v);
  };

  const setPlaylist = (v: Music[]) => {
    setPlaylistState(v);
    safeSet('loveniya_msc', 'loveniya_msc', v);
  };

  const setCapsules = (v: Capsule[]) => {
    setCapsulesState(v);
    safeSet('loveniya_capsules', 'loveniya_capsules', v);
  };

  const setTrashItems = (v: TrashItem[]) => {
    setTrashItemsState(v);
    safeSet('loveniya_trash', 'loveniya_trash', v);
  };

  const handleSetLetterContent = (text: string) => {
    setLetterContentState(text);
    safeSet('loveniya_letter', 'loveniya_letter', text);
  };

  const moveToTrash = (type: TrashItem['type'], item: any) => {
    const trashObj: TrashItem = {
      trashId: 'trash_' + Date.now(),
      type,
      deletedAt: new Date().toLocaleDateString('fa-IR'),
      itemPayload: item
    };
    setTrashItems([trashObj, ...trashItems]);
  };

  const restoreFromTrash = (trashId: string) => {
    const item = trashItems.find(t => t.trashId === trashId);
    if (!item) return;
    
    if (item.type === 'memory') setMemories([...memories, item.itemPayload]);
    if (item.type === 'pledge') setPledges([...pledges, item.itemPayload]);
    if (item.type === 'dream') setDreams([...dreams, item.itemPayload]);
    if (item.type === 'music') setPlaylist([...playlist, item.itemPayload]);
    if (item.type === 'capsule') setCapsules([...capsules, item.itemPayload]);
    
    setTrashItems(trashItems.filter(t => t.trashId !== trashId));
  };

  const permanentlyDeleteFromTrash = (trashId: string) => {
    setTrashItems(trashItems.filter(t => t.trashId !== trashId));
  };

  const emptyTrash = () => setTrashItems([]);

  const addMemory = (m: Memory) => setMemories([m, ...memories]);
  const updateMemory = (m: Memory) => setMemories(memories.map(x => x.id === m.id ? m : x));
  const removeMemory = (id: string) => {
    const item = memories.find(x => x.id === id);
    if (item) moveToTrash('memory', item);
    setMemories(memories.filter(x => x.id !== id));
  };

  const addPledge = (p: Pledge) => setPledges([p, ...pledges]);
  const updatePledge = (p: Pledge) => setPledges(pledges.map(x => x.id === p.id ? p : x));
  const removePledge = (id: string) => {
    const item = pledges.find(x => x.id === id);
    if (item) moveToTrash('pledge', item);
    setPledges(pledges.filter(x => x.id !== id));
  };

  const addDream = (d: Dream) => setDreams([d, ...dreams]);
  const updateDream = (d: Dream) => setDreams(dreams.map(x => x.id === d.id ? d : x));
  const removeDream = (id: string) => {
    const item = dreams.find(x => x.id === id);
    if (item) moveToTrash('dream', item);
    setDreams(dreams.filter(x => x.id !== id));
  };

  const addMusic = (m: Music) => setPlaylist([m, ...playlist]);
  const updateMusic = (m: Music) => setPlaylist(playlist.map(x => x.id === m.id ? m : x));
  const removeMusic = (id: string) => {
    const item = playlist.find(x => x.id === id);
    if (item) moveToTrash('music', item);
    setPlaylist(playlist.filter(x => x.id !== id));
  };

  const addCapsule = (c: Capsule) => setCapsules([c, ...capsules]);
  const updateCapsule = (c: Capsule) => setCapsules(capsules.map(x => x.id === c.id ? c : x));
  const removeCapsule = (id: string) => {
    const item = capsules.find(x => x.id === id);
    if (item) moveToTrash('capsule', item);
    setCapsules(capsules.filter(x => x.id !== id));
  };

  return (
    <StoreContext.Provider value={{
      memories, pledges, dreams, playlist, capsules, trashItems, letterContent,
      syncStatus, syncError,
      addMemory, updateMemory, removeMemory,
      addPledge, updatePledge, removePledge,
      addDream, updateDream, removeDream,
      addMusic, updateMusic, removeMusic,
      addCapsule, updateCapsule, removeCapsule,
      setLetterContent: handleSetLetterContent,
      moveToTrash, emptyTrash, restoreFromTrash, permanentlyDeleteFromTrash
    }}>
      {children}
    </StoreContext.Provider>
  );
};